SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


DROP TABLE IF EXISTS `glpi_agents`;
CREATE TABLE `glpi_agents` (
  `id` int(10) UNSIGNED NOT NULL,
  `deviceid` varchar(255) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `agenttypes_id` int(10) UNSIGNED NOT NULL,
  `last_contact` timestamp NULL DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL,
  `useragent` varchar(255) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `port` varchar(6) DEFAULT NULL,
  `remote_addr` varchar(255) DEFAULT NULL,
  `threads_networkdiscovery` int(11) NOT NULL DEFAULT 1 COMMENT 'Number of threads for Network discovery',
  `threads_networkinventory` int(11) NOT NULL DEFAULT 1 COMMENT 'Number of threads for Network inventory',
  `timeout_networkdiscovery` int(11) NOT NULL DEFAULT 0 COMMENT 'Network Discovery task timeout (disabled by default)',
  `timeout_networkinventory` int(11) NOT NULL DEFAULT 0 COMMENT 'Network Inventory task timeout (disabled by default)',
  `use_module_wake_on_lan` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_computer_inventory` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_esx_remote_inventory` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_remote_inventory` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_network_inventory` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_network_discovery` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_package_deployment` tinyint(4) NOT NULL DEFAULT 0,
  `use_module_collect_data` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_agenttypes`;
CREATE TABLE `glpi_agenttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_agenttypes` (`id`, `name`) VALUES
(1, 'Core');

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php ALERT_* constant',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) DEFAULT NULL,
  `app_token` varchar(255) DEFAULT NULL,
  `app_token_date` timestamp NULL DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_apiclients` (`id`, `entities_id`, `is_recursive`, `name`, `date_mod`, `date_creation`, `is_active`, `ipv4_range_start`, `ipv4_range_end`, `ipv6`, `app_token`, `app_token_date`, `dolog_method`, `comment`) VALUES
(1, 0, 1, 'full access from localhost', NULL, NULL, 1, 2130706433, 2130706433, '::1', NULL, NULL, 0, NULL),
(2, 0, 0, 'marc', '2023-06-08 00:00:47', '2023-06-08 00:00:47', 0, NULL, NULL, NULL, 'BuOlLHhZchVVk9RMOV01AsW8tby7YJjCU3yWz4Ii', '2023-06-08 00:00:47', 0, '');

DROP TABLE IF EXISTS `glpi_applianceenvironments`;
CREATE TABLE `glpi_applianceenvironments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_appliances`;
CREATE TABLE `glpi_appliances` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `appliancetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `applianceenvironments_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `externalidentifier` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `is_helpdesk_visible` tinyint(4) NOT NULL DEFAULT 1,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_appliances_items`;
CREATE TABLE `glpi_appliances_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `appliances_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_appliances_items_relations`;
CREATE TABLE `glpi_appliances_items_relations` (
  `id` int(10) UNSIGNED NOT NULL,
  `appliances_items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_appliancetypes`;
CREATE TABLE `glpi_appliancetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `externalidentifier` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(10) UNSIGNED NOT NULL,
  `authldaps_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `host` varchar(255) DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT 389,
  `name` varchar(255) DEFAULT NULL,
  `timeout` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `basedn` varchar(255) DEFAULT NULL,
  `rootdn` varchar(255) DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT 389,
  `condition` text DEFAULT NULL,
  `login_field` varchar(255) DEFAULT 'uid',
  `sync_field` varchar(255) DEFAULT NULL,
  `use_tls` tinyint(4) NOT NULL DEFAULT 0,
  `group_field` varchar(255) DEFAULT NULL,
  `group_condition` text DEFAULT NULL,
  `group_search_type` int(11) NOT NULL DEFAULT 0,
  `group_member_field` varchar(255) DEFAULT NULL,
  `email1_field` varchar(255) DEFAULT NULL,
  `realname_field` varchar(255) DEFAULT NULL,
  `firstname_field` varchar(255) DEFAULT NULL,
  `phone_field` varchar(255) DEFAULT NULL,
  `phone2_field` varchar(255) DEFAULT NULL,
  `mobile_field` varchar(255) DEFAULT NULL,
  `comment_field` varchar(255) DEFAULT NULL,
  `use_dn` tinyint(4) NOT NULL DEFAULT 1,
  `time_offset` int(11) NOT NULL DEFAULT 0 COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT 0,
  `title_field` varchar(255) DEFAULT NULL,
  `category_field` varchar(255) DEFAULT NULL,
  `language_field` varchar(255) DEFAULT NULL,
  `entity_field` varchar(255) DEFAULT NULL,
  `entity_condition` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `rootdn_passwd` varchar(255) DEFAULT NULL,
  `registration_number_field` varchar(255) DEFAULT NULL,
  `email2_field` varchar(255) DEFAULT NULL,
  `email3_field` varchar(255) DEFAULT NULL,
  `email4_field` varchar(255) DEFAULT NULL,
  `location_field` varchar(255) DEFAULT NULL,
  `responsible_field` varchar(255) DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT 0,
  `ldap_maxlimit` int(11) NOT NULL DEFAULT 0,
  `can_support_pagesize` tinyint(4) NOT NULL DEFAULT 0,
  `picture_field` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `inventory_domain` varchar(255) DEFAULT NULL,
  `tls_certfile` text DEFAULT NULL,
  `tls_keyfile` text DEFAULT NULL,
  `use_bind` tinyint(4) NOT NULL DEFAULT 1,
  `timeout` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `connect_string` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_blacklists` (`id`, `type`, `name`, `value`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 3, 'invalid serial', 'N/A', NULL, NULL, NULL),
(2, 3, 'invalid serial', '(null string)', NULL, NULL, NULL),
(3, 3, 'invalid serial', 'INVALID', NULL, NULL, NULL),
(4, 3, 'invalid serial', 'SYS-1234567890', NULL, NULL, NULL),
(5, 3, 'invalid serial', 'SYS-9876543210', NULL, NULL, NULL),
(6, 3, 'invalid serial', 'SN-12345', NULL, NULL, NULL),
(7, 3, 'invalid serial', 'SN-1234567890', NULL, NULL, NULL),
(8, 3, 'invalid serial', '/^0+$/', NULL, NULL, NULL),
(9, 3, 'invalid serial', '/^1+$/', NULL, NULL, NULL),
(10, 3, 'invalid serial', '/\\d\\.\\d(\\.\\d)?/', NULL, NULL, NULL),
(11, 3, 'invalid serial', '/^(0|1)+$/', NULL, NULL, NULL),
(12, 3, 'invalid serial', '0123456789', NULL, NULL, NULL),
(13, 3, 'invalid serial', '12345', NULL, NULL, NULL),
(14, 3, 'invalid serial', '123456', NULL, NULL, NULL),
(15, 3, 'invalid serial', '1234567', NULL, NULL, NULL),
(16, 3, 'invalid serial', '12345678', NULL, NULL, NULL),
(17, 3, 'invalid serial', '123456789', NULL, NULL, NULL),
(18, 3, 'invalid serial', '1234567890', NULL, NULL, NULL),
(19, 3, 'invalid serial', '123456789000', NULL, NULL, NULL),
(20, 3, 'invalid serial', '12345678901234567', NULL, NULL, NULL),
(21, 3, 'invalid serial', 'NNNNNNN', NULL, NULL, NULL),
(22, 3, 'invalid serial', 'xxxxxxxxxxx', NULL, NULL, NULL),
(23, 3, 'invalid serial', 'EVAL', NULL, NULL, NULL),
(24, 3, 'invalid serial', 'IATPASS', NULL, NULL, NULL),
(25, 3, 'invalid serial', 'none', NULL, NULL, NULL),
(26, 3, 'invalid serial', 'To Be Filled By O.E.M.', NULL, NULL, NULL),
(27, 3, 'invalid serial', 'Tulip Computers', NULL, NULL, NULL),
(28, 3, 'invalid serial', 'Serial Number xxxxxx', NULL, NULL, NULL),
(29, 3, 'invalid serial', 'SN-123456fvgv3i0b8o5n6n7k', NULL, NULL, NULL),
(30, 3, 'invalid serial', 'Unknow', NULL, NULL, NULL),
(31, 3, 'invalid serial', 'System Serial Number', NULL, NULL, NULL),
(32, 3, 'invalid serial', 'MB-1234567890', NULL, NULL, NULL),
(33, 3, 'invalid serial', 'empty', NULL, NULL, NULL),
(34, 3, 'invalid serial', 'Not Specified', NULL, NULL, NULL),
(35, 3, 'invalid serial', 'OEM_Serial', NULL, NULL, NULL),
(36, 3, 'invalid serial', 'SystemSerialNumb', NULL, NULL, NULL),
(37, 4, 'invalid UUID', 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF', NULL, NULL, NULL),
(38, 4, 'invalid UUID', '03000200-0400-0500-0006-000700080009', NULL, NULL, NULL),
(39, 4, 'invalid UUID', '6AB5B300-538D-1014-9FB5-B0684D007B53', NULL, NULL, NULL),
(40, 4, 'invalid UUID', '01010101-0101-0101-0101-010101010101', NULL, NULL, NULL),
(41, 4, 'invalid UUID', '2', NULL, NULL, NULL),
(42, 2, 'empty MAC', '', NULL, NULL, NULL),
(43, 2, 'invalid MAC', '20:41:53:59:4e:ff', NULL, NULL, NULL),
(44, 2, 'invalid MAC', '02:00:4e:43:50:49', NULL, NULL, NULL),
(45, 2, 'invalid MAC', 'e2:e6:16:20:0a:35', NULL, NULL, NULL),
(46, 2, 'invalid MAC', 'd2:0a:2d:a0:04:be', NULL, NULL, NULL),
(47, 2, 'invalid MAC', '00:a0:c6:00:00:00', NULL, NULL, NULL),
(48, 2, 'invalid MAC', 'd2:6b:25:2f:2c:e7', NULL, NULL, NULL),
(49, 2, 'invalid MAC', '33:50:6f:45:30:30', NULL, NULL, NULL),
(50, 2, 'invalid MAC', '0a:00:27:00:00:00', NULL, NULL, NULL),
(51, 2, 'invalid MAC', '00:50:56:C0:00:01', NULL, NULL, NULL),
(52, 2, 'invalid MAC', '00:50:56:C0:00:08', NULL, NULL, NULL),
(53, 2, 'invalid MAC', '02:80:37:EC:02:00', NULL, NULL, NULL),
(54, 2, 'invalid MAC', '50:50:54:50:30:30', NULL, NULL, NULL),
(55, 2, 'invalid MAC', '24:b6:20:52:41:53', NULL, NULL, NULL),
(56, 2, 'invalid MAC', '00:50:56:C0:00:02', NULL, NULL, NULL),
(57, 2, 'invalid MAC', '/00:50:56:C0:[0-9a-f]+:[0-9a-f]+/i', NULL, NULL, NULL),
(58, 2, 'invalid MAC', 'FE:FF:FF:FF:FF:FF', NULL, NULL, NULL),
(59, 2, 'invalid MAC', '00:00:00:00:00:00', NULL, NULL, NULL),
(60, 2, 'invalid MAC', '00:0b:ca:fe:00:00', NULL, NULL, NULL),
(61, 6, 'Unknow', 'Unknow', NULL, NULL, NULL),
(62, 6, 'To Be Filled By O.E.M.', 'To Be Filled By O.E.M.', NULL, NULL, NULL),
(63, 6, '*', '*', NULL, NULL, NULL),
(64, 6, 'System Product Name', 'System Product Name', NULL, NULL, NULL),
(65, 6, 'Product Name', 'Product Name', NULL, NULL, NULL),
(66, 6, 'System Name', 'System Name', NULL, NULL, NULL),
(67, 6, 'All Series', 'All Series', NULL, NULL, NULL),
(68, 8, 'System manufacturer', 'System manufacturer', NULL, NULL, NULL),
(69, 1, 'empty IP', '', NULL, NULL, NULL),
(70, 1, 'zero IP', '0.0.0.0', NULL, NULL, NULL),
(71, 1, 'localhost', '127.0.0.1', NULL, NULL, NULL),
(72, 1, 'IPV6 localhost', '::1', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `budgettypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_businesscriticities`;
CREATE TABLE `glpi_businesscriticities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `businesscriticities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cables`;
CREATE TABLE `glpi_cables` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `itemtype_endpoint_a` varchar(255) DEFAULT NULL,
  `itemtype_endpoint_b` varchar(255) DEFAULT NULL,
  `items_id_endpoint_a` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id_endpoint_b` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `socketmodels_id_endpoint_a` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `socketmodels_id_endpoint_b` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sockets_id_endpoint_a` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sockets_id_endpoint_b` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cablestrands_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `color` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cabletypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cablestrands`;
CREATE TABLE `glpi_cablestrands` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cabletypes`;
CREATE TABLE `glpi_cabletypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `cache_duration` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_calendars` (`id`, `name`, `entities_id`, `is_recursive`, `comment`, `date_mod`, `cache_duration`, `date_creation`) VALUES
(1, 'Default', 0, 1, 'Default calendar', NULL, '[0,43200,43200,43200,43200,43200,0]', NULL);

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(10) UNSIGNED NOT NULL,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `day` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_calendarsegments` (`id`, `calendars_id`, `entities_id`, `is_recursive`, `day`, `begin`, `end`) VALUES
(1, 1, 0, 0, 1, '08:00:00', '20:00:00'),
(2, 1, 0, 0, 2, '08:00:00', '20:00:00'),
(3, 1, 0, 0, 3, '08:00:00', '20:00:00'),
(4, 1, 0, 0, 4, '08:00:00', '20:00:00'),
(5, 1, 0, 0, 5, '08:00:00', '20:00:00');

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(10) UNSIGNED NOT NULL,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `holidays_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cartridgeitemtypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `alarm_threshold` int(11) NOT NULL DEFAULT 10,
  `stock_target` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `cartridgeitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `printermodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cartridgeitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `printers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_certificates`;
CREATE TABLE `glpi_certificates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `certificatetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to glpi_certificatetypes (id)',
  `dns_name` varchar(255) DEFAULT NULL,
  `dns_suffix` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to glpi_users (id)',
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to glpi_groups (id)',
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to glpi_locations (id)',
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to glpi_manufacturers (id)',
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_autosign` tinyint(4) NOT NULL DEFAULT 0,
  `date_expiration` date DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to states (id)',
  `command` text DEFAULT NULL,
  `certificate_request` text DEFAULT NULL,
  `certificate_item` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_certificates_items`;
CREATE TABLE `glpi_certificates_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `certificates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to various tables, according to itemtype (id)',
  `itemtype` varchar(100) NOT NULL COMMENT 'see .class.php file',
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_certificatetypes`;
CREATE TABLE `glpi_certificatetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `cost_time` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_material` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1,
  `content` longtext DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `solvedate` timestamp NULL DEFAULT NULL,
  `closedate` timestamp NULL DEFAULT NULL,
  `time_to_resolve` timestamp NULL DEFAULT NULL,
  `users_id_recipient` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_lastupdater` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `urgency` int(11) NOT NULL DEFAULT 1,
  `impact` int(11) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 1,
  `itilcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `impactcontent` longtext DEFAULT NULL,
  `controlistcontent` longtext DEFAULT NULL,
  `rolloutplancontent` longtext DEFAULT NULL,
  `backoutplancontent` longtext DEFAULT NULL,
  `checklistcontent` longtext DEFAULT NULL,
  `global_validation` int(11) NOT NULL DEFAULT 1,
  `validation_percent` int(11) NOT NULL DEFAULT 0,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `begin_waiting_date` timestamp NULL DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT 0,
  `close_delay_stat` int(11) NOT NULL DEFAULT 0,
  `solve_delay_stat` int(11) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 0,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 0,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `taskcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `state` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_editor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `tasktemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0,
  `is_private` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changetemplatehiddenfields`;
CREATE TABLE `glpi_changetemplatehiddenfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changetemplatemandatoryfields`;
CREATE TABLE `glpi_changetemplatemandatoryfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_changetemplatemandatoryfields` (`id`, `changetemplates_id`, `num`) VALUES
(1, 1, 21);

DROP TABLE IF EXISTS `glpi_changetemplatepredefinedfields`;
CREATE TABLE `glpi_changetemplatepredefinedfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_changetemplates`;
CREATE TABLE `glpi_changetemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_changetemplates` (`id`, `name`, `entities_id`, `is_recursive`, `comment`) VALUES
(1, 'Default', 0, 1, NULL);

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `changes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_validate` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment_submission` text DEFAULT NULL,
  `comment_validation` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 2,
  `submission_date` timestamp NULL DEFAULT NULL,
  `validation_date` timestamp NULL DEFAULT NULL,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_clusters`;
CREATE TABLE `glpi_clusters` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to states (id)',
  `comment` text DEFAULT NULL,
  `clustertypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_clustertypes`;
CREATE TABLE `glpi_clustertypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(10) UNSIGNED NOT NULL,
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `antivirus_version` varchar(255) DEFAULT NULL,
  `signature_version` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_uptodate` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_expiration` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `computermodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `computertypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `last_inventory_update` timestamp NULL DEFAULT NULL,
  `last_boot` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `virtualmachinesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `virtualmachinetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uuid` varchar(255) NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT 0,
  `ram` varchar(255) NOT NULL DEFAULT '',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(10) UNSIGNED NOT NULL,
  `context` varchar(150) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_configs` (`id`, `context`, `name`, `value`) VALUES
(1, 'core', 'version', '10.0.7'),
(2, 'core', 'show_jobs_at_login', '0'),
(3, 'core', 'cut', '250'),
(4, 'core', 'list_limit', '15'),
(5, 'core', 'list_limit_max', '50'),
(6, 'core', 'url_maxlength', '30'),
(7, 'core', 'event_loglevel', '5'),
(8, 'core', 'notifications_mailing', '0'),
(9, 'core', 'admin_email', 'admsys@localhost'),
(10, 'core', 'admin_email_name', ''),
(11, 'core', 'from_email', NULL),
(12, 'core', 'from_email_name', NULL),
(13, 'core', 'noreply_email', ''),
(14, 'core', 'noreply_email_name', ''),
(15, 'core', 'replyto_email', ''),
(16, 'core', 'replyto_email_name', ''),
(17, 'core', 'mailing_signature', 'SIGNATURE'),
(18, 'core', 'use_anonymous_helpdesk', '0'),
(19, 'core', 'use_anonymous_followups', '0'),
(20, 'core', 'language', 'fr_FR'),
(21, 'core', 'priority_1', '#fff2f2'),
(22, 'core', 'priority_2', '#ffe0e0'),
(23, 'core', 'priority_3', '#ffcece'),
(24, 'core', 'priority_4', '#ffbfbf'),
(25, 'core', 'priority_5', '#ffadad'),
(26, 'core', 'priority_6', '#ff5555'),
(27, 'core', 'date_tax', '2005-12-31'),
(28, 'core', 'cas_host', ''),
(29, 'core', 'cas_port', '443'),
(30, 'core', 'cas_uri', ''),
(31, 'core', 'cas_logout', ''),
(32, 'core', 'cas_version', 'CAS_VERSION_2_0'),
(33, 'core', 'existing_auth_server_field_clean_domain', '0'),
(34, 'core', 'planning_begin', '08:00:00'),
(35, 'core', 'planning_end', '20:00:00'),
(36, 'core', 'utf8_conv', '1'),
(37, 'core', 'use_public_faq', '0'),
(38, 'core', 'url_base', 'http://glpi.local'),
(39, 'core', 'show_link_in_mail', '0'),
(40, 'core', 'text_login', ''),
(41, 'core', 'founded_new_version', ''),
(42, 'core', 'dropdown_max', '100'),
(43, 'core', 'ajax_wildcard', '*'),
(44, 'core', 'ajax_limit_count', '10'),
(45, 'core', 'is_users_auto_add', '1'),
(46, 'core', 'date_format', '2'),
(47, 'core', 'number_format', '0'),
(48, 'core', 'csv_delimiter', ';'),
(49, 'core', 'is_ids_visible', '0'),
(50, 'core', 'smtp_mode', '0'),
(51, 'core', 'smtp_host', ''),
(52, 'core', 'smtp_port', '25'),
(53, 'core', 'smtp_username', ''),
(54, 'core', 'smtp_oauth_provider', ''),
(55, 'core', 'smtp_oauth_client_id', ''),
(56, 'core', 'smtp_oauth_client_secret', ''),
(57, 'core', 'smtp_oauth_options', '{}'),
(58, 'core', 'smtp_oauth_refresh_token', ''),
(59, 'core', 'proxy_name', ''),
(60, 'core', 'proxy_port', '8080'),
(61, 'core', 'proxy_user', ''),
(62, 'core', 'add_followup_on_update_ticket', '1'),
(63, 'core', 'keep_tickets_on_delete', '0'),
(64, 'core', 'time_step', '5'),
(65, 'core', 'decimal_number', '2'),
(66, 'core', 'helpdesk_doc_url', ''),
(67, 'core', 'central_doc_url', ''),
(68, 'core', 'documentcategories_id_forticket', '0'),
(69, 'core', 'monitors_management_restrict', '2'),
(70, 'core', 'phones_management_restrict', '2'),
(71, 'core', 'peripherals_management_restrict', '2'),
(72, 'core', 'printers_management_restrict', '2'),
(73, 'core', 'use_log_in_files', '1'),
(74, 'core', 'time_offset', '0'),
(75, 'core', 'is_contact_autoupdate', '1'),
(76, 'core', 'is_user_autoupdate', '1'),
(77, 'core', 'is_group_autoupdate', '1'),
(78, 'core', 'is_location_autoupdate', '1'),
(79, 'core', 'state_autoupdate_mode', '0'),
(80, 'core', 'is_contact_autoclean', '0'),
(81, 'core', 'is_user_autoclean', '0'),
(82, 'core', 'is_group_autoclean', '0'),
(83, 'core', 'is_location_autoclean', '0'),
(84, 'core', 'state_autoclean_mode', '0'),
(85, 'core', 'use_flat_dropdowntree', '0'),
(86, 'core', 'use_autoname_by_entity', '1'),
(87, 'core', 'softwarecategories_id_ondelete', '1'),
(88, 'core', 'x509_email_field', ''),
(89, 'core', 'x509_cn_restrict', ''),
(90, 'core', 'x509_o_restrict', ''),
(91, 'core', 'x509_ou_restrict', ''),
(92, 'core', 'default_mailcollector_filesize_max', '2097152'),
(93, 'core', 'followup_private', '0'),
(94, 'core', 'task_private', '0'),
(95, 'core', 'default_software_helpdesk_visible', '1'),
(96, 'core', 'names_format', '0'),
(97, 'core', 'default_requesttypes_id', '1'),
(98, 'core', 'use_noright_users_add', '1'),
(99, 'core', 'cron_limit', '5'),
(100, 'core', 'priority_matrix', '{\"1\":{\"1\":1,\"2\":1,\"3\":2,\"4\":2,\"5\":2},\"2\":{\"1\":1,\"2\":2,\"3\":2,\"4\":3,\"5\":3},\"3\":{\"1\":2,\"2\":2,\"3\":3,\"4\":4,\"5\":4},\"4\":{\"1\":2,\"2\":3,\"3\":4,\"4\":4,\"5\":5},\"5\":{\"1\":2,\"2\":3,\"3\":4,\"4\":5,\"5\":5}}'),
(101, 'core', 'urgency_mask', '62'),
(102, 'core', 'impact_mask', '62'),
(103, 'core', 'user_deleted_ldap', '0'),
(104, 'core', 'user_restored_ldap', '0'),
(105, 'core', 'auto_create_infocoms', '0'),
(106, 'core', 'use_slave_for_search', '0'),
(107, 'core', 'proxy_passwd', ''),
(108, 'core', 'smtp_passwd', ''),
(109, 'core', 'show_count_on_tabs', '1'),
(110, 'core', 'refresh_views', '0'),
(111, 'core', 'set_default_tech', '1'),
(112, 'core', 'allow_search_view', '2'),
(113, 'core', 'allow_search_all', '0'),
(114, 'core', 'allow_search_global', '1'),
(115, 'core', 'display_count_on_home', '5'),
(116, 'core', 'use_password_security', '0'),
(117, 'core', 'password_min_length', '8'),
(118, 'core', 'password_need_number', '1'),
(119, 'core', 'password_need_letter', '1'),
(120, 'core', 'password_need_caps', '1'),
(121, 'core', 'password_need_symbol', '1'),
(122, 'core', 'use_check_pref', '0'),
(123, 'core', 'notification_to_myself', '1'),
(124, 'core', 'duedateok_color', '#06ff00'),
(125, 'core', 'duedatewarning_color', '#ffb800'),
(126, 'core', 'duedatecritical_color', '#ff0000'),
(127, 'core', 'duedatewarning_less', '20'),
(128, 'core', 'duedatecritical_less', '5'),
(129, 'core', 'duedatewarning_unit', '%'),
(130, 'core', 'duedatecritical_unit', '%'),
(131, 'core', 'realname_ssofield', ''),
(132, 'core', 'firstname_ssofield', ''),
(133, 'core', 'email1_ssofield', ''),
(134, 'core', 'email2_ssofield', ''),
(135, 'core', 'email3_ssofield', ''),
(136, 'core', 'email4_ssofield', ''),
(137, 'core', 'phone_ssofield', ''),
(138, 'core', 'phone2_ssofield', ''),
(139, 'core', 'mobile_ssofield', ''),
(140, 'core', 'comment_ssofield', ''),
(141, 'core', 'title_ssofield', ''),
(142, 'core', 'category_ssofield', ''),
(143, 'core', 'language_ssofield', ''),
(144, 'core', 'entity_ssofield', ''),
(145, 'core', 'registration_number_ssofield', ''),
(146, 'core', 'ssovariables_id', '0'),
(147, 'core', 'ssologout_url', ''),
(148, 'core', 'translate_kb', '0'),
(149, 'core', 'translate_dropdowns', '0'),
(150, 'core', 'translate_reminders', '0'),
(151, 'core', 'pdffont', 'helvetica'),
(152, 'core', 'keep_devices_when_purging_item', '0'),
(153, 'core', 'maintenance_mode', '0'),
(154, 'core', 'maintenance_text', ''),
(155, 'core', 'attach_ticket_documents_to_mail', '0'),
(156, 'core', 'backcreated', '0'),
(157, 'core', 'task_state', '1'),
(158, 'core', 'palette', 'auror_dark'),
(159, 'core', 'page_layout', 'horizontal'),
(160, 'core', 'fold_menu', '0'),
(161, 'core', 'fold_search', '0'),
(162, 'core', 'savedsearches_pinned', '0'),
(163, 'core', 'timeline_order', 'natural'),
(164, 'core', 'itil_layout', ''),
(165, 'core', 'richtext_layout', 'classic'),
(166, 'core', 'lock_use_lock_item', '0'),
(167, 'core', 'lock_autolock_mode', '1'),
(168, 'core', 'lock_directunlock_notification', '0'),
(169, 'core', 'lock_item_list', '[]'),
(170, 'core', 'lock_lockprofile_id', '8'),
(171, 'core', 'set_default_requester', '1'),
(172, 'core', 'highcontrast_css', '0'),
(173, 'core', 'default_central_tab', '0'),
(174, 'core', 'smtp_check_certificate', '1'),
(175, 'core', 'enable_api', '1'),
(176, 'core', 'enable_api_login_credentials', '0'),
(177, 'core', 'enable_api_login_external_token', '1'),
(178, 'core', 'url_base_api', 'http://glpi.local/api'),
(179, 'core', 'login_remember_time', '604800'),
(180, 'core', 'login_remember_default', '1'),
(181, 'core', 'use_notifications', '0'),
(182, 'core', 'notifications_ajax', '0'),
(183, 'core', 'notifications_ajax_check_interval', '5'),
(184, 'core', 'notifications_ajax_sound', NULL),
(185, 'core', 'notifications_ajax_icon_url', '/pics/glpi.png'),
(186, 'core', 'dbversion', '10.0.7@5d45269702917a32805e25b678f6779a98b145f6'),
(187, 'core', 'smtp_max_retries', '5'),
(188, 'core', 'smtp_sender', NULL),
(189, 'core', 'instance_uuid', NULL),
(190, 'core', 'registration_uuid', NULL),
(191, 'core', 'smtp_retry_time', '5'),
(192, 'core', 'purge_addrelation', '0'),
(193, 'core', 'purge_deleterelation', '0'),
(194, 'core', 'purge_createitem', '0'),
(195, 'core', 'purge_deleteitem', '0'),
(196, 'core', 'purge_restoreitem', '0'),
(197, 'core', 'purge_updateitem', '0'),
(198, 'core', 'purge_item_software_install', '0'),
(199, 'core', 'purge_software_item_install', '0'),
(200, 'core', 'purge_software_version_install', '0'),
(201, 'core', 'purge_infocom_creation', '0'),
(202, 'core', 'purge_profile_user', '0'),
(203, 'core', 'purge_group_user', '0'),
(204, 'core', 'purge_adddevice', '0'),
(205, 'core', 'purge_updatedevice', '0'),
(206, 'core', 'purge_deletedevice', '0'),
(207, 'core', 'purge_connectdevice', '0'),
(208, 'core', 'purge_disconnectdevice', '0'),
(209, 'core', 'purge_userdeletedfromldap', '0'),
(210, 'core', 'purge_comments', '0'),
(211, 'core', 'purge_datemod', '0'),
(212, 'core', 'purge_all', '0'),
(213, 'core', 'purge_user_auth_changes', '0'),
(214, 'core', 'purge_plugins', '0'),
(215, 'core', 'purge_refusedequipment', '0'),
(216, 'core', 'display_login_source', '1'),
(217, 'core', 'devices_in_menu', '[\"Item_DeviceSimcard\"]'),
(218, 'core', 'password_expiration_delay', '-1'),
(219, 'core', 'password_expiration_notice', '-1'),
(220, 'core', 'password_expiration_lock_delay', '-1'),
(221, 'core', 'default_dashboard_central', 'central'),
(222, 'core', 'default_dashboard_assets', 'assets'),
(223, 'core', 'default_dashboard_helpdesk', 'assistance'),
(224, 'core', 'default_dashboard_mini_ticket', 'mini_tickets'),
(225, 'core', 'impact_enabled_itemtypes', '[\"Appliance\",\"Cluster\",\"Computer\",\"Datacenter\",\"DCRoom\",\"Domain\",\"Enclosure\",\"Monitor\",\"NetworkEquipment\",\"PDU\",\"Peripheral\",\"Phone\",\"Printer\",\"Rack\",\"Software\",\"DatabaseInstance\"]'),
(226, 'core', 'document_max_size', '2'),
(227, 'core', 'planning_work_days', '[0,1,2,3,4,5,6]'),
(228, 'core', 'system_user', '6'),
(229, 'core', 'support_legacy_data', '0'),
(230, 'core', 'initialized_rules_collections', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCollection\",\"RuleDictionnaryOperatingSystemCollection\",\"RuleDictionnaryOperatingSystemVersionCollection\",\"RuleDictionnaryOperatingSystemEditionCollection\"]'),
(231, 'core', 'timeline_action_btn_layout', '0'),
(232, 'core', 'timeline_date_format', '0'),
(233, 'inventory', 'enabled_inventory', '1'),
(234, 'inventory', 'import_software', '1'),
(235, 'inventory', 'import_volume', '1'),
(236, 'inventory', 'import_antivirus', '1'),
(237, 'inventory', 'import_registry', '1'),
(238, 'inventory', 'import_process', '1'),
(239, 'inventory', 'import_vm', '1'),
(240, 'inventory', 'import_monitor_on_partial_sn', '0'),
(241, 'inventory', 'import_unmanaged', '1'),
(242, 'inventory', 'component_processor', '1'),
(243, 'inventory', 'component_memory', '1'),
(244, 'inventory', 'component_harddrive', '1'),
(245, 'inventory', 'component_networkcard', '1'),
(246, 'inventory', 'component_graphiccard', '1'),
(247, 'inventory', 'component_soundcard', '1'),
(248, 'inventory', 'component_drive', '1'),
(249, 'inventory', 'component_networkdrive', '1'),
(250, 'inventory', 'component_networkcardvirtual', '1'),
(251, 'inventory', 'component_control', '1'),
(252, 'inventory', 'component_battery', '1'),
(253, 'inventory', 'component_simcard', '1'),
(254, 'inventory', 'states_id_default', '0'),
(255, 'inventory', 'entities_id_default', '0'),
(256, 'inventory', 'location', '0'),
(257, 'inventory', 'group', '0'),
(258, 'inventory', 'vm_type', '0'),
(259, 'inventory', 'vm_components', '0'),
(260, 'inventory', 'vm_as_computer', '0'),
(261, 'inventory', 'component_removablemedia', '1'),
(262, 'inventory', 'component_powersupply', '1'),
(263, 'inventory', 'inventory_frequency', '24'),
(264, 'inventory', 'import_monitor', '1'),
(265, 'inventory', 'import_printer', '1'),
(266, 'inventory', 'import_peripheral', '1'),
(267, 'inventory', 'stale_agents_delay', '0'),
(268, 'inventory', 'stale_agents_action', '[\"0\"]'),
(269, 'inventory', 'stale_agents_status', '0'),
(270, 'core', 'marketplace_replace_plugins', '2'),
(271, 'core', 'glpinetwork_registration_key', 'loedD2CLWu/xl7jqwnjEyXzJ8hNSw2MaPisc3ugaIK0Fw6NULm7DWnxyOoS206/dIvq3A+S7QSjU7hXEb7vOx+s73l2iT4GWyQuahGOBtHWoJIkkrIq+bQhsTuMAwEIktQEAjk+7R6TUcPJ1AficUuZE/oRX0DPn3I8pNDL0gGjPLrg3q8gP86ao4hK8peM0cYpdf7FBQZelXWum6dxyi6lb8PWL02tifP/t1ts3qm4jD4egOPTDc3v++G/Rnfye4N5QfCmbFEuEZLGZQaZIIoOuPCbtqmjs+odqXB0SxsOY3qLyFmibKA2Co0qlTwfUWR46LgHGdAkgEWN+6MZnoDAAW03xaDihHw1HTnCFzNjpU18LG9pZ/hjkTWNYsJ6czmcmiGhA+wzs03+dyJmubU4+781hDFuRhw/TbYDcBFgCl9E5KRzEheYCxOwrukfVHr8NVrHuP3v8bpcsrIM7a9uRYy6UHSzjlPqhjgtdMZ5N5HzgwUyK5adgiLvHZl5g6ZpAWLc774GU0N6fsk7P8LEyElhi2oEX6DPCeTwzZx8snQdhoy1OHR7fAziZrSfOxDUi8XW0+yx7r3FXlpuIDdahE1NN9cWjic7OOMSWM2uZe49F7XrYbhsDq++3Qa4o7B/SfO/rKl8Ny3rsIYfEQZsttE4czW33sberGP7peBMZ460xStvq3JkLikcECz1b1xPn0BcgPkHWTI8KTj8kV6Yv5Pabx4tUTaTilFUungwyYvfDh3hue9c/jmKqw/Ecd9eGLY7++zs='),
(272, 'core', 'glpi_network_uuid', 'qqRSETzvGy0baBkI1nFsrMrd70ilI5yhLqq4vwYA'),
(274, 'core', 'timezone', '0');

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `consumableitemtypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `alarm_threshold` int(11) NOT NULL DEFAULT 10,
  `stock_target` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `consumableitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `phone2` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contacttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `usertitles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `address` text DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `contacts_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(10) UNSIGNED NOT NULL,
  `contracts_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `num` varchar(255) DEFAULT NULL,
  `contracttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT 0,
  `notice` int(11) NOT NULL DEFAULT 0,
  `periodicity` int(11) NOT NULL DEFAULT 0,
  `billing` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `accounting_number` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(4) NOT NULL DEFAULT 0,
  `sunday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `sunday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_sunday` tinyint(4) NOT NULL DEFAULT 0,
  `max_links_allowed` int(11) NOT NULL DEFAULT 0,
  `alert` int(11) NOT NULL DEFAULT 0,
  `renewal` int(11) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `contracts_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `contracts_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `crontasks_id` int(10) UNSIGNED NOT NULL,
  `crontasklogs_id` int(10) UNSIGNED NOT NULL COMMENT 'id of ''start'' event',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) DEFAULT NULL COMMENT 'message'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_crontasklogs` (`id`, `crontasks_id`, `crontasklogs_id`, `date`, `state`, `elapsed`, `volume`, `content`) VALUES
(1, 5, 0, '2023-06-07 20:37:53', 0, 0, 0, 'Run mode: GLPI'),
(2, 5, 1, '2023-06-07 20:37:53', 2, 0.00258899, 0, 'Action completed, no processing required'),
(3, 6, 0, '2023-06-07 20:46:07', 0, 0, 0, 'Run mode: GLPI'),
(4, 6, 3, '2023-06-07 20:46:07', 2, 0.010457, 0, 'Action completed, no processing required'),
(5, 9, 0, '2023-06-07 20:46:46', 0, 0, 0, 'Run mode: GLPI'),
(6, 9, 5, '2023-06-07 20:46:46', 2, 0.00556803, 0, 'Action completed, no processing required'),
(7, 12, 0, '2023-06-07 20:47:46', 0, 0, 0, 'Run mode: GLPI'),
(8, 12, 7, '2023-06-07 20:47:46', 2, 0.0240951, 0, 'Action completed, no processing required'),
(9, 13, 0, '2023-06-07 20:50:32', 0, 0, 0, 'Run mode: GLPI'),
(10, 13, 9, '2023-06-07 20:50:32', 2, 0.00229192, 0, 'Action completed, no processing required'),
(11, 14, 0, '2023-06-07 20:56:32', 0, 0, 0, 'Run mode: GLPI'),
(12, 14, 11, '2023-06-07 20:56:32', 2, 0.00528502, 0, 'Action completed, no processing required'),
(13, 15, 0, '2023-06-07 21:02:45', 0, 0, 0, 'Run mode: GLPI'),
(14, 15, 13, '2023-06-07 21:02:45', 2, 0.00315714, 0, 'Action completed, no processing required'),
(15, 16, 0, '2023-06-07 21:08:24', 0, 0, 0, 'Run mode: GLPI'),
(16, 16, 15, '2023-06-07 21:08:24', 2, 0.00194812, 0, 'Action completed, no processing required'),
(17, 17, 0, '2023-06-07 21:15:00', 0, 0, 0, 'Run mode: GLPI'),
(18, 17, 17, '2023-06-07 21:15:00', 2, 0.00480008, 0, 'Action completed, no processing required'),
(19, 18, 0, '2023-06-07 21:20:01', 0, 0, 0, 'Run mode: GLPI'),
(20, 18, 19, '2023-06-07 21:20:01', 2, 0.00416684, 0, 'Action completed, no processing required'),
(21, 19, 0, '2023-06-07 21:25:46', 0, 0, 0, 'Run mode: GLPI'),
(22, 19, 21, '2023-06-07 21:25:46', 2, 0.00418305, 0, 'Action completed, fully processed'),
(23, 20, 0, '2023-06-07 21:30:54', 0, 0, 0, 'Run mode: GLPI'),
(24, 20, 23, '2023-06-07 21:30:54', 2, 0.00251794, 0, 'Action completed, no processing required'),
(25, 44, 0, '2023-06-07 21:31:55', 0, 0, 0, 'Run mode: GLPI'),
(26, 44, 25, '2023-06-07 21:31:55', 2, 0.00473094, 0, 'Action completed, fully processed'),
(27, 21, 0, '2023-06-07 21:32:13', 0, 0, 0, 'Run mode: GLPI'),
(28, 21, 27, '2023-06-07 21:32:13', 2, 0.00180507, 0, 'Action completed, no processing required'),
(29, 22, 0, '2023-06-07 21:36:29', 0, 0, 0, 'Run mode: GLPI'),
(30, 22, 29, '2023-06-07 21:36:29', 2, 0.00358105, 0, 'Action completed, no processing required'),
(31, 23, 0, '2023-06-07 21:41:56', 0, 0, 0, 'Run mode: GLPI'),
(32, 23, 31, '2023-06-07 21:41:56', 2, 0.00264382, 0, 'Action completed, no processing required'),
(33, 24, 0, '2023-06-07 21:47:49', 0, 0, 0, 'Run mode: GLPI'),
(34, 24, 33, '2023-06-07 21:47:49', 2, 0.0149159, 0, 'Action completed, no processing required'),
(35, 25, 0, '2023-06-07 23:16:59', 0, 0, 0, 'Run mode: GLPI'),
(36, 25, 35, '2023-06-07 23:16:59', 2, 0.0150781, 0, 'Action completed, no processing required'),
(37, 31, 0, '2023-06-07 23:17:01', 0, 0, 0, 'Run mode: GLPI'),
(38, 31, 37, '2023-06-07 23:17:01', 2, 0.00291014, 0, 'Action completed, no processing required'),
(39, 32, 0, '2023-06-07 23:17:05', 0, 0, 0, 'Run mode: GLPI'),
(40, 32, 39, '2023-06-07 23:17:05', 2, 0.00410199, 0, 'Action completed, no processing required'),
(41, 9, 0, '2023-06-07 23:18:26', 0, 0, 0, 'Run mode: GLPI'),
(42, 9, 41, '2023-06-07 23:18:26', 2, 0.00418305, 0, 'Action completed, no processing required'),
(43, 17, 0, '2023-06-07 23:18:36', 0, 0, 0, 'Run mode: GLPI'),
(44, 17, 43, '2023-06-07 23:18:36', 2, 0.00235891, 0, 'Action completed, no processing required'),
(45, 21, 0, '2023-06-07 23:21:41', 0, 0, 0, 'Run mode: GLPI'),
(46, 21, 45, '2023-06-07 23:21:41', 2, 0.0135169, 0, 'Action completed, no processing required'),
(47, 22, 0, '2023-06-07 23:23:08', 0, 0, 0, 'Run mode: GLPI'),
(48, 22, 47, '2023-06-07 23:23:08', 2, 0.021904, 0, 'Action completed, no processing required'),
(49, 13, 0, '2023-06-07 23:23:20', 0, 0, 0, 'Run mode: GLPI'),
(50, 13, 49, '2023-06-07 23:23:20', 2, 0.0129111, 0, 'Action completed, no processing required'),
(51, 14, 0, '2023-06-07 23:24:21', 0, 0, 0, 'Run mode: GLPI'),
(52, 14, 51, '2023-06-07 23:24:21', 2, 0.0126078, 0, 'Action completed, no processing required'),
(53, 20, 0, '2023-06-07 23:24:27', 0, 0, 0, 'Run mode: GLPI'),
(54, 20, 53, '2023-06-07 23:24:27', 2, 0.0032649, 0, 'Action completed, no processing required'),
(55, 24, 0, '2023-06-07 23:25:15', 0, 0, 0, 'Run mode: GLPI'),
(56, 24, 55, '2023-06-07 23:25:15', 2, 0.0149791, 0, 'Action completed, no processing required'),
(57, 32, 0, '2023-06-07 23:25:15', 0, 0, 0, 'Run mode: GLPI'),
(58, 32, 57, '2023-06-07 23:25:15', 2, 0.0031569, 0, 'Action completed, no processing required'),
(59, 17, 0, '2023-06-07 23:25:26', 0, 0, 0, 'Run mode: GLPI'),
(60, 17, 59, '2023-06-07 23:25:26', 2, 0.00314307, 0, 'Action completed, no processing required'),
(61, 22, 0, '2023-06-07 23:29:39', 0, 0, 0, 'Run mode: GLPI'),
(62, 22, 61, '2023-06-07 23:29:39', 2, 0.00357199, 0, 'Action completed, no processing required'),
(63, 21, 0, '2023-06-07 23:29:40', 0, 0, 0, 'Run mode: GLPI'),
(64, 21, 63, '2023-06-07 23:29:40', 2, 0.001827, 0, 'Action completed, no processing required'),
(65, 9, 0, '2023-06-07 23:32:17', 0, 0, 0, 'Run mode: GLPI'),
(66, 9, 65, '2023-06-07 23:32:17', 2, 0.011899, 0, 'Action completed, no processing required'),
(67, 17, 0, '2023-06-07 23:37:30', 0, 0, 0, 'Run mode: GLPI'),
(68, 17, 67, '2023-06-07 23:37:30', 2, 0.014277, 0, 'Action completed, no processing required'),
(69, 22, 0, '2023-06-07 23:41:46', 0, 0, 0, 'Run mode: GLPI'),
(70, 22, 69, '2023-06-07 23:41:46', 2, 0.0171492, 0, 'Action completed, no processing required'),
(71, 32, 0, '2023-06-07 23:41:47', 0, 0, 0, 'Run mode: GLPI'),
(72, 32, 71, '2023-06-07 23:41:47', 2, 0.00214505, 0, 'Action completed, no processing required'),
(73, 21, 0, '2023-06-07 23:46:41', 0, 0, 0, 'Run mode: GLPI'),
(74, 21, 73, '2023-06-07 23:46:41', 2, 0.00294805, 0, 'Action completed, no processing required'),
(75, 9, 0, '2023-06-07 23:47:04', 0, 0, 0, 'Run mode: GLPI'),
(76, 9, 75, '2023-06-07 23:47:04', 2, 0.00273085, 0, 'Action completed, no processing required'),
(77, 17, 0, '2023-06-07 23:53:18', 0, 0, 0, 'Run mode: GLPI'),
(78, 17, 77, '2023-06-07 23:53:18', 2, 0.00236487, 0, 'Action completed, no processing required'),
(79, 22, 0, '2023-06-07 23:53:34', 0, 0, 0, 'Run mode: GLPI'),
(80, 22, 79, '2023-06-07 23:53:34', 2, 0.00297904, 0, 'Action completed, no processing required'),
(81, 32, 0, '2023-06-07 23:59:45', 0, 0, 0, 'Run mode: GLPI'),
(82, 32, 81, '2023-06-07 23:59:45', 2, 0.00942397, 0, 'Action completed, no processing required'),
(83, 21, 0, '2023-06-08 00:05:51', 0, 0, 0, 'Run mode: GLPI'),
(84, 21, 83, '2023-06-08 00:05:51', 2, 0.00220799, 0, 'Action completed, no processing required'),
(85, 22, 0, '2023-06-08 00:06:58', 0, 0, 0, 'Run mode: GLPI'),
(86, 22, 85, '2023-06-08 00:06:58', 2, 0.00276995, 0, 'Action completed, no processing required');

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `name` varchar(150) NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT 1 COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT 1 COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT 3 COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT 0,
  `hourmax` int(11) NOT NULL DEFAULT 24,
  `logs_lifetime` int(11) NOT NULL DEFAULT 30 COMMENT 'number of days',
  `lastrun` timestamp NULL DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Task run by internal / external cron.' ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_crontasks` (`id`, `itemtype`, `name`, `frequency`, `param`, `state`, `mode`, `allowmode`, `hourmin`, `hourmax`, `logs_lifetime`, `lastrun`, `lastcode`, `comment`, `date_mod`, `date_creation`) VALUES
(2, 'CartridgeItem', 'cartridge', 86400, 10, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(3, 'ConsumableItem', 'consumable', 86400, 10, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(4, 'SoftwareLicense', 'software', 86400, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(5, 'Contract', 'contract', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 20:37:00', NULL, NULL, NULL, NULL),
(6, 'Infocom', 'infocom', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 20:46:00', NULL, NULL, NULL, NULL),
(7, 'CronTask', 'logs', 86400, 30, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(9, 'MailCollector', 'mailgate', 600, 10, 1, 1, 3, 0, 24, 30, '2023-06-07 23:47:00', NULL, NULL, NULL, NULL),
(10, 'DBconnection', 'checkdbreplicate', 300, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(11, 'CronTask', 'checkupdate', 604800, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(12, 'CronTask', 'session', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 20:47:00', NULL, NULL, NULL, NULL),
(13, 'CronTask', 'graph', 3600, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:23:00', NULL, NULL, NULL, NULL),
(14, 'ReservationItem', 'reservation', 3600, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:24:00', NULL, NULL, NULL, NULL),
(15, 'Ticket', 'closeticket', 43200, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 21:02:00', NULL, NULL, NULL, NULL),
(16, 'Ticket', 'alertnotclosed', 43200, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 21:08:00', NULL, NULL, NULL, NULL),
(17, 'SlaLevel_Ticket', 'slaticket', 300, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:53:00', NULL, NULL, NULL, NULL),
(18, 'Ticket', 'createinquest', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 21:20:00', NULL, NULL, NULL, NULL),
(19, 'CronTask', 'watcher', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 21:25:00', NULL, NULL, NULL, NULL),
(20, 'CommonITILRecurrentCron', 'RecurrentItems', 3600, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:24:00', NULL, NULL, NULL, NULL),
(21, 'PlanningRecall', 'planningrecall', 300, NULL, 1, 1, 3, 0, 24, 30, '2023-06-08 00:05:00', NULL, NULL, NULL, NULL),
(22, 'QueuedNotification', 'queuednotification', 60, 50, 1, 1, 3, 0, 24, 30, '2023-06-08 00:06:00', NULL, NULL, NULL, NULL),
(23, 'QueuedNotification', 'queuednotificationclean', 86400, 30, 1, 1, 3, 0, 24, 30, '2023-06-07 21:41:00', NULL, NULL, NULL, NULL),
(24, 'CronTask', 'temp', 3600, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:25:00', NULL, NULL, NULL, NULL),
(25, 'MailCollector', 'mailgateerror', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:16:00', NULL, NULL, NULL, NULL),
(26, 'CronTask', 'circularlogs', 86400, 4, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(27, 'ObjectLock', 'unlockobject', 86400, 4, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(28, 'SavedSearch', 'countAll', 604800, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(29, 'SavedSearch_Alert', 'savedsearchesalerts', 86400, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(30, 'Telemetry', 'telemetry', 2592000, NULL, 0, 1, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(31, 'Certificate', 'certificate', 86400, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:17:00', NULL, NULL, NULL, NULL),
(32, 'OlaLevel_Ticket', 'olaticket', 300, NULL, 1, 1, 3, 0, 24, 30, '2023-06-07 23:59:00', NULL, NULL, NULL, NULL),
(33, 'PurgeLogs', 'PurgeLogs', 604800, 24, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(34, 'Ticket', 'purgeticket', 604800, NULL, 0, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(35, 'Document', 'cleanorphans', 604800, NULL, 0, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(36, 'User', 'passwordexpiration', 86400, 100, 0, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(37, 'Glpi\\Marketplace\\Controller', 'checkAllUpdates', 86400, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(38, 'CleanSoftwareCron', 'cleansoftware', 2592000, 1000, 0, 2, 3, 0, 24, 300, NULL, NULL, NULL, NULL, NULL),
(39, 'Domain', 'DomainsAlert', 86400, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(40, 'Glpi\\Inventory\\Inventory', 'cleantemp', 86400, NULL, 0, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(41, 'Glpi\\Inventory\\Inventory', 'cleanorphans', 604800, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(42, 'PendingReasonCron', 'pendingreason_autobump_autosolve', 1800, NULL, 1, 2, 3, 0, 24, 60, NULL, NULL, NULL, NULL, NULL),
(43, 'Agent', 'Cleanoldagents', 86400, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, NULL, NULL),
(44, 'PluginGlpiinventoryTask', 'taskscheduler', 60, NULL, 1, 1, 3, 0, 24, 10, '2023-06-07 21:31:00', NULL, NULL, '2023-06-07 21:32:06', '2023-06-07 21:08:19'),
(45, 'PluginGlpiinventoryTaskjobstate', 'cleantaskjob', 86400, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, NULL, '2023-06-07 21:08:19', '2023-06-07 21:08:19'),
(46, 'PluginGlpiinventoryAgentWakeup', 'wakeupAgents', 120, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, 'Réveiller les agents', '2023-06-07 21:08:19', '2023-06-07 21:08:19'),
(47, 'PluginGlpiinventoryTask', 'cleanondemand', 86400, NULL, 1, 2, 3, 0, 24, 30, NULL, NULL, 'Clean on demand deployment tasks', '2023-06-07 21:08:19', '2023-06-07 21:08:19');

DROP TABLE IF EXISTS `glpi_dashboards_dashboards`;
CREATE TABLE `glpi_dashboards_dashboards` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `context` varchar(100) NOT NULL DEFAULT 'core',
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_dashboards_dashboards` (`id`, `key`, `name`, `context`, `users_id`) VALUES
(1, 'central', 'Central', 'core', 0),
(2, 'assets', 'Parc', 'core', 0),
(3, 'assistance', 'Assistance', 'core', 0),
(4, 'mini_tickets', 'Mini tableau de bord pour les tickets', 'mini_core', 0),
(5, 'plugin_glpiinventory_dashboard', 'Glpi inventory reports', 'core', 0);

DROP TABLE IF EXISTS `glpi_dashboards_filters`;
CREATE TABLE `glpi_dashboards_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `dashboards_dashboards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `filter` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_dashboards_items`;
CREATE TABLE `glpi_dashboards_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `dashboards_dashboards_id` int(10) UNSIGNED NOT NULL,
  `gridstack_id` varchar(255) NOT NULL,
  `card_id` varchar(255) NOT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `card_options` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_dashboards_items` (`id`, `dashboards_dashboards_id`, `gridstack_id`, `card_id`, `x`, `y`, `width`, `height`, `card_options`) VALUES
(27, 2, 'bn_count_Computer_34cfbaf9-a471-4852-b48c-0dadea7644de', 'bn_count_Computer', 0, 0, 4, 3, '{\"color\":\"#f3d0d0\",\"widgettype\":\"bigNumber\"}'),
(28, 2, 'bn_count_Software_60091467-2137-49f4-8834-f6602a482079', 'bn_count_Software', 4, 0, 4, 3, '{\"color\":\"#d1f1a8\",\"widgettype\":\"bigNumber\"}'),
(29, 2, 'bn_count_Printer_c9a385d4-76a3-4971-ad0e-1470efeafacc', 'bn_count_Printer', 8, 3, 4, 3, '{\"color\":\"#5da8d6\",\"widgettype\":\"bigNumber\"}'),
(30, 2, 'bn_count_PDU_60053eb6-8dda-4416-9a4b-afd51889bd09', 'bn_count_PDU', 12, 3, 4, 3, '{\"color\":\"#ffb62f\",\"widgettype\":\"bigNumber\"}'),
(31, 2, 'bn_count_Rack_0fdc196f-20d2-4f63-9ddb-b75c165cc664', 'bn_count_Rack', 12, 0, 4, 3, '{\"color\":\"#f7d79a\",\"widgettype\":\"bigNumber\"}'),
(32, 2, 'bn_count_Phone_c31fde2d-510a-4482-b17d-2f65b61eae08', 'bn_count_Phone', 16, 3, 4, 3, '{\"color\":\"#a0cec2\",\"widgettype\":\"bigNumber\"}'),
(33, 2, 'bn_count_Enclosure_c21ce30a-58c3-456a-81ec-3c5f01527a8f', 'bn_count_Enclosure', 16, 0, 4, 3, '{\"color\":\"#d7e8e4\",\"widgettype\":\"bigNumber\"}'),
(34, 2, 'bn_count_NetworkEquipment_76f1e239-777b-4552-b053-ae5c64190347', 'bn_count_NetworkEquipment', 8, 0, 4, 3, '{\"color\":\"#c8dae4\",\"widgettype\":\"bigNumber\"}'),
(35, 2, 'bn_count_SoftwareLicense_576e58fe-a386-480f-b405-1c2315b8ab47', 'bn_count_SoftwareLicense', 4, 3, 4, 3, '{\"color\":\"#9bc06b\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(36, 2, 'bn_count_Monitor_890e16d3-b121-48c6-9713-d9c239d9a970', 'bn_count_Monitor', 0, 3, 4, 3, '{\"color\":\"#dc6f6f\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(37, 2, 'count_Computer_Manufacturer_986e92e8-32e8-4a6f-806f-6f5383acbb3f', 'count_Computer_Manufacturer', 4, 6, 4, 4, '{\"color\":\"#f3f5f1\",\"widgettype\":\"hbar\",\"use_gradient\":\"1\",\"limit\":\"5\"}'),
(38, 2, 'count_Computer_State_290c5920-9eab-4db8-8753-46108e60f1d8', 'count_Computer_State', 0, 6, 4, 4, '{\"color\":\"#fbf7f7\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\"}'),
(39, 2, 'count_Computer_ComputerType_c58f9c7e-22d5-478b-8226-d2a752bcbb09', 'count_Computer_ComputerType', 8, 6, 4, 4, '{\"color\":\"#f5f9fa\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\"}'),
(40, 2, 'count_NetworkEquipment_Manufacturer_8132b21c-6f7f-4dc1-af54-bea794cb96e9', 'count_NetworkEquipment_Manufacturer', 12, 6, 4, 4, '{\"color\":\"#fcf8ed\",\"widgettype\":\"hbar\",\"use_gradient\":\"0\",\"limit\":\"5\"}'),
(41, 2, 'count_Monitor_Manufacturer_43b0c16b-af82-418e-aac1-f32b39705c0d', 'count_Monitor_Manufacturer', 16, 6, 4, 4, '{\"color\":\"#f9fbfb\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\"}'),
(42, 3, 'bn_count_Ticket_344e761b-f7e8-4617-8c90-154b266b4d67', 'bn_count_Ticket', 0, 0, 3, 2, '{\"color\":\"#ffdc64\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(43, 3, 'bn_count_Problem_bdb4002b-a674-4493-820f-af85bed44d2a', 'bn_count_Problem', 0, 4, 3, 2, '{\"color\":\"#f0967b\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(44, 3, 'bn_count_Change_b9b87513-4f40-41e6-8621-f51f9a30fb19', 'bn_count_Change', 0, 6, 3, 2, '{\"color\":\"#cae3c4\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(45, 3, 'bn_count_tickets_late_1e9ae481-21b4-4463-a830-dec1b68ec5e7', 'bn_count_tickets_late', 0, 2, 3, 2, '{\"color\":\"#f8911f\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(46, 3, 'bn_count_tickets_incoming_336a36d9-67fe-4475-880e-447bd766b8fe', 'bn_count_tickets_incoming', 3, 6, 3, 2, '{\"color\":\"#a0e19d\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(47, 3, 'bn_count_tickets_closed_e004bab5-f2b6-4060-a401-a2a8b9885245', 'bn_count_tickets_closed', 9, 8, 3, 2, '{\"color\":\"#515151\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(48, 3, 'bn_count_tickets_assigned_7455c855-6df8-4514-a3d9-8b0fce52bd63', 'bn_count_tickets_assigned', 6, 6, 3, 2, '{\"color\":\"#eaf5f7\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(49, 3, 'bn_count_tickets_solved_5e9759b3-ee7e-4a14-b68f-1ac024ef55ee', 'bn_count_tickets_solved', 9, 6, 3, 2, '{\"color\":\"#d8d8d8\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(50, 3, 'bn_count_tickets_waiting_102b2c2a-6ac6-4d73-ba47-8b09382fe00e', 'bn_count_tickets_waiting', 3, 8, 3, 2, '{\"color\":\"#ffcb7d\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(51, 3, 'bn_count_TicketRecurrent_13f79539-61f6-45f7-8dde-045706e652f2', 'bn_count_TicketRecurrent', 0, 8, 3, 2, '{\"color\":\"#fafafa\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(52, 3, 'bn_count_tickets_planned_267bf627-9d5e-4b6c-b53d-b8623d793ccf', 'bn_count_tickets_planned', 6, 8, 3, 2, '{\"color\":\"#6298d5\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(53, 3, 'top_ticket_ITILCategory_0cba0c84-6c62-4cd8-8564-18614498d8e4', 'top_ticket_ITILCategory', 12, 6, 4, 4, '{\"color\":\"#f1f5ef\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"7\"}'),
(54, 3, 'top_ticket_RequestType_b9e43f34-8e94-4a6e-9023-c5d1e2ce7859', 'top_ticket_RequestType', 16, 6, 4, 4, '{\"color\":\"#f9fafb\",\"widgettype\":\"hbar\",\"use_gradient\":\"1\",\"limit\":\"4\"}'),
(55, 3, 'top_ticket_Entity_a8e65812-519c-488e-9892-9adbe22fbd5c', 'top_ticket_Entity', 20, 6, 4, 4, '{\"color\":\"#f7f1f0\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"7\"}'),
(56, 3, 'ticket_evolution_76fd4926-ee5e-48db-b6d6-e2947c190c5e', 'ticket_evolution', 3, 0, 12, 6, '{\"color\":\"#f3f7f8\",\"widgettype\":\"areas\",\"use_gradient\":\"0\",\"limit\":\"12\"}'),
(57, 3, 'ticket_status_5b256a35-b36b-4db5-ba11-ea7c125f126e', 'ticket_status', 15, 0, 11, 6, '{\"color\":\"#f7f3f2\",\"widgettype\":\"stackedbars\",\"use_gradient\":\"0\",\"limit\":\"12\"}'),
(58, 4, 'bn_count_tickets_closed_ccf7246b-645a-40d2-8206-fa33c769e3f5', 'bn_count_tickets_closed', 24, 0, 4, 2, '{\"color\":\"#fafafa\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(59, 4, 'bn_count_Ticket_d5bf3576-5033-40fb-bbdb-292294a7698e', 'bn_count_Ticket', 0, 0, 4, 2, '{\"color\":\"#ffd957\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(60, 4, 'bn_count_tickets_incoming_055e813c-b0ce-4687-91ef-559249e8ddd8', 'bn_count_tickets_incoming', 4, 0, 4, 2, '{\"color\":\"#6fd169\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(61, 4, 'bn_count_tickets_waiting_793c665b-b620-4b3a-a5a8-cf502defc008', 'bn_count_tickets_waiting', 8, 0, 4, 2, '{\"color\":\"#ffcb7d\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(62, 4, 'bn_count_tickets_assigned_d3d2f697-52b4-435e-9030-a760dd649085', 'bn_count_tickets_assigned', 12, 0, 4, 2, '{\"color\":\"#eaf4f7\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(63, 4, 'bn_count_tickets_planned_0c7f3569-c23b-4ee3-8e85-279229b23e70', 'bn_count_tickets_planned', 16, 0, 4, 2, '{\"color\":\"#6298d5\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(64, 4, 'bn_count_tickets_solved_ae2406cf-e8e8-410b-b355-46e3f5705ee8', 'bn_count_tickets_solved', 20, 0, 4, 2, '{\"color\":\"#d7d7d7\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\"}'),
(65, 5, 'plugin_glpiinventory_nb_agent_4cf154c5-8df4-4f88-96e0-ccf55a63045a', 'plugin_glpiinventory_nb_agent', 0, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(66, 5, 'plugin_glpiinventory_nb_task_f6bb8ce8-b24b-4384-9d09-0020c8f3491d', 'plugin_glpiinventory_nb_task', 3, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(67, 5, 'plugin_glpiinventory_nb_printer_7839b66f-f74c-443f-96a0-180728b7c998', 'plugin_glpiinventory_nb_printer', 6, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(68, 5, 'plugin_glpiinventory_nb_networkequipement_ba66eb68-833e-4360-b6cc-172973293d38', 'plugin_glpiinventory_nb_networkequipement', 9, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(69, 5, 'plugin_glpiinventory_nb_phone_417b2adc-d74b-4fed-af51-e200d0e42b26', 'plugin_glpiinventory_nb_phone', 12, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(70, 5, 'plugin_glpiinventory_nb_computer_c9bcf7e0-2b7b-4e64-8beb-49ad0bf3fb58', 'plugin_glpiinventory_nb_computer', 15, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#606f91\"}'),
(71, 5, 'plugin_glpiinventory_nb_unmanaged_f3e4cbd7-5337-436b-87fa-a3e637f86a18', 'plugin_glpiinventory_nb_unmanaged', 18, 0, 3, 2, '{\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"point_labels\":\"0\",\"color\":\"#e69138\"}'),
(521, 1, 'bn_count_Computer_4a315743-151c-40cb-a20b-762250668dac', 'bn_count_Computer', 3, 0, 3, 2, '{\"color\":\"#e69393\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_81692134a641044329c56f16006b1592c75d3b1e\"}'),
(522, 1, 'bn_count_Software_0690f524-e826-47a9-b50a-906451196b83', 'bn_count_Software', 0, 0, 3, 2, '{\"color\":\"#aaddac\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_f13c7cc0cc9d01643c3817ba358fb10576934797\"}'),
(523, 1, 'bn_count_Rack_c6502e0a-5991-46b4-a771-7f355137306b', 'bn_count_Rack', 7, 2, 3, 2, '{\"color\":\"#0e87a0\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_472f99ca4261272f9f0dda857621ff20d8989037\"}'),
(524, 1, 'bn_count_SoftwareLicense_e755fd06-283e-4479-ba35-2d548f8f8a90', 'bn_count_SoftwareLicense', 0, 2, 3, 2, '{\"color\":\"#27ab3c\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_8114a054c3c4dc71bba014d47b93ab61fbb0fd78\"}'),
(525, 1, 'bn_count_Monitor_7059b94c-583c-4ba7-b100-d40461165318', 'bn_count_Monitor', 3, 2, 3, 2, '{\"color\":\"#b52d30\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_ca849a636ddf146ea13a1f3d587bc4d270b86139\"}'),
(526, 1, 'bn_count_Ticket_a74c0903-3387-4a07-9111-b0938af8f1e7', 'bn_count_Ticket', 14, 5, 3, 2, '{\"color\":\"#ffdc64\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_1fc6da26ead918ddaefd27e06d6d80f4910c963a\"}'),
(527, 1, 'bn_count_Problem_c1cf5cfb-f626-472e-82a1-49c3e200e746', 'bn_count_Problem', 20, 5, 3, 2, '{\"color\":\"#f08d7b\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_06729d81ed7198db709e214401dcf808a187cb52\"}'),
(528, 1, 'count_Computer_Manufacturer_6129c451-42b5-489d-b693-c362adf32d49', 'count_Computer_Manufacturer', 0, 4, 5, 4, '{\"color\":\"#f8faf9\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\",\"cache_key\":\"dashboard_card_central_f368e76b4e76a5b236978802af8bbfa2377df3a7\"}'),
(529, 1, 'top_ticket_user_requester_c74f52a8-046a-4077-b1a6-c9f840d34b82', 'top_ticket_user_requester', 14, 7, 6, 5, '{\"color\":\"#f9fafb\",\"widgettype\":\"hbar\",\"use_gradient\":\"1\",\"limit\":\"5\",\"cache_key\":\"dashboard_card_central_7ac4baa49f58d34d71482c6a217998a0bbd91808\"}'),
(530, 1, 'bn_count_tickets_late_04c47208-d7e5-4aca-9566-d46e68c45c67', 'bn_count_tickets_late', 17, 5, 3, 2, '{\"color\":\"#f8911f\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_fbe752c75b569a6e7699a53e282c2ce6740a2a33\"}'),
(531, 1, 'ticket_status_2e4e968b-d4e6-4e33-9ce9-a1aaff53dfde', 'ticket_status', 14, 0, 12, 5, '{\"color\":\"#fafafa\",\"widgettype\":\"stackedbars\",\"use_gradient\":\"0\",\"limit\":\"12\",\"cache_key\":\"dashboard_card_central_c1cfd256199058d985f197fb2d1b8e8b32739cbf\"}'),
(532, 1, 'top_ticket_ITILCategory_37736ba9-d429-4cb3-9058-ef4d111d9269', 'top_ticket_ITILCategory', 20, 7, 6, 5, '{\"color\":\"#fbf9f9\",\"widgettype\":\"hbar\",\"use_gradient\":\"1\",\"limit\":\"5\",\"cache_key\":\"dashboard_card_central_5a90b906aceaefe637fe6ed72abf294ee695b49c\"}'),
(533, 1, 'bn_count_Printer_517684b0-b064-49dd-943e-fcb6f915e453', 'bn_count_Printer', 10, 2, 3, 2, '{\"color\":\"#365a8f\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_becee5e49b059b2a187d005f58bff3dc03344210\"}'),
(534, 1, 'bn_count_Phone_f70c489f-02c1-46e5-978b-94a95b5038ee', 'bn_count_Phone', 10, 0, 3, 2, '{\"color\":\"#d5e1ec\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_9978cfb8cdfdc3b0f79f6fa4f5c1da387953bbf8\"}'),
(535, 1, 'bn_count_Change_ab950dbd-cd25-466d-8dff-7dcaca386564', 'bn_count_Change', 23, 5, 3, 2, '{\"color\":\"#cae3c4\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_fb54e1e99117d878358775bbbca19baf8ea0b980\"}'),
(536, 1, 'bn_count_Group_b84a93f2-a26c-49d7-82a4-5446697cc5b0', 'bn_count_Group', 4, 8, 4, 2, '{\"color\":\"#e0e0e0\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_6910a7d991e307cbc59c81903a5454aac052b584\"}'),
(537, 1, 'bn_count_Profile_770b35e8-68e9-4b4f-9e09-5a11058f069f', 'bn_count_Profile', 4, 10, 4, 2, '{\"color\":\"#e0e0e0\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_045c9cfff36241f69560c4f17087ca33b34c0ca4\"}'),
(538, 1, 'bn_count_Supplier_36ff9011-e4cf-4d89-b9ab-346b9857d734', 'bn_count_Supplier', 8, 8, 3, 2, '{\"color\":\"#c9c9c9\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_e8198835389e732c960802797943a782f9ca1e59\"}'),
(539, 1, 'bn_count_KnowbaseItem_a3785a56-bed4-4a30-8387-f251f5365b3b', 'bn_count_KnowbaseItem', 8, 10, 3, 2, '{\"color\":\"#c9c9c9\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_ea79131c5ee7eba0bc35103ddaf96b0a15591947\"}'),
(540, 1, 'bn_count_Entity_9b82951a-ba52-45cc-a2d3-1d238ec37adf', 'bn_count_Entity', 0, 10, 4, 2, '{\"color\":\"#f9f9f9\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_d9e0ad10850b56dfa2edbad74eff8b812883a4df\"}'),
(541, 1, 'bn_count_Document_7dc7f4b8-61ff-4147-b994-5541bddd7b66', 'bn_count_Document', 11, 8, 3, 2, '{\"color\":\"#b4b4b4\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_4500ea0deb1fc7e3bf0a0312d1dc4ec461cf1636\"}'),
(542, 1, 'bn_count_Project_4d412ee2-8b79-469b-995f-4c0a05ab849d', 'bn_count_Project', 11, 10, 3, 2, '{\"color\":\"#b3b3b3\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_01d9e913ce375525faf2deddc6443e41b31f96e9\"}'),
(543, 1, 'bn_count_NetworkEquipment_c537e334-d584-43bc-b6de-b4a939143e89', 'bn_count_NetworkEquipment', 7, 0, 3, 2, '{\"color\":\"#bfe7ea\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_002ef0d7f5e00e100e899ca02c1489056e79af50\"}'),
(544, 1, 'bn_count_User_ac0cbe52-3593-43c1-8ecc-0eb115de494d', 'bn_count_User', 0, 8, 4, 2, '{\"color\":\"#fafafa\",\"widgettype\":\"bigNumber\",\"use_gradient\":\"0\",\"limit\":\"7\",\"cache_key\":\"dashboard_card_central_294adc2e1c3691c881e916b61a39d6063556a2e9\"}'),
(545, 1, 'count_Monitor_MonitorModel_5a476ff9-116e-4270-858b-c003c20841a9', 'count_Monitor_MonitorModel', 5, 4, 5, 4, '{\"color\":\"#f5fafa\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\",\"cache_key\":\"dashboard_card_central_b00a2f3bb3c0195d661dc5f5e32e8f3f4a1b9f85\"}'),
(546, 1, 'count_NetworkEquipment_State_81f2ae35-b366-4065-ac26-02ea4e3704a6', 'count_NetworkEquipment_State', 10, 4, 4, 4, '{\"color\":\"#f5f3ef\",\"widgettype\":\"donut\",\"use_gradient\":\"1\",\"limit\":\"5\",\"cache_key\":\"dashboard_card_central_954cbf53cbfe02b9f1d5189ea3406d46e30de1c6\"}');

DROP TABLE IF EXISTS `glpi_dashboards_rights`;
CREATE TABLE `glpi_dashboards_rights` (
  `id` int(10) UNSIGNED NOT NULL,
  `dashboards_dashboards_id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_databaseinstancecategories`;
CREATE TABLE `glpi_databaseinstancecategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_databaseinstances`;
CREATE TABLE `glpi_databaseinstances` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(255) NOT NULL DEFAULT '',
  `port` varchar(10) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `size` int(11) NOT NULL DEFAULT 0,
  `databaseinstancetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `databaseinstancecategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL DEFAULT '',
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_onbackup` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_helpdesk_visible` tinyint(4) NOT NULL DEFAULT 1,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_lastboot` timestamp NULL DEFAULT NULL,
  `date_lastbackup` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_databaseinstancetypes`;
CREATE TABLE `glpi_databaseinstancetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_databases`;
CREATE TABLE `glpi_databases` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `size` int(11) NOT NULL DEFAULT 0,
  `databaseinstances_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_onbackup` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_update` timestamp NULL DEFAULT NULL,
  `date_lastbackup` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_datacenters`;
CREATE TABLE `glpi_datacenters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_datacenters` (`id`, `name`, `entities_id`, `is_recursive`, `locations_id`, `is_deleted`, `date_mod`, `date_creation`, `pictures`) VALUES
(1, 'Paris', 0, 0, 1, 0, '2023-06-07 21:36:54', '2023-06-07 21:34:10', NULL),
(2, 'Lyon', 0, 0, 2, 0, '2023-06-07 21:36:49', '2023-06-07 21:34:22', NULL);

DROP TABLE IF EXISTS `glpi_dcrooms`;
CREATE TABLE `glpi_dcrooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `vis_cols` int(11) DEFAULT NULL,
  `vis_rows` int(11) DEFAULT NULL,
  `blueprint` text DEFAULT NULL,
  `datacenters_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicebatteries`;
CREATE TABLE `glpi_devicebatteries` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `voltage` int(11) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `devicebatterytypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicebatterymodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicebatterymodels`;
CREATE TABLE `glpi_devicebatterymodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicebatterytypes`;
CREATE TABLE `glpi_devicebatterytypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecameramodels`;
CREATE TABLE `glpi_devicecameramodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecameras`;
CREATE TABLE `glpi_devicecameras` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `flashunit` tinyint(4) NOT NULL DEFAULT 0,
  `lensfacing` varchar(255) DEFAULT NULL,
  `orientation` varchar(255) DEFAULT NULL,
  `focallength` varchar(255) DEFAULT NULL,
  `sensorsize` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicecameramodels_id` int(10) UNSIGNED DEFAULT NULL,
  `support` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecasemodels`;
CREATE TABLE `glpi_devicecasemodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `devicecasetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicecasemodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecontrolmodels`;
CREATE TABLE `glpi_devicecontrolmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `is_raid` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `interfacetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicecontrolmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicedrivemodels`;
CREATE TABLE `glpi_devicedrivemodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `is_writer` tinyint(4) NOT NULL DEFAULT 1,
  `speed` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `interfacetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicedrivemodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicefirmwaremodels`;
CREATE TABLE `glpi_devicefirmwaremodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicefirmwares`;
CREATE TABLE `glpi_devicefirmwares` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `devicefirmwaretypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicefirmwaremodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicefirmwaretypes`;
CREATE TABLE `glpi_devicefirmwaretypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_devicefirmwaretypes` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'BIOS', NULL, NULL, NULL),
(2, 'UEFI', NULL, NULL, NULL),
(3, 'Firmware', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_devicegenericmodels`;
CREATE TABLE `glpi_devicegenericmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicegenerics`;
CREATE TABLE `glpi_devicegenerics` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `devicegenerictypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `devicegenericmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicegenerictypes`;
CREATE TABLE `glpi_devicegenerictypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicegraphiccardmodels`;
CREATE TABLE `glpi_devicegraphiccardmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `interfacetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `memory_default` int(11) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicegraphiccardmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `chipset` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_deviceharddrivemodels`;
CREATE TABLE `glpi_deviceharddrivemodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `rpm` varchar(255) DEFAULT NULL,
  `interfacetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cache` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `capacity_default` int(11) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `deviceharddrivemodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `frequence` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `size_default` int(11) NOT NULL DEFAULT 0,
  `devicememorytypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicememorymodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicememorymodels`;
CREATE TABLE `glpi_devicememorymodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_devicememorytypes` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'EDO', NULL, NULL, NULL),
(2, 'DDR', NULL, NULL, NULL),
(3, 'SDRAM', NULL, NULL, NULL),
(4, 'SDRAM-2', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_devicemotherboardmodels`;
CREATE TABLE `glpi_devicemotherboardmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `chipset` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicemotherboardmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicenetworkcardmodels`;
CREATE TABLE `glpi_devicenetworkcardmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `bandwidth` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mac_default` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicenetworkcardmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicepcimodels`;
CREATE TABLE `glpi_devicepcimodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `devicenetworkcardmodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicepcimodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `power` varchar(255) DEFAULT NULL,
  `is_atx` tinyint(4) NOT NULL DEFAULT 1,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicepowersupplymodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicepowersupplymodels`;
CREATE TABLE `glpi_devicepowersupplymodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_deviceprocessormodels`;
CREATE TABLE `glpi_deviceprocessormodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `frequency_default` int(11) NOT NULL DEFAULT 0,
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `deviceprocessormodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesensormodels`;
CREATE TABLE `glpi_devicesensormodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesensors`;
CREATE TABLE `glpi_devicesensors` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `devicesensortypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `devicesensormodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesensortypes`;
CREATE TABLE `glpi_devicesensortypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesimcards`;
CREATE TABLE `glpi_devicesimcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `voltage` int(11) DEFAULT NULL,
  `devicesimcardtypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `allow_voip` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesimcardtypes`;
CREATE TABLE `glpi_devicesimcardtypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_devicesimcardtypes` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'Full SIM', NULL, NULL, NULL),
(2, 'Mini SIM', NULL, NULL, NULL),
(3, 'Micro SIM', NULL, NULL, NULL),
(4, 'Nano SIM', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_devicesoundcardmodels`;
CREATE TABLE `glpi_devicesoundcardmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `devicesoundcardmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `num` int(11) NOT NULL DEFAULT 0,
  `rank` int(11) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_displaypreferences` (`id`, `itemtype`, `num`, `rank`, `users_id`) VALUES
(1, 'Computer', 4, 4, 0),
(2, 'Computer', 45, 6, 0),
(3, 'Computer', 40, 5, 0),
(4, 'Computer', 5, 3, 0),
(5, 'Computer', 23, 2, 0),
(6, 'DocumentType', 3, 1, 0),
(7, 'Monitor', 31, 1, 0),
(8, 'Monitor', 23, 2, 0),
(9, 'Monitor', 3, 3, 0),
(10, 'Monitor', 4, 4, 0),
(11, 'Printer', 31, 1, 0),
(12, 'NetworkEquipment', 31, 1, 0),
(13, 'NetworkEquipment', 23, 2, 0),
(14, 'Printer', 23, 2, 0),
(15, 'Printer', 3, 3, 0),
(16, 'Software', 4, 3, 0),
(17, 'Software', 5, 2, 0),
(18, 'Software', 23, 1, 0),
(19, 'CartridgeItem', 4, 2, 0),
(20, 'CartridgeItem', 34, 1, 0),
(21, 'Peripheral', 3, 3, 0),
(22, 'Peripheral', 23, 2, 0),
(23, 'Peripheral', 31, 1, 0),
(24, 'Computer', 31, 1, 0),
(25, 'Computer', 3, 7, 0),
(26, 'Computer', 19, 8, 0),
(27, 'Computer', 17, 9, 0),
(28, 'NetworkEquipment', 3, 3, 0),
(29, 'NetworkEquipment', 4, 4, 0),
(30, 'NetworkEquipment', 11, 6, 0),
(31, 'NetworkEquipment', 19, 7, 0),
(32, 'Printer', 4, 4, 0),
(33, 'Printer', 19, 6, 0),
(34, 'Monitor', 19, 6, 0),
(35, 'Monitor', 7, 7, 0),
(36, 'Peripheral', 4, 4, 0),
(37, 'Peripheral', 19, 6, 0),
(38, 'Peripheral', 7, 7, 0),
(39, 'Contact', 3, 1, 0),
(40, 'Contact', 4, 2, 0),
(41, 'Contact', 5, 3, 0),
(42, 'Contact', 6, 4, 0),
(43, 'Contact', 9, 5, 0),
(44, 'Supplier', 9, 1, 0),
(45, 'Supplier', 3, 2, 0),
(46, 'Supplier', 4, 3, 0),
(47, 'Supplier', 5, 4, 0),
(48, 'Supplier', 10, 5, 0),
(49, 'Supplier', 6, 6, 0),
(50, 'Contract', 4, 1, 0),
(51, 'Contract', 3, 2, 0),
(52, 'Contract', 5, 3, 0),
(53, 'Contract', 6, 4, 0),
(54, 'Contract', 7, 5, 0),
(55, 'Contract', 11, 6, 0),
(56, 'CartridgeItem', 23, 3, 0),
(57, 'CartridgeItem', 3, 4, 0),
(58, 'DocumentType', 6, 2, 0),
(59, 'DocumentType', 4, 3, 0),
(60, 'DocumentType', 5, 4, 0),
(61, 'Document', 3, 1, 0),
(62, 'Document', 4, 2, 0),
(63, 'Document', 7, 3, 0),
(64, 'Document', 5, 4, 0),
(65, 'Document', 16, 5, 0),
(66, 'User', 34, 1, 0),
(67, 'User', 5, 3, 0),
(68, 'User', 6, 4, 0),
(69, 'User', 3, 5, 0),
(70, 'ConsumableItem', 34, 1, 0),
(71, 'ConsumableItem', 4, 2, 0),
(72, 'ConsumableItem', 23, 3, 0),
(73, 'ConsumableItem', 3, 4, 0),
(74, 'NetworkEquipment', 40, 5, 0),
(75, 'Printer', 40, 5, 0),
(76, 'Monitor', 40, 5, 0),
(77, 'Peripheral', 40, 5, 0),
(78, 'User', 8, 6, 0),
(79, 'Phone', 31, 1, 0),
(80, 'Phone', 23, 2, 0),
(81, 'Phone', 3, 3, 0),
(82, 'Phone', 4, 4, 0),
(83, 'Phone', 40, 5, 0),
(84, 'Phone', 19, 6, 0),
(85, 'Phone', 7, 7, 0),
(86, 'Group', 16, 1, 0),
(87, 'AllAssets', 31, 1, 0),
(88, 'ReservationItem', 4, 1, 0),
(89, 'ReservationItem', 3, 2, 0),
(90, 'Budget', 3, 2, 0),
(91, 'Software', 72, 4, 0),
(92, 'Software', 163, 5, 0),
(93, 'Budget', 5, 1, 0),
(94, 'Budget', 4, 3, 0),
(95, 'Budget', 19, 4, 0),
(96, 'CronTask', 8, 1, 0),
(97, 'CronTask', 3, 2, 0),
(98, 'CronTask', 4, 3, 0),
(99, 'CronTask', 7, 4, 0),
(100, 'RequestType', 14, 1, 0),
(101, 'RequestType', 15, 2, 0),
(102, 'NotificationTemplate', 4, 1, 0),
(103, 'NotificationTemplate', 16, 2, 0),
(104, 'Notification', 5, 1, 0),
(105, 'Notification', 6, 2, 0),
(106, 'Notification', 2, 3, 0),
(107, 'Notification', 4, 4, 0),
(108, 'Notification', 80, 5, 0),
(109, 'Notification', 86, 6, 0),
(110, 'MailCollector', 2, 1, 0),
(111, 'MailCollector', 19, 2, 0),
(112, 'AuthLDAP', 3, 1, 0),
(113, 'AuthLDAP', 19, 2, 0),
(114, 'AuthMail', 3, 1, 0),
(115, 'AuthMail', 19, 2, 0),
(116, 'IPNetwork', 18, 1, 0),
(117, 'WifiNetwork', 10, 1, 0),
(118, 'Profile', 2, 1, 0),
(119, 'Profile', 3, 2, 0),
(120, 'Profile', 19, 3, 0),
(121, 'Transfer', 19, 1, 0),
(122, 'TicketValidation', 3, 1, 0),
(123, 'TicketValidation', 2, 2, 0),
(124, 'TicketValidation', 8, 3, 0),
(125, 'TicketValidation', 4, 4, 0),
(126, 'TicketValidation', 9, 5, 0),
(127, 'TicketValidation', 7, 6, 0),
(128, 'NotImportedEmail', 2, 1, 0),
(129, 'NotImportedEmail', 5, 2, 0),
(130, 'NotImportedEmail', 4, 3, 0),
(131, 'NotImportedEmail', 6, 4, 0),
(132, 'NotImportedEmail', 16, 5, 0),
(133, 'NotImportedEmail', 19, 6, 0),
(134, 'RuleRightParameter', 11, 1, 0),
(135, 'Ticket', 12, 1, 0),
(136, 'Ticket', 19, 2, 0),
(137, 'Ticket', 15, 3, 0),
(138, 'Ticket', 3, 4, 0),
(139, 'Ticket', 4, 5, 0),
(140, 'Ticket', 5, 6, 0),
(141, 'Ticket', 7, 7, 0),
(142, 'Calendar', 19, 1, 0),
(143, 'Holiday', 11, 1, 0),
(144, 'Holiday', 12, 2, 0),
(145, 'Holiday', 13, 3, 0),
(146, 'SLA', 4, 1, 0),
(147, 'Ticket', 18, 8, 0),
(148, 'AuthLDAP', 30, 3, 0),
(149, 'AuthMail', 6, 3, 0),
(150, 'FQDN', 11, 1, 0),
(151, 'FieldUnicity', 1, 1, 0),
(152, 'FieldUnicity', 80, 2, 0),
(153, 'FieldUnicity', 4, 3, 0),
(154, 'FieldUnicity', 3, 4, 0),
(155, 'FieldUnicity', 86, 5, 0),
(156, 'FieldUnicity', 30, 6, 0),
(157, 'Problem', 21, 1, 0),
(158, 'Problem', 12, 2, 0),
(159, 'Problem', 19, 3, 0),
(160, 'Problem', 15, 4, 0),
(161, 'Problem', 3, 5, 0),
(162, 'Problem', 7, 6, 0),
(163, 'Problem', 18, 7, 0),
(164, 'Vlan', 11, 1, 0),
(165, 'TicketRecurrent', 11, 1, 0),
(166, 'TicketRecurrent', 12, 2, 0),
(167, 'TicketRecurrent', 13, 3, 0),
(168, 'TicketRecurrent', 15, 4, 0),
(169, 'TicketRecurrent', 14, 5, 0),
(170, 'Reminder', 2, 1, 0),
(171, 'Reminder', 3, 2, 0),
(172, 'Reminder', 4, 3, 0),
(173, 'Reminder', 5, 4, 0),
(174, 'Reminder', 6, 5, 0),
(175, 'Reminder', 7, 6, 0),
(176, 'IPNetwork', 10, 2, 0),
(177, 'IPNetwork', 11, 3, 0),
(178, 'IPNetwork', 12, 4, 0),
(179, 'IPNetwork', 17, 5, 0),
(180, 'NetworkName', 12, 1, 0),
(181, 'NetworkName', 13, 2, 0),
(182, 'RSSFeed', 2, 1, 0),
(183, 'RSSFeed', 4, 2, 0),
(184, 'RSSFeed', 5, 3, 0),
(185, 'RSSFeed', 19, 4, 0),
(186, 'RSSFeed', 6, 5, 0),
(187, 'RSSFeed', 7, 6, 0),
(188, 'Blacklist', 12, 1, 0),
(189, 'Blacklist', 11, 2, 0),
(190, 'ReservationItem', 5, 3, 0),
(191, 'QueuedNotification', 16, 1, 0),
(192, 'QueuedNotification', 7, 2, 0),
(193, 'QueuedNotification', 20, 3, 0),
(194, 'QueuedNotification', 21, 4, 0),
(195, 'QueuedNotification', 22, 5, 0),
(196, 'QueuedNotification', 15, 6, 0),
(197, 'Change', 12, 1, 0),
(198, 'Change', 19, 2, 0),
(199, 'Change', 15, 3, 0),
(200, 'Change', 7, 4, 0),
(201, 'Change', 18, 5, 0),
(202, 'Project', 3, 1, 0),
(203, 'Project', 4, 2, 0),
(204, 'Project', 12, 3, 0),
(205, 'Project', 5, 4, 0),
(206, 'Project', 15, 5, 0),
(207, 'Project', 21, 6, 0),
(208, 'ProjectState', 12, 1, 0),
(209, 'ProjectState', 11, 2, 0),
(210, 'ProjectTask', 2, 1, 0),
(211, 'ProjectTask', 12, 2, 0),
(212, 'ProjectTask', 14, 3, 0),
(213, 'ProjectTask', 5, 4, 0),
(214, 'ProjectTask', 7, 5, 0),
(215, 'ProjectTask', 8, 6, 0),
(216, 'ProjectTask', 13, 7, 0),
(217, 'CartridgeItem', 9, 5, 0),
(218, 'ConsumableItem', 9, 5, 0),
(219, 'ReservationItem', 9, 4, 0),
(220, 'SoftwareLicense', 1, 1, 0),
(221, 'SoftwareLicense', 3, 2, 0),
(222, 'SoftwareLicense', 10, 3, 0),
(223, 'SoftwareLicense', 162, 4, 0),
(224, 'SoftwareLicense', 5, 5, 0),
(225, 'SavedSearch', 8, 1, 0),
(226, 'SavedSearch', 9, 1, 0),
(227, 'SavedSearch', 3, 1, 0),
(228, 'SavedSearch', 10, 1, 0),
(229, 'SavedSearch', 11, 1, 0),
(230, 'Plugin', 2, 1, 0),
(231, 'Plugin', 3, 2, 0),
(232, 'Plugin', 4, 3, 0),
(233, 'Plugin', 5, 4, 0),
(234, 'Plugin', 6, 5, 0),
(235, 'Plugin', 7, 6, 0),
(236, 'Plugin', 8, 7, 0),
(237, 'Cluster', 31, 1, 0),
(238, 'Cluster', 19, 2, 0),
(239, 'Domain', 3, 1, 0),
(240, 'Domain', 4, 2, 0),
(241, 'Domain', 2, 3, 0),
(242, 'Domain', 6, 4, 0),
(243, 'Domain', 7, 5, 0),
(244, 'DomainRecord', 2, 1, 0),
(245, 'DomainRecord', 3, 2, 0),
(246, 'Appliance', 2, 1, 0),
(247, 'Appliance', 3, 2, 0),
(248, 'Appliance', 4, 3, 0),
(249, 'Appliance', 5, 4, 0),
(250, 'Lockedfield', 3, 1, 0),
(251, 'Lockedfield', 13, 2, 0),
(252, 'Lockedfield', 5, 3, 0),
(253, 'Unmanaged', 2, 1, 0),
(254, 'Unmanaged', 4, 2, 0),
(255, 'Unmanaged', 3, 3, 0),
(256, 'Unmanaged', 5, 4, 0),
(257, 'Unmanaged', 7, 5, 0),
(258, 'Unmanaged', 10, 6, 0),
(259, 'Unmanaged', 18, 7, 0),
(260, 'Unmanaged', 14, 8, 0),
(261, 'Unmanaged', 15, 9, 0),
(262, 'Unmanaged', 9, 10, 0),
(263, 'NetworkPortType', 10, 1, 0),
(264, 'NetworkPortType', 11, 2, 0),
(265, 'NetworkPortType', 12, 3, 0),
(266, 'NetworkPort', 3, 1, 0),
(267, 'NetworkPort', 30, 2, 0),
(268, 'NetworkPort', 31, 3, 0),
(269, 'NetworkPort', 32, 4, 0),
(270, 'NetworkPort', 33, 5, 0),
(271, 'NetworkPort', 34, 6, 0),
(272, 'NetworkPort', 35, 7, 0),
(273, 'NetworkPort', 36, 8, 0),
(274, 'NetworkPort', 38, 9, 0),
(275, 'NetworkPort', 39, 10, 0),
(276, 'NetworkPort', 40, 11, 0),
(277, 'NetworkPort', 6, 12, 0),
(278, 'USBVendor', 10, 1, 0),
(279, 'USBVendor', 11, 2, 0),
(280, 'PCIVendor', 10, 1, 0),
(281, 'PCIVendor', 11, 2, 0),
(282, 'Agent', 2, 1, 0),
(283, 'Agent', 4, 2, 0),
(284, 'Agent', 10, 3, 0),
(285, 'Agent', 8, 4, 0),
(286, 'Agent', 11, 5, 0),
(287, 'Agent', 6, 6, 0),
(288, 'Agent', 15, 7, 0),
(289, 'Database', 2, 1, 0),
(290, 'Database', 3, 2, 0),
(291, 'Database', 6, 3, 0),
(292, 'Database', 9, 4, 0),
(293, 'Database', 10, 5, 0),
(294, 'Glpi\\Socket', 5, 1, 0),
(295, 'Glpi\\Socket', 6, 2, 0),
(296, 'Glpi\\Socket', 9, 3, 0),
(297, 'Glpi\\Socket', 8, 4, 0),
(298, 'Glpi\\Socket', 7, 5, 0),
(299, 'Cable', 4, 1, 0),
(300, 'Cable', 31, 2, 0),
(301, 'Cable', 6, 3, 0),
(302, 'Cable', 15, 4, 0),
(303, 'Cable', 24, 5, 0),
(304, 'Cable', 8, 6, 0),
(305, 'Cable', 10, 7, 0),
(306, 'Cable', 13, 8, 0),
(307, 'Cable', 14, 9, 0),
(308, 'PluginGlpiinventoryTask', 2, 1, 0),
(309, 'PluginGlpiinventoryTask', 3, 2, 0),
(310, 'PluginGlpiinventoryTask', 4, 3, 0),
(311, 'PluginGlpiinventoryTask', 5, 4, 0),
(312, 'PluginGlpiinventoryTask', 6, 5, 0),
(313, 'PluginGlpiinventoryTask', 7, 6, 0),
(314, 'PluginGlpiinventoryTask', 30, 7, 0),
(315, 'PluginGlpiinventoryIPRange', 2, 1, 0),
(316, 'PluginGlpiinventoryIPRange', 3, 2, 0),
(317, 'PluginGlpiinventoryIPRange', 4, 3, 0),
(318, 'PluginGlpiinventoryTaskjob', 1, 1, 0),
(319, 'PluginGlpiinventoryTaskjob', 2, 2, 0),
(320, 'PluginGlpiinventoryTaskjob', 3, 3, 0),
(321, 'PluginGlpiinventoryTaskjob', 4, 4, 0),
(322, 'PluginGlpiinventoryTaskjob', 5, 5, 0),
(323, 'PluginGlpiinventoryInventoryComputerBlacklist', 2, 1, 0),
(324, 'PluginGlpiinventoryTaskjoblog', 2, 1, 0),
(325, 'PluginGlpiinventoryTaskjoblog', 3, 2, 0),
(326, 'PluginGlpiinventoryTaskjoblog', 4, 3, 0),
(327, 'PluginGlpiinventoryTaskjoblog', 5, 4, 0),
(328, 'PluginGlpiinventoryTaskjoblog', 6, 5, 0),
(329, 'PluginGlpiinventoryTaskjoblog', 7, 6, 0),
(330, 'PluginGlpiinventoryTaskjoblog', 8, 7, 0),
(331, 'PluginGlpiinventoryStateDiscovery', 2, 1, 0),
(332, 'PluginGlpiinventoryStateDiscovery', 4, 2, 0),
(333, 'PluginGlpiinventoryStateDiscovery', 5, 3, 0),
(334, 'PluginGlpiinventoryStateDiscovery', 6, 4, 0),
(335, 'PluginGlpiinventoryStateDiscovery', 7, 5, 0),
(336, 'PluginGlpiinventoryStateDiscovery', 8, 6, 0),
(337, 'PluginGlpiinventoryStateDiscovery', 9, 7, 0),
(338, 'PluginGlpiinventoryStateDiscovery', 10, 8, 0),
(339, 'PluginGlpiinventoryStateDiscovery', 11, 9, 0),
(340, 'PluginGlpiinventoryStateDiscovery', 12, 10, 0);

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `documentcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mime` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sha1sum` char(40) DEFAULT NULL,
  `is_blacklisted` tinyint(4) NOT NULL DEFAULT 0,
  `tag` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `documents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED DEFAULT 0,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ext` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `mime` varchar(255) DEFAULT NULL,
  `is_uploadable` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_documenttypes` (`id`, `name`, `ext`, `icon`, `mime`, `is_uploadable`, `date_mod`, `comment`, `date_creation`) VALUES
(1, 'JPEG', 'jpg', 'jpg-dist.png', NULL, 1, NULL, NULL, NULL),
(2, 'PNG', 'png', 'png-dist.png', NULL, 1, NULL, NULL, NULL),
(3, 'GIF', 'gif', 'gif-dist.png', NULL, 1, NULL, NULL, NULL),
(4, 'BMP', 'bmp', 'bmp-dist.png', NULL, 1, NULL, NULL, NULL),
(5, 'Photoshop', 'psd', 'psd-dist.png', NULL, 1, NULL, NULL, NULL),
(6, 'TIFF', 'tif', 'tif-dist.png', NULL, 1, NULL, NULL, NULL),
(7, 'AIFF', 'aiff', 'aiff-dist.png', NULL, 1, NULL, NULL, NULL),
(8, 'Windows Media', 'asf', 'asf-dist.png', NULL, 1, NULL, NULL, NULL),
(9, 'Windows Media', 'avi', 'avi-dist.png', NULL, 1, NULL, NULL, NULL),
(10, 'BZip', 'bz2', 'bz2-dist.png', NULL, 1, NULL, NULL, NULL),
(11, 'Word', 'doc', 'doc-dist.png', NULL, 1, NULL, NULL, NULL),
(12, 'DjVu', 'djvu', '', NULL, 1, NULL, NULL, NULL),
(13, 'PostScript', 'eps', 'ps-dist.png', NULL, 1, NULL, NULL, NULL),
(14, 'GZ', 'gz', 'gz-dist.png', NULL, 1, NULL, NULL, NULL),
(15, 'HTML', 'html', 'html-dist.png', NULL, 1, NULL, NULL, NULL),
(16, 'Midi', 'mid', 'mid-dist.png', NULL, 1, NULL, NULL, NULL),
(17, 'QuickTime', 'mov', 'mov-dist.png', NULL, 1, NULL, NULL, NULL),
(18, 'MP3', 'mp3', 'mp3-dist.png', NULL, 1, NULL, NULL, NULL),
(19, 'MPEG', 'mpg', 'mpg-dist.png', NULL, 1, NULL, NULL, NULL),
(20, 'Ogg Vorbis', 'ogg', 'ogg-dist.png', NULL, 1, NULL, NULL, NULL),
(21, 'PDF', 'pdf', 'pdf-dist.png', NULL, 1, NULL, NULL, NULL),
(22, 'PowerPoint', 'ppt', 'ppt-dist.png', NULL, 1, NULL, NULL, NULL),
(23, 'PostScript', 'ps', 'ps-dist.png', NULL, 1, NULL, NULL, NULL),
(24, 'QuickTime', 'qt', 'qt-dist.png', NULL, 1, NULL, NULL, NULL),
(25, 'RealAudio', 'ra', 'ra-dist.png', NULL, 1, NULL, NULL, NULL),
(26, 'RealAudio', 'ram', 'ram-dist.png', NULL, 1, NULL, NULL, NULL),
(27, 'RealAudio', 'rm', 'rm-dist.png', NULL, 1, NULL, NULL, NULL),
(28, 'RTF', 'rtf', 'rtf-dist.png', NULL, 1, NULL, NULL, NULL),
(29, 'StarOffice', 'sdd', 'sdd-dist.png', NULL, 1, NULL, NULL, NULL),
(30, 'StarOffice', 'sdw', 'sdw-dist.png', NULL, 1, NULL, NULL, NULL),
(31, 'Stuffit', 'sit', 'sit-dist.png', NULL, 1, NULL, NULL, NULL),
(32, 'OpenOffice Impress', 'sxi', 'sxi-dist.png', NULL, 1, NULL, NULL, NULL),
(33, 'OpenOffice', 'sxw', 'sxw-dist.png', NULL, 1, NULL, NULL, NULL),
(34, 'Flash', 'swf', 'swf-dist.png', NULL, 1, NULL, NULL, NULL),
(35, 'TGZ', 'tgz', 'tgz-dist.png', NULL, 1, NULL, NULL, NULL),
(36, 'texte', 'txt', 'txt-dist.png', NULL, 1, NULL, NULL, NULL),
(37, 'WAV', 'wav', 'wav-dist.png', NULL, 1, NULL, NULL, NULL),
(38, 'Excel', 'xls', 'xls-dist.png', NULL, 1, NULL, NULL, NULL),
(39, 'XML', 'xml', 'xml-dist.png', NULL, 1, NULL, NULL, NULL),
(40, 'Windows Media', 'wmv', 'wmv-dist.png', NULL, 1, NULL, NULL, NULL),
(41, 'Zip', 'zip', 'zip-dist.png', NULL, 1, NULL, NULL, NULL),
(42, 'MNG', 'mng', '', NULL, 1, NULL, NULL, NULL),
(43, 'Adobe Illustrator', 'ai', 'ai-dist.png', NULL, 1, NULL, NULL, NULL),
(44, 'C source', 'c', 'c-dist.png', NULL, 1, NULL, NULL, NULL),
(45, 'Debian', 'deb', 'deb-dist.png', NULL, 1, NULL, NULL, NULL),
(46, 'DVI', 'dvi', 'dvi-dist.png', NULL, 1, NULL, NULL, NULL),
(47, 'C header', 'h', 'h-dist.png', NULL, 1, NULL, NULL, NULL),
(48, 'Pascal', 'pas', 'pas-dist.png', NULL, 1, NULL, NULL, NULL),
(49, 'RedHat/Mandrake/SuSE', 'rpm', 'rpm-dist.png', NULL, 1, NULL, NULL, NULL),
(50, 'OpenOffice Calc', 'sxc', 'sxc-dist.png', NULL, 1, NULL, NULL, NULL),
(51, 'LaTeX', 'tex', 'tex-dist.png', NULL, 1, NULL, NULL, NULL),
(52, 'GIMP multi-layer', 'xcf', 'xcf-dist.png', NULL, 1, NULL, NULL, NULL),
(53, 'JPEG', 'jpeg', 'jpg-dist.png', NULL, 1, NULL, NULL, NULL),
(54, 'Oasis Open Office Writer', 'odt', 'odt-dist.png', NULL, 1, NULL, NULL, NULL),
(55, 'Oasis Open Office Calc', 'ods', 'ods-dist.png', NULL, 1, NULL, NULL, NULL),
(56, 'Oasis Open Office Impress', 'odp', 'odp-dist.png', NULL, 1, NULL, NULL, NULL),
(57, 'Oasis Open Office Impress Template', 'otp', 'odp-dist.png', NULL, 1, NULL, NULL, NULL),
(58, 'Oasis Open Office Writer Template', 'ott', 'odt-dist.png', NULL, 1, NULL, NULL, NULL),
(59, 'Oasis Open Office Calc Template', 'ots', 'ods-dist.png', NULL, 1, NULL, NULL, NULL),
(60, 'Oasis Open Office Math', 'odf', 'odf-dist.png', NULL, 1, NULL, NULL, NULL),
(61, 'Oasis Open Office Draw', 'odg', 'odg-dist.png', NULL, 1, NULL, NULL, NULL),
(62, 'Oasis Open Office Draw Template', 'otg', 'odg-dist.png', NULL, 1, NULL, NULL, NULL),
(63, 'Oasis Open Office Base', 'odb', 'odb-dist.png', NULL, 1, NULL, NULL, NULL),
(64, 'Oasis Open Office HTML', 'oth', 'oth-dist.png', NULL, 1, NULL, NULL, NULL),
(65, 'Oasis Open Office Writer Master', 'odm', 'odm-dist.png', NULL, 1, NULL, NULL, NULL),
(66, 'Oasis Open Office Chart', 'odc', '', NULL, 1, NULL, NULL, NULL),
(67, 'Oasis Open Office Image', 'odi', '', NULL, 1, NULL, NULL, NULL),
(68, 'Word XML', 'docx', 'doc-dist.png', NULL, 1, NULL, NULL, NULL),
(69, 'Excel XML', 'xlsx', 'xls-dist.png', NULL, 1, NULL, NULL, NULL),
(70, 'PowerPoint XML', 'pptx', 'ppt-dist.png', NULL, 1, NULL, NULL, NULL),
(71, 'Comma-Separated Values', 'csv', 'csv-dist.png', NULL, 1, NULL, NULL, NULL),
(72, 'Scalable Vector Graphics', 'svg', 'svg-dist.png', NULL, 1, NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_domainrecords`;
CREATE TABLE `glpi_domainrecords` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `data_obj` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `domains_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `domainrecordtypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ttl` int(11) NOT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_domainrecordtypes`;
CREATE TABLE `glpi_domainrecordtypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `fields` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_domainrecordtypes` (`id`, `name`, `fields`, `entities_id`, `is_recursive`, `comment`) VALUES
(1, 'A', '[]', 0, 1, 'Host address'),
(2, 'AAAA', '[]', 0, 1, 'IPv6 host address'),
(3, 'ALIAS', '[]', 0, 1, 'Auto resolved alias'),
(4, 'CNAME', '[{\"key\":\"target\",\"label\":\"Target\",\"placeholder\":\"sip.example.com.\",\"is_fqdn\":true}]', 0, 1, 'Canonical name for an alias'),
(5, 'MX', '[{\"key\":\"priority\",\"label\":\"Priority\",\"placeholder\":\"10\"},{\"key\":\"server\",\"label\":\"Server\",\"placeholder\":\"mail.example.com.\",\"is_fqdn\":true}]', 0, 1, 'Mail eXchange'),
(6, 'NS', '[]', 0, 1, 'Name Server'),
(7, 'PTR', '[]', 0, 1, 'Pointer'),
(8, 'SOA', '[{\"key\":\"primary_name_server\",\"label\":\"Primary name server\",\"placeholder\":\"ns1.example.com.\",\"is_fqdn\":true},{\"key\":\"primary_contact\",\"label\":\"Primary contact\",\"placeholder\":\"admin.example.com.\",\"is_fqdn\":true},{\"key\":\"serial\",\"label\":\"Serial\",\"placeholder\":\"2020010101\"},{\"key\":\"zone_refresh_timer\",\"label\":\"Zone refresh timer\",\"placeholder\":\"86400\"},{\"key\":\"failed_refresh_retry_timer\",\"label\":\"Failed refresh retry timer\",\"placeholder\":\"7200\"},{\"key\":\"zone_expiry_timer\",\"label\":\"Zone expiry timer\",\"placeholder\":\"1209600\"},{\"key\":\"minimum_ttl\",\"label\":\"Minimum TTL\",\"placeholder\":\"300\"}]', 0, 1, 'Start Of Authority'),
(9, 'SRV', '[{\"key\":\"priority\",\"label\":\"Priority\",\"placeholder\":\"0\"},{\"key\":\"weight\",\"label\":\"Weight\",\"placeholder\":\"10\"},{\"key\":\"port\",\"label\":\"Port\",\"placeholder\":\"5060\"},{\"key\":\"target\",\"label\":\"Target\",\"placeholder\":\"sip.example.com.\",\"is_fqdn\":true}]', 0, 1, 'Location of service'),
(10, 'TXT', '[{\"key\":\"data\",\"label\":\"TXT record data\",\"placeholder\":\"Your TXT record data\",\"quote_value\":true}]', 0, 1, 'Descriptive text'),
(11, 'CAA', '[{\"key\":\"flag\",\"label\":\"Flag\",\"placeholder\":\"0\"},{\"key\":\"tag\",\"label\":\"Tag\",\"placeholder\":\"issue\"},{\"key\":\"value\",\"label\":\"Value\",\"placeholder\":\"letsencrypt.org\",\"quote_value\":true}]', 0, 1, 'Certification Authority Authorization');

DROP TABLE IF EXISTS `glpi_domainrelations`;
CREATE TABLE `glpi_domainrelations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_domainrelations` (`id`, `name`, `entities_id`, `is_recursive`, `comment`) VALUES
(1, 'Belongs', 0, 1, 'Item belongs to domain'),
(2, 'Manage', 0, 1, 'Item manages domain');

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `domaintypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_expiration` timestamp NULL DEFAULT NULL,
  `date_domaincreation` timestamp NULL DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_domains_items`;
CREATE TABLE `glpi_domains_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `domains_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `domainrelations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_domaintypes`;
CREATE TABLE `glpi_domaintypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  `field` varchar(100) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_enclosuremodels`;
CREATE TABLE `glpi_enclosuremodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_enclosures`;
CREATE TABLE `glpi_enclosures` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `enclosuremodels_id` int(10) UNSIGNED DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `orientation` tinyint(4) DEFAULT NULL,
  `power_supplies` tinyint(4) NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to states (id)',
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED DEFAULT 0,
  `completename` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `sons_cache` longtext DEFAULT NULL,
  `ancestors_cache` longtext DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `admin_email_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `from_email_name` varchar(255) DEFAULT NULL,
  `noreply_email` varchar(255) DEFAULT NULL,
  `noreply_email_name` varchar(255) DEFAULT NULL,
  `replyto_email` varchar(255) DEFAULT NULL,
  `replyto_email_name` varchar(255) DEFAULT NULL,
  `notification_subject_tag` varchar(255) DEFAULT NULL,
  `ldap_dn` varchar(255) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `authldaps_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mail_domain` varchar(255) DEFAULT NULL,
  `entity_ldapfilter` text DEFAULT NULL,
  `mailing_signature` text DEFAULT NULL,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT -2,
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT -2,
  `use_licenses_alert` int(11) NOT NULL DEFAULT -2,
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT -2,
  `use_certificates_alert` int(11) NOT NULL DEFAULT -2,
  `send_certificates_alert_before_delay` int(11) NOT NULL DEFAULT -2,
  `certificates_alert_repeat_interval` int(11) NOT NULL DEFAULT -2,
  `use_contracts_alert` int(11) NOT NULL DEFAULT -2,
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT -2,
  `use_infocoms_alert` int(11) NOT NULL DEFAULT -2,
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT -2,
  `use_reservations_alert` int(11) NOT NULL DEFAULT -2,
  `use_domains_alert` int(11) NOT NULL DEFAULT -2,
  `send_domains_alert_close_expiries_delay` int(11) NOT NULL DEFAULT -2,
  `send_domains_alert_expired_delay` int(11) NOT NULL DEFAULT -2,
  `autoclose_delay` int(11) NOT NULL DEFAULT -2,
  `autopurge_delay` int(11) NOT NULL DEFAULT -10,
  `notclosed_delay` int(11) NOT NULL DEFAULT -2,
  `calendars_strategy` tinyint(4) NOT NULL DEFAULT -2,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `auto_assign_mode` int(11) NOT NULL DEFAULT -2,
  `tickettype` int(11) NOT NULL DEFAULT -2,
  `max_closedate` timestamp NULL DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT -2,
  `inquest_rate` int(11) NOT NULL DEFAULT 0,
  `inquest_delay` int(11) NOT NULL DEFAULT -10,
  `inquest_URL` varchar(255) DEFAULT NULL,
  `autofill_warranty_date` varchar(255) NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) NOT NULL DEFAULT '-2',
  `tickettemplates_strategy` tinyint(4) NOT NULL DEFAULT -2,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `changetemplates_strategy` tinyint(4) NOT NULL DEFAULT -2,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `problemtemplates_strategy` tinyint(4) NOT NULL DEFAULT -2,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_strategy_software` tinyint(4) NOT NULL DEFAULT -2,
  `entities_id_software` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `default_contract_alert` int(11) NOT NULL DEFAULT -2,
  `default_infocom_alert` int(11) NOT NULL DEFAULT -2,
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT -2,
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT -2,
  `delay_send_emails` int(11) NOT NULL DEFAULT -2,
  `is_notif_enable_default` int(11) NOT NULL DEFAULT -2,
  `inquest_duration` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `autofill_decommission_date` varchar(255) NOT NULL DEFAULT '-2',
  `suppliers_as_private` int(11) NOT NULL DEFAULT -2,
  `anonymize_support_agents` int(11) NOT NULL DEFAULT -2,
  `display_users_initials` int(11) NOT NULL DEFAULT -2,
  `contracts_strategy_default` tinyint(4) NOT NULL DEFAULT -2,
  `contracts_id_default` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `enable_custom_css` int(11) NOT NULL DEFAULT -2,
  `custom_css_code` text DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `altitude` varchar(255) DEFAULT NULL,
  `transfers_strategy` tinyint(4) NOT NULL DEFAULT -2,
  `transfers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `agent_base_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_entities` (`id`, `name`, `entities_id`, `completename`, `comment`, `level`, `sons_cache`, `ancestors_cache`, `registration_number`, `address`, `postcode`, `town`, `state`, `country`, `website`, `phonenumber`, `fax`, `email`, `admin_email`, `admin_email_name`, `from_email`, `from_email_name`, `noreply_email`, `noreply_email_name`, `replyto_email`, `replyto_email_name`, `notification_subject_tag`, `ldap_dn`, `tag`, `authldaps_id`, `mail_domain`, `entity_ldapfilter`, `mailing_signature`, `cartridges_alert_repeat`, `consumables_alert_repeat`, `use_licenses_alert`, `send_licenses_alert_before_delay`, `use_certificates_alert`, `send_certificates_alert_before_delay`, `certificates_alert_repeat_interval`, `use_contracts_alert`, `send_contracts_alert_before_delay`, `use_infocoms_alert`, `send_infocoms_alert_before_delay`, `use_reservations_alert`, `use_domains_alert`, `send_domains_alert_close_expiries_delay`, `send_domains_alert_expired_delay`, `autoclose_delay`, `autopurge_delay`, `notclosed_delay`, `calendars_strategy`, `calendars_id`, `auto_assign_mode`, `tickettype`, `max_closedate`, `inquest_config`, `inquest_rate`, `inquest_delay`, `inquest_URL`, `autofill_warranty_date`, `autofill_use_date`, `autofill_buy_date`, `autofill_delivery_date`, `autofill_order_date`, `tickettemplates_strategy`, `tickettemplates_id`, `changetemplates_strategy`, `changetemplates_id`, `problemtemplates_strategy`, `problemtemplates_id`, `entities_strategy_software`, `entities_id_software`, `default_contract_alert`, `default_infocom_alert`, `default_cartridges_alarm_threshold`, `default_consumables_alarm_threshold`, `delay_send_emails`, `is_notif_enable_default`, `inquest_duration`, `date_mod`, `date_creation`, `autofill_decommission_date`, `suppliers_as_private`, `anonymize_support_agents`, `display_users_initials`, `contracts_strategy_default`, `contracts_id_default`, `enable_custom_css`, `custom_css_code`, `latitude`, `longitude`, `altitude`, `transfers_strategy`, `transfers_id`, `agent_base_url`) VALUES
(0, 'Entité racine', NULL, 'Entité racine', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2, -2, -2, -10, -10, 0, 0, 0, -10, 1, NULL, 1, 0, 0, NULL, '0', '0', '0', '0', '0', 0, 1, 0, 1, 0, 1, -10, 0, 0, 0, 10, 10, 0, 1, 0, NULL, NULL, '0', 0, 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 'http://192.168.0.50');

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `reminders_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(10) UNSIGNED NOT NULL,
  `rssfeeds_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_events` (`id`, `items_id`, `type`, `date`, `service`, `level`, `message`) VALUES
(1, 0, 'system', '2023-06-07 20:37:52', 'login', 3, 'Connexion échouée de  depuis l\'IP 192.168.0.20'),
(2, 0, 'system', '2023-06-07 20:37:56', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(3, 0, 'system', '2023-06-07 20:46:12', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(4, 0, 'system', '2023-06-07 20:46:50', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(5, 0, 'system', '2023-06-07 20:49:38', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(6, 3, 'users', '2023-06-07 20:50:02', 'setup', 5, 'glpi met à jour un élément'),
(7, 3, 'users', '2023-06-07 20:50:08', 'setup', 5, 'glpi met à jour un élément'),
(8, 2, 'users', '2023-06-07 20:50:14', 'setup', 5, 'glpi met à jour un élément'),
(9, 3, 'users', '2023-06-07 20:50:19', 'setup', 5, 'glpi met à jour un élément'),
(10, 4, 'users', '2023-06-07 20:50:23', 'setup', 5, 'glpi met à jour un élément'),
(11, 5, 'users', '2023-06-07 20:50:27', 'setup', 5, 'glpi met à jour un élément'),
(12, 0, 'system', '2023-06-07 20:50:35', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(13, 0, 'Plugin', '2023-06-07 21:08:19', 'setup', 3, 'Le plugin « GLPI Inventory » a été installé par glpi (2).'),
(14, 0, 'Plugin', '2023-06-07 21:14:10', 'setup', 3, 'Le plugin « GLPI Inventory » a été activé par glpi (2).'),
(15, 2, 'users', '2023-06-07 21:24:54', 'setup', 5, 'glpi met à jour un élément'),
(16, 0, 'Plugin', '2023-06-07 21:28:10', 'setup', 3, 'Le plugin « Form Creator » a été installé par glpi (2).'),
(17, 0, 'Plugin', '2023-06-07 21:28:14', 'setup', 3, 'Le plugin « Form Creator » a été activé par glpi (2).'),
(18, 0, 'Plugin', '2023-06-07 21:28:18', 'setup', 3, 'Le plugin « Form Creator » a été désinstallé par glpi (2).'),
(19, 1, 'datacenters', '2023-06-07 21:34:10', 'inventory', 4, 'glpi ajoute l\'élément Paris'),
(20, 2, 'datacenters', '2023-06-07 21:34:22', 'inventory', 4, 'glpi ajoute l\'élément Lyon'),
(21, 1, 'Location', '2023-06-07 21:36:29', 'setup', 4, 'glpi ajoute l\'élément Paris'),
(22, 2, 'Location', '2023-06-07 21:36:37', 'setup', 4, 'glpi ajoute l\'élément Lyon'),
(23, 2, 'datacenters', '2023-06-07 21:36:49', 'inventory', 4, 'glpi met à jour un élément'),
(24, 1, 'datacenters', '2023-06-07 21:36:54', 'inventory', 4, 'glpi met à jour un élément'),
(25, 3, 'Location', '2023-06-07 21:37:25', 'setup', 4, 'glpi ajoute l\'élément Gaillard'),
(26, 2, 'Location', '2023-06-07 21:37:32', 'setup', 4, 'glpi met à jour un élément'),
(27, 2, 'users', '2023-06-07 21:39:57', 'setup', 5, 'glpi met à jour un élément'),
(28, 2, 'users', '2023-06-07 21:41:21', 'setup', 5, 'glpi met à jour un élément'),
(29, 2, 'users', '2023-06-07 21:41:56', 'setup', 5, 'glpi met à jour un élément'),
(30, 1, 'ITILCategory', '2023-06-07 21:44:52', 'setup', 4, 'glpi ajoute l\'élément Panne'),
(31, 2, 'ITILCategory', '2023-06-07 21:44:59', 'setup', 4, 'glpi ajoute l\'élément Matériel'),
(32, 3, 'ITILCategory', '2023-06-07 21:45:05', 'setup', 4, 'glpi ajoute l\'élément Casque'),
(33, 1, 'ITILCategory', '2023-06-07 21:45:17', 'setup', 4, 'glpi met à jour un élément'),
(34, 0, 'system', '2023-06-07 23:17:04', 'login', 3, 'Connexion échouée de glpi depuis l\'IP 192.168.0.20'),
(35, 0, 'system', '2023-06-07 23:17:11', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(36, 0, 'system', '2023-06-07 23:18:25', 'login', 3, 'Connexion échouée de glpi depuis l\'IP 192.168.0.20'),
(37, 0, 'system', '2023-06-07 23:18:28', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(38, 0, 'system', '2023-06-07 23:18:33', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(39, 0, 'system', '2023-06-07 23:18:39', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(40, 0, 'system', '2023-06-07 23:18:45', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(41, 0, 'system', '2023-06-07 23:18:52', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(42, 0, 'system', '2023-06-07 23:21:44', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(43, 0, 'system', '2023-06-07 23:23:23', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(44, 0, 'system', '2023-06-07 23:24:27', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(45, 0, 'system', '2023-06-07 23:24:30', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(46, 0, 'system', '2023-06-07 23:25:18', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(47, 0, 'system', '2023-06-07 23:25:28', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(48, 0, 'system', '2023-06-07 23:29:45', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(49, 0, 'system', '2023-06-07 23:46:33', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(50, 0, 'system', '2023-06-07 23:47:06', 'login', 3, 'glpi se connecte depuis l\'IP 192.168.0.20'),
(51, 2, 'APIClient', '2023-06-08 00:00:47', 'setup', 4, 'glpi ajoute l\'élément marc');

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `itemtype` varchar(255) NOT NULL DEFAULT '',
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `itemtype` varchar(255) NOT NULL DEFAULT '',
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fields` text DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `action_refuse` tinyint(4) NOT NULL DEFAULT 0,
  `action_notify` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores field unicity criterias' ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_filesystems` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'ext', NULL, NULL, NULL),
(2, 'ext2', NULL, NULL, NULL),
(3, 'ext3', NULL, NULL, NULL),
(4, 'ext4', NULL, NULL, NULL),
(5, 'FAT', NULL, NULL, NULL),
(6, 'FAT32', NULL, NULL, NULL),
(7, 'VFAT', NULL, NULL, NULL),
(8, 'HFS', NULL, NULL, NULL),
(9, 'HPFS', NULL, NULL, NULL),
(10, 'HTFS', NULL, NULL, NULL),
(11, 'JFS', NULL, NULL, NULL),
(12, 'JFS2', NULL, NULL, NULL),
(13, 'NFS', NULL, NULL, NULL),
(14, 'NTFS', NULL, NULL, NULL),
(15, 'ReiserFS', NULL, NULL, NULL),
(16, 'SMBFS', NULL, NULL, NULL),
(17, 'UDF', NULL, NULL, NULL),
(18, 'UFS', NULL, NULL, NULL),
(19, 'XFS', NULL, NULL, NULL),
(20, 'ZFS', NULL, NULL, NULL),
(21, 'APFS', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `fqdn` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `ldap_field` varchar(255) DEFAULT NULL,
  `ldap_value` text DEFAULT NULL,
  `ldap_group_dn` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `is_requester` tinyint(4) NOT NULL DEFAULT 1,
  `is_watcher` tinyint(4) NOT NULL DEFAULT 1,
  `is_assign` tinyint(4) NOT NULL DEFAULT 1,
  `is_task` tinyint(4) NOT NULL DEFAULT 1,
  `is_notify` tinyint(4) NOT NULL DEFAULT 1,
  `is_itemgroup` tinyint(4) NOT NULL DEFAULT 1,
  `is_usergroup` tinyint(4) NOT NULL DEFAULT 1,
  `is_manager` tinyint(4) NOT NULL DEFAULT 1,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `reminders_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(10) UNSIGNED NOT NULL,
  `rssfeeds_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_manager` tinyint(4) NOT NULL DEFAULT 0,
  `is_userdelegate` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_imageformats`;
CREATE TABLE `glpi_imageformats` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_imageresolutions`;
CREATE TABLE `glpi_imageresolutions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_video` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_impactcompounds`;
CREATE TABLE `glpi_impactcompounds` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT '',
  `color` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_impactcontexts`;
CREATE TABLE `glpi_impactcontexts` (
  `id` int(10) UNSIGNED NOT NULL,
  `positions` mediumtext NOT NULL,
  `zoom` float NOT NULL DEFAULT 0,
  `pan_x` float NOT NULL DEFAULT 0,
  `pan_y` float NOT NULL DEFAULT 0,
  `impact_color` varchar(255) NOT NULL DEFAULT '',
  `depends_color` varchar(255) NOT NULL DEFAULT '',
  `impact_and_depends_color` varchar(255) NOT NULL DEFAULT '',
  `show_depends` tinyint(4) NOT NULL DEFAULT 1,
  `show_impact` tinyint(4) NOT NULL DEFAULT 1,
  `max_depth` int(11) NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_impactitems`;
CREATE TABLE `glpi_impactitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(255) NOT NULL DEFAULT '',
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `parent_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `impactcontexts_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_slave` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_impactrelations`;
CREATE TABLE `glpi_impactrelations` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype_source` varchar(255) NOT NULL DEFAULT '',
  `items_id_source` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype_impacted` varchar(255) NOT NULL DEFAULT '',
  `items_id_impacted` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT 0,
  `warranty_info` varchar(255) DEFAULT NULL,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `order_number` varchar(255) DEFAULT NULL,
  `delivery_number` varchar(255) DEFAULT NULL,
  `immo_number` varchar(255) DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `warranty_value` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `sink_time` int(11) NOT NULL DEFAULT 0,
  `sink_type` int(11) NOT NULL DEFAULT 0,
  `sink_coeff` float NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `bill` varchar(255) DEFAULT NULL,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `alert` int(11) NOT NULL DEFAULT 0,
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `decommission_date` timestamp NULL DEFAULT NULL,
  `businesscriticities_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_interfacetypes` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'IDE', NULL, NULL, NULL),
(2, 'SATA', NULL, NULL, NULL),
(3, 'SCSI', NULL, NULL, NULL),
(4, 'USB', NULL, NULL, NULL),
(5, 'AGP', NULL, NULL, NULL),
(6, 'PCI', NULL, NULL, NULL),
(7, 'PCIe', NULL, NULL, NULL),
(8, 'PCI-X', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `version` tinyint(3) UNSIGNED DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `binary_0` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `binary_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `binary_2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `binary_3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `mainitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mainitemtype` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(10) UNSIGNED NOT NULL,
  `ipaddresses_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ipnetworks_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `ipnetworks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `addressable` tinyint(4) NOT NULL DEFAULT 0,
  `version` tinyint(3) UNSIGNED DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `address_0` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `address_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `address_2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `address_3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `netmask` varchar(40) DEFAULT NULL,
  `netmask_0` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `netmask_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `netmask_2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `netmask_3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `gateway` varchar(40) DEFAULT NULL,
  `gateway_0` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `gateway_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `gateway_2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `gateway_3` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(10) UNSIGNED NOT NULL,
  `ipnetworks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `vlans_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_clusters`;
CREATE TABLE `glpi_items_clusters` (
  `id` int(10) UNSIGNED NOT NULL,
  `clusters_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicebatteries`;
CREATE TABLE `glpi_items_devicebatteries` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicebatteries_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturing_date` date DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `real_capacity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicecameras`;
CREATE TABLE `glpi_items_devicecameras` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicecameras_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicecameras_imageformats`;
CREATE TABLE `glpi_items_devicecameras_imageformats` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_devicecameras_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `imageformats_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicecameras_imageresolutions`;
CREATE TABLE `glpi_items_devicecameras_imageresolutions` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_devicecameras_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `imageresolutions_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicecases_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicecontrols_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicedrives_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicefirmwares`;
CREATE TABLE `glpi_items_devicefirmwares` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicefirmwares_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicegenerics`;
CREATE TABLE `glpi_items_devicegenerics` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicegenerics_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicegraphiccards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `memory` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `deviceharddrives_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `capacity` int(11) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicememories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `size` int(11) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicemotherboards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicenetworkcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mac` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicepcis_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicepowersupplies_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `deviceprocessors_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `frequency` int(11) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicesensors`;
CREATE TABLE `glpi_items_devicesensors` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicesensors_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicesimcards`;
CREATE TABLE `glpi_items_devicesimcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to various table, according to itemtype (id)',
  `itemtype` varchar(100) NOT NULL,
  `devicesimcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `lines_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `pin` varchar(255) NOT NULL DEFAULT '',
  `pin2` varchar(255) NOT NULL DEFAULT '',
  `puk` varchar(255) NOT NULL DEFAULT '',
  `puk2` varchar(255) NOT NULL DEFAULT '',
  `msin` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `devicesoundcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `busID` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_disks`;
CREATE TABLE `glpi_items_disks` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `mountpoint` varchar(255) DEFAULT NULL,
  `filesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `totalsize` int(11) NOT NULL DEFAULT 0,
  `freesize` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `encryption_status` int(11) NOT NULL DEFAULT 0,
  `encryption_tool` varchar(255) DEFAULT NULL,
  `encryption_algorithm` varchar(255) DEFAULT NULL,
  `encryption_type` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_enclosures`;
CREATE TABLE `glpi_items_enclosures` (
  `id` int(10) UNSIGNED NOT NULL,
  `enclosures_id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_kanbans`;
CREATE TABLE `glpi_items_kanbans` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL,
  `state` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_operatingsystems`;
CREATE TABLE `glpi_items_operatingsystems` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `operatingsystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `operatingsystemversions_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `operatingsystemservicepacks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `operatingsystemarchitectures_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `operatingsystemkernelversions_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `license_number` varchar(255) DEFAULT NULL,
  `licenseid` varchar(255) DEFAULT NULL,
  `operatingsystemeditions_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `install_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_racks`;
CREATE TABLE `glpi_items_racks` (
  `id` int(10) UNSIGNED NOT NULL,
  `racks_id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL,
  `orientation` tinyint(4) DEFAULT NULL,
  `bgcolor` varchar(7) DEFAULT NULL,
  `hpos` tinyint(4) NOT NULL DEFAULT 0,
  `is_reserved` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_remotemanagements`;
CREATE TABLE `glpi_items_remotemanagements` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `remoteid` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_softwarelicenses`;
CREATE TABLE `glpi_items_softwarelicenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `softwarelicenses_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_softwareversions`;
CREATE TABLE `glpi_items_softwareversions` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `softwareversions_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted_item` tinyint(4) NOT NULL DEFAULT 0,
  `is_template_item` tinyint(4) NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_install` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(255) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `itilcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `completename` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `knowbaseitemcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `code` varchar(255) DEFAULT NULL,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `is_helpdeskvisible` tinyint(4) NOT NULL DEFAULT 1,
  `tickettemplates_id_incident` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickettemplates_id_demand` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_incident` int(11) NOT NULL DEFAULT 1,
  `is_request` int(11) NOT NULL DEFAULT 1,
  `is_problem` int(11) NOT NULL DEFAULT 1,
  `is_change` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_itilcategories` (`id`, `entities_id`, `is_recursive`, `itilcategories_id`, `name`, `completename`, `comment`, `level`, `knowbaseitemcategories_id`, `users_id`, `groups_id`, `code`, `ancestors_cache`, `sons_cache`, `is_helpdeskvisible`, `tickettemplates_id_incident`, `tickettemplates_id_demand`, `changetemplates_id`, `problemtemplates_id`, `is_incident`, `is_request`, `is_problem`, `is_change`, `date_mod`, `date_creation`) VALUES
(1, 0, 0, 0, 'Pannes', 'Pannes', '', 1, 0, 0, 0, '', '[]', '{\"1\":1,\"2\":2,\"3\":3}', 1, 0, 0, 0, 0, 1, 1, 1, 1, '2023-06-07 21:45:17', '2023-06-07 21:44:52'),
(2, 0, 0, 1, 'Matériel', 'Pannes > Matériel', '', 2, 0, 0, 0, '', '{\"1\":1}', NULL, 1, 0, 0, 0, 0, 1, 1, 1, 1, '2023-06-07 21:44:59', '2023-06-07 21:44:59'),
(3, 0, 0, 2, 'Casque', 'Pannes > Matériel > Casque', '', 3, 0, 0, 0, '', '{\"1\":1,\"2\":2}', NULL, 1, 0, 0, 0, 0, 1, 1, 1, 1, '2023-06-07 21:45:05', '2023-06-07 21:45:05');

DROP TABLE IF EXISTS `glpi_itilfollowups`;
CREATE TABLE `glpi_itilfollowups` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_editor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `is_private` tinyint(4) NOT NULL DEFAULT 0,
  `requesttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0,
  `sourceitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sourceof_items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_itilfollowuptemplates`;
CREATE TABLE `glpi_itilfollowuptemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `requesttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_private` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_itilsolutions`;
CREATE TABLE `glpi_itilsolutions` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `solutiontypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `solutiontype_name` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_approval` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_name` varchar(255) DEFAULT NULL,
  `users_id_editor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_approval` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_name_approval` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `itilfollowups_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Followup reference on reject or approve a solution'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_itils_projects`;
CREATE TABLE `glpi_itils_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL DEFAULT '',
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `knowbaseitemcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `completename` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `sons_cache` longtext DEFAULT NULL,
  `ancestors_cache` longtext DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` text DEFAULT NULL,
  `answer` longtext DEFAULT NULL,
  `is_faq` tinyint(4) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `view` int(11) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `begin_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_comments`;
CREATE TABLE `glpi_knowbaseitems_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `language` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `parent_comment_id` int(10) UNSIGNED DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_items`;
CREATE TABLE `glpi_knowbaseitems_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitems_knowbaseitemcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `knowbaseitemcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_revisions`;
CREATE TABLE `glpi_knowbaseitems_revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL,
  `revision` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `answer` longtext DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(10) UNSIGNED NOT NULL,
  `knowbaseitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `language` varchar(10) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `answer` longtext DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_lineoperators`;
CREATE TABLE `glpi_lineoperators` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `mcc` int(11) DEFAULT NULL,
  `mnc` int(11) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_lines`;
CREATE TABLE `glpi_lines` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `caller_num` varchar(255) NOT NULL DEFAULT '',
  `caller_name` varchar(255) NOT NULL DEFAULT '',
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `lineoperators_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `linetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_linetypes`;
CREATE TABLE `glpi_linetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 1,
  `name` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `open_window` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `links_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `building` varchar(255) DEFAULT NULL,
  `room` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `altitude` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_locations` (`id`, `entities_id`, `is_recursive`, `name`, `locations_id`, `completename`, `comment`, `level`, `ancestors_cache`, `sons_cache`, `address`, `postcode`, `town`, `state`, `country`, `building`, `room`, `latitude`, `longitude`, `altitude`, `date_mod`, `date_creation`) VALUES
(1, 0, 0, 'Paris', 0, 'Paris', '', 1, '[]', '{\"1\":1}', '', '', 'Paris', 'France', 'France', '', '', '', '', '', '2023-06-07 21:36:29', '2023-06-07 21:36:29'),
(2, 0, 0, 'Lyon', 0, 'Lyon', '', 1, '[]', '{\"2\":2}', '', '', 'Lyon', '', 'France', '', '', '', '', '', '2023-06-07 21:37:32', '2023-06-07 21:36:37'),
(3, 0, 0, 'Gaillard', 0, 'Gaillard', '', 1, '[]', NULL, '10 allée des Cyclamens', '', 'Gaillard', '', 'France', '', '', '', '', '', '2023-06-07 21:37:25', '2023-06-07 21:37:25');

DROP TABLE IF EXISTS `glpi_lockedfields`;
CREATE TABLE `glpi_lockedfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `field` varchar(50) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_global` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL DEFAULT '',
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype_link` varchar(100) NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT 0 COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) DEFAULT NULL,
  `new_value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_logs` (`id`, `itemtype`, `items_id`, `itemtype_link`, `linked_action`, `user_name`, `date_mod`, `id_search_option`, `old_value`, `new_value`) VALUES
(1, 'RuleImportAsset', 1, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(2, 'RuleImportAsset', 1, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Is partial is Yes (1)'),
(3, 'RuleCriteria', 1, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(4, 'RuleImportAsset', 1, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (2)'),
(5, 'RuleCriteria', 2, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(6, 'RuleImportAsset', 1, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (1)'),
(7, 'RuleAction', 1, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(8, 'RuleImportAsset', 2, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(9, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (3)'),
(10, 'RuleCriteria', 3, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(11, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (4)'),
(12, 'RuleCriteria', 4, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(13, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (5)'),
(14, 'RuleCriteria', 5, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(15, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port number is already present Yes (6)'),
(16, 'RuleCriteria', 6, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(17, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port number exists Yes (7)'),
(18, 'RuleCriteria', 7, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(19, 'RuleImportAsset', 2, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'General &#62; Restrict criteria to same network port Yes Yes (8)'),
(20, 'RuleCriteria', 8, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(21, 'RuleImportAsset', 2, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (2)'),
(22, 'RuleAction', 2, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(23, 'RuleImportAsset', 3, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(24, 'RuleImportAsset', 3, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (9)'),
(25, 'RuleCriteria', 9, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(26, 'RuleImportAsset', 3, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (10)'),
(27, 'RuleCriteria', 10, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(28, 'RuleImportAsset', 3, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (11)'),
(29, 'RuleCriteria', 11, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(30, 'RuleImportAsset', 3, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port number is already present Yes (12)'),
(31, 'RuleCriteria', 12, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(32, 'RuleImportAsset', 3, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port number exists Yes (13)'),
(33, 'RuleCriteria', 13, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(34, 'RuleImportAsset', 3, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (3)'),
(35, 'RuleAction', 3, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(36, 'RuleImportAsset', 4, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(37, 'RuleImportAsset', 4, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (14)'),
(38, 'RuleCriteria', 14, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(39, 'RuleImportAsset', 4, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (15)'),
(40, 'RuleCriteria', 15, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(41, 'RuleImportAsset', 4, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port number exists Yes (16)'),
(42, 'RuleCriteria', 16, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(43, 'RuleImportAsset', 4, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (4)'),
(44, 'RuleAction', 4, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(45, 'RuleImportAsset', 5, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(46, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (17)'),
(47, 'RuleCriteria', 17, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(48, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; IP is already present Yes (18)'),
(49, 'RuleCriteria', 18, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(50, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; IP exists Yes (19)'),
(51, 'RuleCriteria', 19, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(52, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port description is already present Yes (20)'),
(53, 'RuleCriteria', 20, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(54, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port description exists Yes (21)'),
(55, 'RuleCriteria', 21, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(56, 'RuleImportAsset', 5, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'General &#62; Restrict criteria to same network port Yes Yes (22)'),
(57, 'RuleCriteria', 22, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(58, 'RuleImportAsset', 5, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (5)'),
(59, 'RuleAction', 5, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(60, 'RuleImportAsset', 6, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(61, 'RuleImportAsset', 6, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (23)'),
(62, 'RuleCriteria', 23, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(63, 'RuleImportAsset', 6, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; IP is already present Yes (24)'),
(64, 'RuleCriteria', 24, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(65, 'RuleImportAsset', 6, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; IP exists Yes (25)'),
(66, 'RuleCriteria', 25, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(67, 'RuleImportAsset', 6, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port description is already present Yes (26)'),
(68, 'RuleCriteria', 26, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(69, 'RuleImportAsset', 6, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port description exists Yes (27)'),
(70, 'RuleCriteria', 27, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(71, 'RuleImportAsset', 6, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (6)'),
(72, 'RuleAction', 6, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(73, 'RuleImportAsset', 7, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(74, 'RuleImportAsset', 7, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (28)'),
(75, 'RuleCriteria', 28, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(76, 'RuleImportAsset', 7, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; IP exists Yes (29)'),
(77, 'RuleCriteria', 29, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(78, 'RuleImportAsset', 7, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; Port description exists Yes (30)'),
(79, 'RuleCriteria', 30, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(80, 'RuleImportAsset', 7, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (7)'),
(81, 'RuleAction', 7, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(82, 'RuleImportAsset', 8, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(83, 'RuleImportAsset', 8, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (31)'),
(84, 'RuleCriteria', 31, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(85, 'RuleImportAsset', 8, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (32)'),
(86, 'RuleCriteria', 32, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(87, 'RuleImportAsset', 8, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (33)'),
(88, 'RuleCriteria', 33, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(89, 'RuleImportAsset', 8, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'General &#62; Only criteria of this rule in data Yes Yes (34)'),
(90, 'RuleCriteria', 34, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(91, 'RuleImportAsset', 8, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (8)'),
(92, 'RuleAction', 8, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(93, 'RuleImportAsset', 9, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(94, 'RuleImportAsset', 9, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type does not exist Yes (35)'),
(95, 'RuleCriteria', 35, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(96, 'RuleImportAsset', 9, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (36)'),
(97, 'RuleCriteria', 36, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(98, 'RuleImportAsset', 9, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'General &#62; Only criteria of this rule in data Yes Yes (37)'),
(99, 'RuleCriteria', 37, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(100, 'RuleImportAsset', 9, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (9)'),
(101, 'RuleAction', 9, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(102, 'RuleImportAsset', 10, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(103, 'RuleImportAsset', 10, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (38)'),
(104, 'RuleCriteria', 38, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(105, 'RuleImportAsset', 10, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name does not exist Yes (39)'),
(106, 'RuleCriteria', 39, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(107, 'RuleImportAsset', 10, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (10)'),
(108, 'RuleAction', 10, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(109, 'RuleImportAsset', 11, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(110, 'RuleImportAsset', 11, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (40)'),
(111, 'RuleCriteria', 40, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(112, 'RuleImportAsset', 11, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (41)'),
(113, 'RuleCriteria', 41, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(114, 'RuleImportAsset', 11, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (42)'),
(115, 'RuleCriteria', 42, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(116, 'RuleImportAsset', 11, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID is already present Yes (43)'),
(117, 'RuleCriteria', 43, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(118, 'RuleImportAsset', 11, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (44)'),
(119, 'RuleCriteria', 44, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(120, 'RuleImportAsset', 11, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (11)'),
(121, 'RuleAction', 11, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(122, 'RuleImportAsset', 12, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(123, 'RuleImportAsset', 12, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (45)'),
(124, 'RuleCriteria', 45, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(125, 'RuleImportAsset', 12, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (46)'),
(126, 'RuleCriteria', 46, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(127, 'RuleImportAsset', 12, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (47)'),
(128, 'RuleCriteria', 47, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(129, 'RuleImportAsset', 12, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID is empty Yes (48)'),
(130, 'RuleCriteria', 48, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(131, 'RuleImportAsset', 12, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (12)'),
(132, 'RuleAction', 12, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(133, 'RuleImportAsset', 13, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(134, 'RuleImportAsset', 13, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (49)'),
(135, 'RuleCriteria', 49, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(136, 'RuleImportAsset', 13, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (50)'),
(137, 'RuleCriteria', 50, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(138, 'RuleImportAsset', 13, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (51)'),
(139, 'RuleCriteria', 51, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(140, 'RuleImportAsset', 13, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (13)'),
(141, 'RuleAction', 13, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(142, 'RuleImportAsset', 14, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(143, 'RuleImportAsset', 14, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (52)'),
(144, 'RuleCriteria', 52, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(145, 'RuleImportAsset', 14, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (53)'),
(146, 'RuleCriteria', 53, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(147, 'RuleImportAsset', 14, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (54)'),
(148, 'RuleCriteria', 54, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(149, 'RuleImportAsset', 14, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (14)'),
(150, 'RuleAction', 14, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(151, 'RuleImportAsset', 15, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(152, 'RuleImportAsset', 15, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (55)'),
(153, 'RuleCriteria', 55, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(154, 'RuleImportAsset', 15, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID is already present Yes (56)'),
(155, 'RuleCriteria', 56, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(156, 'RuleImportAsset', 15, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (57)'),
(157, 'RuleCriteria', 57, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(158, 'RuleImportAsset', 15, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (15)'),
(159, 'RuleAction', 15, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(160, 'RuleImportAsset', 16, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(161, 'RuleImportAsset', 16, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (58)'),
(162, 'RuleCriteria', 58, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(163, 'RuleImportAsset', 16, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (59)'),
(164, 'RuleCriteria', 59, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(165, 'RuleImportAsset', 16, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (60)'),
(166, 'RuleCriteria', 60, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(167, 'RuleImportAsset', 16, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (16)'),
(168, 'RuleAction', 16, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(169, 'RuleImportAsset', 17, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(170, 'RuleImportAsset', 17, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (61)'),
(171, 'RuleCriteria', 61, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(172, 'RuleImportAsset', 17, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name is already present Yes (62)'),
(173, 'RuleCriteria', 62, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(174, 'RuleImportAsset', 17, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (63)'),
(175, 'RuleCriteria', 63, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(176, 'RuleImportAsset', 17, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (17)'),
(177, 'RuleAction', 17, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(178, 'RuleImportAsset', 18, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(179, 'RuleImportAsset', 18, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (64)'),
(180, 'RuleCriteria', 64, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(181, 'RuleImportAsset', 18, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (65)'),
(182, 'RuleCriteria', 65, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(183, 'RuleImportAsset', 18, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (18)'),
(184, 'RuleAction', 18, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(185, 'RuleImportAsset', 19, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(186, 'RuleImportAsset', 19, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (66)'),
(187, 'RuleCriteria', 66, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(188, 'RuleImportAsset', 19, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (67)'),
(189, 'RuleCriteria', 67, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(190, 'RuleImportAsset', 19, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (19)'),
(191, 'RuleAction', 19, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(192, 'RuleImportAsset', 20, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(193, 'RuleImportAsset', 20, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (68)'),
(194, 'RuleCriteria', 68, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(195, 'RuleImportAsset', 20, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (69)'),
(196, 'RuleCriteria', 69, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(197, 'RuleImportAsset', 20, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (20)'),
(198, 'RuleAction', 20, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(199, 'RuleImportAsset', 21, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(200, 'RuleImportAsset', 21, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (70)'),
(201, 'RuleCriteria', 70, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(202, 'RuleImportAsset', 21, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (71)'),
(203, 'RuleCriteria', 71, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(204, 'RuleImportAsset', 21, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (21)'),
(205, 'RuleAction', 21, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(206, 'RuleImportAsset', 22, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(207, 'RuleImportAsset', 22, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Computers (72)'),
(208, 'RuleCriteria', 72, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(209, 'RuleImportAsset', 22, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (22)'),
(210, 'RuleAction', 22, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(211, 'RuleImportAsset', 23, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(212, 'RuleImportAsset', 23, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (73)'),
(213, 'RuleCriteria', 73, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(214, 'RuleImportAsset', 23, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name does not exist Yes (74)'),
(215, 'RuleCriteria', 74, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(216, 'RuleImportAsset', 23, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (23)'),
(217, 'RuleAction', 23, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(218, 'RuleImportAsset', 24, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(219, 'RuleImportAsset', 24, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (75)'),
(220, 'RuleCriteria', 75, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(221, 'RuleImportAsset', 24, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (76)'),
(222, 'RuleCriteria', 76, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(223, 'RuleImportAsset', 24, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (77)'),
(224, 'RuleCriteria', 77, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(225, 'RuleImportAsset', 24, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (24)'),
(226, 'RuleAction', 24, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(227, 'RuleImportAsset', 25, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(228, 'RuleImportAsset', 25, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (78)'),
(229, 'RuleCriteria', 78, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(230, 'RuleImportAsset', 25, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (79)'),
(231, 'RuleCriteria', 79, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(232, 'RuleImportAsset', 25, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (80)'),
(233, 'RuleCriteria', 80, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(234, 'RuleImportAsset', 25, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (25)'),
(235, 'RuleAction', 25, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(236, 'RuleImportAsset', 26, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(237, 'RuleImportAsset', 26, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (81)'),
(238, 'RuleCriteria', 81, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(239, 'RuleImportAsset', 26, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (82)'),
(240, 'RuleCriteria', 82, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(241, 'RuleImportAsset', 26, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (26)'),
(242, 'RuleAction', 26, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(243, 'RuleImportAsset', 27, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(244, 'RuleImportAsset', 27, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (83)'),
(245, 'RuleCriteria', 83, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(246, 'RuleImportAsset', 27, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (84)'),
(247, 'RuleCriteria', 84, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(248, 'RuleImportAsset', 27, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (27)'),
(249, 'RuleAction', 27, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(250, 'RuleImportAsset', 28, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(251, 'RuleImportAsset', 28, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Printers (85)'),
(252, 'RuleCriteria', 85, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(253, 'RuleImportAsset', 28, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (28)'),
(254, 'RuleAction', 28, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(255, 'RuleImportAsset', 29, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(256, 'RuleImportAsset', 29, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (86)'),
(257, 'RuleCriteria', 86, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(258, 'RuleImportAsset', 29, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name does not exist Yes (87)'),
(259, 'RuleCriteria', 87, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(260, 'RuleImportAsset', 29, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (29)'),
(261, 'RuleAction', 29, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(262, 'RuleImportAsset', 30, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(263, 'RuleImportAsset', 30, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (88)'),
(264, 'RuleCriteria', 88, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(265, 'RuleImportAsset', 30, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (89)'),
(266, 'RuleCriteria', 89, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(267, 'RuleImportAsset', 30, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (90)'),
(268, 'RuleCriteria', 90, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(269, 'RuleImportAsset', 30, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (30)'),
(270, 'RuleAction', 30, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(271, 'RuleImportAsset', 31, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(272, 'RuleImportAsset', 31, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (91)'),
(273, 'RuleCriteria', 91, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(274, 'RuleImportAsset', 31, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (92)'),
(275, 'RuleCriteria', 92, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(276, 'RuleImportAsset', 31, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (93)'),
(277, 'RuleCriteria', 93, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(278, 'RuleImportAsset', 31, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (31)'),
(279, 'RuleAction', 31, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(280, 'RuleImportAsset', 32, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(281, 'RuleImportAsset', 32, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (94)'),
(282, 'RuleCriteria', 94, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(283, 'RuleImportAsset', 32, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (95)'),
(284, 'RuleCriteria', 95, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(285, 'RuleImportAsset', 32, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (32)'),
(286, 'RuleAction', 32, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(287, 'RuleImportAsset', 33, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(288, 'RuleImportAsset', 33, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (96)'),
(289, 'RuleCriteria', 96, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(290, 'RuleImportAsset', 33, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (97)'),
(291, 'RuleCriteria', 97, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(292, 'RuleImportAsset', 33, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (33)'),
(293, 'RuleAction', 33, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(294, 'RuleImportAsset', 34, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(295, 'RuleImportAsset', 34, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Network devices (98)'),
(296, 'RuleCriteria', 98, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(297, 'RuleImportAsset', 34, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (34)'),
(298, 'RuleAction', 34, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(299, 'RuleImportAsset', 35, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(300, 'RuleImportAsset', 35, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Devices (99)'),
(301, 'RuleCriteria', 99, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(302, 'RuleImportAsset', 35, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (100)'),
(303, 'RuleCriteria', 100, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(304, 'RuleImportAsset', 35, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (101)'),
(305, 'RuleCriteria', 101, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(306, 'RuleImportAsset', 35, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (35)'),
(307, 'RuleAction', 35, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(308, 'RuleImportAsset', 36, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(309, 'RuleImportAsset', 36, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Devices (102)'),
(310, 'RuleCriteria', 102, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(311, 'RuleImportAsset', 36, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (103)'),
(312, 'RuleCriteria', 103, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(313, 'RuleImportAsset', 36, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (36)'),
(314, 'RuleAction', 36, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(315, 'RuleImportAsset', 37, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(316, 'RuleImportAsset', 37, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Devices (104)'),
(317, 'RuleCriteria', 104, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(318, 'RuleImportAsset', 37, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (37)'),
(319, 'RuleAction', 37, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(320, 'RuleImportAsset', 38, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(321, 'RuleImportAsset', 38, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Monitors (105)'),
(322, 'RuleCriteria', 105, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(323, 'RuleImportAsset', 38, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (106)'),
(324, 'RuleCriteria', 106, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(325, 'RuleImportAsset', 38, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (107)'),
(326, 'RuleCriteria', 107, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(327, 'RuleImportAsset', 38, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (38)'),
(328, 'RuleAction', 38, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(329, 'RuleImportAsset', 39, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(330, 'RuleImportAsset', 39, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Monitors (108)'),
(331, 'RuleCriteria', 108, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(332, 'RuleImportAsset', 39, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (109)'),
(333, 'RuleCriteria', 109, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(334, 'RuleImportAsset', 39, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (39)'),
(335, 'RuleAction', 39, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(336, 'RuleImportAsset', 40, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(337, 'RuleImportAsset', 40, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Monitors (110)'),
(338, 'RuleCriteria', 110, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(339, 'RuleImportAsset', 40, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (40)'),
(340, 'RuleAction', 40, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(341, 'RuleImportAsset', 41, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(342, 'RuleImportAsset', 41, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Phones (111)'),
(343, 'RuleCriteria', 111, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(344, 'RuleImportAsset', 41, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name does not exist Yes (112)'),
(345, 'RuleCriteria', 112, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(346, 'RuleImportAsset', 41, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (41)'),
(347, 'RuleAction', 41, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(348, 'RuleImportAsset', 42, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(349, 'RuleImportAsset', 42, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Phones (113)'),
(350, 'RuleCriteria', 113, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(351, 'RuleImportAsset', 42, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (114)'),
(352, 'RuleCriteria', 114, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(353, 'RuleImportAsset', 42, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (115)'),
(354, 'RuleCriteria', 115, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(355, 'RuleImportAsset', 42, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (42)'),
(356, 'RuleAction', 42, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(357, 'RuleImportAsset', 43, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(358, 'RuleImportAsset', 43, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Phones (116)'),
(359, 'RuleCriteria', 116, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(360, 'RuleImportAsset', 43, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (117)'),
(361, 'RuleCriteria', 117, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(362, 'RuleImportAsset', 43, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (43)'),
(363, 'RuleAction', 43, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(364, 'RuleImportAsset', 44, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(365, 'RuleImportAsset', 44, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Phones (118)'),
(366, 'RuleCriteria', 118, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(367, 'RuleImportAsset', 44, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (44)'),
(368, 'RuleAction', 44, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(369, 'RuleImportAsset', 45, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(370, 'RuleImportAsset', 45, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Clusters (119)'),
(371, 'RuleCriteria', 119, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(372, 'RuleImportAsset', 45, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (120)'),
(373, 'RuleCriteria', 120, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(374, 'RuleImportAsset', 45, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID is already present Yes (121)'),
(375, 'RuleCriteria', 121, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(376, 'RuleImportAsset', 45, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (45)'),
(377, 'RuleAction', 45, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(378, 'RuleImportAsset', 46, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(379, 'RuleImportAsset', 46, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Clusters (122)'),
(380, 'RuleCriteria', 122, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(381, 'RuleImportAsset', 46, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; UUID exists Yes (123)'),
(382, 'RuleCriteria', 123, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(383, 'RuleImportAsset', 46, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (46)'),
(384, 'RuleAction', 46, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(385, 'RuleImportAsset', 47, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(386, 'RuleImportAsset', 47, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Clusters (124)'),
(387, 'RuleCriteria', 124, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(388, 'RuleImportAsset', 47, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (47)'),
(389, 'RuleAction', 47, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(390, 'RuleImportAsset', 48, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(391, 'RuleImportAsset', 48, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Enclosures (125)'),
(392, 'RuleCriteria', 125, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(393, 'RuleImportAsset', 48, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (126)'),
(394, 'RuleCriteria', 126, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(395, 'RuleImportAsset', 48, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (127)'),
(396, 'RuleCriteria', 127, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(397, 'RuleImportAsset', 48, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (48)'),
(398, 'RuleAction', 48, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(399, 'RuleImportAsset', 49, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(400, 'RuleImportAsset', 49, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Enclosures (128)'),
(401, 'RuleCriteria', 128, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(402, 'RuleImportAsset', 49, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (129)'),
(403, 'RuleCriteria', 129, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(404, 'RuleImportAsset', 49, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (49)'),
(405, 'RuleAction', 49, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(406, 'RuleImportAsset', 50, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(407, 'RuleImportAsset', 50, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Enclosures (130)'),
(408, 'RuleCriteria', 130, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(409, 'RuleImportAsset', 50, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (50)'),
(410, 'RuleAction', 50, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(411, 'RuleImportAsset', 51, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(412, 'RuleImportAsset', 51, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name does not exist Yes (131)'),
(413, 'RuleCriteria', 131, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(414, 'RuleImportAsset', 51, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (51)'),
(415, 'RuleAction', 51, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(416, 'RuleImportAsset', 52, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(417, 'RuleImportAsset', 52, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (132)'),
(418, 'RuleCriteria', 132, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(419, 'RuleImportAsset', 52, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number is already present Yes (133)'),
(420, 'RuleCriteria', 133, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(421, 'RuleImportAsset', 52, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (52)'),
(422, 'RuleAction', 52, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(423, 'RuleImportAsset', 53, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(424, 'RuleImportAsset', 53, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (134)'),
(425, 'RuleCriteria', 134, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(426, 'RuleImportAsset', 53, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC is already present Yes (135)'),
(427, 'RuleCriteria', 135, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(428, 'RuleImportAsset', 53, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (53)'),
(429, 'RuleAction', 53, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(430, 'RuleImportAsset', 54, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(431, 'RuleImportAsset', 54, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Serial number exists Yes (136)'),
(432, 'RuleCriteria', 136, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(433, 'RuleImportAsset', 54, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (54)'),
(434, 'RuleAction', 54, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(435, 'RuleImportAsset', 55, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(436, 'RuleImportAsset', 55, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Network port &#62; MAC exists Yes (137)'),
(437, 'RuleCriteria', 137, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(438, 'RuleImportAsset', 55, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (55)'),
(439, 'RuleAction', 55, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(440, 'RuleImportAsset', 56, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(441, 'RuleImportAsset', 56, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is No itemtype defined (138)'),
(442, 'RuleCriteria', 138, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(443, 'RuleImportAsset', 56, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (56)'),
(444, 'RuleAction', 56, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(445, 'RuleImportAsset', 57, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(446, 'RuleImportAsset', 57, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Database instances (139)'),
(447, 'RuleCriteria', 139, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(448, 'RuleImportAsset', 57, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (140)'),
(449, 'RuleCriteria', 140, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(450, 'RuleImportAsset', 57, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name is already present Yes (141)'),
(451, 'RuleCriteria', 141, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(452, 'RuleImportAsset', 57, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Linked asset is already present Yes (142)'),
(453, 'RuleCriteria', 142, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(454, 'RuleImportAsset', 57, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (57)'),
(455, 'RuleAction', 57, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(456, 'RuleImportAsset', 58, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(457, 'RuleImportAsset', 58, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Database instances (143)'),
(458, 'RuleCriteria', 143, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(459, 'RuleImportAsset', 58, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (144)'),
(460, 'RuleCriteria', 144, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(461, 'RuleImportAsset', 58, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (58)'),
(462, 'RuleAction', 58, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(463, 'RuleImportAsset', 59, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(464, 'RuleImportAsset', 59, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Database instances (145)'),
(465, 'RuleCriteria', 145, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(466, 'RuleImportAsset', 59, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (59)'),
(467, 'RuleAction', 59, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(468, 'RuleImportAsset', 60, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(469, 'RuleImportAsset', 60, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Unmanaged devices (146)'),
(470, 'RuleCriteria', 146, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(471, 'RuleImportAsset', 60, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (147)'),
(472, 'RuleCriteria', 147, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(473, 'RuleImportAsset', 60, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name is already present Yes (148)'),
(474, 'RuleCriteria', 148, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(475, 'RuleImportAsset', 60, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (60)'),
(476, 'RuleAction', 60, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(477, 'RuleImportAsset', 61, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(478, 'RuleImportAsset', 61, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Unmanaged devices (149)'),
(479, 'RuleCriteria', 149, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(480, 'RuleImportAsset', 61, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Name exists Yes (150)'),
(481, 'RuleCriteria', 150, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(482, 'RuleImportAsset', 61, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Link if possible (61)'),
(483, 'RuleAction', 61, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(484, 'RuleImportAsset', 62, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(485, 'RuleImportAsset', 62, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Asset &#62; Item type is Unmanaged devices (151)'),
(486, 'RuleCriteria', 151, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(487, 'RuleImportAsset', 62, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Inventory link Assign Import denied (no log) (62)'),
(488, 'RuleAction', 62, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(489, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections []', '[\"RuleImportAssetCollection\"]'),
(490, 'RuleMailCollector', 63, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(491, 'RuleMailCollector', 63, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Subject email header regular expression matches /.*/ (152)'),
(492, 'RuleCriteria', 152, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(493, 'RuleMailCollector', 63, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Entity Assign Entité racine (63)'),
(494, 'RuleAction', 63, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(495, 'RuleMailCollector', 64, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(496, 'RuleMailCollector', 64, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'X-Auto-Response-Suppress email header regular expression matches /S+/ (153)'),
(497, 'RuleCriteria', 153, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(498, 'RuleMailCollector', 64, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Reject email (without email response) Assign Yes (64)'),
(499, 'RuleAction', 64, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(500, 'RuleMailCollector', 65, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(501, 'RuleMailCollector', 65, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Auto-Submitted email header regular expression matches /^(?!.*no).+$/i (154)'),
(502, 'RuleCriteria', 154, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(503, 'RuleMailCollector', 65, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Reject email (without email response) Assign Yes (65)'),
(504, 'RuleAction', 65, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(505, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\"]', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\"]'),
(506, 'RuleRight', 66, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(507, 'RuleRight', 66, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Authentication type is LDAP directory: (155)'),
(508, 'RuleCriteria', 155, '0', 20, '', '2023-06-07 20:36:23', 0, '', '');
INSERT INTO `glpi_logs` (`id`, `itemtype`, `items_id`, `itemtype_link`, `linked_action`, `user_name`, `date_mod`, `id_search_option`, `old_value`, `new_value`) VALUES
(509, 'RuleRight', 66, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Authentication type is Email server: (156)'),
(510, 'RuleCriteria', 156, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(511, 'RuleRight', 66, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Entity Assign Entité racine (66)'),
(512, 'RuleAction', 66, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(513, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\"]', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\"]'),
(514, 'RuleSoftwareCategory', 67, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(515, 'RuleSoftwareCategory', 67, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Software is * (157)'),
(516, 'RuleCriteria', 157, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(517, 'RuleSoftwareCategory', 67, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Import category from inventory tool Assign Yes (67)'),
(518, 'RuleAction', 67, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(519, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\"]', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\"]'),
(520, 'RuleTicket', 68, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(521, 'RuleTicket', 68, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Ticket location does not exist Yes (158)'),
(522, 'RuleCriteria', 158, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(523, 'RuleTicket', 68, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Unavailable exists Yes (159)'),
(524, 'RuleCriteria', 159, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(525, 'RuleTicket', 68, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Location Copy from item Yes (68)'),
(526, 'RuleAction', 68, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(527, 'RuleTicket', 69, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(528, 'RuleTicket', 69, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Ticket location does not exist Yes (160)'),
(529, 'RuleCriteria', 160, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(530, 'RuleTicket', 69, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Requester location exists Yes (161)'),
(531, 'RuleCriteria', 161, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(532, 'RuleTicket', 69, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Location Copy from user Yes (69)'),
(533, 'RuleAction', 69, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(534, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\"]', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\"]'),
(535, 'RuleAsset', 70, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(536, 'RuleAsset', 70, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Item type is Computer (162)'),
(537, 'RuleCriteria', 162, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(538, 'RuleAsset', 70, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Automatic inventory is Yes (163)'),
(539, 'RuleCriteria', 163, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(540, 'RuleAsset', 70, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Alternate username regular expression matches /(.*)@/ (164)'),
(541, 'RuleCriteria', 164, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(542, 'RuleAsset', 70, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'User based contact information Assign the value from regular expression #0 (70)'),
(543, 'RuleAction', 70, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(544, 'RuleAsset', 71, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(545, 'RuleAsset', 71, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Item type is Computer (165)'),
(546, 'RuleCriteria', 165, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(547, 'RuleAsset', 71, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Automatic inventory is Yes (166)'),
(548, 'RuleCriteria', 166, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(549, 'RuleAsset', 71, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Alternate username regular expression matches /(.*)[,|/]/ (167)'),
(550, 'RuleCriteria', 167, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(551, 'RuleAsset', 71, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'User based contact information Assign the value from regular expression #0 (71)'),
(552, 'RuleAction', 71, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(553, 'RuleAsset', 72, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(554, 'RuleAsset', 72, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Item type is Computer (168)'),
(555, 'RuleCriteria', 168, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(556, 'RuleAsset', 72, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Automatic inventory is Yes (169)'),
(557, 'RuleCriteria', 169, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(558, 'RuleAsset', 72, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Alternate username regular expression matches /(.*)/ (170)'),
(559, 'RuleCriteria', 170, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(560, 'RuleAsset', 72, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'User based contact information Assign the value from regular expression #0 (72)'),
(561, 'RuleAction', 72, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(562, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\"]', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCollection\"]'),
(563, 'RuleDictionnaryOperatingSystem', 73, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(564, 'RuleDictionnaryOperatingSystem', 73, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:D+|)([d.]*) ?(?:(?([w ]+))?)?/ (171)'),
(565, 'RuleCriteria', 171, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(566, 'RuleDictionnaryOperatingSystem', 73, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system Add the result of regular expression #0 (73)'),
(567, 'RuleAction', 73, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(568, 'RuleDictionnaryOperatingSystem', 74, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(569, 'RuleDictionnaryOperatingSystem', 74, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (Windows) (XP|d.d|d{1,4}|Vista)(™)? ?(.*)/ (172)'),
(570, 'RuleCriteria', 172, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(571, 'RuleDictionnaryOperatingSystem', 74, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system Add the result of regular expression #1 (74)'),
(572, 'RuleAction', 74, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(573, 'RuleDictionnaryOperatingSystem', 75, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(574, 'RuleDictionnaryOperatingSystem', 75, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (?:(Hyper-V|Windows)(?:(R))?) ((?:Server|))(?:(R)|®)? (d{4}(?: R2)?)(?:[,s]++)?([^s]*)(?: Edition(?: x64)?)?$'),
(575, 'RuleCriteria', 173, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(576, 'RuleDictionnaryOperatingSystem', 75, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system Add the result of regular expression #1 #2 (75)'),
(577, 'RuleAction', 75, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(578, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCol', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCollection\",\"RuleDictionnaryOpera'),
(579, 'RuleDictionnaryOperatingSystemVersion', 76, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(580, 'RuleDictionnaryOperatingSystemVersion', 76, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:D+|)([d.]+) ?(?:(?([w ]+))?)?/ (174)'),
(581, 'RuleCriteria', 174, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(582, 'RuleDictionnaryOperatingSystemVersion', 76, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Version Add the result of regular expression #1 (76)'),
(583, 'RuleAction', 76, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(584, 'RuleDictionnaryOperatingSystemVersion', 77, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(585, 'RuleDictionnaryOperatingSystemVersion', 77, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (Windows) (XP|d.d|d{1,4}|Vista)(™)? ?(.*)/ (175)'),
(586, 'RuleCriteria', 175, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(587, 'RuleDictionnaryOperatingSystemVersion', 77, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Version Add the result of regular expression #2 (77)'),
(588, 'RuleAction', 77, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(589, 'RuleDictionnaryOperatingSystemVersion', 78, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(590, 'RuleDictionnaryOperatingSystemVersion', 78, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (?:(Hyper-V|Windows)(?:(R))?) ((?:Server|))(?:(R)|®)? (d{4}(?: R2)?)(?:[,s]++)?([^s]*)(?: Edition(?: x64)?)?$'),
(591, 'RuleCriteria', 176, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(592, 'RuleDictionnaryOperatingSystemVersion', 78, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Version Add the result of regular expression #3 (78)'),
(593, 'RuleAction', 78, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(594, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCol', '[\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCollection\",\"RuleDictionnaryOpera'),
(595, 'RuleDictionnaryOperatingSystemEdition', 79, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(596, 'RuleDictionnaryOperatingSystemEdition', 79, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:D+|)([d.]+) ?(?:(?([w ]+))?)?/ (177)'),
(597, 'RuleCriteria', 177, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(598, 'RuleDictionnaryOperatingSystemEdition', 79, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Edition Add the result of regular expression #2 (79)'),
(599, 'RuleAction', 79, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(600, 'RuleDictionnaryOperatingSystemEdition', 80, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(601, 'RuleDictionnaryOperatingSystemEdition', 80, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (Windows) (XP|d.d|d{1,4}|Vista)(™)? ?(.*)/ (178)'),
(602, 'RuleCriteria', 178, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(603, 'RuleDictionnaryOperatingSystemEdition', 80, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Edition Add the result of regular expression #4 (80)'),
(604, 'RuleAction', 80, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(605, 'RuleDictionnaryOperatingSystemEdition', 81, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(606, 'RuleDictionnaryOperatingSystemEdition', 81, 'RuleCriteria', 17, '', '2023-06-07 20:36:23', 0, '', 'Operating system regular expression matches /(Microsoft)(?&#62;(R)|®)? (?:(Hyper-V|Windows)(?:(R))?) ((?:Server|))(?:(R)|®)? (d{4}(?: R2)?)(?:[,s]++)?([^s]*)(?: Edition(?: x64)?)?$'),
(607, 'RuleCriteria', 179, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(608, 'RuleDictionnaryOperatingSystemEdition', 81, 'RuleAction', 17, '', '2023-06-07 20:36:23', 0, '', 'Edition Add the result of regular expression #4 (81)'),
(609, 'RuleAction', 81, '0', 20, '', '2023-06-07 20:36:23', 0, '', ''),
(610, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'initialized_rules_collections [\"RuleImportAssetCollection\",\"RuleMailCollectorCollection\",\"RuleRightCollection\",\"RuleSoftwareCategoryCollection\",\"RuleTicketCollection\",\"RuleAssetCol', '{...}'),
(611, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'language en_GB', 'fr_FR'),
(612, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'version FILLED AT INSTALL', '10.0.7'),
(613, 'Config', 1, '', 0, '', '2023-06-07 20:36:23', 1, 'dbversion FILLED AT INSTALL', '10.0.7@5d45269702917a32805e25b678f6779a98b145f6'),
(614, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 20:56:50', 1, 'enabled_inventory (inventory) 0', '1'),
(615, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 20:56:50', 1, 'stale_agents_action (inventory) [0]', '[\"0\"]'),
(616, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 20:57:03', 1, 'marketplace_replace_plugins ', '1'),
(617, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 21:03:42', 1, 'glpinetwork_registration_key ********', '********'),
(618, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 21:03:42', 1, 'glpi_network_uuid ', 'qqRSETzvGy0baBkI1nFsrMrd70ilI5yhLqq4vwYA'),
(619, 'User', 7, 'Profile', 17, 'glpi (2)', '2023-06-07 21:08:19', 0, '', 'Self-Service (1)'),
(620, 'User', 7, '0', 20, 'glpi (2)', '2023-06-07 21:08:19', 0, '', ''),
(621, 'CronTask', 44, '0', 20, 'glpi (2)', '2023-06-07 21:08:19', 0, '', ''),
(622, 'CronTask', 45, '0', 20, 'glpi (2)', '2023-06-07 21:08:19', 0, '', ''),
(623, 'CronTask', 46, '0', 20, 'glpi (2)', '2023-06-07 21:08:19', 0, '', ''),
(624, 'CronTask', 47, '0', 20, 'glpi (2)', '2023-06-07 21:08:19', 0, '', ''),
(666, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 21:28:10', 1, 'schema_version (formcreator) ', '2.13'),
(677, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 21:28:18', 1, 'schema_version (formcreator) 2.13', ''),
(678, 'CronTask', 44, '', 0, 'glpi (2)', '2023-06-07 21:31:54', 5, '2', '1'),
(679, 'CronTask', 44, '', 0, 'glpi (2)', '2023-06-07 21:32:06', 19, '30', '10'),
(680, 'Datacenter', 1, '0', 20, 'glpi (2)', '2023-06-07 21:34:10', 0, '', ''),
(681, 'Datacenter', 2, '0', 20, 'glpi (2)', '2023-06-07 21:34:22', 0, '', ''),
(682, 'Location', 1, '0', 20, 'glpi (2)', '2023-06-07 21:36:29', 0, '', ''),
(683, 'Location', 2, '0', 20, 'glpi (2)', '2023-06-07 21:36:37', 0, '', ''),
(684, 'Datacenter', 2, '', 0, 'glpi (2)', '2023-06-07 21:36:49', 3, '&nbsp; (0)', 'Lyon (2)'),
(685, 'Datacenter', 1, '', 0, 'glpi (2)', '2023-06-07 21:36:54', 3, '&nbsp; (0)', 'Paris (1)'),
(686, 'Location', 3, '0', 20, 'glpi (2)', '2023-06-07 21:37:25', 0, '', ''),
(687, 'Location', 2, '', 0, 'glpi (2)', '2023-06-07 21:37:32', 105, '', 'France'),
(688, 'ITILCategory', 1, '0', 20, 'glpi (2)', '2023-06-07 21:44:52', 0, '', ''),
(689, 'ITILCategory', 1, 'ITILCategory', 17, 'glpi (2)', '2023-06-07 21:44:59', 0, '', 'Matériel (2)'),
(690, 'ITILCategory', 2, '0', 20, 'glpi (2)', '2023-06-07 21:44:59', 0, '', ''),
(691, 'ITILCategory', 2, 'ITILCategory', 17, 'glpi (2)', '2023-06-07 21:45:05', 0, '', 'Casque (3)'),
(692, 'ITILCategory', 3, '0', 20, 'glpi (2)', '2023-06-07 21:45:05', 0, '', ''),
(693, 'ITILCategory', 1, '', 0, 'glpi (2)', '2023-06-07 21:45:17', 14, 'Panne', 'Pannes'),
(694, 'ITILCategory', 1, '', 0, 'glpi (2)', '2023-06-07 21:45:17', 1, 'Panne', 'Pannes'),
(695, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:22:20', 1, 'url_base http://localhost/glpi', 'http://192.168.0.50/glpi'),
(696, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:25:50', 1, 'url_base http://192.168.0.50/glpi', 'http://192.168.0.50'),
(697, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:26:04', 1, 'palette auror', 'auror_dark'),
(698, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:26:04', 1, 'page_layout vertical', 'horizontal'),
(699, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:26:04', 1, 'timezone ', '0'),
(700, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:26:08', 1, 'date_format 0', '2'),
(701, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:49:54', 1, 'marketplace_replace_plugins 1', '2'),
(702, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:50:09', 1, 'glpinetwork_registration_key ********', '********'),
(703, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:50:13', 1, 'glpinetwork_registration_key ********', '********'),
(704, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:50:24', 1, 'url_base http://192.168.0.50', 'http://glpi.local'),
(705, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:53:51', 1, 'url_base_api http://localhost/glpi/api', 'http://glpi.local/api'),
(706, 'Config', 1, '', 0, 'glpi (2)', '2023-06-07 23:53:51', 1, 'enable_api 0', '1'),
(707, 'APIClient', 2, '0', 20, 'glpi (2)', '2023-06-08 00:00:47', 0, '', '');

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT 2097152,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `passwd` varchar(255) DEFAULT NULL,
  `accepted` varchar(255) DEFAULT NULL,
  `refused` varchar(255) DEFAULT NULL,
  `errors` int(11) NOT NULL DEFAULT 0,
  `use_mail_date` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `requester_field` int(11) NOT NULL DEFAULT 0,
  `add_cc_to_observer` tinyint(4) NOT NULL DEFAULT 0,
  `collect_only_unread` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_manuallinks`;
CREATE TABLE `glpi_manuallinks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(8096) NOT NULL,
  `open_window` tinyint(4) NOT NULL DEFAULT 1,
  `icon` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `size` decimal(5,2) NOT NULL DEFAULT 0.00,
  `have_micro` tinyint(4) NOT NULL DEFAULT 0,
  `have_speaker` tinyint(4) NOT NULL DEFAULT 0,
  `have_subd` tinyint(4) NOT NULL DEFAULT 0,
  `have_bnc` tinyint(4) NOT NULL DEFAULT 0,
  `have_dvi` tinyint(4) NOT NULL DEFAULT 0,
  `have_pivot` tinyint(4) NOT NULL DEFAULT 0,
  `have_hdmi` tinyint(4) NOT NULL DEFAULT 0,
  `have_displayport` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `monitortypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `monitormodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_global` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networknames_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `fqdns_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `ram` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkequipmenttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkequipmentmodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sysdescr` text DEFAULT NULL,
  `cpu` int(11) NOT NULL DEFAULT 0,
  `uptime` varchar(255) NOT NULL DEFAULT '0',
  `last_inventory_update` timestamp NULL DEFAULT NULL,
  `snmpcredentials_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `fqdns_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ipnetworks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkports_id_list` text DEFAULT NULL COMMENT 'array of associated networkports_id',
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkports_id_alias` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportconnectionlogs`;
CREATE TABLE `glpi_networkportconnectionlogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `connected` tinyint(4) NOT NULL DEFAULT 0,
  `networkports_id_source` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkports_id_destination` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_devicenetworkcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` varchar(10) DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT 10 COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_devicenetworkcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkportfiberchanneltypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `wwn` varchar(16) DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT 10 COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportfiberchanneltypes`;
CREATE TABLE `glpi_networkportfiberchanneltypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkportmetrics`;
CREATE TABLE `glpi_networkportmetrics` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `ifinbytes` bigint(20) NOT NULL DEFAULT 0,
  `ifinerrors` bigint(20) NOT NULL DEFAULT 0,
  `ifoutbytes` bigint(20) NOT NULL DEFAULT 0,
  `ifouterrors` bigint(20) NOT NULL DEFAULT 0,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `logical_number` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `instantiation_type` varchar(255) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `ifmtu` int(11) NOT NULL DEFAULT 0,
  `ifspeed` bigint(20) NOT NULL DEFAULT 0,
  `ifinternalstatus` varchar(255) DEFAULT NULL,
  `ifconnectionstatus` int(11) NOT NULL DEFAULT 0,
  `iflastchange` varchar(255) DEFAULT NULL,
  `ifinbytes` bigint(20) NOT NULL DEFAULT 0,
  `ifinerrors` bigint(20) NOT NULL DEFAULT 0,
  `ifoutbytes` bigint(20) NOT NULL DEFAULT 0,
  `ifouterrors` bigint(20) NOT NULL DEFAULT 0,
  `ifstatus` varchar(255) DEFAULT NULL,
  `ifdescr` varchar(255) DEFAULT NULL,
  `ifalias` varchar(255) DEFAULT NULL,
  `portduplex` varchar(255) DEFAULT NULL,
  `trunk` tinyint(4) NOT NULL DEFAULT 0,
  `lastup` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkports_id_2` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `vlans_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tagged` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networkporttypes`;
CREATE TABLE `glpi_networkporttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `value_decimal` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_importable` tinyint(4) NOT NULL DEFAULT 0,
  `instantiation_type` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_networkporttypes` (`id`, `entities_id`, `is_recursive`, `value_decimal`, `name`, `comment`, `is_importable`, `instantiation_type`, `date_creation`, `date_mod`) VALUES
(1, 0, 0, 0, 'Name', 'Description References', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(2, 0, 0, 1, 'other', 'none of the following [RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(3, 0, 0, 2, 'regular1822', 'BBN Report 1822 [RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(4, 0, 0, 3, 'hdh1822', 'BBN Report 1822 [RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(5, 0, 0, 4, 'ddn-x25', 'BBN Report 1822 [RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(6, 0, 0, 5, 'x25', 'X.25 [RFC1382]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(7, 0, 0, 6, 'ethernet-csmacd', '[RFC1213]', 1, 'NetworkPortEthernet', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(8, 0, 0, 7, 'IEEE802.3', 'DEPRECATED [RFC3635]', 1, 'NetworkPortEthernet', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(9, 0, 0, 8, 'IEEE802.4', 'Token Bus-like Objects [RFC1239]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(10, 0, 0, 9, 'IEEE802.5', 'Token Ring-like Objects [RFC1748]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(11, 0, 0, 10, 'iso88026-man', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(12, 0, 0, 11, 'starLan', 'DEPRECATED [RFC3635]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(13, 0, 0, 12, 'proteon-10Mbit', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(14, 0, 0, 13, 'proteon-80Mbit', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(15, 0, 0, 14, 'hyperchannel', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(16, 0, 0, 15, 'FDDI', 'FDDI Objects [RFC1512]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(17, 0, 0, 16, 'lapb', 'LAP B [RFC1381]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(18, 0, 0, 17, 'sdlc', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(19, 0, 0, 18, 'ds1', 'T1/E1 Carrier Objects [RFC4805]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(20, 0, 0, 19, 'e1', 'obsolete [RFC4805]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(21, 0, 0, 20, 'basicISDN', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(22, 0, 0, 21, 'primaryISDN', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(23, 0, 0, 22, 'propPointToPointSerial', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(24, 0, 0, 23, 'ppp', 'Point-to-Point Protocol [RFC1213][RFC1471]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(25, 0, 0, 24, 'softwareLoopback', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(26, 0, 0, 25, 'eon', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(27, 0, 0, 26, 'ethernet-3Mbit', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(28, 0, 0, 27, 'nsip', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(29, 0, 0, 28, 'slip', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(30, 0, 0, 29, 'ultra', '[RFC1213]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(31, 0, 0, 30, 'ds3', 'DS3/E3 Interface Objects [RFC3896]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(32, 0, 0, 31, 'sip', 'SMDS Interface Objects [RFC1694]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(33, 0, 0, 32, 'frame-relay', 'Frame Relay Objects for DTE [RFC2115]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(34, 0, 0, 33, 'RS-232', 'RS-232 Objects [RFC1659]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(35, 0, 0, 34, 'Parallel', 'Parallel Printer Objects [RFC1660]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(36, 0, 0, 35, 'arcnet', 'ARC network', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(37, 0, 0, 36, 'arcnet-plus', 'ARC network plus', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(38, 0, 0, 37, 'atm', 'ATM', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(39, 0, 0, 38, 'MIOX25', 'MIOX25 [RFC1461]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(40, 0, 0, 39, 'SONET', 'SONET or SDH', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(41, 0, 0, 40, 'x25ple', 'X.25 packet level [RFC2127]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(42, 0, 0, 41, 'iso88022llc', '802.2 LLC', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(43, 0, 0, 42, 'localTalk', '', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(44, 0, 0, 43, 'smds-dxi', 'SMDS DXI', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(45, 0, 0, 44, 'frameRelayService', 'Frame Relay DCE [RFC2954]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(46, 0, 0, 45, 'v35', 'V.35', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(47, 0, 0, 46, 'hssi', 'HSSI', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(48, 0, 0, 47, 'hippi', 'HIPPI', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(49, 0, 0, 48, 'modem', 'generic modem', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(50, 0, 0, 49, 'aal5', 'AAL5 over ATM', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(51, 0, 0, 50, 'sonetPath', '', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(52, 0, 0, 51, 'sonetVT', '', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(53, 0, 0, 52, 'smds-icip', 'SMDS Inter-Carrier Interface Protocol', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(54, 0, 0, 53, 'propVirtual', 'proprietary vitural/internal interface [RFC2863]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(55, 0, 0, 54, 'propMultiLink', 'proprietary multi-link multiplexing [RFC2863]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(56, 0, 0, 55, 'ieee80212', '100BaseVG', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(57, 0, 0, 56, 'fibre-channel', 'Fibre Channel', 1, 'NetworkPortFiberchannel', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(58, 0, 0, 57, 'hippiInterfaces', 'HIPPI interfaces [Philip_Cameron]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(59, 0, 0, 58, 'FrameRelayInterconnect', 'Interconnet over FR [Unknown]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(60, 0, 0, 59, 'aflane8023', 'ATM Emulated LAN for 802.3 [Keith_McCloghrie]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(61, 0, 0, 60, 'aflane8025', 'ATM Emulated LAN for 802.5 [Keith_McCloghrie]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(62, 0, 0, 61, 'cctEmul', 'ATM Emulated circuit [Guy_Fedorkow]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(63, 0, 0, 62, 'fastEther', 'DEPRECATED [RFC3635]', 1, 'NetworkPortEthernet', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(64, 0, 0, 63, 'isdn', 'ISDN and X.25 [RFC1356]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(65, 0, 0, 64, 'v11', 'CCITT V.11/X.21 [Satish_Popat]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(66, 0, 0, 65, 'v36', 'CCITT V.36 [Satish_Popat]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(67, 0, 0, 66, 'g703-64k', 'CCITT G703 at 64Kbps [Satish_Popat]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(68, 0, 0, 67, 'g703-2mb', 'CCITT G703 at 2Mbps [Satish_Popat]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(69, 0, 0, 68, 'qllc', 'SNA QLLC [Satish_Popat]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(70, 0, 0, 69, 'fastEtherFX', 'DEPRECATED [RFC3635]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(71, 0, 0, 70, 'channel', 'channel [Steven_Schwell]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(72, 0, 0, 71, 'IEEE802.11', 'radio spread spectrum [Dawkoon_Paul_Lee]', 1, 'NetworkPortWifi', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(73, 0, 0, 72, 'ibm370parChan', 'IBM System 360/370 OEMI Channel [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(74, 0, 0, 73, 'ESCON', 'IBM Enterprise Systems Connection [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(75, 0, 0, 74, 'DLSw', 'Data Link Switching [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(76, 0, 0, 75, 'ISDNs', 'ISDN S/T interface [Ed_Alcoff]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(77, 0, 0, 76, 'ISDNu', 'ISDN U interface [Ed_Alcoff]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(78, 0, 0, 77, 'lapd', 'Link Access Protocol D [Ed_Alcoff]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(79, 0, 0, 78, 'ip-switch', 'IP Switching Objects [Joe_Wei]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(80, 0, 0, 79, 'rsrb', 'Remote Source Route Bridging [Bob_Clouston]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(81, 0, 0, 80, 'atm-logical', 'ATM Logical Port [RFC3606]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(82, 0, 0, 81, 'ds0', 'Digital Signal Level 0 [RFC2494]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(83, 0, 0, 82, 'ds0Bundle', 'group of ds0s on the same ds1 [RFC2494]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(84, 0, 0, 83, 'bsc', 'Bisynchronous Protocol [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(85, 0, 0, 84, 'async', 'Asynchronous Protocol [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(86, 0, 0, 85, 'cnr', 'Combat Net Radio [Herb_Jensen]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(87, 0, 0, 86, 'iso88025Dtr', 'ISO 802.5r DTR [Trevor_Warwick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(88, 0, 0, 87, 'eplrs', 'Enhanced  Pos Loc Report Sys [Herb_Jensen]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(89, 0, 0, 88, 'arap', 'Appletalk Remote Access Protocol [Jim_Halpin]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(90, 0, 0, 89, 'propCnls', 'Proprietary Connectionless Proto. [Robert_Neill]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(91, 0, 0, 90, 'hostPad', 'CCITT-ITU X.29 PAD Protocol [Robert_Neill]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(92, 0, 0, 91, 'termPad', 'CCITT-ITU X.3 PAD Facility [Robert_Neill]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(93, 0, 0, 92, 'frameRelayMPI', 'Multiproto Interconnect over FR [Robert_Neill]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(94, 0, 0, 93, 'x213', 'CCITT-ITU X213 [Robert_Neill]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(95, 0, 0, 94, 'adsl', 'Asymmetric Digital Subscriber Loop [Gregory_Bathrick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(96, 0, 0, 95, 'radsl', 'Rate-Adapt. Digital Subscriber Loop [Gregory_Bathrick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(97, 0, 0, 96, 'sdsl', 'Symmetric Digital Subscriber Loop [Gregory_Bathrick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(98, 0, 0, 97, 'vdsl', 'Very H-Speed Digital Subscrib. Loop [Gregory_Bathrick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(99, 0, 0, 98, 'iso88025CRFPInt', 'ISO 802.5 CRFP [Trevor_Warwick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(100, 0, 0, 99, 'myrinet', 'Myricom Myrinet [Bob_Felderman]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(101, 0, 0, 100, 'voiceEM', 'Voice recEive and transMit (E&#38;M) [Bob_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(102, 0, 0, 101, 'voiceFXO', 'Voice Foreign Exchange Office [Bob_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(103, 0, 0, 102, 'voiceFXS', 'Voice Foreign Exchange Station [Bob_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(104, 0, 0, 103, 'voiceEncap', 'Voice encapsulation [Bob_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(105, 0, 0, 104, 'voiceOverIp', 'Voice over IP encapsulation [Bob_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(106, 0, 0, 105, 'atmDxi', 'ATM DXI [Gary_Hanson]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(107, 0, 0, 106, 'atmFuni', 'ATM FUNI [Gary_Hanson]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(108, 0, 0, 107, 'atmIma', 'ATM IMA [Chris_Martin]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(109, 0, 0, 108, 'pppMultilinkBundle', 'PPP Multilink Bundle [John_Shriver]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(110, 0, 0, 109, 'ipOverCdlc', 'IBM ipOverCdlc [Ken_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(111, 0, 0, 110, 'ipOverClaw', 'IBM Common Link Access to Workstn [Ken_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(112, 0, 0, 111, 'stackToStack', 'IBM stackToStack [Ken_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(113, 0, 0, 112, 'virtualIpAddress', 'IBM VIPA [Ken_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(114, 0, 0, 113, 'mpc', 'IBM multi-protocol channel support [Ken_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(115, 0, 0, 114, 'ipOverAtm', 'IBM ipOverAtm [RFC2320]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(116, 0, 0, 115, 'iso88025Fiber', 'ISO 802.5j Fiber Token Ring [Kevin_Lingle]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(117, 0, 0, 116, 'tdlc', 'IBM twinaxial data link control [John_Pechacek]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(118, 0, 0, 117, 'gigabitEthernet', 'DEPRECATED [RFC3635]', 1, 'NetworkPortEthernet', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(119, 0, 0, 118, 'hdlc', 'HDLC [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(120, 0, 0, 119, 'lapf', 'LAP F [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(121, 0, 0, 120, 'v37', 'V.37 [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(122, 0, 0, 121, 'x25mlp', 'Multi-Link Protocol [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(123, 0, 0, 122, 'x25huntGroup', 'X25 Hunt Group [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(124, 0, 0, 123, 'transpHdlc', 'Transp HDLC [Sebastien_Rosset]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(125, 0, 0, 124, 'interleave', 'Interleave channel [Karmous_Edwards]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(126, 0, 0, 125, 'fast', 'Fast channel [Karmous_Edwards]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(127, 0, 0, 126, 'ip', 'IP (for APPN HPR in IP networks) [Robert_Moore]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(128, 0, 0, 127, 'docsCableMaclayer', 'CATV Mac Layer [Azlina_Palmer]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(129, 0, 0, 128, 'docsCableDownstream', 'CATV Downstream interface [Azlina_Palmer]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(130, 0, 0, 129, 'docsCableUpstream', 'CATV Upstream interface [Azlina_Palmer]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(131, 0, 0, 130, 'a12MppSwitch', 'Avalon Parallel Processor [Ross_Harvey]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(132, 0, 0, 131, 'tunnel', 'Encapsulation interface [Dave_Thaler]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(133, 0, 0, 132, 'coffee', 'coffee pot [RFC2325]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(134, 0, 0, 133, 'ces', 'Circiut Emulation Service [Ron_Carmona]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(135, 0, 0, 134, 'atmSubInterface', '(x)  ATM Sub Interface [Keith_McCloghrie]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(136, 0, 0, 135, 'l2vlan', 'Layer 2 Virtual LAN using 802.1Q [Mike_MacFaden]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(137, 0, 0, 136, 'l3ipvlan', 'Layer 3 Virtual LAN - IP Protocol [Mike_MacFaden]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(138, 0, 0, 137, 'l3ipxvlan', 'Layer 3 Virtual LAN - IPX Prot. [Mike_MacFaden]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(139, 0, 0, 138, 'digitalPowerLine', 'IP over Power Lines [Hans_Scholtes]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(140, 0, 0, 139, 'mediaMailOverIp', '(xxx)  Multimedia Mail over IP [Hongchi_Shih]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(141, 0, 0, 140, 'dtm', 'Dynamic synchronous Transfer Mode [Jakob_Ellerstedt]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(142, 0, 0, 141, 'dcn', 'Data Communications Network [James_Card]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(143, 0, 0, 142, 'ipForward', 'IP Forwarding Interface [James_Card]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(144, 0, 0, 143, 'msdsl', 'Multi-rate Symmetric DSL [Gopinath_Durairaj]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(145, 0, 0, 144, 'ieee1394     IEEE1394', 'High Performance Serial Bus [Kenji_Fujisawa]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(146, 0, 0, 145, 'if-gsn', 'HIPPI-6400 [Jean_Michel_Pittet]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(147, 0, 0, 146, 'dvbRccMacLayer', 'DVB-RCC MAC Layer [Maarten_Oelering]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(148, 0, 0, 147, 'dvbRccDownstream', 'DVB-RCC Downstream Channel [Maarten_Oelering]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(149, 0, 0, 148, 'dvbRccUpstream', 'DVB-RCC Upstream Channel [Maarten_Oelering]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(150, 0, 0, 149, 'atmVirtual', 'ATM Virtual Interface [Subrahmanya_Hegde]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(151, 0, 0, 150, 'mplsTunnel', 'MPLS Tunnel Virtual Interface [Cheenu_Srinivasan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(152, 0, 0, 151, 'srp', 'Spatial Reuse Protocol [Bill_Shetti]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(153, 0, 0, 152, 'voiceOverAtm', 'Voice over ATM [Chris_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(154, 0, 0, 153, 'voiceOverFrameRelay', 'Voice Over Frame Relay [Chris_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(155, 0, 0, 154, 'idsl', 'Digital Subscriber Loop over ISDN [Patrick_Gili]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(156, 0, 0, 155, 'compositeLink', 'Avici Composite Link Interface [Joseph_Dube]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(157, 0, 0, 156, 'ss7SigLink', 'SS7 Signaling Link [Cheenu_Srinivasan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(158, 0, 0, 157, 'propWirelessP2P', 'Prop. P2P wireless interface [Joseph_Raja]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(159, 0, 0, 158, 'frForward', 'Frame forward Interface [Subrahmanya_Hegde]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(160, 0, 0, 159, 'rfc1483', 'Multiprotocol over ATM AAL5 [RFC1483]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(161, 0, 0, 160, 'USB', 'USB Interface [Bejamin_Dolnik]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(162, 0, 0, 161, 'ieee8023adLag', 'IEEE 802.3ad Link Aggregate [Les_Bell]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(163, 0, 0, 162, 'bgpPolicyAccounting', 'BGP Policy Accounting [Vinod_B_C]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(164, 0, 0, 163, 'frf16MfrBundle', 'FRF.16 Multilik Frame Relay [Pate_Prayson]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(165, 0, 0, 164, 'h323Gatekeeper', 'H323 Gatekeeper [Chris_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(166, 0, 0, 165, 'h323Proxy', 'H323 Voice and Video Proxy [Chris_White]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(167, 0, 0, 166, 'mpls', 'MPLS [Cheenu_Srinivasan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(168, 0, 0, 167, 'mfSigLink', 'Multi-frequency signaling link [Cheenu_Srinivasan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(169, 0, 0, 168, 'hdsl2', 'High Bit-Rate DSL, 2nd gen. [Bob_Ray]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(170, 0, 0, 169, 'shdsl', 'Multirate HDSL2 [Bob_Ray]', 1, 'NetworkPortEthernet', '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(171, 0, 0, 170, 'ds1FDL', 'Facility Data Link (4Kbps) on a DS1 [Bill_Kwan]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(172, 0, 0, 171, 'POS', 'Packet over SONET/SDH Interface [Ewart_Tempest]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(173, 0, 0, 172, 'dvbAsiIn', 'DVB-ASI Input [Hezi_Oved]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(174, 0, 0, 173, 'dvbAsiOut', 'DVB-ASI Output [Hezi_Oved]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(175, 0, 0, 174, 'plc', 'Power Line Communications [Andrew_Lunn]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(176, 0, 0, 175, 'NFAS', 'Non-Facility Associated Signaling [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(177, 0, 0, 176, 'TR008', 'TROO8 [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(178, 0, 0, 177, 'GR303RDT', 'Remote Digital Terminal [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(179, 0, 0, 178, 'GR303IDT', 'Integrated Digital Terminal [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(180, 0, 0, 179, 'ISUP', 'ISUP [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(181, 0, 0, 180, 'propDocsWirelessMaclayer', 'Cisco proprietary Maclayer [Joseph_Raja]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(182, 0, 0, 181, 'propDocsWirelessDownstream', 'Cisco proprietary Downstream [Joseph_Raja]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(183, 0, 0, 182, 'propDocsWirelessUpstream', 'Cisco proprietary Upstream [Joseph_Raja]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(184, 0, 0, 183, 'hiperlan2', 'HIPERLAN Type 2 Radio Interface [Jamshid_Khun_Jush]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(185, 0, 0, 184, 'propBWAp2Mp', 'PropBroadbandWirelessAccesspt2Multipt\n(use of this type for IEEE 802.16\nWMAN, interfaces as per IEEE 802.16\nis deprecated and iftype 237 should\nbe used instead) [Zvika_Zilberman]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(186, 0, 0, 185, 'sonetOverheadChannel', 'SONET Overhead Channel [ODSI_Coalition_K_Arv]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(187, 0, 0, 186, 'digitalWrapperOverheadChannel', 'Digital Wrapper\nOverhead [ODSI_Coalition_K_Arv]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(188, 0, 0, 187, 'aal2', 'ATM adaptation layer 2 [K_Ashoka]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(189, 0, 0, 188, 'radioMAC', 'MAC layer over radio links [Daniele_Behar]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(190, 0, 0, 189, 'atmRadio', 'ATM over radio links [Daniele_Behar]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(191, 0, 0, 190, 'IMT', 'Inter-Machine Trunks [Sidney_Antommarchi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(192, 0, 0, 191, 'mvl', 'Multiple Virtual Lines DSL [Kevin_Baughman]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(193, 0, 0, 192, 'reachDSL', 'Long Reach DSL [Kevin_Baughman]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(194, 0, 0, 193, 'frDlciEndPt', 'Frame Relay DLCI End Point [Robert_Steinberger]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(195, 0, 0, 194, 'atmVciEndPt', 'ATM VCI End Point [Robert_Steinberger]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(196, 0, 0, 195, 'opticalChannel', 'Optical Channel [Mark_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(197, 0, 0, 196, 'opticalTransport', 'Optical Transport [Mark_Stewart]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(198, 0, 0, 197, 'propAtm', 'Proprietary ATM [Subrahmanya_Hegde]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(199, 0, 0, 198, 'voiceOverCable', 'Voice Over Cable Interface [Eugene_Nechamkin]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(200, 0, 0, 199, 'infiniband', 'Infiniband [Bill_Strahm]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(201, 0, 0, 200, 'teLink', 'TE Link [Martin_Dubuc]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(202, 0, 0, 201, 'q2931', 'Q.2931 [Sidney_Antommarchi_2]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(203, 0, 0, 202, 'virtualTg', 'Virtual Trunk Group [Sidney_Antommarchi_2]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(204, 0, 0, 203, 'sipTg', 'SIP Trunk Group [Sidney_Antommarchi_2]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(205, 0, 0, 204, 'sipSig', 'SIP Signaling [Sidney_Antommarchi_2]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(206, 0, 0, 205, 'docsCableUpstreamChannel', 'CATV Upstream Channel [Greg_Nakanishi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(207, 0, 0, 206, 'econet', 'Acorn Econet [Ben_Harris]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(208, 0, 0, 207, 'pon155', 'FSAN 155Mb Symetrical PON interface [Graham_Higgins]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(209, 0, 0, 208, 'pon622', 'FSAN 622Mb Symetrical PON interface [Graham_Higgins]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(210, 0, 0, 209, 'bridge', 'Transparent bridge interface [Yuzo_Watanabe]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(211, 0, 0, 210, 'linegroup', 'Interface common to multiple lines [Yuzo_Watanabe]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(212, 0, 0, 211, 'voiceEMFGD', 'voice E&#38;M Feature Group D [Taher_Shaikh]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(213, 0, 0, 212, 'voiceFGDEANA', 'voice FGD Exchange Access North American [Taher_Shaikh]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(214, 0, 0, 213, 'voiceDID', 'voice Direct Inward Dialing [Taher_Shaikh]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(215, 0, 0, 214, 'mpegTransport', 'MPEG transport interface [Gaurav_Aggarwal]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(216, 0, 0, 215, 'sixToFour', '6to4 interface  (DEPRECATED) [RFC4087]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(217, 0, 0, 216, 'gtp', 'GTP (GPRS Tunneling Protocol) [Rajesh_M_L]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(218, 0, 0, 217, 'pdnEtherLoop1', 'Paradyne EtherLoop 1 [Shu_Dong]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(219, 0, 0, 218, 'pdnEtherLoop2', 'Paradyne EtherLoop 2 [Shu_Dong]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(220, 0, 0, 219, 'opticalChannelGroup', 'Optical Channel Group [Hing_Kam_Lam]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(221, 0, 0, 220, 'homepna', 'HomePNA ITU-T G.989 [Stephen_Palm]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(222, 0, 0, 221, 'gfp', 'Generic Framing Procedure (GFP) [Italo_Busi]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(223, 0, 0, 222, 'ciscoISLvlan', 'Layer 2 Virtual LAN using Cisco ISL [Sandeep_Raghavendra]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(224, 0, 0, 223, 'actelisMetaLOOP', 'Acteleis proprietary MetaLOOP\nHigh Speed Link [Edward_Beili]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(225, 0, 0, 224, 'fcipLink', 'FCIP Link [Anil_Rijhsinghani]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(226, 0, 0, 225, 'rpr', 'Resilient Packet Ring Interface Type [IEEE 802.17]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(227, 0, 0, 226, 'qam', 'RF Qam Interface [Jeyachitra_Alagar]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(228, 0, 0, 227, 'lmp', 'Link Management Protocol [RFC4327]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(229, 0, 0, 228, 'cblVectaStar', 'Cambridge Broadband Networks Limited\nVectaStar [John_Naylon]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(230, 0, 0, 229, 'docsCableMCmtsDownstream', 'CATV Modular CMTS Downstream\nInterface [Eduardo_Cardona][\"Data-Over-Cable Service Interface Specifications:\nM-CMTS Operations Support System Interface Specification,\nCM-SP-M-OSSI-I01-050805\", DOCSIS, August 2005.][http://www.cablemodem.com/specifications][https://www.cablelabs.com/specifications/archives/docsis.html]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(231, 0, 0, 230, 'adsl2', 'Asymmetric Digital Subscriber Loop\nVersion 2 (DEPRECATED - REPLACED\nBY 238) [RFC4706]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(232, 0, 0, 231, 'macSecControlledIF', 'MACSecControlled [Paul_Congdon]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(233, 0, 0, 232, 'macSecUncontrolledIF', 'MACSecUncontrolled [Paul_Congdon]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(234, 0, 0, 233, 'aviciOpticalEther', 'Avici Optical Ethernet Aggregate [Somen_Bhattacharya]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(235, 0, 0, 234, 'atmbond', 'atmbond [https://www.itu.int/rec/T-REC-G.998.1-200501-I/en]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(236, 0, 0, 235, 'voiceFGDOS', 'voice FGD Operator Services [Lizzie_Cheung]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(237, 0, 0, 236, 'mocaVersion1', 'MultiMedia over Coax Alliance [Ladd_Wardani]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(238, 0, 0, 237, 'ieee80216WMAN', 'IEEE 802.16 WMAN interface [http://standards.ieee.org/getieee802/802.16.html]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(239, 0, 0, 238, 'adsl2plus', 'Asymmetric Digital Subscriber Loop\nVersion 2 -- Version 2 Plus and all\nvariants [RFC4706]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(240, 0, 0, 239, 'dvbRcsMacLayer', 'DVB-RCS MAC Layer [RFC5728][ETSI EN 301 790][https://web.archive.org/web/20181229131835/http://satlabs.org/pdf/SatLabs_System_Recommendations_v2.0_M&#38;C.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(241, 0, 0, 240, 'dvbTdm', 'DVB Satellite TDM [RFC5728][ETSI EN 300 421][ETSI EN 302 307][https://web.archive.org/web/20181229131835/http://satlabs.org/pdf/SatLabs_System_Recommendations_v2.0_M&#38;C.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(242, 0, 0, 241, 'dvbRcsTdma', 'DVB-RCS TDMA [RFC5728][ETSI EN 301 790][ETSI EN 300 421][https://web.archive.org/web/20181229131835/http://satlabs.org/pdf/SatLabs_System_Recommendations_v2.0_M&#38;C.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(243, 0, 0, 242, 'x86Laps', 'LAPS based on ITU-T X.86/Y.1323 [Orly_Nicklass][http://grouper.ieee.org/groups/802/3/ad_hoc/etholaps/public/docs/opening_report_0301.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(244, 0, 0, 243, 'wwanPP', '3GPP WWAN [Gabriel_Montenegro][https://www.3gpp.org/ftp/specs/archive/23_series/23.060/23060-740.zip]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(245, 0, 0, 244, 'wwanPP2', '3GPP2 WWAN [Gabriel_Montenegro][http://www.3gpp2.org/Public_html/Specs/C.S0017-005-A_v1.0_040617.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(246, 0, 0, 245, 'voiceEBS', 'voice P-phone EBS physical interface [Tom_Chou]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(247, 0, 0, 246, 'ifPwType', 'Pseudowire interface type [RFC5601]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(248, 0, 0, 247, 'ILAN', 'Internal LAN on a bridge per IEEE\n802.1ap [Glenn_Parsons][http://www.ieee802.org/1/files/private/ap-drafts/d3/802-1ap-D3-4.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(249, 0, 0, 248, 'PIP', 'Provider Instance Port on a bridge\nper IEEE 802.1ah PBB [Glenn_Parsons][http://www.ieee802.org/1/files/private/ah-drafts/d4/802-1ah-d4-2.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(250, 0, 0, 249, 'aluELP', 'Alcatel-Lucent Ethernet Link Protection [Xiaohua_Ma]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(251, 0, 0, 250, 'gpon', 'Gigabit-capable passive optical networks\n(G-PON)  as per ITU-T G.984 [Hyeri_Koh]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(252, 0, 0, 251, 'vdsl2', 'Very high speed digital subscriber\nline Version 2 (as per ITU-T Recommendation\nG.993.2) [Markus_Freudenberger][RFC5650]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(253, 0, 0, 252, 'capwapDot11Profile', 'WLAN Profile Interface [RFC5834]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(254, 0, 0, 253, 'capwapDot11Bss', 'WLAN BSS Interface [RFC5834]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(255, 0, 0, 254, 'capwapWtpVirtualRadio', 'WTP Virtual Radio Interface [RFC5833]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(256, 0, 0, 255, 'bits', 'bitsport [Du_Feng]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(257, 0, 0, 256, 'docsCableUpstreamRfPort', 'DOCSIS CATV Upstream RF\nPort [Michael_Patrick][https://www.cablelabs.com/specifications/CM-SP-EQAM-PMI-I01-081209.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(258, 0, 0, 257, 'cableDownstreamRfPort', 'CATV downstream RF port [Michael_Patrick]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(259, 0, 0, 258, 'vmwareVirtualNic', 'VMware Virtual Network Interface [Mike_MacFaden]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(260, 0, 0, 259, 'ieee802154', 'IEEE 802.15.4 WPAN interface [Juergen_Schoenwaelde][\"IEEE Std. 802.15.4-2006\", October 2006.]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(261, 0, 0, 260, 'otnOdu', 'OTN Optical Data Unit [Jim_Vance][https://www.itu.int/ITU-T/studygroups/com15/otn/OTNtutorial.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(262, 0, 0, 261, 'otnOtu', 'OTN Optical channel Transport Unit [Jim_Vance][https://www.itu.int/ITU-T/studygroups/com15/otn/OTNtutorial.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(263, 0, 0, 262, 'ifVfiType', 'VPLS Forwarding Instance Interface\nType [Manas_Pati]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(264, 0, 0, 263, 'g9981', 'G.998.1 bonded interface [RFC6768][RFC Errata 3591]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(265, 0, 0, 264, 'g9982', 'G.998.2 bonded interface [RFC6767][RFC Errata 3589]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(266, 0, 0, 265, 'g9983', 'G.998.3 bonded interface [RFC6766][RFC Errata 3588]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(267, 0, 0, 266, 'aluEpon (E-PON)', 'Ethernet Passive Optical Networks [Karel_Meijfroidt]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(268, 0, 0, 267, 'aluEponOnu', 'EPON Optical Network Unit [Karel_Meijfroidt]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(269, 0, 0, 268, 'aluEponPhysicalUni', 'EPON physical User to Network\ninterface [Karel_Meijfroidt]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(270, 0, 0, 269, 'aluEponLogicalLink', 'The emulation of a point-to-point\nlink over the EPON layer [Karel_Meijfroidt]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(271, 0, 0, 270, 'aluGponOnu', 'GPON Optical Network Unit [Karel_Meijfroidt][https://www.itu.int/rec/T-REC-G.984.2/en]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(272, 0, 0, 271, 'aluGponPhysicalUni', 'GPON physical User to Network\ninterface [Karel_Meijfroidt][https://www.itu.int/rec/T-REC-G.984.2/en]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(273, 0, 0, 272, 'vmwareNicTeam', 'VMware NIC Team [Michael_MacFaden][https://www.vmware.com/pdf/esx2_NIC_Teaming.pdf]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(274, 0, 0, 273, 'Reserved', 'The corresponding transmission value\nis allocated according to the following\nreference. [RFC6825]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(275, 0, 0, 274, 'Reserved', 'The corresponding transmission value\nis allocated according to the following reference. [RFC7257]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(276, 0, 0, 275, 'Reserved', 'The corresponding transmission value\nis allocated according to the following reference. [RFC7257]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(277, 0, 0, 276, 'Reserved', 'The corresponding transmission value\nis allocated according to the following reference. [RFC7257]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(278, 0, 0, 277, 'docsOfdmDownstream', 'CATV Downstream OFDM interface [https://www.cablelabs.com/specification/cable-modem-operations-support-system-interface-specification][Miguel_O_Alvarez]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(279, 0, 0, 278, 'docsOfdmaUpstream', 'CATV Upstream OFDMA interface [https://www.cablelabs.com/specification/cable-modem-operations-support-system-interface-specification][Miguel_O_Alvarez]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(280, 0, 0, 279, 'gfast', 'G.fast port [ITU-T G.9701]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(281, 0, 0, 280, 'sdci', 'SDCI (IO-Link) [IEC 61131-9 Edition 1.0 2013-09][Markus_Rentschler]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(282, 0, 0, 281, 'xboxWireless', 'Xbox wireless [Brandon_Jiang]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(283, 0, 0, 282, 'fastdsl', 'FastDSL [BBF TR-355][Broadband_Forum]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(284, 0, 0, 283, 'docsCableScte55d1FwdOob', 'Cable SCTE 55-1 OOB Forward Channel [https://www.scte.org/documents/pdf/Standards/ANSI_SCTE-55-1-2009.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(285, 0, 0, 284, 'docsCableScte55d1RetOob', 'Cable SCTE 55-1 OOB Return Channel [https://www.scte.org/documents/pdf/Standards/ANSI_SCTE-55-1-2009.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(286, 0, 0, 285, 'docsCableScte55d2DsOob', 'Cable SCTE 55-2 OOB Downstream Channel [https://web.archive.org/web/20190822104256/http://www.scte.org/documents/pdf/Standards/ANSI_SCTE%2055-2%202008.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(287, 0, 0, 286, 'docsCableScte55d2UsOob', 'Cable SCTE 55-2 OOB Upstream Channel [https://web.archive.org/web/20190822104256/http://www.scte.org/documents/pdf/Standards/ANSI_SCTE%2055-2%202008.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(288, 0, 0, 287, 'docsCableNdf', 'Cable Narrowband Digital Forward [http://www.cablelabs.com/wp-content/uploads/specdocs/CM-SP-R-OOB-I04-160923.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(289, 0, 0, 288, 'docsCableNdr', 'Cable Narrowband Digital Return [http://www.cablelabs.com/wp-content/uploads/specdocs/CM-SP-R-OOB-I04-160923.pdf][Brian_Hedstrom]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(290, 0, 0, 289, 'ptm', 'Packet Transfer Mode [ITU-T G.993.1, Annex H][ITU-T G.993.2][ITU-T G.9701][Broadband_Forum]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(291, 0, 0, 290, 'ghn', 'G.hn port [ITU-T G.9961][Broadband_Forum]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(292, 0, 0, 291, 'otnOtsi', 'Optical Tributary Signal [ITU-T G.959.1][Koteswara_Boyapati]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(293, 0, 0, 292, 'otnOtuc', 'OTN OTUCn [ITU-T G.709/Y.1331][Koteswara_Boyapati]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(294, 0, 0, 293, 'otnOduc', 'OTN ODUC [ITU-T G.709][Koteswara_Boyapati]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(295, 0, 0, 294, 'otnOtsig', 'OTN OTUC Signal [ITU-T G.709][Koteswara_Boyapati]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(296, 0, 0, 295, 'microwaveCarrierTermination', 'air interface of a single microwave carrier [RFC8561]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(297, 0, 0, 296, 'microwaveRadioLinkTerminal', 'radio link interface for one or several aggregated microwave carriers [RFC8561]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(298, 0, 0, 297, 'ieee8021axDrni', 'IEEE 802.1AX Distributed Resilient Network Interface [IEEE 802.1AX-Rev-d2-0][John_Messenger]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(299, 0, 0, 298, 'ax25', 'AX.25 network interfaces [AX.25 Link Access Protocol for Amateur Packet Radio version 2.2][Iain_Learmonth]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(300, 0, 0, 299, 'ieee19061nanocom', 'Nanoscale and Molecular Communication [IEEE 1906.1-2015][Stephen_F_Bush]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(301, 0, 0, 300, 'cpri', 'Common Public Radio Interface [CPRI v7.0][Renwang_Liu]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(302, 0, 0, 301, 'omni', 'Overlay Multilink Network Interface (OMNI) [draft-templin-6man-omni-00][Fred_L_Templin]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(303, 0, 0, 302, 'roe', 'Radio over Ethernet Interface [1914.3-2018 - IEEE Standard for Radio over Ethernet Encapsulations and Mappings][Renwang_Liu]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23'),
(304, 0, 0, 303, 'p2pOverLan', 'Point to Point over LAN interface [RFC9296]', 0, NULL, '2023-06-07 20:36:23', '2023-06-07 20:36:23');

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(10) UNSIGNED NOT NULL,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_devicenetworkcards_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `wifinetworks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkportwifis_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'only useful in case of Managed node',
  `version` varchar(20) DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_lastupdater` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `event` varchar(255) NOT NULL,
  `comment` text DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `allow_response` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_notifications` (`id`, `name`, `entities_id`, `itemtype`, `event`, `comment`, `is_recursive`, `is_active`, `date_mod`, `date_creation`, `allow_response`) VALUES
(1, 'Alert Tickets not closed', 0, 'Ticket', 'alertnotclosed', NULL, 1, 1, NULL, NULL, 1),
(2, 'New Ticket', 0, 'Ticket', 'new', NULL, 1, 1, NULL, NULL, 1),
(3, 'Update Ticket', 0, 'Ticket', 'update', NULL, 1, 0, NULL, NULL, 1),
(4, 'Close Ticket', 0, 'Ticket', 'closed', NULL, 1, 1, NULL, NULL, 1),
(5, 'Add Followup', 0, 'Ticket', 'add_followup', NULL, 1, 1, NULL, NULL, 1),
(6, 'Add Task', 0, 'Ticket', 'add_task', NULL, 1, 1, NULL, NULL, 1),
(7, 'Update Followup', 0, 'Ticket', 'update_followup', NULL, 1, 1, NULL, NULL, 1),
(8, 'Update Task', 0, 'Ticket', 'update_task', NULL, 1, 1, NULL, NULL, 1),
(9, 'Delete Followup', 0, 'Ticket', 'delete_followup', NULL, 1, 1, NULL, NULL, 1),
(10, 'Delete Task', 0, 'Ticket', 'delete_task', NULL, 1, 1, NULL, NULL, 1),
(11, 'Resolve ticket', 0, 'Ticket', 'solved', NULL, 1, 1, NULL, NULL, 1),
(12, 'Ticket Validation', 0, 'Ticket', 'validation', NULL, 1, 1, NULL, NULL, 1),
(13, 'New Reservation', 0, 'Reservation', 'new', NULL, 1, 1, NULL, NULL, 1),
(14, 'Update Reservation', 0, 'Reservation', 'update', NULL, 1, 1, NULL, NULL, 1),
(15, 'Delete Reservation', 0, 'Reservation', 'delete', NULL, 1, 1, NULL, NULL, 1),
(16, 'Alert Reservation', 0, 'Reservation', 'alert', NULL, 1, 1, NULL, NULL, 1),
(17, 'Contract Notice', 0, 'Contract', 'notice', NULL, 1, 1, NULL, NULL, 1),
(18, 'Contract End', 0, 'Contract', 'end', NULL, 1, 1, NULL, NULL, 1),
(19, 'MySQL Synchronization', 0, 'DBConnection', 'desynchronization', NULL, 1, 1, NULL, NULL, 1),
(20, 'Cartridges', 0, 'CartridgeItem', 'alert', NULL, 1, 1, NULL, NULL, 1),
(21, 'Consumables', 0, 'ConsumableItem', 'alert', NULL, 1, 1, NULL, NULL, 1),
(22, 'Infocoms', 0, 'Infocom', 'alert', NULL, 1, 1, NULL, NULL, 1),
(23, 'Software Licenses', 0, 'SoftwareLicense', 'alert', NULL, 1, 1, NULL, NULL, 1),
(24, 'Ticket Recall', 0, 'Ticket', 'recall', NULL, 1, 1, NULL, NULL, 1),
(25, 'Password Forget', 0, 'User', 'passwordforget', NULL, 1, 1, NULL, NULL, 1),
(26, 'Ticket Satisfaction', 0, 'Ticket', 'satisfaction', NULL, 1, 1, NULL, NULL, 1),
(27, 'Item not unique', 0, 'FieldUnicity', 'refuse', NULL, 1, 1, NULL, NULL, 1),
(28, 'CronTask Watcher', 0, 'CronTask', 'alert', NULL, 1, 1, NULL, NULL, 1),
(29, 'New Problem', 0, 'Problem', 'new', NULL, 1, 1, NULL, NULL, 1),
(30, 'Update Problem', 0, 'Problem', 'update', NULL, 1, 1, NULL, NULL, 1),
(31, 'Resolve Problem', 0, 'Problem', 'solved', NULL, 1, 1, NULL, NULL, 1),
(32, 'Add Task', 0, 'Problem', 'add_task', NULL, 1, 1, NULL, NULL, 1),
(33, 'Update Task', 0, 'Problem', 'update_task', NULL, 1, 1, NULL, NULL, 1),
(34, 'Delete Task', 0, 'Problem', 'delete_task', NULL, 1, 1, NULL, NULL, 1),
(35, 'Close Problem', 0, 'Problem', 'closed', NULL, 1, 1, NULL, NULL, 1),
(36, 'Delete Problem', 0, 'Problem', 'delete', NULL, 1, 1, NULL, NULL, 1),
(37, 'Ticket Validation Answer', 0, 'Ticket', 'validation_answer', NULL, 1, 1, NULL, NULL, 1),
(38, 'Contract End Periodicity', 0, 'Contract', 'periodicity', NULL, 1, 1, NULL, NULL, 1),
(39, 'Contract Notice Periodicity', 0, 'Contract', 'periodicitynotice', NULL, 1, 1, NULL, NULL, 1),
(40, 'Planning recall', 0, 'PlanningRecall', 'planningrecall', NULL, 1, 1, NULL, NULL, 1),
(41, 'Delete Ticket', 0, 'Ticket', 'delete', NULL, 1, 1, NULL, NULL, 1),
(42, 'New Change', 0, 'Change', 'new', NULL, 1, 1, NULL, NULL, 1),
(43, 'Update Change', 0, 'Change', 'update', NULL, 1, 1, NULL, NULL, 1),
(44, 'Resolve Change', 0, 'Change', 'solved', NULL, 1, 1, NULL, NULL, 1),
(45, 'Add Task', 0, 'Change', 'add_task', NULL, 1, 1, NULL, NULL, 1),
(46, 'Update Task', 0, 'Change', 'update_task', NULL, 1, 1, NULL, NULL, 1),
(47, 'Delete Task', 0, 'Change', 'delete_task', NULL, 1, 1, NULL, NULL, 1),
(48, 'Close Change', 0, 'Change', 'closed', NULL, 1, 1, NULL, NULL, 1),
(49, 'Delete Change', 0, 'Change', 'delete', NULL, 1, 1, NULL, NULL, 1),
(50, 'Ticket Satisfaction Answer', 0, 'Ticket', 'replysatisfaction', NULL, 1, 1, NULL, NULL, 1),
(51, 'Receiver errors', 0, 'MailCollector', 'error', NULL, 1, 1, NULL, NULL, 1),
(52, 'New Project', 0, 'Project', 'new', NULL, 1, 1, NULL, NULL, 1),
(53, 'Update Project', 0, 'Project', 'update', NULL, 1, 1, NULL, NULL, 1),
(54, 'Delete Project', 0, 'Project', 'delete', NULL, 1, 1, NULL, NULL, 1),
(55, 'New Project Task', 0, 'ProjectTask', 'new', NULL, 1, 1, NULL, NULL, 1),
(56, 'Update Project Task', 0, 'ProjectTask', 'update', NULL, 1, 1, NULL, NULL, 1),
(57, 'Delete Project Task', 0, 'ProjectTask', 'delete', NULL, 1, 1, NULL, NULL, 1),
(58, 'Request Unlock Items', 0, 'ObjectLock', 'unlock', NULL, 1, 1, NULL, NULL, 1),
(59, 'New user in requesters', 0, 'Ticket', 'requester_user', NULL, 1, 1, NULL, NULL, 1),
(60, 'New group in requesters', 0, 'Ticket', 'requester_group', NULL, 1, 1, NULL, NULL, 1),
(61, 'New user in observers', 0, 'Ticket', 'observer_user', NULL, 1, 1, NULL, NULL, 1),
(62, 'New group in observers', 0, 'Ticket', 'observer_group', NULL, 1, 1, NULL, NULL, 1),
(63, 'New user in assignees', 0, 'Ticket', 'assign_user', NULL, 1, 1, NULL, NULL, 1),
(64, 'New group in assignees', 0, 'Ticket', 'assign_group', NULL, 1, 1, NULL, NULL, 1),
(65, 'New supplier in assignees', 0, 'Ticket', 'assign_supplier', NULL, 1, 1, NULL, NULL, 1),
(66, 'Saved searches', 0, 'SavedSearch_Alert', 'alert', NULL, 1, 1, NULL, NULL, 1),
(67, 'Certificates', 0, 'Certificate', 'alert', NULL, 1, 1, NULL, NULL, 1),
(68, 'Alert expired domains', 0, 'Domain', 'ExpiredDomains', NULL, 1, 1, NULL, NULL, 1),
(69, 'Alert domains close expiries', 0, 'Domain', 'DomainsWhichExpire', NULL, 1, 1, NULL, NULL, 1),
(70, 'Password expires alert', 0, 'User', 'passwordexpires', NULL, 1, 1, NULL, NULL, 1),
(71, 'Check plugin updates', 0, 'Glpi\\Marketplace\\Controller', 'checkpluginsupdate', NULL, 1, 1, NULL, NULL, 1),
(72, 'New user mentionned', 0, 'Ticket', 'user_mention', NULL, 1, 1, NULL, NULL, 1);

DROP TABLE IF EXISTS `glpi_notifications_notificationtemplates`;
CREATE TABLE `glpi_notifications_notificationtemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `notifications_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mode` varchar(20) NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants',
  `notificationtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_notifications_notificationtemplates` (`id`, `notifications_id`, `mode`, `notificationtemplates_id`) VALUES
(1, 1, 'mailing', 6),
(2, 2, 'mailing', 4),
(3, 3, 'mailing', 4),
(4, 4, 'mailing', 4),
(5, 5, 'mailing', 4),
(6, 6, 'mailing', 4),
(7, 7, 'mailing', 4),
(8, 8, 'mailing', 4),
(9, 9, 'mailing', 4),
(10, 10, 'mailing', 4),
(11, 11, 'mailing', 4),
(12, 12, 'mailing', 7),
(13, 13, 'mailing', 2),
(14, 14, 'mailing', 2),
(15, 15, 'mailing', 2),
(16, 16, 'mailing', 3),
(17, 17, 'mailing', 12),
(18, 18, 'mailing', 12),
(19, 19, 'mailing', 1),
(20, 20, 'mailing', 8),
(21, 21, 'mailing', 9),
(22, 22, 'mailing', 10),
(23, 23, 'mailing', 11),
(24, 24, 'mailing', 4),
(25, 25, 'mailing', 13),
(26, 26, 'mailing', 14),
(27, 27, 'mailing', 15),
(28, 28, 'mailing', 16),
(29, 29, 'mailing', 17),
(30, 30, 'mailing', 17),
(31, 31, 'mailing', 17),
(32, 32, 'mailing', 17),
(33, 33, 'mailing', 17),
(34, 34, 'mailing', 17),
(35, 35, 'mailing', 17),
(36, 36, 'mailing', 17),
(37, 37, 'mailing', 7),
(38, 38, 'mailing', 12),
(39, 39, 'mailing', 12),
(40, 40, 'mailing', 18),
(41, 41, 'mailing', 4),
(42, 42, 'mailing', 19),
(43, 43, 'mailing', 19),
(44, 44, 'mailing', 19),
(45, 45, 'mailing', 19),
(46, 46, 'mailing', 19),
(47, 47, 'mailing', 19),
(48, 48, 'mailing', 19),
(49, 49, 'mailing', 19),
(50, 50, 'mailing', 14),
(51, 51, 'mailing', 20),
(52, 52, 'mailing', 21),
(53, 53, 'mailing', 21),
(54, 54, 'mailing', 21),
(55, 55, 'mailing', 22),
(56, 56, 'mailing', 22),
(57, 57, 'mailing', 22),
(58, 58, 'mailing', 23),
(59, 59, 'mailing', 4),
(60, 60, 'mailing', 4),
(61, 61, 'mailing', 4),
(62, 62, 'mailing', 4),
(63, 63, 'mailing', 4),
(64, 64, 'mailing', 4),
(65, 65, 'mailing', 4),
(66, 66, 'mailing', 24),
(67, 67, 'mailing', 25),
(68, 68, 'mailing', 26),
(69, 69, 'mailing', 26),
(70, 70, 'mailing', 27),
(71, 71, 'mailing', 28),
(72, 72, 'mailing', 4);

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `notifications_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_notificationtargets` (`id`, `items_id`, `type`, `notifications_id`) VALUES
(1, 3, 1, 13),
(2, 1, 1, 13),
(3, 3, 2, 2),
(4, 1, 1, 2),
(5, 1, 1, 3),
(6, 1, 1, 5),
(7, 1, 1, 4),
(8, 2, 1, 3),
(9, 4, 1, 3),
(10, 3, 1, 2),
(11, 3, 1, 3),
(12, 3, 1, 5),
(13, 3, 1, 4),
(14, 1, 1, 19),
(15, 14, 1, 12),
(16, 3, 1, 14),
(17, 1, 1, 14),
(18, 3, 1, 15),
(19, 1, 1, 15),
(20, 1, 1, 6),
(21, 3, 1, 6),
(22, 1, 1, 7),
(23, 3, 1, 7),
(24, 1, 1, 8),
(25, 3, 1, 8),
(26, 1, 1, 9),
(27, 3, 1, 9),
(28, 1, 1, 10),
(29, 3, 1, 10),
(30, 1, 1, 11),
(31, 3, 1, 11),
(32, 19, 1, 25),
(33, 3, 1, 26),
(34, 21, 1, 2),
(35, 21, 1, 3),
(36, 21, 1, 5),
(37, 21, 1, 4),
(38, 21, 1, 6),
(39, 21, 1, 7),
(40, 21, 1, 8),
(41, 21, 1, 9),
(42, 21, 1, 10),
(43, 21, 1, 11),
(46, 1, 1, 28),
(47, 3, 1, 29),
(48, 1, 1, 29),
(49, 21, 1, 29),
(50, 2, 1, 30),
(51, 4, 1, 30),
(52, 3, 1, 30),
(53, 1, 1, 30),
(54, 21, 1, 30),
(55, 3, 1, 31),
(56, 1, 1, 31),
(57, 21, 1, 31),
(58, 3, 1, 32),
(59, 1, 1, 32),
(60, 21, 1, 32),
(61, 3, 1, 33),
(62, 1, 1, 33),
(63, 21, 1, 33),
(64, 3, 1, 34),
(65, 1, 1, 34),
(66, 21, 1, 34),
(67, 3, 1, 35),
(68, 1, 1, 35),
(69, 21, 1, 35),
(70, 3, 1, 36),
(71, 1, 1, 36),
(72, 21, 1, 36),
(73, 14, 1, 37),
(74, 3, 1, 40),
(75, 1, 1, 41),
(76, 3, 1, 42),
(77, 1, 1, 42),
(78, 21, 1, 42),
(79, 2, 1, 43),
(80, 4, 1, 43),
(81, 3, 1, 43),
(82, 1, 1, 43),
(83, 21, 1, 43),
(84, 3, 1, 44),
(85, 1, 1, 44),
(86, 21, 1, 44),
(87, 3, 1, 45),
(88, 1, 1, 45),
(89, 21, 1, 45),
(90, 3, 1, 46),
(91, 1, 1, 46),
(92, 21, 1, 46),
(93, 3, 1, 47),
(94, 1, 1, 47),
(95, 21, 1, 47),
(96, 3, 1, 48),
(97, 1, 1, 48),
(98, 21, 1, 48),
(99, 3, 1, 49),
(100, 1, 1, 49),
(101, 21, 1, 49),
(102, 3, 1, 50),
(103, 2, 1, 50),
(104, 1, 1, 51),
(105, 27, 1, 52),
(106, 1, 1, 52),
(107, 28, 1, 52),
(108, 27, 1, 53),
(109, 1, 1, 53),
(110, 28, 1, 53),
(111, 27, 1, 54),
(112, 1, 1, 54),
(113, 28, 1, 54),
(114, 31, 1, 55),
(115, 1, 1, 55),
(116, 32, 1, 55),
(117, 31, 1, 56),
(118, 1, 1, 56),
(119, 32, 1, 56),
(120, 31, 1, 57),
(121, 1, 1, 57),
(122, 32, 1, 57),
(123, 19, 1, 58),
(124, 3, 1, 59),
(125, 13, 1, 60),
(126, 21, 1, 61),
(127, 20, 1, 62),
(128, 2, 1, 63),
(129, 9, 1, 64),
(130, 8, 1, 65),
(131, 19, 1, 66),
(132, 5, 1, 67),
(133, 23, 1, 67),
(134, 5, 1, 68),
(135, 23, 1, 68),
(136, 5, 1, 69),
(137, 23, 1, 69),
(138, 19, 1, 70),
(139, 1, 1, 71),
(140, 39, 1, 72);

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `itemtype` varchar(100) NOT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `css` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_notificationtemplates` (`id`, `name`, `itemtype`, `date_mod`, `comment`, `css`, `date_creation`) VALUES
(1, 'MySQL Synchronization', 'DBConnection', NULL, NULL, NULL, NULL),
(2, 'Reservations', 'Reservation', NULL, NULL, NULL, NULL),
(3, 'Alert Reservation', 'Reservation', NULL, NULL, NULL, NULL),
(4, 'Tickets', 'Ticket', NULL, NULL, NULL, NULL),
(5, 'Tickets (Simple)', 'Ticket', NULL, NULL, NULL, NULL),
(6, 'Alert Tickets not closed', 'Ticket', NULL, NULL, NULL, NULL),
(7, 'Tickets Validation', 'Ticket', NULL, NULL, NULL, NULL),
(8, 'Cartridges', 'CartridgeItem', NULL, NULL, NULL, NULL),
(9, 'Consumables', 'ConsumableItem', NULL, NULL, NULL, NULL),
(10, 'Infocoms', 'Infocom', NULL, NULL, NULL, NULL),
(11, 'Licenses', 'SoftwareLicense', NULL, NULL, NULL, NULL),
(12, 'Contracts', 'Contract', NULL, NULL, NULL, NULL),
(13, 'Password Forget', 'User', NULL, NULL, NULL, NULL),
(14, 'Ticket Satisfaction', 'Ticket', NULL, NULL, NULL, NULL),
(15, 'Item not unique', 'FieldUnicity', NULL, NULL, NULL, NULL),
(16, 'CronTask', 'CronTask', NULL, NULL, NULL, NULL),
(17, 'Problems', 'Problem', NULL, NULL, NULL, NULL),
(18, 'Planning recall', 'PlanningRecall', NULL, NULL, NULL, NULL),
(19, 'Changes', 'Change', NULL, NULL, NULL, NULL),
(20, 'Receiver errors', 'MailCollector', NULL, NULL, NULL, NULL),
(21, 'Projects', 'Project', NULL, NULL, NULL, NULL),
(22, 'Project Tasks', 'ProjectTask', NULL, NULL, NULL, NULL),
(23, 'Unlock Item request', 'ObjectLock', NULL, NULL, NULL, NULL),
(24, 'Saved searches alerts', 'SavedSearch_Alert', NULL, NULL, NULL, NULL),
(25, 'Certificates', 'Certificate', NULL, NULL, NULL, NULL),
(26, 'Alert domains', 'Domain', NULL, NULL, NULL, NULL),
(27, 'Password expires alert', 'User', NULL, NULL, NULL, NULL),
(28, 'Plugin updates', 'Glpi\\Marketplace\\Controller', NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(10) UNSIGNED NOT NULL,
  `notificationtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL,
  `content_text` text DEFAULT NULL,
  `content_html` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_notificationtemplatetranslations` (`id`, `notificationtemplates_id`, `language`, `subject`, `content_text`, `content_html`) VALUES
(1, 1, '', '##lang.dbconnection.title##', '##lang.dbconnection.delay## : ##dbconnection.delay##', '&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;'),
(2, 2, '', '##reservation.action##', '======================================================================\n##lang.reservation.user##: ##reservation.user##\n##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##\n##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##\n##lang.reservation.begin##: ##reservation.begin##\n##lang.reservation.end##: ##reservation.end##\n##lang.reservation.comment##: ##reservation.comment##\n======================================================================', '&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;\n&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;'),
(3, 3, '', '##reservation.action##  ##reservation.entity##', '##lang.reservation.entity## : ##reservation.entity##\n\n\n##FOREACHreservations##\n##lang.reservation.itemtype## : ##reservation.itemtype##\n\n ##lang.reservation.item## : ##reservation.item##\n\n ##reservation.url##\n\n ##ENDFOREACHreservations##', '&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;\n##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;\n ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;\n &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;\n ##ENDFOREACHreservations##&lt;/p&gt;'),
(4, 4, '', '##ticket.action## ##ticket.title##', ' ##IFticket.storestatus=5##\n ##lang.ticket.url## : ##ticket.urlapprove##\n ##lang.ticket.autoclosewarning##\n ##lang.ticket.solvedate## : ##ticket.solvedate##\n ##lang.ticket.solution.type## : ##ticket.solution.type##\n ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##\n ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##\n\n ##lang.ticket.description##\n\n ##lang.ticket.title## : ##ticket.title##\n ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##\n ##lang.ticket.creationdate## : ##ticket.creationdate##\n ##lang.ticket.closedate## : ##ticket.closedate##\n ##lang.ticket.requesttype## : ##ticket.requesttype##\n##lang.ticket.item.name## :\n\n##FOREACHitems##\n\n ##IFticket.itemtype##\n  ##ticket.itemtype## - ##ticket.item.name##\n  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##\n  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##\n  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##\n ##ENDIFticket.itemtype##\n\n##ENDFOREACHitems##\n##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##\n ##lang.ticket.status## : ##ticket.status##\n##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##\n ##lang.ticket.urgency## : ##ticket.urgency##\n ##lang.ticket.impact## : ##ticket.impact##\n ##lang.ticket.priority## : ##ticket.priority##\n##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##\n##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##\n ##lang.ticket.content## : ##ticket.content##\n ##IFticket.storestatus=6##\n\n ##lang.ticket.solvedate## : ##ticket.solvedate##\n ##lang.ticket.solution.type## : ##ticket.solution.type##\n ##lang.ticket.solution.description## : ##ticket.solution.description##\n ##ENDIFticket.storestatus##\n\n##FOREACHtimelineitems##\n[##timelineitems.date##]\n##lang.timelineitems.author## ##timelineitems.author##\n##lang.timelineitems.description## ##timelineitems.description##\n##lang.timelineitems.date## ##timelineitems.date##\n##lang.timelineitems.position## ##timelineitems.position##\n##lang.timelineitems.type## ##timelineitems.type##\n##lang.timelineitems.typename## ##timelineitems.typename##\n##ENDFOREACHtimelineitems##\n\n##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##\n##lang.ticket.numberoftasks## : ##ticket.numberoftasks##', '&lt;!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    --&gt;\n&lt;div&gt;##IFticket.storestatus=5##&lt;/div&gt;\n&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlapprove##\"&gt;##ticket.urlapprove##&lt;/a&gt; &lt;strong&gt;&#160;&lt;/strong&gt;&lt;/div&gt;\n&lt;div&gt;&lt;strong&gt;##lang.ticket.autoclosewarning##&lt;/strong&gt;&lt;/div&gt;\n&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.ticket.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##ticket.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.ticket.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##ticket.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.ticket.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##ticket.solution.description## ##ENDIFticket.storestatus##&lt;/div&gt;\n&lt;div&gt;##ELSEticket.storestatus## ##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;##ticket.url##&lt;/a&gt; ##ENDELSEticket.storestatus##&lt;/div&gt;\n&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.ticket.description##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.authors##&lt;/span&gt;&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.creationdate##&lt;/span&gt;&#160;:##ticket.creationdate## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.closedate##&lt;/span&gt;&#160;:##ticket.closedate## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.requesttype##&lt;/span&gt;&#160;:##ticket.requesttype##&lt;br /&gt;\n&lt;br /&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.item.name##&lt;/span&gt;&#160;:\n&lt;p&gt;##FOREACHitems##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## &lt;/div&gt;&lt;br /&gt;\n&lt;p&gt;##ENDFOREACHitems##&lt;/p&gt;\n##IFticket.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.assigntousers##&lt;/span&gt;&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.ticket.status## &lt;/span&gt;&#160;: ##ticket.status##&lt;br /&gt; ##IFticket.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.assigntogroups##&lt;/span&gt;&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.urgency##&lt;/span&gt;&#160;: ##ticket.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.impact##&lt;/span&gt;&#160;: ##ticket.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.priority##&lt;/span&gt;&#160;: ##ticket.priority## &lt;br /&gt; ##IFticket.user.email##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.user.email##&lt;/span&gt;&#160;: ##ticket.user.email ##ENDIFticket.user.email##    &lt;br /&gt; ##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.ticket.content##&lt;/span&gt;&#160;: ##ticket.content##&lt;/p&gt;\n&lt;br /&gt;##IFticket.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.ticket.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##ticket.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.ticket.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##ticket.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.ticket.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##ticket.solution.description##&lt;br /&gt;##ENDIFticket.storestatus##&lt;/p&gt;\n&lt;p&gt;##FOREACHtimelineitems##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;&lt;br /&gt;&lt;strong&gt; [##timelineitems.date##]&lt;/strong&gt;&lt;br /&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.timelineitems.author## &lt;/span&gt; &lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt;##timelineitems.author##&lt;/span&gt;&lt;br /&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.timelineitems.description## &lt;/span&gt; &lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt;##timelineitems.description##&lt;/span&gt;&lt;br /&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.timelineitems.date## &lt;/span&gt; &lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt;##timelineitems.date##&lt;/span&gt;&lt;br /&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.timelineitems.position## &lt;/span&gt;&lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt; ##timelineitems.position##&lt;/span&gt;&lt;/div&gt;\n&lt;div class=\"description b\"&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.timelineitems.type## &lt;/span&gt;&lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt; ##timelineitems.type##&lt;/span&gt;&lt;/div&gt;\n&lt;div class=\"description b\"&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.timelineitems.typename## &lt;/span&gt; &lt;span style=\"color: #000000; font-weight: bold; text-decoration: underline;\"&gt;##timelineitems.typename##&lt;/span&gt;&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHtimelineitems##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##&lt;/div&gt;\n&lt;div class=\"description b\"&gt;##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##&lt;/div&gt;'),
(5, 12, '', '##contract.action##  ##contract.entity##', '##lang.contract.entity## : ##contract.entity##\n\n##FOREACHcontracts##\n##lang.contract.name## : ##contract.name##\n##lang.contract.number## : ##contract.number##\n##lang.contract.time## : ##contract.time##\n##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##\n##contract.url##\n##ENDFOREACHcontracts##', '&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;\n&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :\n##contract.name##&lt;br /&gt;\n##lang.contract.number## : ##contract.number##&lt;br /&gt;\n##lang.contract.time## : ##contract.time##&lt;br /&gt;\n##IFcontract.type####lang.contract.type## : ##contract.type##\n##ENDIFcontract.type##&lt;br /&gt;\n&lt;a href=\"##contract.url##\"&gt;\n##contract.url##&lt;/a&gt;&lt;br /&gt;\n##ENDFOREACHcontracts##&lt;/p&gt;'),
(6, 5, '', '##ticket.action## ##ticket.title##', '##lang.ticket.url## : ##ticket.url##\n\n##lang.ticket.description##\n\n\n##lang.ticket.title##  :##ticket.title##\n\n##lang.ticket.authors##  :##IFticket.authors##\n##ticket.authors## ##ENDIFticket.authors##\n##ELSEticket.authors##--##ENDELSEticket.authors##\n\n##IFticket.category## ##lang.ticket.category##  :##ticket.category##\n##ENDIFticket.category## ##ELSEticket.category##\n##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##\n\n##lang.ticket.content##  : ##ticket.content##\n##IFticket.itemtype##\n##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##\n##ENDIFticket.itemtype##', '&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;\n##ticket.url##&lt;/a&gt;&lt;/div&gt;\n&lt;div class=\"description b\"&gt;\n##lang.ticket.description##&lt;/div&gt;\n&lt;p&gt;&lt;span\nstyle=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##\n&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n##lang.ticket.authors##&lt;/span&gt;\n##IFticket.authors## ##ticket.authors##\n##ENDIFticket.authors##\n##ELSEticket.authors##--##ENDELSEticket.authors##\n&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;\n##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##\n##ENDIFticket.category## ##ELSEticket.category##\n##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##\n&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n##lang.ticket.content##&lt;/span&gt;&#160;:\n##ticket.content##&lt;br /&gt;##IFticket.itemtype##\n&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;\n##lang.ticket.item.name##&lt;/span&gt;&#160;:\n##ticket.itemtype## - ##ticket.item.name##\n##ENDIFticket.itemtype##&lt;/p&gt;'),
(7, 7, '', '##ticket.action## ##ticket.title##', '##FOREACHvalidations##\n\n##IFvalidation.storestatus=2##\n##validation.submission.title##\n##lang.validation.commentsubmission## : ##validation.commentsubmission##\n##ENDIFvalidation.storestatus##\n##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##\n\n##lang.ticket.url## : ##ticket.urlvalidation##\n\n##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##\n##IFvalidation.commentvalidation##\n##lang.validation.commentvalidation## : ##validation.commentvalidation##\n##ENDIFvalidation.commentvalidation##\n##ENDFOREACHvalidations##', '&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;\n&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;\n&lt;div&gt;##validation.submission.title##&lt;/div&gt;\n&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;\n&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;\n&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;\n&lt;div&gt;&lt;/div&gt;\n&lt;div&gt;\n&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;\n&lt;/div&gt;\n&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##\n&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :\n&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##\n&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;'),
(8, 6, '', '##ticket.action## ##ticket.entity##', '##FOREACHtickets##\n##lang.ticket.authors##: ##ticket.authors##\n##lang.ticket.title##: ##ticket.title##\n##lang.ticket.priority##: ##ticket.priority##\n##lang.ticket.status##: ##ticket.status##\n##lang.ticket.attribution##: ##IFticket.assigntousers####ticket.assigntousers##\n##ENDIFticket.assigntousers####IFticket.assigntogroups##\n##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##\n##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##\n##lang.ticket.creationdate##: ##ticket.creationdate##\n##lang.ticket.content##: ##ticket.content## ##ENDFOREACHtickets##', '&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;\n&lt;tbody&gt;\n&lt;tr&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;\n&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;##FOREACHtickets##&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;\n&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;##ENDFOREACHtickets##&lt;/td&gt;\n&lt;/tr&gt;\n&lt;/tbody&gt;\n&lt;/table&gt;'),
(9, 9, '', '##consumable.action##  ##consumable.entity##', '##lang.consumable.entity## : ##consumable.entity##\n\n\n##FOREACHconsumables##\n##lang.consumable.item## : ##consumable.item##\n\n\n##lang.consumable.reference## : ##consumable.reference##\n\n##lang.consumable.remaining## : ##consumable.remaining##\n##lang.consumable.stock_target## : ##consumable.stock_target##\n##lang.consumable.to_order## : ##consumable.to_order##\n\n##consumable.url##\n\n##ENDFOREACHconsumables##', '&lt;p&gt;\n##lang.consumable.entity## : ##consumable.entity##\n&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##\n&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;\n&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;\n##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;\n##lang.consumable.stock_target## : ##consumable.stock_target##&lt;br /&gt;\n##lang.consumable.to_order## : ##consumable.to_order##&lt;br /&gt;\n&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;\n   ##ENDFOREACHconsumables##&lt;/p&gt;'),
(10, 8, '', '##cartridge.action##  ##cartridge.entity##', '##lang.cartridge.entity## : ##cartridge.entity##\n\n\n##FOREACHcartridges##\n##lang.cartridge.item## : ##cartridge.item##\n\n\n##lang.cartridge.reference## : ##cartridge.reference##\n\n##lang.cartridge.remaining## : ##cartridge.remaining##\n##lang.cartridge.stock_target## : ##cartridge.stock_target##\n##lang.cartridge.to_order## : ##cartridge.to_order##\n\n##cartridge.url##\n ##ENDFOREACHcartridges##', '&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##\n&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##\n&lt;br /&gt;##lang.cartridge.item## :\n##cartridge.item##&lt;br /&gt; &lt;br /&gt;\n##lang.cartridge.reference## :\n##cartridge.reference##&lt;br /&gt;\n##lang.cartridge.remaining## :\n##cartridge.remaining##&lt;br /&gt;\n##lang.cartridge.stock_target## :\n##cartridge.stock_target##&lt;br /&gt;\n##lang.cartridge.to_order## :\n##cartridge.to_order##&lt;br /&gt;\n&lt;a href=\"##cartridge.url##\"&gt;\n##cartridge.url##&lt;/a&gt;&lt;br /&gt;\n##ENDFOREACHcartridges##&lt;/p&gt;'),
(11, 10, '', '##infocom.action##  ##infocom.entity##', '##lang.infocom.entity## : ##infocom.entity##\n\n\n##FOREACHinfocoms##\n\n##lang.infocom.itemtype## : ##infocom.itemtype##\n\n##lang.infocom.item## : ##infocom.item##\n\n\n##lang.infocom.expirationdate## : ##infocom.expirationdate##\n\n##infocom.url##\n ##ENDFOREACHinfocoms##', '&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##\n&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##\n&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;\n##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;\n##lang.infocom.expirationdate## : ##infocom.expirationdate##\n&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;\n##infocom.url##&lt;/a&gt;&lt;br /&gt;\n##ENDFOREACHinfocoms##&lt;/p&gt;'),
(12, 11, '', '##license.action##  ##license.entity##', '##lang.license.entity## : ##license.entity##\n\n##FOREACHlicenses##\n\n##lang.license.item## : ##license.item##\n\n##lang.license.serial## : ##license.serial##\n\n##lang.license.expirationdate## : ##license.expirationdate##\n\n##license.url##\n ##ENDFOREACHlicenses##', '&lt;p&gt;\n##lang.license.entity## : ##license.entity##&lt;br /&gt;\n##FOREACHlicenses##\n&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;\n##lang.license.serial## : ##license.serial##&lt;br /&gt;\n##lang.license.expirationdate## : ##license.expirationdate##\n&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##\n&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;'),
(13, 13, '', '##user.action##', '##user.realname## ##user.firstname##\n\n##lang.passwordforget.information##\n\n##lang.passwordforget.link## ##user.passwordforgeturl##', '&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;\n&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;'),
(14, 14, '', '##ticket.action## ##ticket.title##', '##lang.ticket.title## : ##ticket.title##\n\n##lang.ticket.closedate## : ##ticket.closedate##\n\n##lang.satisfaction.text## ##ticket.urlsatisfaction##', '&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;\n&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;\n&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;'),
(15, 15, '', '##lang.unicity.action##', '##lang.unicity.entity## : ##unicity.entity##\n\n##lang.unicity.itemtype## : ##unicity.itemtype##\n\n##lang.unicity.message## : ##unicity.message##\n\n##lang.unicity.action_user## : ##unicity.action_user##\n\n##lang.unicity.action_type## : ##unicity.action_type##\n\n##lang.unicity.date## : ##unicity.date##', '&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;\n&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;\n&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;\n&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;\n&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;\n&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;'),
(16, 16, '', '##crontask.action##', '##lang.crontask.warning##\n\n##FOREACHcrontasks##\n ##crontask.name## : ##crontask.description##\n\n##ENDFOREACHcrontasks##', '&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;\n&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;'),
(17, 17, '', '##problem.action## ##problem.title##', '##IFproblem.storestatus=5##\n ##lang.problem.url## : ##problem.urlapprove##\n ##lang.problem.solvedate## : ##problem.solvedate##\n ##lang.problem.solution.type## : ##problem.solution.type##\n ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##\n ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##\n\n ##lang.problem.description##\n\n ##lang.problem.title##  :##problem.title##\n ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##\n ##lang.problem.creationdate##  :##problem.creationdate##\n ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##\n ##lang.problem.status##  : ##problem.status##\n ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##\n ##lang.problem.urgency##  : ##problem.urgency##\n ##lang.problem.impact##  : ##problem.impact##\n ##lang.problem.priority## : ##problem.priority##\n##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##\n ##lang.problem.content##  : ##problem.content##\n\n##IFproblem.storestatus=6##\n ##lang.problem.solvedate## : ##problem.solvedate##\n ##lang.problem.solution.type## : ##problem.solution.type##\n ##lang.problem.solution.description## : ##problem.solution.description##\n##ENDIFproblem.storestatus##\n ##lang.problem.numberoffollowups## : ##problem.numberoffollowups##\n\n##FOREACHfollowups##\n\n [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##\n ##lang.followup.author## ##followup.author##\n ##lang.followup.description## ##followup.description##\n ##lang.followup.date## ##followup.date##\n ##lang.followup.requesttype## ##followup.requesttype##\n\n##ENDFOREACHfollowups##\n ##lang.problem.numberoftickets## : ##problem.numberoftickets##\n\n##FOREACHtickets##\n [##ticket.date##] ##lang.problem.title## : ##ticket.title##\n ##lang.problem.content## ##ticket.content##\n\n##ENDFOREACHtickets##\n ##lang.problem.numberoftasks## : ##problem.numberoftasks##\n\n##FOREACHtasks##\n [##task.date##]\n ##lang.task.author## ##task.author##\n ##lang.task.description## ##task.description##\n ##lang.task.time## ##task.time##\n ##lang.task.category## ##task.category##\n\n##ENDFOREACHtasks##\n', '&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;\n&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;\n&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;\n&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;\n&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;\n&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.problem.numberoffollowups##&#160;: ##problem.numberoffollowups##&lt;/div&gt;\n&lt;p&gt;##FOREACHfollowups##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;&lt;br /&gt; &lt;strong&gt; [##followup.date##] &lt;em&gt;##lang.followup.isprivate## : ##followup.isprivate## &lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.author## &lt;/span&gt; ##followup.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.description## &lt;/span&gt; ##followup.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.date## &lt;/span&gt; ##followup.date##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.requesttype## &lt;/span&gt; ##followup.requesttype##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHfollowups##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;\n&lt;p&gt;##FOREACHtickets##&lt;/p&gt;\n&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##\n&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;\n&lt;p&gt;##FOREACHtasks##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;\n&lt;/div&gt;'),
(18, 18, '', '##recall.action##: ##recall.item.name##', '##recall.action##: ##recall.item.name##\n\n##recall.item.content##\n\n##lang.recall.planning.begin##: ##recall.planning.begin##\n##lang.recall.planning.end##: ##recall.planning.end##\n##lang.recall.planning.state##: ##recall.planning.state##\n##lang.recall.item.private##: ##recall.item.private##', '&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;\n&lt;p&gt;##recall.item.content##&lt;/p&gt;\n&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\n&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;'),
(19, 19, '', '##change.action## ##change.title##', '##IFchange.storestatus=5##\n ##lang.change.url## : ##change.urlapprove##\n ##lang.change.solvedate## : ##change.solvedate##\n ##lang.change.solution.type## : ##change.solution.type##\n ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##\n ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##\n\n ##lang.change.description##\n\n ##lang.change.title##  :##change.title##\n ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##\n ##lang.change.creationdate##  :##change.creationdate##\n ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##\n ##lang.change.status##  : ##change.status##\n ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##\n ##lang.change.urgency##  : ##change.urgency##\n ##lang.change.impact##  : ##change.impact##\n ##lang.change.priority## : ##change.priority##\n##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##\n ##lang.change.content##  : ##change.content##\n\n##IFchange.storestatus=6##\n ##lang.change.solvedate## : ##change.solvedate##\n ##lang.change.solution.type## : ##change.solution.type##\n ##lang.change.solution.description## : ##change.solution.description##\n##ENDIFchange.storestatus##\n ##lang.change.numberoffollowups## : ##change.numberoffollowups##\n\n##FOREACHfollowups##\n\n [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##\n ##lang.followup.author## ##followup.author##\n ##lang.followup.description## ##followup.description##\n ##lang.followup.date## ##followup.date##\n ##lang.followup.requesttype## ##followup.requesttype##\n\n##ENDFOREACHfollowups##\n ##lang.change.numberofproblems## : ##change.numberofproblems##\n\n##FOREACHproblems##\n [##problem.date##] ##lang.change.title## : ##problem.title##\n ##lang.change.content## ##problem.content##\n\n##ENDFOREACHproblems##\n ##lang.change.numberoftasks## : ##change.numberoftasks##\n\n##FOREACHtasks##\n [##task.date##]\n ##lang.task.author## ##task.author##\n ##lang.task.description## ##task.description##\n ##lang.task.time## ##task.time##\n ##lang.task.category## ##task.category##\n\n##ENDFOREACHtasks##\n', '&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;\n&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;\n&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;\n&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;\n&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;\n&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.change.numberoffollowups##&#160;: ##change.numberoffollowups##&lt;/div&gt;\n&lt;p&gt;##FOREACHfollowups##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;&lt;br /&gt; &lt;strong&gt; [##followup.date##] &lt;em&gt;##lang.followup.isprivate## : ##followup.isprivate## &lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.author## &lt;/span&gt; ##followup.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.description## &lt;/span&gt; ##followup.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.date## &lt;/span&gt; ##followup.date##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.followup.requesttype## &lt;/span&gt; ##followup.requesttype##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHfollowups##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;\n&lt;p&gt;##FOREACHproblems##&lt;/p&gt;\n&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##\n&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;\n&lt;p&gt;##FOREACHtasks##&lt;/p&gt;\n&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;\n&lt;/div&gt;'),
(20, 20, '', '##mailcollector.action##', '##FOREACHmailcollectors##\n##lang.mailcollector.name## : ##mailcollector.name##\n##lang.mailcollector.errors## : ##mailcollector.errors##\n##mailcollector.url##\n##ENDFOREACHmailcollectors##', '&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;\n&lt;p&gt;&lt;/p&gt;'),
(21, 21, '', '##project.action## ##project.name## ##project.code##', '##lang.project.url## : ##project.url##\n\n##lang.project.description##\n\n##lang.project.name## : ##project.name##\n##lang.project.code## : ##project.code##\n##lang.project.manager## : ##project.manager##\n##lang.project.managergroup## : ##project.managergroup##\n##lang.project.creationdate## : ##project.creationdate##\n##lang.project.priority## : ##project.priority##\n##lang.project.state## : ##project.state##\n##lang.project.type## : ##project.type##\n##lang.project.description## : ##project.description##\n\n##lang.project.numberoftasks## : ##project.numberoftasks##\n\n\n\n##FOREACHtasks##\n\n[##task.creationdate##]\n##lang.task.name## : ##task.name##\n##lang.task.state## : ##task.state##\n##lang.task.type## : ##task.type##\n##lang.task.percent## : ##task.percent##\n##lang.task.description## : ##task.description##\n\n##ENDFOREACHtasks##', '&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;\n&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;\n&lt;div&gt;\n&lt;p&gt;##FOREACHtasks##&lt;/p&gt;\n&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;\n&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` (`id`, `notificationtemplates_id`, `language`, `subject`, `content_text`, `content_html`) VALUES
(22, 22, '', '##projecttask.action## ##projecttask.name##', '##lang.projecttask.url## : ##projecttask.url##\n\n##lang.projecttask.description##\n\n##lang.projecttask.name## : ##projecttask.name##\n##lang.projecttask.project## : ##projecttask.project##\n##lang.projecttask.creationdate## : ##projecttask.creationdate##\n##lang.projecttask.state## : ##projecttask.state##\n##lang.projecttask.type## : ##projecttask.type##\n##lang.projecttask.description## : ##projecttask.description##\n\n##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##\n\n\n\n##FOREACHtasks##\n\n[##task.creationdate##]\n##lang.task.name## : ##task.name##\n##lang.task.state## : ##task.state##\n##lang.task.type## : ##task.type##\n##lang.task.percent## : ##task.percent##\n##lang.task.description## : ##task.description##\n\n##ENDFOREACHtasks##', '&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;\n&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;\n&lt;div&gt;\n&lt;p&gt;##FOREACHtasks##&lt;/p&gt;\n&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;\n&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;\n&lt;/div&gt;'),
(23, 23, '', '##objectlock.action##', '##objectlock.type## ###objectlock.id## - ##objectlock.name##\n\n      ##lang.objectlock.url##\n      ##objectlock.url##\n\n      ##lang.objectlock.date_mod##\n      ##objectlock.date_mod##\n\n      Hello ##objectlock.lockedby.firstname##,\n      Could go to this item and unlock it for me?\n      Thank you,\n      Regards,\n      ##objectlock.requester.firstname##', '&lt;table&gt;\n      &lt;tbody&gt;\n      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;\n      &lt;tr&gt;\n      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;\n      &lt;td&gt;##objectlock.url##&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;\n      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;/tbody&gt;\n      &lt;/table&gt;\n      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;'),
(24, 24, '', '##savedsearch.action## ##savedsearch.name##', '##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##\n\n      ##savedsearch.message##\n\n      ##lang.savedsearch.url##\n      ##savedsearch.url##\n\n      Regards,', '&lt;table&gt;\n      &lt;tbody&gt;\n      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;\n      &lt;tr&gt;&lt;td colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.message##&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;\n      &lt;tr&gt;\n      &lt;td&gt;##lang.savedsearch.url##&lt;/td&gt;\n      &lt;td&gt;##savedsearch.url##&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;/tbody&gt;\n      &lt;/table&gt;\n      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello &lt;br /&gt;Regards,&lt;/span&gt;&lt;/p&gt;'),
(25, 25, '', '##certificate.action##  ##certificate.name##', '##lang.certificate.entity## : ##certificate.entity##\n\n##lang.certificate.serial## : ##certificate.serial##\n\n##lang.certificate.expirationdate## : ##certificate.expirationdate##\n\n##certificate.url##', '&lt;p&gt;\n##lang.certificate.entity## : ##certificate.entity##&lt;br /&gt;\n&lt;br /&gt;##lang.certificate.name## : ##certificate.name##&lt;br /&gt;\n##lang.certificate.serial## : ##certificate.serial##&lt;br /&gt;\n##lang.certificate.expirationdate## : ##certificate.expirationdate##\n&lt;br /&gt; &lt;a href=\"##certificate.url##\"&gt; ##certificate.url##\n&lt;/a&gt;&lt;br /&gt;\n&lt;/p&gt;'),
(26, 26, '', '##domain.action## : ##domain.name##', '##lang.domain.entity## :##domain.entity##\n   ##lang.domain.name## : ##domain.name## - ##lang.domain.dateexpiration## : ##domain.dateexpiration##', '&lt;p&gt;##lang.domain.entity## :##domain.entity##&lt;br /&gt; &lt;br /&gt;\n                        ##lang.domain.name##  : ##domain.name## - ##lang.domain.dateexpiration## :  ##domain.dateexpiration##&lt;br /&gt;\n                        &lt;/p&gt;'),
(27, 27, '', '##user.action##', '##user.realname## ##user.firstname##,\n\n##IFuser.password.has_expired=1##\n##lang.password.has_expired.information##\n##ENDIFuser.password.has_expired##\n##ELSEuser.password.has_expired##\n##lang.password.expires_soon.information##\n##ENDELSEuser.password.has_expired##\n##lang.user.password.expiration.date##: ##user.password.expiration.date##\n##IFuser.account.lock.date##\n##lang.user.account.lock.date##: ##user.account.lock.date##\n##ENDIFuser.account.lock.date##\n\n##password.update.link## ##user.password.update.url##', '&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;\n\n##IFuser.password.has_expired=1##\n&lt;p&gt;##lang.password.has_expired.information##&lt;/p&gt;\n##ENDIFuser.password.has_expired##\n##ELSEuser.password.has_expired##\n&lt;p&gt;##lang.password.expires_soon.information##&lt;/p&gt;\n##ENDELSEuser.password.has_expired##\n&lt;p&gt;##lang.user.password.expiration.date##: ##user.password.expiration.date##&lt;/p&gt;\n##IFuser.account.lock.date##\n&lt;p&gt;##lang.user.account.lock.date##: ##user.account.lock.date##&lt;/p&gt;\n##ENDIFuser.account.lock.date##\n\n&lt;p&gt;##lang.password.update.link## &lt;a href=\"##user.password.update.url##\"&gt;##user.password.update.url##&lt;/a&gt;&lt;/p&gt;'),
(28, 28, '', '##lang.plugins_updates_available##', '##lang.plugins_updates_available##\n\n##FOREACHplugins##\n##plugin.name## :##plugin.old_version## -&gt; ##plugin.version##\n##ENDFOREACHplugins##\n\n##lang.marketplace.url## : ##marketplace.url##', '&lt;p&gt;##lang.plugins_updates_available##&lt;/p&gt;\n&lt;ul&gt;##FOREACHplugins##\n&lt;li&gt;##plugin.name## :##plugin.old_version## -&gt; ##plugin.version##&lt;/li&gt;\n##ENDFOREACHplugins##&lt;/ul&gt;\n&lt;p&gt;##lang.marketplace.url## : &lt;a title=\"##lang.marketplace.url##\" href=\"##marketplace.url##\" target=\"_blank\" rel=\"noopener\"&gt;##marketplace.url##&lt;/a&gt;&lt;/p&gt;');

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(10) UNSIGNED NOT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `subject` text DEFAULT NULL,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL COMMENT 'Type of locked object',
  `items_id` int(10) UNSIGNED NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(10) UNSIGNED NOT NULL COMMENT 'id of the locker',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_olalevelactions`;
CREATE TABLE `glpi_olalevelactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `olalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `action_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_olalevelcriterias`;
CREATE TABLE `glpi_olalevelcriterias` (
  `id` int(10) UNSIGNED NOT NULL,
  `olalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `criteria` varchar(255) DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_olalevels`;
CREATE TABLE `glpi_olalevels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `olas_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `match` char(10) DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_olalevels_tickets`;
CREATE TABLE `glpi_olalevels_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `olalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_olas`;
CREATE TABLE `glpi_olas` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `number_time` int(11) NOT NULL,
  `use_ticket_calendar` tinyint(4) NOT NULL DEFAULT 0,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `definition_time` varchar(255) DEFAULT NULL,
  `end_of_working_day` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `slms_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemeditions`;
CREATE TABLE `glpi_operatingsystemeditions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemkernels`;
CREATE TABLE `glpi_operatingsystemkernels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemkernelversions`;
CREATE TABLE `glpi_operatingsystemkernelversions` (
  `id` int(10) UNSIGNED NOT NULL,
  `operatingsystemkernels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_passivedcequipmentmodels`;
CREATE TABLE `glpi_passivedcequipmentmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_passivedcequipments`;
CREATE TABLE `glpi_passivedcequipments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `passivedcequipmentmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `passivedcequipmenttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to states (id)',
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_passivedcequipmenttypes`;
CREATE TABLE `glpi_passivedcequipmenttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pcivendors`;
CREATE TABLE `glpi_pcivendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `vendorid` varchar(4) NOT NULL,
  `deviceid` varchar(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pdumodels`;
CREATE TABLE `glpi_pdumodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `max_power` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `is_rackable` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pdus`;
CREATE TABLE `glpi_pdus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `pdumodels_id` int(10) UNSIGNED DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'RELATION to states (id)',
  `comment` text DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `pdutypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pdus_plugs`;
CREATE TABLE `glpi_pdus_plugs` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugs_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `pdus_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `number_plugs` int(11) DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pdus_racks`;
CREATE TABLE `glpi_pdus_racks` (
  `id` int(10) UNSIGNED NOT NULL,
  `racks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `pdus_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `side` int(11) DEFAULT 0,
  `position` int(11) NOT NULL,
  `bgcolor` varchar(7) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pdutypes`;
CREATE TABLE `glpi_pdutypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pendingreasons`;
CREATE TABLE `glpi_pendingreasons` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `followup_frequency` int(11) NOT NULL DEFAULT 0,
  `followups_before_resolution` int(11) NOT NULL DEFAULT 0,
  `itilfollowuptemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `solutiontemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_pendingreasons_items`;
CREATE TABLE `glpi_pendingreasons_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `pendingreasons_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL DEFAULT '',
  `followup_frequency` int(11) NOT NULL DEFAULT 0,
  `followups_before_resolution` int(11) NOT NULL DEFAULT 0,
  `bump_count` int(11) NOT NULL DEFAULT 0,
  `last_bump_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT 0,
  `required_units` int(11) NOT NULL DEFAULT 1,
  `depth` float NOT NULL DEFAULT 1,
  `power_connections` int(11) NOT NULL DEFAULT 0,
  `power_consumption` int(11) NOT NULL DEFAULT 0,
  `is_half_rack` tinyint(4) NOT NULL DEFAULT 0,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `peripheraltypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `peripheralmodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `brand` varchar(255) DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_global` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `phonetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `phonemodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `brand` varchar(255) DEFAULT NULL,
  `phonepowersupplies_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `number_line` varchar(255) DEFAULT NULL,
  `have_headset` tinyint(4) NOT NULL DEFAULT 0,
  `have_hp` tinyint(4) NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_global` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `last_inventory_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_planningeventcategories`;
CREATE TABLE `glpi_planningeventcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_planningexternalevents`;
CREATE TABLE `glpi_planningexternalevents` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `planningexternaleventtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 1,
  `date` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_guests` text DEFAULT NULL,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `rrule` text DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `planningeventcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `background` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_planningexternaleventtemplates`;
CREATE TABLE `glpi_planningexternaleventtemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT 0,
  `before_time` int(11) NOT NULL DEFAULT 0,
  `rrule` text DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `planningeventcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `background` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(10) UNSIGNED NOT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `before_time` int(11) NOT NULL DEFAULT -10,
  `when` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugins`;
CREATE TABLE `glpi_plugins` (
  `id` int(10) UNSIGNED NOT NULL,
  `directory` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `state` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  `license` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugins` (`id`, `directory`, `name`, `version`, `state`, `author`, `homepage`, `license`) VALUES
(1, 'glpiinventory', 'GLPI Inventory', '1.2.1', 1, 'Teclib\'', 'https://github.com/glpi-project/glpi-inventory-plugin', 'AGPLv3+'),
(2, 'formcreator', 'Form Creator', '2.13.6', 2, '<a href=\"http://www.teclib.com\">Teclib\'</a>', 'https://github.com/pluginsGLPI/formcreator', '<a href=\"/marketplace/formcreator/LICENSE.md\" target=\"_blank\">GPLv2</a>');

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_agentmodules`;
CREATE TABLE `glpi_plugin_glpiinventory_agentmodules` (
  `id` int(10) UNSIGNED NOT NULL,
  `modulename` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `exceptions` text DEFAULT NULL COMMENT 'array(agent_id)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_glpiinventory_agentmodules` (`id`, `modulename`, `is_active`, `exceptions`) VALUES
(1, 'WAKEONLAN', 0, '[]'),
(2, 'INVENTORY', 1, '[]'),
(3, 'InventoryComputerESX', 0, '[]'),
(4, 'NETWORKINVENTORY', 0, '[]'),
(5, 'NETWORKDISCOVERY', 0, '[]'),
(6, 'DEPLOY', 1, '[]'),
(7, 'Collect', 1, '[]');

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects`;
CREATE TABLE `glpi_plugin_glpiinventory_collects` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_files`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_files` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `plugin_glpiinventory_collects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `dir` varchar(255) DEFAULT NULL,
  `limit` int(11) NOT NULL DEFAULT 50,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `filter_regex` varchar(255) DEFAULT NULL,
  `filter_sizeequals` int(11) NOT NULL DEFAULT 0,
  `filter_sizegreater` int(11) NOT NULL DEFAULT 0,
  `filter_sizelower` int(11) NOT NULL DEFAULT 0,
  `filter_checksumsha512` varchar(255) DEFAULT NULL,
  `filter_checksumsha2` varchar(255) DEFAULT NULL,
  `filter_name` varchar(255) DEFAULT NULL,
  `filter_iname` varchar(255) DEFAULT NULL,
  `filter_is_file` tinyint(4) NOT NULL DEFAULT 1,
  `filter_is_dir` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_files_contents`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_files_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plugin_glpiinventory_collects_files_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `pathfile` text DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_registries`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_registries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `plugin_glpiinventory_collects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `hive` varchar(255) DEFAULT NULL,
  `path` text DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_registries_contents`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_registries_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plugin_glpiinventory_collects_registries_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_wmis`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_wmis` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `plugin_glpiinventory_collects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `moniker` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `properties` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_collects_wmis_contents`;
CREATE TABLE `glpi_plugin_glpiinventory_collects_wmis_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `computers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plugin_glpiinventory_collects_wmis_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `property` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_configs`;
CREATE TABLE `glpi_plugin_glpiinventory_configs` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_glpiinventory_configs` (`id`, `type`, `value`) VALUES
(1, 'version', '1.2.1'),
(2, 'ssl_only', '1'),
(3, 'delete_task', '7'),
(4, 'agent_port', '62354'),
(5, 'extradebug', '0'),
(6, 'users_id', '7'),
(7, 'wakeup_agent_max', '10'),
(8, 'import_software', '1'),
(9, 'import_volume', '1'),
(10, 'import_antivirus', '1'),
(11, 'import_registry', '1'),
(12, 'import_process', '1'),
(13, 'import_vm', '1'),
(14, 'import_monitor_on_partial_sn', '0'),
(15, 'component_processor', '1'),
(16, 'component_memory', '1'),
(17, 'component_harddrive', '1'),
(18, 'component_networkcard', '1'),
(19, 'component_graphiccard', '1'),
(20, 'component_soundcard', '1'),
(21, 'component_drive', '1'),
(22, 'component_networkdrive', '1'),
(23, 'component_control', '1'),
(24, 'component_removablemedia', '0'),
(25, 'component_simcard', '1'),
(26, 'component_powersupply', '1'),
(27, 'states_id_default', '0'),
(28, 'location', '0'),
(29, 'group', '0'),
(30, 'create_vm', '0'),
(31, 'component_networkcardvirtual', '1'),
(32, 'otherserial', '0'),
(33, 'component_battery', '1'),
(34, 'threads_networkdiscovery', '20'),
(35, 'threads_networkinventory', '10'),
(36, 'timeout_networkdiscovery', '1'),
(37, 'timeout_networkinventory', '15'),
(38, 'server_upload_path', '/var/www/html/glpi/files/_plugins/glpiinventory/upload'),
(39, 'alert_winpath', '1'),
(40, 'server_as_mirror', '1'),
(41, 'manage_osname', '1'),
(42, 'clean_on_demand_tasks', '-1'),
(43, 'reprepare_job', '0'),
(44, 'entities_id', '0'),
(45, 'is_recursive', '1');

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_credentialips`;
CREATE TABLE `glpi_plugin_glpiinventory_credentialips` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plugin_glpiinventory_credentials_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_credentials`;
CREATE TABLE `glpi_plugin_glpiinventory_credentials` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `itemtype` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deployfiles`;
CREATE TABLE `glpi_plugin_glpiinventory_deployfiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  `filesize` bigint(20) NOT NULL,
  `comment` text DEFAULT NULL,
  `sha512` char(128) NOT NULL,
  `shortsha512` char(6) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploygroups`;
CREATE TABLE `glpi_plugin_glpiinventory_deploygroups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text DEFAULT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploygroups_dynamicdatas`;
CREATE TABLE `glpi_plugin_glpiinventory_deploygroups_dynamicdatas` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploygroups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `fields_array` text DEFAULT NULL,
  `can_update_group` tinyint(4) NOT NULL DEFAULT 0,
  `computers_id_cache` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploygroups_staticdatas`;
CREATE TABLE `glpi_plugin_glpiinventory_deploygroups_staticdatas` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploygroups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploymirrors`;
CREATE TABLE `glpi_plugin_glpiinventory_deploymirrors` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `locations_id` int(10) UNSIGNED NOT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploypackages`;
CREATE TABLE `glpi_plugin_glpiinventory_deploypackages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `json` longtext DEFAULT NULL,
  `plugin_glpiinventory_deploygroups_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploypackages_entities`;
CREATE TABLE `glpi_plugin_glpiinventory_deploypackages_entities` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploypackages_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploypackages_groups`;
CREATE TABLE `glpi_plugin_glpiinventory_deploypackages_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploypackages_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploypackages_profiles`;
CREATE TABLE `glpi_plugin_glpiinventory_deploypackages_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploypackages_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deploypackages_users`;
CREATE TABLE `glpi_plugin_glpiinventory_deploypackages_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_deploypackages_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_deployuserinteractiontemplates`;
CREATE TABLE `glpi_plugin_glpiinventory_deployuserinteractiontemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `json` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_inventorycomputerstats`;
CREATE TABLE `glpi_plugin_glpiinventory_inventorycomputerstats` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `day` smallint(6) NOT NULL DEFAULT 0,
  `hour` tinyint(4) NOT NULL DEFAULT 0,
  `counter` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_plugin_glpiinventory_inventorycomputerstats` (`id`, `day`, `hour`, `counter`) VALUES
(1, 1, 0, 0),
(2, 1, 1, 0),
(3, 1, 2, 0),
(4, 1, 3, 0),
(5, 1, 4, 0),
(6, 1, 5, 0),
(7, 1, 6, 0),
(8, 1, 7, 0),
(9, 1, 8, 0),
(10, 1, 9, 0),
(11, 1, 10, 0),
(12, 1, 11, 0),
(13, 1, 12, 0),
(14, 1, 13, 0),
(15, 1, 14, 0),
(16, 1, 15, 0),
(17, 1, 16, 0),
(18, 1, 17, 0),
(19, 1, 18, 0),
(20, 1, 19, 0),
(21, 1, 20, 0),
(22, 1, 21, 0),
(23, 1, 22, 0),
(24, 1, 23, 0),
(25, 2, 0, 0),
(26, 2, 1, 0),
(27, 2, 2, 0),
(28, 2, 3, 0),
(29, 2, 4, 0),
(30, 2, 5, 0),
(31, 2, 6, 0),
(32, 2, 7, 0),
(33, 2, 8, 0),
(34, 2, 9, 0),
(35, 2, 10, 0),
(36, 2, 11, 0),
(37, 2, 12, 0),
(38, 2, 13, 0),
(39, 2, 14, 0),
(40, 2, 15, 0),
(41, 2, 16, 0),
(42, 2, 17, 0),
(43, 2, 18, 0),
(44, 2, 19, 0),
(45, 2, 20, 0),
(46, 2, 21, 0),
(47, 2, 22, 0),
(48, 2, 23, 0),
(49, 3, 0, 0),
(50, 3, 1, 0),
(51, 3, 2, 0),
(52, 3, 3, 0),
(53, 3, 4, 0),
(54, 3, 5, 0),
(55, 3, 6, 0),
(56, 3, 7, 0),
(57, 3, 8, 0),
(58, 3, 9, 0),
(59, 3, 10, 0),
(60, 3, 11, 0),
(61, 3, 12, 0),
(62, 3, 13, 0),
(63, 3, 14, 0),
(64, 3, 15, 0),
(65, 3, 16, 0),
(66, 3, 17, 0),
(67, 3, 18, 0),
(68, 3, 19, 0),
(69, 3, 20, 0),
(70, 3, 21, 0),
(71, 3, 22, 0),
(72, 3, 23, 0),
(73, 4, 0, 0),
(74, 4, 1, 0),
(75, 4, 2, 0),
(76, 4, 3, 0),
(77, 4, 4, 0),
(78, 4, 5, 0),
(79, 4, 6, 0),
(80, 4, 7, 0),
(81, 4, 8, 0),
(82, 4, 9, 0),
(83, 4, 10, 0),
(84, 4, 11, 0),
(85, 4, 12, 0),
(86, 4, 13, 0),
(87, 4, 14, 0),
(88, 4, 15, 0),
(89, 4, 16, 0),
(90, 4, 17, 0),
(91, 4, 18, 0),
(92, 4, 19, 0),
(93, 4, 20, 0),
(94, 4, 21, 0),
(95, 4, 22, 0),
(96, 4, 23, 0),
(97, 5, 0, 0),
(98, 5, 1, 0),
(99, 5, 2, 0),
(100, 5, 3, 0),
(101, 5, 4, 0),
(102, 5, 5, 0),
(103, 5, 6, 0),
(104, 5, 7, 0),
(105, 5, 8, 0),
(106, 5, 9, 0),
(107, 5, 10, 0),
(108, 5, 11, 0),
(109, 5, 12, 0),
(110, 5, 13, 0),
(111, 5, 14, 0),
(112, 5, 15, 0),
(113, 5, 16, 0),
(114, 5, 17, 0),
(115, 5, 18, 0),
(116, 5, 19, 0),
(117, 5, 20, 0),
(118, 5, 21, 0),
(119, 5, 22, 0),
(120, 5, 23, 0),
(121, 6, 0, 0),
(122, 6, 1, 0),
(123, 6, 2, 0),
(124, 6, 3, 0),
(125, 6, 4, 0),
(126, 6, 5, 0),
(127, 6, 6, 0),
(128, 6, 7, 0),
(129, 6, 8, 0),
(130, 6, 9, 0),
(131, 6, 10, 0),
(132, 6, 11, 0),
(133, 6, 12, 0),
(134, 6, 13, 0),
(135, 6, 14, 0),
(136, 6, 15, 0),
(137, 6, 16, 0),
(138, 6, 17, 0),
(139, 6, 18, 0),
(140, 6, 19, 0),
(141, 6, 20, 0),
(142, 6, 21, 0),
(143, 6, 22, 0),
(144, 6, 23, 0),
(145, 7, 0, 0),
(146, 7, 1, 0),
(147, 7, 2, 0),
(148, 7, 3, 0),
(149, 7, 4, 0),
(150, 7, 5, 0),
(151, 7, 6, 0),
(152, 7, 7, 0),
(153, 7, 8, 0),
(154, 7, 9, 0),
(155, 7, 10, 0),
(156, 7, 11, 0),
(157, 7, 12, 0),
(158, 7, 13, 0),
(159, 7, 14, 0),
(160, 7, 15, 0),
(161, 7, 16, 0),
(162, 7, 17, 0),
(163, 7, 18, 0),
(164, 7, 19, 0),
(165, 7, 20, 0),
(166, 7, 21, 0),
(167, 7, 22, 0),
(168, 7, 23, 0),
(169, 8, 0, 0),
(170, 8, 1, 0),
(171, 8, 2, 0),
(172, 8, 3, 0),
(173, 8, 4, 0),
(174, 8, 5, 0),
(175, 8, 6, 0),
(176, 8, 7, 0),
(177, 8, 8, 0),
(178, 8, 9, 0),
(179, 8, 10, 0),
(180, 8, 11, 0),
(181, 8, 12, 0),
(182, 8, 13, 0),
(183, 8, 14, 0),
(184, 8, 15, 0),
(185, 8, 16, 0),
(186, 8, 17, 0),
(187, 8, 18, 0),
(188, 8, 19, 0),
(189, 8, 20, 0),
(190, 8, 21, 0),
(191, 8, 22, 0),
(192, 8, 23, 0),
(193, 9, 0, 0),
(194, 9, 1, 0),
(195, 9, 2, 0),
(196, 9, 3, 0),
(197, 9, 4, 0),
(198, 9, 5, 0),
(199, 9, 6, 0),
(200, 9, 7, 0),
(201, 9, 8, 0),
(202, 9, 9, 0),
(203, 9, 10, 0),
(204, 9, 11, 0),
(205, 9, 12, 0),
(206, 9, 13, 0),
(207, 9, 14, 0),
(208, 9, 15, 0),
(209, 9, 16, 0),
(210, 9, 17, 0),
(211, 9, 18, 0),
(212, 9, 19, 0),
(213, 9, 20, 0),
(214, 9, 21, 0),
(215, 9, 22, 0),
(216, 9, 23, 0),
(217, 10, 0, 0),
(218, 10, 1, 0),
(219, 10, 2, 0),
(220, 10, 3, 0),
(221, 10, 4, 0),
(222, 10, 5, 0),
(223, 10, 6, 0),
(224, 10, 7, 0),
(225, 10, 8, 0),
(226, 10, 9, 0),
(227, 10, 10, 0),
(228, 10, 11, 0),
(229, 10, 12, 0),
(230, 10, 13, 0),
(231, 10, 14, 0),
(232, 10, 15, 0),
(233, 10, 16, 0),
(234, 10, 17, 0),
(235, 10, 18, 0),
(236, 10, 19, 0),
(237, 10, 20, 0),
(238, 10, 21, 0),
(239, 10, 22, 0),
(240, 10, 23, 0),
(241, 11, 0, 0),
(242, 11, 1, 0),
(243, 11, 2, 0),
(244, 11, 3, 0),
(245, 11, 4, 0),
(246, 11, 5, 0),
(247, 11, 6, 0),
(248, 11, 7, 0),
(249, 11, 8, 0),
(250, 11, 9, 0),
(251, 11, 10, 0),
(252, 11, 11, 0),
(253, 11, 12, 0),
(254, 11, 13, 0),
(255, 11, 14, 0),
(256, 11, 15, 0),
(257, 11, 16, 0),
(258, 11, 17, 0),
(259, 11, 18, 0),
(260, 11, 19, 0),
(261, 11, 20, 0),
(262, 11, 21, 0),
(263, 11, 22, 0),
(264, 11, 23, 0),
(265, 12, 0, 0),
(266, 12, 1, 0),
(267, 12, 2, 0),
(268, 12, 3, 0),
(269, 12, 4, 0),
(270, 12, 5, 0),
(271, 12, 6, 0),
(272, 12, 7, 0),
(273, 12, 8, 0),
(274, 12, 9, 0),
(275, 12, 10, 0),
(276, 12, 11, 0),
(277, 12, 12, 0),
(278, 12, 13, 0),
(279, 12, 14, 0),
(280, 12, 15, 0),
(281, 12, 16, 0),
(282, 12, 17, 0),
(283, 12, 18, 0),
(284, 12, 19, 0),
(285, 12, 20, 0),
(286, 12, 21, 0),
(287, 12, 22, 0),
(288, 12, 23, 0),
(289, 13, 0, 0),
(290, 13, 1, 0),
(291, 13, 2, 0),
(292, 13, 3, 0),
(293, 13, 4, 0),
(294, 13, 5, 0),
(295, 13, 6, 0),
(296, 13, 7, 0),
(297, 13, 8, 0),
(298, 13, 9, 0),
(299, 13, 10, 0),
(300, 13, 11, 0),
(301, 13, 12, 0),
(302, 13, 13, 0),
(303, 13, 14, 0),
(304, 13, 15, 0),
(305, 13, 16, 0),
(306, 13, 17, 0),
(307, 13, 18, 0),
(308, 13, 19, 0),
(309, 13, 20, 0),
(310, 13, 21, 0),
(311, 13, 22, 0),
(312, 13, 23, 0),
(313, 14, 0, 0),
(314, 14, 1, 0),
(315, 14, 2, 0),
(316, 14, 3, 0),
(317, 14, 4, 0),
(318, 14, 5, 0),
(319, 14, 6, 0),
(320, 14, 7, 0),
(321, 14, 8, 0),
(322, 14, 9, 0),
(323, 14, 10, 0),
(324, 14, 11, 0),
(325, 14, 12, 0),
(326, 14, 13, 0),
(327, 14, 14, 0),
(328, 14, 15, 0),
(329, 14, 16, 0),
(330, 14, 17, 0),
(331, 14, 18, 0),
(332, 14, 19, 0),
(333, 14, 20, 0),
(334, 14, 21, 0),
(335, 14, 22, 0),
(336, 14, 23, 0),
(337, 15, 0, 0),
(338, 15, 1, 0),
(339, 15, 2, 0),
(340, 15, 3, 0),
(341, 15, 4, 0),
(342, 15, 5, 0),
(343, 15, 6, 0),
(344, 15, 7, 0),
(345, 15, 8, 0),
(346, 15, 9, 0),
(347, 15, 10, 0),
(348, 15, 11, 0),
(349, 15, 12, 0),
(350, 15, 13, 0),
(351, 15, 14, 0),
(352, 15, 15, 0),
(353, 15, 16, 0),
(354, 15, 17, 0),
(355, 15, 18, 0),
(356, 15, 19, 0),
(357, 15, 20, 0),
(358, 15, 21, 0),
(359, 15, 22, 0),
(360, 15, 23, 0),
(361, 16, 0, 0),
(362, 16, 1, 0),
(363, 16, 2, 0),
(364, 16, 3, 0),
(365, 16, 4, 0),
(366, 16, 5, 0),
(367, 16, 6, 0),
(368, 16, 7, 0),
(369, 16, 8, 0),
(370, 16, 9, 0),
(371, 16, 10, 0),
(372, 16, 11, 0),
(373, 16, 12, 0),
(374, 16, 13, 0),
(375, 16, 14, 0),
(376, 16, 15, 0),
(377, 16, 16, 0),
(378, 16, 17, 0),
(379, 16, 18, 0),
(380, 16, 19, 0),
(381, 16, 20, 0),
(382, 16, 21, 0),
(383, 16, 22, 0),
(384, 16, 23, 0),
(385, 17, 0, 0),
(386, 17, 1, 0),
(387, 17, 2, 0),
(388, 17, 3, 0),
(389, 17, 4, 0),
(390, 17, 5, 0),
(391, 17, 6, 0),
(392, 17, 7, 0),
(393, 17, 8, 0),
(394, 17, 9, 0),
(395, 17, 10, 0),
(396, 17, 11, 0),
(397, 17, 12, 0),
(398, 17, 13, 0),
(399, 17, 14, 0),
(400, 17, 15, 0),
(401, 17, 16, 0),
(402, 17, 17, 0),
(403, 17, 18, 0),
(404, 17, 19, 0),
(405, 17, 20, 0),
(406, 17, 21, 0),
(407, 17, 22, 0),
(408, 17, 23, 0),
(409, 18, 0, 0),
(410, 18, 1, 0),
(411, 18, 2, 0),
(412, 18, 3, 0),
(413, 18, 4, 0),
(414, 18, 5, 0),
(415, 18, 6, 0),
(416, 18, 7, 0),
(417, 18, 8, 0),
(418, 18, 9, 0),
(419, 18, 10, 0),
(420, 18, 11, 0),
(421, 18, 12, 0),
(422, 18, 13, 0),
(423, 18, 14, 0),
(424, 18, 15, 0),
(425, 18, 16, 0),
(426, 18, 17, 0),
(427, 18, 18, 0),
(428, 18, 19, 0),
(429, 18, 20, 0),
(430, 18, 21, 0),
(431, 18, 22, 0),
(432, 18, 23, 0),
(433, 19, 0, 0),
(434, 19, 1, 0),
(435, 19, 2, 0),
(436, 19, 3, 0),
(437, 19, 4, 0),
(438, 19, 5, 0),
(439, 19, 6, 0),
(440, 19, 7, 0),
(441, 19, 8, 0),
(442, 19, 9, 0),
(443, 19, 10, 0),
(444, 19, 11, 0),
(445, 19, 12, 0),
(446, 19, 13, 0),
(447, 19, 14, 0),
(448, 19, 15, 0),
(449, 19, 16, 0),
(450, 19, 17, 0),
(451, 19, 18, 0),
(452, 19, 19, 0),
(453, 19, 20, 0),
(454, 19, 21, 0),
(455, 19, 22, 0),
(456, 19, 23, 0),
(457, 20, 0, 0),
(458, 20, 1, 0),
(459, 20, 2, 0),
(460, 20, 3, 0),
(461, 20, 4, 0),
(462, 20, 5, 0),
(463, 20, 6, 0),
(464, 20, 7, 0),
(465, 20, 8, 0),
(466, 20, 9, 0),
(467, 20, 10, 0),
(468, 20, 11, 0),
(469, 20, 12, 0),
(470, 20, 13, 0),
(471, 20, 14, 0),
(472, 20, 15, 0),
(473, 20, 16, 0),
(474, 20, 17, 0),
(475, 20, 18, 0),
(476, 20, 19, 0),
(477, 20, 20, 0),
(478, 20, 21, 0),
(479, 20, 22, 0),
(480, 20, 23, 0),
(481, 21, 0, 0),
(482, 21, 1, 0),
(483, 21, 2, 0),
(484, 21, 3, 0),
(485, 21, 4, 0),
(486, 21, 5, 0),
(487, 21, 6, 0),
(488, 21, 7, 0),
(489, 21, 8, 0),
(490, 21, 9, 0),
(491, 21, 10, 0),
(492, 21, 11, 0),
(493, 21, 12, 0),
(494, 21, 13, 0),
(495, 21, 14, 0),
(496, 21, 15, 0),
(497, 21, 16, 0),
(498, 21, 17, 0),
(499, 21, 18, 0),
(500, 21, 19, 0),
(501, 21, 20, 0),
(502, 21, 21, 0),
(503, 21, 22, 0),
(504, 21, 23, 0),
(505, 22, 0, 0),
(506, 22, 1, 0),
(507, 22, 2, 0),
(508, 22, 3, 0),
(509, 22, 4, 0),
(510, 22, 5, 0),
(511, 22, 6, 0),
(512, 22, 7, 0),
(513, 22, 8, 0),
(514, 22, 9, 0),
(515, 22, 10, 0),
(516, 22, 11, 0),
(517, 22, 12, 0),
(518, 22, 13, 0),
(519, 22, 14, 0),
(520, 22, 15, 0),
(521, 22, 16, 0),
(522, 22, 17, 0),
(523, 22, 18, 0),
(524, 22, 19, 0),
(525, 22, 20, 0),
(526, 22, 21, 0),
(527, 22, 22, 0),
(528, 22, 23, 0),
(529, 23, 0, 0),
(530, 23, 1, 0),
(531, 23, 2, 0),
(532, 23, 3, 0),
(533, 23, 4, 0),
(534, 23, 5, 0),
(535, 23, 6, 0),
(536, 23, 7, 0),
(537, 23, 8, 0),
(538, 23, 9, 0),
(539, 23, 10, 0),
(540, 23, 11, 0),
(541, 23, 12, 0),
(542, 23, 13, 0),
(543, 23, 14, 0),
(544, 23, 15, 0),
(545, 23, 16, 0),
(546, 23, 17, 0),
(547, 23, 18, 0),
(548, 23, 19, 0),
(549, 23, 20, 0),
(550, 23, 21, 0),
(551, 23, 22, 0),
(552, 23, 23, 0),
(553, 24, 0, 0),
(554, 24, 1, 0),
(555, 24, 2, 0),
(556, 24, 3, 0),
(557, 24, 4, 0),
(558, 24, 5, 0),
(559, 24, 6, 0),
(560, 24, 7, 0),
(561, 24, 8, 0),
(562, 24, 9, 0),
(563, 24, 10, 0),
(564, 24, 11, 0),
(565, 24, 12, 0),
(566, 24, 13, 0),
(567, 24, 14, 0),
(568, 24, 15, 0),
(569, 24, 16, 0),
(570, 24, 17, 0),
(571, 24, 18, 0),
(572, 24, 19, 0),
(573, 24, 20, 0),
(574, 24, 21, 0),
(575, 24, 22, 0),
(576, 24, 23, 0),
(577, 25, 0, 0),
(578, 25, 1, 0),
(579, 25, 2, 0),
(580, 25, 3, 0),
(581, 25, 4, 0),
(582, 25, 5, 0),
(583, 25, 6, 0),
(584, 25, 7, 0),
(585, 25, 8, 0),
(586, 25, 9, 0),
(587, 25, 10, 0),
(588, 25, 11, 0),
(589, 25, 12, 0),
(590, 25, 13, 0),
(591, 25, 14, 0),
(592, 25, 15, 0),
(593, 25, 16, 0),
(594, 25, 17, 0),
(595, 25, 18, 0),
(596, 25, 19, 0),
(597, 25, 20, 0),
(598, 25, 21, 0),
(599, 25, 22, 0),
(600, 25, 23, 0),
(601, 26, 0, 0),
(602, 26, 1, 0),
(603, 26, 2, 0),
(604, 26, 3, 0),
(605, 26, 4, 0),
(606, 26, 5, 0),
(607, 26, 6, 0),
(608, 26, 7, 0),
(609, 26, 8, 0),
(610, 26, 9, 0),
(611, 26, 10, 0),
(612, 26, 11, 0),
(613, 26, 12, 0),
(614, 26, 13, 0),
(615, 26, 14, 0),
(616, 26, 15, 0),
(617, 26, 16, 0),
(618, 26, 17, 0),
(619, 26, 18, 0),
(620, 26, 19, 0),
(621, 26, 20, 0),
(622, 26, 21, 0),
(623, 26, 22, 0),
(624, 26, 23, 0),
(625, 27, 0, 0),
(626, 27, 1, 0),
(627, 27, 2, 0),
(628, 27, 3, 0),
(629, 27, 4, 0),
(630, 27, 5, 0),
(631, 27, 6, 0),
(632, 27, 7, 0),
(633, 27, 8, 0),
(634, 27, 9, 0),
(635, 27, 10, 0),
(636, 27, 11, 0),
(637, 27, 12, 0),
(638, 27, 13, 0),
(639, 27, 14, 0),
(640, 27, 15, 0),
(641, 27, 16, 0),
(642, 27, 17, 0),
(643, 27, 18, 0),
(644, 27, 19, 0),
(645, 27, 20, 0),
(646, 27, 21, 0),
(647, 27, 22, 0),
(648, 27, 23, 0),
(649, 28, 0, 0),
(650, 28, 1, 0),
(651, 28, 2, 0),
(652, 28, 3, 0),
(653, 28, 4, 0),
(654, 28, 5, 0),
(655, 28, 6, 0),
(656, 28, 7, 0),
(657, 28, 8, 0),
(658, 28, 9, 0),
(659, 28, 10, 0),
(660, 28, 11, 0),
(661, 28, 12, 0),
(662, 28, 13, 0),
(663, 28, 14, 0),
(664, 28, 15, 0),
(665, 28, 16, 0),
(666, 28, 17, 0),
(667, 28, 18, 0),
(668, 28, 19, 0),
(669, 28, 20, 0),
(670, 28, 21, 0),
(671, 28, 22, 0),
(672, 28, 23, 0),
(673, 29, 0, 0),
(674, 29, 1, 0),
(675, 29, 2, 0),
(676, 29, 3, 0),
(677, 29, 4, 0),
(678, 29, 5, 0),
(679, 29, 6, 0),
(680, 29, 7, 0),
(681, 29, 8, 0),
(682, 29, 9, 0),
(683, 29, 10, 0),
(684, 29, 11, 0),
(685, 29, 12, 0),
(686, 29, 13, 0),
(687, 29, 14, 0),
(688, 29, 15, 0),
(689, 29, 16, 0),
(690, 29, 17, 0),
(691, 29, 18, 0),
(692, 29, 19, 0),
(693, 29, 20, 0),
(694, 29, 21, 0),
(695, 29, 22, 0),
(696, 29, 23, 0),
(697, 30, 0, 0),
(698, 30, 1, 0),
(699, 30, 2, 0),
(700, 30, 3, 0),
(701, 30, 4, 0),
(702, 30, 5, 0),
(703, 30, 6, 0),
(704, 30, 7, 0),
(705, 30, 8, 0),
(706, 30, 9, 0),
(707, 30, 10, 0),
(708, 30, 11, 0),
(709, 30, 12, 0),
(710, 30, 13, 0),
(711, 30, 14, 0),
(712, 30, 15, 0),
(713, 30, 16, 0),
(714, 30, 17, 0),
(715, 30, 18, 0),
(716, 30, 19, 0),
(717, 30, 20, 0),
(718, 30, 21, 0),
(719, 30, 22, 0),
(720, 30, 23, 0),
(721, 31, 0, 0),
(722, 31, 1, 0),
(723, 31, 2, 0),
(724, 31, 3, 0),
(725, 31, 4, 0),
(726, 31, 5, 0),
(727, 31, 6, 0),
(728, 31, 7, 0),
(729, 31, 8, 0),
(730, 31, 9, 0),
(731, 31, 10, 0),
(732, 31, 11, 0),
(733, 31, 12, 0),
(734, 31, 13, 0),
(735, 31, 14, 0),
(736, 31, 15, 0),
(737, 31, 16, 0),
(738, 31, 17, 0),
(739, 31, 18, 0),
(740, 31, 19, 0),
(741, 31, 20, 0),
(742, 31, 21, 0),
(743, 31, 22, 0),
(744, 31, 23, 0),
(745, 32, 0, 0),
(746, 32, 1, 0),
(747, 32, 2, 0),
(748, 32, 3, 0),
(749, 32, 4, 0),
(750, 32, 5, 0),
(751, 32, 6, 0),
(752, 32, 7, 0),
(753, 32, 8, 0),
(754, 32, 9, 0),
(755, 32, 10, 0),
(756, 32, 11, 0),
(757, 32, 12, 0),
(758, 32, 13, 0),
(759, 32, 14, 0),
(760, 32, 15, 0),
(761, 32, 16, 0),
(762, 32, 17, 0),
(763, 32, 18, 0),
(764, 32, 19, 0),
(765, 32, 20, 0),
(766, 32, 21, 0),
(767, 32, 22, 0),
(768, 32, 23, 0),
(769, 33, 0, 0),
(770, 33, 1, 0),
(771, 33, 2, 0),
(772, 33, 3, 0),
(773, 33, 4, 0),
(774, 33, 5, 0),
(775, 33, 6, 0),
(776, 33, 7, 0),
(777, 33, 8, 0),
(778, 33, 9, 0),
(779, 33, 10, 0),
(780, 33, 11, 0),
(781, 33, 12, 0),
(782, 33, 13, 0),
(783, 33, 14, 0),
(784, 33, 15, 0),
(785, 33, 16, 0),
(786, 33, 17, 0),
(787, 33, 18, 0),
(788, 33, 19, 0),
(789, 33, 20, 0),
(790, 33, 21, 0),
(791, 33, 22, 0),
(792, 33, 23, 0),
(793, 34, 0, 0),
(794, 34, 1, 0),
(795, 34, 2, 0),
(796, 34, 3, 0),
(797, 34, 4, 0),
(798, 34, 5, 0),
(799, 34, 6, 0),
(800, 34, 7, 0),
(801, 34, 8, 0),
(802, 34, 9, 0),
(803, 34, 10, 0),
(804, 34, 11, 0),
(805, 34, 12, 0),
(806, 34, 13, 0),
(807, 34, 14, 0),
(808, 34, 15, 0),
(809, 34, 16, 0),
(810, 34, 17, 0),
(811, 34, 18, 0),
(812, 34, 19, 0),
(813, 34, 20, 0),
(814, 34, 21, 0),
(815, 34, 22, 0),
(816, 34, 23, 0),
(817, 35, 0, 0),
(818, 35, 1, 0),
(819, 35, 2, 0),
(820, 35, 3, 0),
(821, 35, 4, 0),
(822, 35, 5, 0),
(823, 35, 6, 0),
(824, 35, 7, 0),
(825, 35, 8, 0),
(826, 35, 9, 0),
(827, 35, 10, 0),
(828, 35, 11, 0),
(829, 35, 12, 0),
(830, 35, 13, 0),
(831, 35, 14, 0),
(832, 35, 15, 0),
(833, 35, 16, 0),
(834, 35, 17, 0),
(835, 35, 18, 0),
(836, 35, 19, 0),
(837, 35, 20, 0),
(838, 35, 21, 0),
(839, 35, 22, 0),
(840, 35, 23, 0),
(841, 36, 0, 0),
(842, 36, 1, 0),
(843, 36, 2, 0),
(844, 36, 3, 0),
(845, 36, 4, 0),
(846, 36, 5, 0),
(847, 36, 6, 0),
(848, 36, 7, 0),
(849, 36, 8, 0),
(850, 36, 9, 0),
(851, 36, 10, 0),
(852, 36, 11, 0),
(853, 36, 12, 0),
(854, 36, 13, 0),
(855, 36, 14, 0),
(856, 36, 15, 0),
(857, 36, 16, 0),
(858, 36, 17, 0),
(859, 36, 18, 0),
(860, 36, 19, 0),
(861, 36, 20, 0),
(862, 36, 21, 0),
(863, 36, 22, 0),
(864, 36, 23, 0),
(865, 37, 0, 0),
(866, 37, 1, 0),
(867, 37, 2, 0),
(868, 37, 3, 0),
(869, 37, 4, 0),
(870, 37, 5, 0),
(871, 37, 6, 0),
(872, 37, 7, 0),
(873, 37, 8, 0),
(874, 37, 9, 0),
(875, 37, 10, 0),
(876, 37, 11, 0),
(877, 37, 12, 0),
(878, 37, 13, 0),
(879, 37, 14, 0),
(880, 37, 15, 0),
(881, 37, 16, 0),
(882, 37, 17, 0),
(883, 37, 18, 0),
(884, 37, 19, 0),
(885, 37, 20, 0),
(886, 37, 21, 0),
(887, 37, 22, 0),
(888, 37, 23, 0),
(889, 38, 0, 0),
(890, 38, 1, 0),
(891, 38, 2, 0),
(892, 38, 3, 0),
(893, 38, 4, 0),
(894, 38, 5, 0),
(895, 38, 6, 0),
(896, 38, 7, 0),
(897, 38, 8, 0),
(898, 38, 9, 0),
(899, 38, 10, 0),
(900, 38, 11, 0),
(901, 38, 12, 0),
(902, 38, 13, 0),
(903, 38, 14, 0),
(904, 38, 15, 0),
(905, 38, 16, 0),
(906, 38, 17, 0),
(907, 38, 18, 0),
(908, 38, 19, 0),
(909, 38, 20, 0),
(910, 38, 21, 0),
(911, 38, 22, 0),
(912, 38, 23, 0),
(913, 39, 0, 0),
(914, 39, 1, 0),
(915, 39, 2, 0),
(916, 39, 3, 0),
(917, 39, 4, 0),
(918, 39, 5, 0),
(919, 39, 6, 0),
(920, 39, 7, 0),
(921, 39, 8, 0),
(922, 39, 9, 0),
(923, 39, 10, 0),
(924, 39, 11, 0),
(925, 39, 12, 0),
(926, 39, 13, 0),
(927, 39, 14, 0),
(928, 39, 15, 0),
(929, 39, 16, 0),
(930, 39, 17, 0),
(931, 39, 18, 0),
(932, 39, 19, 0),
(933, 39, 20, 0),
(934, 39, 21, 0),
(935, 39, 22, 0),
(936, 39, 23, 0),
(937, 40, 0, 0),
(938, 40, 1, 0),
(939, 40, 2, 0),
(940, 40, 3, 0),
(941, 40, 4, 0),
(942, 40, 5, 0),
(943, 40, 6, 0),
(944, 40, 7, 0),
(945, 40, 8, 0),
(946, 40, 9, 0),
(947, 40, 10, 0),
(948, 40, 11, 0),
(949, 40, 12, 0),
(950, 40, 13, 0),
(951, 40, 14, 0),
(952, 40, 15, 0),
(953, 40, 16, 0),
(954, 40, 17, 0),
(955, 40, 18, 0),
(956, 40, 19, 0),
(957, 40, 20, 0),
(958, 40, 21, 0),
(959, 40, 22, 0),
(960, 40, 23, 0),
(961, 41, 0, 0),
(962, 41, 1, 0),
(963, 41, 2, 0),
(964, 41, 3, 0),
(965, 41, 4, 0),
(966, 41, 5, 0),
(967, 41, 6, 0),
(968, 41, 7, 0),
(969, 41, 8, 0),
(970, 41, 9, 0),
(971, 41, 10, 0),
(972, 41, 11, 0),
(973, 41, 12, 0),
(974, 41, 13, 0),
(975, 41, 14, 0),
(976, 41, 15, 0),
(977, 41, 16, 0),
(978, 41, 17, 0),
(979, 41, 18, 0),
(980, 41, 19, 0),
(981, 41, 20, 0),
(982, 41, 21, 0),
(983, 41, 22, 0),
(984, 41, 23, 0),
(985, 42, 0, 0),
(986, 42, 1, 0),
(987, 42, 2, 0),
(988, 42, 3, 0),
(989, 42, 4, 0),
(990, 42, 5, 0),
(991, 42, 6, 0),
(992, 42, 7, 0),
(993, 42, 8, 0),
(994, 42, 9, 0),
(995, 42, 10, 0),
(996, 42, 11, 0),
(997, 42, 12, 0),
(998, 42, 13, 0),
(999, 42, 14, 0),
(1000, 42, 15, 0),
(1001, 42, 16, 0),
(1002, 42, 17, 0),
(1003, 42, 18, 0),
(1004, 42, 19, 0),
(1005, 42, 20, 0),
(1006, 42, 21, 0),
(1007, 42, 22, 0),
(1008, 42, 23, 0),
(1009, 43, 0, 0),
(1010, 43, 1, 0),
(1011, 43, 2, 0),
(1012, 43, 3, 0),
(1013, 43, 4, 0),
(1014, 43, 5, 0),
(1015, 43, 6, 0),
(1016, 43, 7, 0),
(1017, 43, 8, 0),
(1018, 43, 9, 0),
(1019, 43, 10, 0),
(1020, 43, 11, 0),
(1021, 43, 12, 0),
(1022, 43, 13, 0),
(1023, 43, 14, 0),
(1024, 43, 15, 0),
(1025, 43, 16, 0),
(1026, 43, 17, 0),
(1027, 43, 18, 0),
(1028, 43, 19, 0),
(1029, 43, 20, 0),
(1030, 43, 21, 0),
(1031, 43, 22, 0),
(1032, 43, 23, 0),
(1033, 44, 0, 0),
(1034, 44, 1, 0),
(1035, 44, 2, 0),
(1036, 44, 3, 0),
(1037, 44, 4, 0),
(1038, 44, 5, 0),
(1039, 44, 6, 0),
(1040, 44, 7, 0),
(1041, 44, 8, 0),
(1042, 44, 9, 0),
(1043, 44, 10, 0),
(1044, 44, 11, 0),
(1045, 44, 12, 0),
(1046, 44, 13, 0),
(1047, 44, 14, 0),
(1048, 44, 15, 0),
(1049, 44, 16, 0),
(1050, 44, 17, 0),
(1051, 44, 18, 0),
(1052, 44, 19, 0),
(1053, 44, 20, 0),
(1054, 44, 21, 0),
(1055, 44, 22, 0),
(1056, 44, 23, 0),
(1057, 45, 0, 0),
(1058, 45, 1, 0),
(1059, 45, 2, 0),
(1060, 45, 3, 0),
(1061, 45, 4, 0),
(1062, 45, 5, 0),
(1063, 45, 6, 0),
(1064, 45, 7, 0),
(1065, 45, 8, 0),
(1066, 45, 9, 0),
(1067, 45, 10, 0),
(1068, 45, 11, 0),
(1069, 45, 12, 0),
(1070, 45, 13, 0),
(1071, 45, 14, 0),
(1072, 45, 15, 0),
(1073, 45, 16, 0),
(1074, 45, 17, 0),
(1075, 45, 18, 0),
(1076, 45, 19, 0),
(1077, 45, 20, 0),
(1078, 45, 21, 0),
(1079, 45, 22, 0),
(1080, 45, 23, 0),
(1081, 46, 0, 0),
(1082, 46, 1, 0),
(1083, 46, 2, 0),
(1084, 46, 3, 0),
(1085, 46, 4, 0),
(1086, 46, 5, 0),
(1087, 46, 6, 0),
(1088, 46, 7, 0),
(1089, 46, 8, 0),
(1090, 46, 9, 0),
(1091, 46, 10, 0),
(1092, 46, 11, 0),
(1093, 46, 12, 0),
(1094, 46, 13, 0),
(1095, 46, 14, 0),
(1096, 46, 15, 0),
(1097, 46, 16, 0),
(1098, 46, 17, 0),
(1099, 46, 18, 0),
(1100, 46, 19, 0),
(1101, 46, 20, 0),
(1102, 46, 21, 0),
(1103, 46, 22, 0),
(1104, 46, 23, 0),
(1105, 47, 0, 0),
(1106, 47, 1, 0),
(1107, 47, 2, 0),
(1108, 47, 3, 0),
(1109, 47, 4, 0),
(1110, 47, 5, 0),
(1111, 47, 6, 0),
(1112, 47, 7, 0),
(1113, 47, 8, 0),
(1114, 47, 9, 0),
(1115, 47, 10, 0),
(1116, 47, 11, 0),
(1117, 47, 12, 0),
(1118, 47, 13, 0),
(1119, 47, 14, 0),
(1120, 47, 15, 0),
(1121, 47, 16, 0),
(1122, 47, 17, 0),
(1123, 47, 18, 0),
(1124, 47, 19, 0),
(1125, 47, 20, 0),
(1126, 47, 21, 0),
(1127, 47, 22, 0),
(1128, 47, 23, 0),
(1129, 48, 0, 0),
(1130, 48, 1, 0),
(1131, 48, 2, 0),
(1132, 48, 3, 0),
(1133, 48, 4, 0),
(1134, 48, 5, 0),
(1135, 48, 6, 0),
(1136, 48, 7, 0),
(1137, 48, 8, 0),
(1138, 48, 9, 0),
(1139, 48, 10, 0),
(1140, 48, 11, 0),
(1141, 48, 12, 0),
(1142, 48, 13, 0),
(1143, 48, 14, 0),
(1144, 48, 15, 0),
(1145, 48, 16, 0),
(1146, 48, 17, 0),
(1147, 48, 18, 0),
(1148, 48, 19, 0),
(1149, 48, 20, 0),
(1150, 48, 21, 0),
(1151, 48, 22, 0),
(1152, 48, 23, 0),
(1153, 49, 0, 0),
(1154, 49, 1, 0),
(1155, 49, 2, 0),
(1156, 49, 3, 0),
(1157, 49, 4, 0),
(1158, 49, 5, 0),
(1159, 49, 6, 0),
(1160, 49, 7, 0),
(1161, 49, 8, 0),
(1162, 49, 9, 0),
(1163, 49, 10, 0),
(1164, 49, 11, 0),
(1165, 49, 12, 0),
(1166, 49, 13, 0),
(1167, 49, 14, 0),
(1168, 49, 15, 0),
(1169, 49, 16, 0),
(1170, 49, 17, 0),
(1171, 49, 18, 0),
(1172, 49, 19, 0),
(1173, 49, 20, 0),
(1174, 49, 21, 0),
(1175, 49, 22, 0),
(1176, 49, 23, 0),
(1177, 50, 0, 0),
(1178, 50, 1, 0),
(1179, 50, 2, 0),
(1180, 50, 3, 0),
(1181, 50, 4, 0),
(1182, 50, 5, 0),
(1183, 50, 6, 0),
(1184, 50, 7, 0),
(1185, 50, 8, 0),
(1186, 50, 9, 0),
(1187, 50, 10, 0),
(1188, 50, 11, 0),
(1189, 50, 12, 0),
(1190, 50, 13, 0),
(1191, 50, 14, 0),
(1192, 50, 15, 0),
(1193, 50, 16, 0),
(1194, 50, 17, 0),
(1195, 50, 18, 0),
(1196, 50, 19, 0),
(1197, 50, 20, 0),
(1198, 50, 21, 0),
(1199, 50, 22, 0),
(1200, 50, 23, 0),
(1201, 51, 0, 0),
(1202, 51, 1, 0),
(1203, 51, 2, 0),
(1204, 51, 3, 0),
(1205, 51, 4, 0),
(1206, 51, 5, 0),
(1207, 51, 6, 0),
(1208, 51, 7, 0),
(1209, 51, 8, 0),
(1210, 51, 9, 0),
(1211, 51, 10, 0),
(1212, 51, 11, 0),
(1213, 51, 12, 0),
(1214, 51, 13, 0),
(1215, 51, 14, 0),
(1216, 51, 15, 0),
(1217, 51, 16, 0),
(1218, 51, 17, 0),
(1219, 51, 18, 0),
(1220, 51, 19, 0),
(1221, 51, 20, 0),
(1222, 51, 21, 0),
(1223, 51, 22, 0),
(1224, 51, 23, 0),
(1225, 52, 0, 0),
(1226, 52, 1, 0),
(1227, 52, 2, 0),
(1228, 52, 3, 0),
(1229, 52, 4, 0),
(1230, 52, 5, 0),
(1231, 52, 6, 0),
(1232, 52, 7, 0),
(1233, 52, 8, 0),
(1234, 52, 9, 0),
(1235, 52, 10, 0),
(1236, 52, 11, 0),
(1237, 52, 12, 0),
(1238, 52, 13, 0),
(1239, 52, 14, 0),
(1240, 52, 15, 0),
(1241, 52, 16, 0),
(1242, 52, 17, 0),
(1243, 52, 18, 0),
(1244, 52, 19, 0),
(1245, 52, 20, 0),
(1246, 52, 21, 0),
(1247, 52, 22, 0),
(1248, 52, 23, 0),
(1249, 53, 0, 0),
(1250, 53, 1, 0),
(1251, 53, 2, 0),
(1252, 53, 3, 0),
(1253, 53, 4, 0),
(1254, 53, 5, 0),
(1255, 53, 6, 0),
(1256, 53, 7, 0),
(1257, 53, 8, 0),
(1258, 53, 9, 0),
(1259, 53, 10, 0),
(1260, 53, 11, 0),
(1261, 53, 12, 0),
(1262, 53, 13, 0),
(1263, 53, 14, 0),
(1264, 53, 15, 0),
(1265, 53, 16, 0),
(1266, 53, 17, 0),
(1267, 53, 18, 0),
(1268, 53, 19, 0),
(1269, 53, 20, 0),
(1270, 53, 21, 0),
(1271, 53, 22, 0),
(1272, 53, 23, 0),
(1273, 54, 0, 0),
(1274, 54, 1, 0),
(1275, 54, 2, 0),
(1276, 54, 3, 0),
(1277, 54, 4, 0),
(1278, 54, 5, 0),
(1279, 54, 6, 0),
(1280, 54, 7, 0),
(1281, 54, 8, 0),
(1282, 54, 9, 0),
(1283, 54, 10, 0),
(1284, 54, 11, 0),
(1285, 54, 12, 0),
(1286, 54, 13, 0),
(1287, 54, 14, 0),
(1288, 54, 15, 0),
(1289, 54, 16, 0),
(1290, 54, 17, 0),
(1291, 54, 18, 0),
(1292, 54, 19, 0),
(1293, 54, 20, 0),
(1294, 54, 21, 0),
(1295, 54, 22, 0),
(1296, 54, 23, 0),
(1297, 55, 0, 0),
(1298, 55, 1, 0),
(1299, 55, 2, 0),
(1300, 55, 3, 0),
(1301, 55, 4, 0),
(1302, 55, 5, 0),
(1303, 55, 6, 0),
(1304, 55, 7, 0),
(1305, 55, 8, 0),
(1306, 55, 9, 0),
(1307, 55, 10, 0),
(1308, 55, 11, 0),
(1309, 55, 12, 0),
(1310, 55, 13, 0),
(1311, 55, 14, 0),
(1312, 55, 15, 0),
(1313, 55, 16, 0),
(1314, 55, 17, 0),
(1315, 55, 18, 0),
(1316, 55, 19, 0),
(1317, 55, 20, 0),
(1318, 55, 21, 0),
(1319, 55, 22, 0),
(1320, 55, 23, 0),
(1321, 56, 0, 0),
(1322, 56, 1, 0),
(1323, 56, 2, 0),
(1324, 56, 3, 0),
(1325, 56, 4, 0),
(1326, 56, 5, 0),
(1327, 56, 6, 0),
(1328, 56, 7, 0),
(1329, 56, 8, 0),
(1330, 56, 9, 0),
(1331, 56, 10, 0),
(1332, 56, 11, 0),
(1333, 56, 12, 0),
(1334, 56, 13, 0),
(1335, 56, 14, 0),
(1336, 56, 15, 0),
(1337, 56, 16, 0),
(1338, 56, 17, 0),
(1339, 56, 18, 0),
(1340, 56, 19, 0),
(1341, 56, 20, 0),
(1342, 56, 21, 0),
(1343, 56, 22, 0),
(1344, 56, 23, 0),
(1345, 57, 0, 0),
(1346, 57, 1, 0),
(1347, 57, 2, 0),
(1348, 57, 3, 0),
(1349, 57, 4, 0),
(1350, 57, 5, 0),
(1351, 57, 6, 0),
(1352, 57, 7, 0),
(1353, 57, 8, 0),
(1354, 57, 9, 0),
(1355, 57, 10, 0),
(1356, 57, 11, 0),
(1357, 57, 12, 0),
(1358, 57, 13, 0),
(1359, 57, 14, 0),
(1360, 57, 15, 0),
(1361, 57, 16, 0),
(1362, 57, 17, 0),
(1363, 57, 18, 0),
(1364, 57, 19, 0),
(1365, 57, 20, 0),
(1366, 57, 21, 0),
(1367, 57, 22, 0),
(1368, 57, 23, 0),
(1369, 58, 0, 0),
(1370, 58, 1, 0),
(1371, 58, 2, 0),
(1372, 58, 3, 0),
(1373, 58, 4, 0),
(1374, 58, 5, 0),
(1375, 58, 6, 0),
(1376, 58, 7, 0),
(1377, 58, 8, 0),
(1378, 58, 9, 0),
(1379, 58, 10, 0),
(1380, 58, 11, 0),
(1381, 58, 12, 0),
(1382, 58, 13, 0),
(1383, 58, 14, 0),
(1384, 58, 15, 0),
(1385, 58, 16, 0),
(1386, 58, 17, 0),
(1387, 58, 18, 0),
(1388, 58, 19, 0),
(1389, 58, 20, 0),
(1390, 58, 21, 0),
(1391, 58, 22, 0),
(1392, 58, 23, 0),
(1393, 59, 0, 0),
(1394, 59, 1, 0),
(1395, 59, 2, 0),
(1396, 59, 3, 0),
(1397, 59, 4, 0),
(1398, 59, 5, 0),
(1399, 59, 6, 0),
(1400, 59, 7, 0),
(1401, 59, 8, 0),
(1402, 59, 9, 0),
(1403, 59, 10, 0),
(1404, 59, 11, 0),
(1405, 59, 12, 0),
(1406, 59, 13, 0),
(1407, 59, 14, 0),
(1408, 59, 15, 0),
(1409, 59, 16, 0),
(1410, 59, 17, 0),
(1411, 59, 18, 0),
(1412, 59, 19, 0),
(1413, 59, 20, 0),
(1414, 59, 21, 0),
(1415, 59, 22, 0),
(1416, 59, 23, 0),
(1417, 60, 0, 0),
(1418, 60, 1, 0),
(1419, 60, 2, 0),
(1420, 60, 3, 0),
(1421, 60, 4, 0),
(1422, 60, 5, 0),
(1423, 60, 6, 0),
(1424, 60, 7, 0),
(1425, 60, 8, 0),
(1426, 60, 9, 0),
(1427, 60, 10, 0),
(1428, 60, 11, 0),
(1429, 60, 12, 0),
(1430, 60, 13, 0),
(1431, 60, 14, 0),
(1432, 60, 15, 0),
(1433, 60, 16, 0),
(1434, 60, 17, 0),
(1435, 60, 18, 0),
(1436, 60, 19, 0),
(1437, 60, 20, 0),
(1438, 60, 21, 0),
(1439, 60, 22, 0),
(1440, 60, 23, 0),
(1441, 61, 0, 0),
(1442, 61, 1, 0),
(1443, 61, 2, 0),
(1444, 61, 3, 0),
(1445, 61, 4, 0),
(1446, 61, 5, 0),
(1447, 61, 6, 0),
(1448, 61, 7, 0),
(1449, 61, 8, 0),
(1450, 61, 9, 0),
(1451, 61, 10, 0),
(1452, 61, 11, 0),
(1453, 61, 12, 0),
(1454, 61, 13, 0),
(1455, 61, 14, 0),
(1456, 61, 15, 0),
(1457, 61, 16, 0),
(1458, 61, 17, 0),
(1459, 61, 18, 0),
(1460, 61, 19, 0),
(1461, 61, 20, 0),
(1462, 61, 21, 0),
(1463, 61, 22, 0),
(1464, 61, 23, 0),
(1465, 62, 0, 0),
(1466, 62, 1, 0),
(1467, 62, 2, 0),
(1468, 62, 3, 0),
(1469, 62, 4, 0),
(1470, 62, 5, 0),
(1471, 62, 6, 0),
(1472, 62, 7, 0),
(1473, 62, 8, 0),
(1474, 62, 9, 0),
(1475, 62, 10, 0),
(1476, 62, 11, 0),
(1477, 62, 12, 0),
(1478, 62, 13, 0),
(1479, 62, 14, 0),
(1480, 62, 15, 0),
(1481, 62, 16, 0),
(1482, 62, 17, 0),
(1483, 62, 18, 0),
(1484, 62, 19, 0),
(1485, 62, 20, 0),
(1486, 62, 21, 0),
(1487, 62, 22, 0),
(1488, 62, 23, 0),
(1489, 63, 0, 0),
(1490, 63, 1, 0),
(1491, 63, 2, 0),
(1492, 63, 3, 0),
(1493, 63, 4, 0),
(1494, 63, 5, 0),
(1495, 63, 6, 0),
(1496, 63, 7, 0),
(1497, 63, 8, 0),
(1498, 63, 9, 0),
(1499, 63, 10, 0),
(1500, 63, 11, 0),
(1501, 63, 12, 0),
(1502, 63, 13, 0),
(1503, 63, 14, 0),
(1504, 63, 15, 0),
(1505, 63, 16, 0),
(1506, 63, 17, 0),
(1507, 63, 18, 0),
(1508, 63, 19, 0),
(1509, 63, 20, 0),
(1510, 63, 21, 0),
(1511, 63, 22, 0),
(1512, 63, 23, 0),
(1513, 64, 0, 0),
(1514, 64, 1, 0),
(1515, 64, 2, 0),
(1516, 64, 3, 0),
(1517, 64, 4, 0),
(1518, 64, 5, 0),
(1519, 64, 6, 0),
(1520, 64, 7, 0),
(1521, 64, 8, 0),
(1522, 64, 9, 0),
(1523, 64, 10, 0),
(1524, 64, 11, 0),
(1525, 64, 12, 0),
(1526, 64, 13, 0),
(1527, 64, 14, 0),
(1528, 64, 15, 0),
(1529, 64, 16, 0),
(1530, 64, 17, 0),
(1531, 64, 18, 0),
(1532, 64, 19, 0),
(1533, 64, 20, 0),
(1534, 64, 21, 0),
(1535, 64, 22, 0),
(1536, 64, 23, 0),
(1537, 65, 0, 0),
(1538, 65, 1, 0),
(1539, 65, 2, 0),
(1540, 65, 3, 0),
(1541, 65, 4, 0),
(1542, 65, 5, 0),
(1543, 65, 6, 0),
(1544, 65, 7, 0),
(1545, 65, 8, 0),
(1546, 65, 9, 0),
(1547, 65, 10, 0),
(1548, 65, 11, 0),
(1549, 65, 12, 0),
(1550, 65, 13, 0),
(1551, 65, 14, 0),
(1552, 65, 15, 0),
(1553, 65, 16, 0),
(1554, 65, 17, 0),
(1555, 65, 18, 0),
(1556, 65, 19, 0),
(1557, 65, 20, 0),
(1558, 65, 21, 0),
(1559, 65, 22, 0),
(1560, 65, 23, 0),
(1561, 66, 0, 0),
(1562, 66, 1, 0),
(1563, 66, 2, 0),
(1564, 66, 3, 0),
(1565, 66, 4, 0),
(1566, 66, 5, 0),
(1567, 66, 6, 0),
(1568, 66, 7, 0),
(1569, 66, 8, 0),
(1570, 66, 9, 0),
(1571, 66, 10, 0),
(1572, 66, 11, 0),
(1573, 66, 12, 0),
(1574, 66, 13, 0),
(1575, 66, 14, 0),
(1576, 66, 15, 0),
(1577, 66, 16, 0),
(1578, 66, 17, 0),
(1579, 66, 18, 0),
(1580, 66, 19, 0),
(1581, 66, 20, 0),
(1582, 66, 21, 0),
(1583, 66, 22, 0),
(1584, 66, 23, 0),
(1585, 67, 0, 0),
(1586, 67, 1, 0),
(1587, 67, 2, 0),
(1588, 67, 3, 0),
(1589, 67, 4, 0),
(1590, 67, 5, 0),
(1591, 67, 6, 0),
(1592, 67, 7, 0),
(1593, 67, 8, 0),
(1594, 67, 9, 0),
(1595, 67, 10, 0),
(1596, 67, 11, 0),
(1597, 67, 12, 0),
(1598, 67, 13, 0),
(1599, 67, 14, 0),
(1600, 67, 15, 0),
(1601, 67, 16, 0),
(1602, 67, 17, 0),
(1603, 67, 18, 0),
(1604, 67, 19, 0),
(1605, 67, 20, 0),
(1606, 67, 21, 0),
(1607, 67, 22, 0),
(1608, 67, 23, 0),
(1609, 68, 0, 0),
(1610, 68, 1, 0),
(1611, 68, 2, 0),
(1612, 68, 3, 0),
(1613, 68, 4, 0),
(1614, 68, 5, 0),
(1615, 68, 6, 0),
(1616, 68, 7, 0),
(1617, 68, 8, 0),
(1618, 68, 9, 0),
(1619, 68, 10, 0),
(1620, 68, 11, 0),
(1621, 68, 12, 0),
(1622, 68, 13, 0),
(1623, 68, 14, 0),
(1624, 68, 15, 0),
(1625, 68, 16, 0),
(1626, 68, 17, 0),
(1627, 68, 18, 0),
(1628, 68, 19, 0),
(1629, 68, 20, 0),
(1630, 68, 21, 0),
(1631, 68, 22, 0),
(1632, 68, 23, 0),
(1633, 69, 0, 0),
(1634, 69, 1, 0),
(1635, 69, 2, 0),
(1636, 69, 3, 0),
(1637, 69, 4, 0),
(1638, 69, 5, 0),
(1639, 69, 6, 0),
(1640, 69, 7, 0),
(1641, 69, 8, 0),
(1642, 69, 9, 0),
(1643, 69, 10, 0),
(1644, 69, 11, 0),
(1645, 69, 12, 0),
(1646, 69, 13, 0),
(1647, 69, 14, 0),
(1648, 69, 15, 0),
(1649, 69, 16, 0),
(1650, 69, 17, 0),
(1651, 69, 18, 0),
(1652, 69, 19, 0),
(1653, 69, 20, 0),
(1654, 69, 21, 0),
(1655, 69, 22, 0),
(1656, 69, 23, 0),
(1657, 70, 0, 0),
(1658, 70, 1, 0),
(1659, 70, 2, 0),
(1660, 70, 3, 0),
(1661, 70, 4, 0),
(1662, 70, 5, 0),
(1663, 70, 6, 0),
(1664, 70, 7, 0),
(1665, 70, 8, 0),
(1666, 70, 9, 0),
(1667, 70, 10, 0),
(1668, 70, 11, 0),
(1669, 70, 12, 0),
(1670, 70, 13, 0),
(1671, 70, 14, 0),
(1672, 70, 15, 0),
(1673, 70, 16, 0),
(1674, 70, 17, 0),
(1675, 70, 18, 0),
(1676, 70, 19, 0),
(1677, 70, 20, 0),
(1678, 70, 21, 0),
(1679, 70, 22, 0),
(1680, 70, 23, 0),
(1681, 71, 0, 0),
(1682, 71, 1, 0),
(1683, 71, 2, 0),
(1684, 71, 3, 0),
(1685, 71, 4, 0),
(1686, 71, 5, 0),
(1687, 71, 6, 0),
(1688, 71, 7, 0),
(1689, 71, 8, 0),
(1690, 71, 9, 0),
(1691, 71, 10, 0),
(1692, 71, 11, 0),
(1693, 71, 12, 0),
(1694, 71, 13, 0),
(1695, 71, 14, 0),
(1696, 71, 15, 0),
(1697, 71, 16, 0),
(1698, 71, 17, 0),
(1699, 71, 18, 0),
(1700, 71, 19, 0),
(1701, 71, 20, 0),
(1702, 71, 21, 0),
(1703, 71, 22, 0),
(1704, 71, 23, 0),
(1705, 72, 0, 0),
(1706, 72, 1, 0),
(1707, 72, 2, 0),
(1708, 72, 3, 0),
(1709, 72, 4, 0),
(1710, 72, 5, 0),
(1711, 72, 6, 0),
(1712, 72, 7, 0),
(1713, 72, 8, 0),
(1714, 72, 9, 0),
(1715, 72, 10, 0),
(1716, 72, 11, 0),
(1717, 72, 12, 0),
(1718, 72, 13, 0),
(1719, 72, 14, 0),
(1720, 72, 15, 0),
(1721, 72, 16, 0),
(1722, 72, 17, 0),
(1723, 72, 18, 0),
(1724, 72, 19, 0),
(1725, 72, 20, 0),
(1726, 72, 21, 0),
(1727, 72, 22, 0),
(1728, 72, 23, 0),
(1729, 73, 0, 0),
(1730, 73, 1, 0),
(1731, 73, 2, 0),
(1732, 73, 3, 0),
(1733, 73, 4, 0),
(1734, 73, 5, 0),
(1735, 73, 6, 0),
(1736, 73, 7, 0),
(1737, 73, 8, 0),
(1738, 73, 9, 0),
(1739, 73, 10, 0),
(1740, 73, 11, 0),
(1741, 73, 12, 0),
(1742, 73, 13, 0),
(1743, 73, 14, 0),
(1744, 73, 15, 0),
(1745, 73, 16, 0),
(1746, 73, 17, 0),
(1747, 73, 18, 0),
(1748, 73, 19, 0),
(1749, 73, 20, 0),
(1750, 73, 21, 0),
(1751, 73, 22, 0),
(1752, 73, 23, 0),
(1753, 74, 0, 0),
(1754, 74, 1, 0),
(1755, 74, 2, 0),
(1756, 74, 3, 0),
(1757, 74, 4, 0),
(1758, 74, 5, 0),
(1759, 74, 6, 0),
(1760, 74, 7, 0),
(1761, 74, 8, 0),
(1762, 74, 9, 0),
(1763, 74, 10, 0),
(1764, 74, 11, 0),
(1765, 74, 12, 0),
(1766, 74, 13, 0),
(1767, 74, 14, 0),
(1768, 74, 15, 0),
(1769, 74, 16, 0),
(1770, 74, 17, 0),
(1771, 74, 18, 0),
(1772, 74, 19, 0),
(1773, 74, 20, 0),
(1774, 74, 21, 0),
(1775, 74, 22, 0),
(1776, 74, 23, 0),
(1777, 75, 0, 0),
(1778, 75, 1, 0),
(1779, 75, 2, 0),
(1780, 75, 3, 0),
(1781, 75, 4, 0),
(1782, 75, 5, 0),
(1783, 75, 6, 0),
(1784, 75, 7, 0),
(1785, 75, 8, 0),
(1786, 75, 9, 0),
(1787, 75, 10, 0),
(1788, 75, 11, 0),
(1789, 75, 12, 0),
(1790, 75, 13, 0),
(1791, 75, 14, 0),
(1792, 75, 15, 0),
(1793, 75, 16, 0),
(1794, 75, 17, 0),
(1795, 75, 18, 0),
(1796, 75, 19, 0),
(1797, 75, 20, 0),
(1798, 75, 21, 0),
(1799, 75, 22, 0),
(1800, 75, 23, 0),
(1801, 76, 0, 0),
(1802, 76, 1, 0),
(1803, 76, 2, 0),
(1804, 76, 3, 0),
(1805, 76, 4, 0),
(1806, 76, 5, 0),
(1807, 76, 6, 0),
(1808, 76, 7, 0),
(1809, 76, 8, 0),
(1810, 76, 9, 0),
(1811, 76, 10, 0),
(1812, 76, 11, 0),
(1813, 76, 12, 0),
(1814, 76, 13, 0),
(1815, 76, 14, 0),
(1816, 76, 15, 0),
(1817, 76, 16, 0),
(1818, 76, 17, 0),
(1819, 76, 18, 0),
(1820, 76, 19, 0),
(1821, 76, 20, 0),
(1822, 76, 21, 0),
(1823, 76, 22, 0),
(1824, 76, 23, 0),
(1825, 77, 0, 0),
(1826, 77, 1, 0),
(1827, 77, 2, 0),
(1828, 77, 3, 0),
(1829, 77, 4, 0),
(1830, 77, 5, 0),
(1831, 77, 6, 0),
(1832, 77, 7, 0),
(1833, 77, 8, 0),
(1834, 77, 9, 0),
(1835, 77, 10, 0),
(1836, 77, 11, 0),
(1837, 77, 12, 0),
(1838, 77, 13, 0),
(1839, 77, 14, 0),
(1840, 77, 15, 0),
(1841, 77, 16, 0),
(1842, 77, 17, 0),
(1843, 77, 18, 0),
(1844, 77, 19, 0),
(1845, 77, 20, 0),
(1846, 77, 21, 0),
(1847, 77, 22, 0),
(1848, 77, 23, 0),
(1849, 78, 0, 0),
(1850, 78, 1, 0),
(1851, 78, 2, 0),
(1852, 78, 3, 0),
(1853, 78, 4, 0),
(1854, 78, 5, 0),
(1855, 78, 6, 0),
(1856, 78, 7, 0),
(1857, 78, 8, 0),
(1858, 78, 9, 0),
(1859, 78, 10, 0),
(1860, 78, 11, 0),
(1861, 78, 12, 0),
(1862, 78, 13, 0),
(1863, 78, 14, 0),
(1864, 78, 15, 0),
(1865, 78, 16, 0),
(1866, 78, 17, 0),
(1867, 78, 18, 0),
(1868, 78, 19, 0),
(1869, 78, 20, 0),
(1870, 78, 21, 0),
(1871, 78, 22, 0),
(1872, 78, 23, 0),
(1873, 79, 0, 0),
(1874, 79, 1, 0),
(1875, 79, 2, 0),
(1876, 79, 3, 0),
(1877, 79, 4, 0),
(1878, 79, 5, 0),
(1879, 79, 6, 0),
(1880, 79, 7, 0),
(1881, 79, 8, 0),
(1882, 79, 9, 0),
(1883, 79, 10, 0),
(1884, 79, 11, 0),
(1885, 79, 12, 0),
(1886, 79, 13, 0),
(1887, 79, 14, 0),
(1888, 79, 15, 0),
(1889, 79, 16, 0),
(1890, 79, 17, 0),
(1891, 79, 18, 0),
(1892, 79, 19, 0),
(1893, 79, 20, 0),
(1894, 79, 21, 0),
(1895, 79, 22, 0),
(1896, 79, 23, 0),
(1897, 80, 0, 0),
(1898, 80, 1, 0),
(1899, 80, 2, 0),
(1900, 80, 3, 0),
(1901, 80, 4, 0),
(1902, 80, 5, 0),
(1903, 80, 6, 0),
(1904, 80, 7, 0),
(1905, 80, 8, 0),
(1906, 80, 9, 0),
(1907, 80, 10, 0),
(1908, 80, 11, 0),
(1909, 80, 12, 0),
(1910, 80, 13, 0),
(1911, 80, 14, 0),
(1912, 80, 15, 0),
(1913, 80, 16, 0),
(1914, 80, 17, 0),
(1915, 80, 18, 0),
(1916, 80, 19, 0),
(1917, 80, 20, 0),
(1918, 80, 21, 0),
(1919, 80, 22, 0),
(1920, 80, 23, 0),
(1921, 81, 0, 0),
(1922, 81, 1, 0),
(1923, 81, 2, 0),
(1924, 81, 3, 0),
(1925, 81, 4, 0),
(1926, 81, 5, 0),
(1927, 81, 6, 0),
(1928, 81, 7, 0),
(1929, 81, 8, 0),
(1930, 81, 9, 0),
(1931, 81, 10, 0),
(1932, 81, 11, 0),
(1933, 81, 12, 0),
(1934, 81, 13, 0),
(1935, 81, 14, 0),
(1936, 81, 15, 0),
(1937, 81, 16, 0),
(1938, 81, 17, 0),
(1939, 81, 18, 0),
(1940, 81, 19, 0),
(1941, 81, 20, 0),
(1942, 81, 21, 0),
(1943, 81, 22, 0),
(1944, 81, 23, 0),
(1945, 82, 0, 0),
(1946, 82, 1, 0),
(1947, 82, 2, 0),
(1948, 82, 3, 0),
(1949, 82, 4, 0),
(1950, 82, 5, 0),
(1951, 82, 6, 0),
(1952, 82, 7, 0),
(1953, 82, 8, 0),
(1954, 82, 9, 0),
(1955, 82, 10, 0),
(1956, 82, 11, 0),
(1957, 82, 12, 0),
(1958, 82, 13, 0),
(1959, 82, 14, 0),
(1960, 82, 15, 0),
(1961, 82, 16, 0),
(1962, 82, 17, 0),
(1963, 82, 18, 0),
(1964, 82, 19, 0),
(1965, 82, 20, 0),
(1966, 82, 21, 0),
(1967, 82, 22, 0),
(1968, 82, 23, 0),
(1969, 83, 0, 0),
(1970, 83, 1, 0),
(1971, 83, 2, 0),
(1972, 83, 3, 0),
(1973, 83, 4, 0),
(1974, 83, 5, 0),
(1975, 83, 6, 0),
(1976, 83, 7, 0),
(1977, 83, 8, 0),
(1978, 83, 9, 0),
(1979, 83, 10, 0),
(1980, 83, 11, 0),
(1981, 83, 12, 0),
(1982, 83, 13, 0),
(1983, 83, 14, 0),
(1984, 83, 15, 0),
(1985, 83, 16, 0),
(1986, 83, 17, 0),
(1987, 83, 18, 0),
(1988, 83, 19, 0),
(1989, 83, 20, 0),
(1990, 83, 21, 0),
(1991, 83, 22, 0),
(1992, 83, 23, 0),
(1993, 84, 0, 0),
(1994, 84, 1, 0),
(1995, 84, 2, 0),
(1996, 84, 3, 0),
(1997, 84, 4, 0),
(1998, 84, 5, 0),
(1999, 84, 6, 0),
(2000, 84, 7, 0),
(2001, 84, 8, 0),
(2002, 84, 9, 0),
(2003, 84, 10, 0),
(2004, 84, 11, 0),
(2005, 84, 12, 0),
(2006, 84, 13, 0),
(2007, 84, 14, 0),
(2008, 84, 15, 0),
(2009, 84, 16, 0),
(2010, 84, 17, 0),
(2011, 84, 18, 0),
(2012, 84, 19, 0),
(2013, 84, 20, 0),
(2014, 84, 21, 0),
(2015, 84, 22, 0),
(2016, 84, 23, 0),
(2017, 85, 0, 0),
(2018, 85, 1, 0),
(2019, 85, 2, 0),
(2020, 85, 3, 0),
(2021, 85, 4, 0),
(2022, 85, 5, 0),
(2023, 85, 6, 0),
(2024, 85, 7, 0),
(2025, 85, 8, 0),
(2026, 85, 9, 0),
(2027, 85, 10, 0),
(2028, 85, 11, 0),
(2029, 85, 12, 0),
(2030, 85, 13, 0),
(2031, 85, 14, 0),
(2032, 85, 15, 0),
(2033, 85, 16, 0),
(2034, 85, 17, 0),
(2035, 85, 18, 0),
(2036, 85, 19, 0),
(2037, 85, 20, 0),
(2038, 85, 21, 0),
(2039, 85, 22, 0),
(2040, 85, 23, 0),
(2041, 86, 0, 0),
(2042, 86, 1, 0),
(2043, 86, 2, 0),
(2044, 86, 3, 0),
(2045, 86, 4, 0),
(2046, 86, 5, 0),
(2047, 86, 6, 0),
(2048, 86, 7, 0),
(2049, 86, 8, 0),
(2050, 86, 9, 0),
(2051, 86, 10, 0),
(2052, 86, 11, 0),
(2053, 86, 12, 0),
(2054, 86, 13, 0),
(2055, 86, 14, 0),
(2056, 86, 15, 0),
(2057, 86, 16, 0),
(2058, 86, 17, 0),
(2059, 86, 18, 0),
(2060, 86, 19, 0),
(2061, 86, 20, 0),
(2062, 86, 21, 0),
(2063, 86, 22, 0),
(2064, 86, 23, 0),
(2065, 87, 0, 0),
(2066, 87, 1, 0),
(2067, 87, 2, 0),
(2068, 87, 3, 0),
(2069, 87, 4, 0),
(2070, 87, 5, 0),
(2071, 87, 6, 0),
(2072, 87, 7, 0),
(2073, 87, 8, 0),
(2074, 87, 9, 0),
(2075, 87, 10, 0),
(2076, 87, 11, 0),
(2077, 87, 12, 0),
(2078, 87, 13, 0),
(2079, 87, 14, 0),
(2080, 87, 15, 0),
(2081, 87, 16, 0),
(2082, 87, 17, 0),
(2083, 87, 18, 0),
(2084, 87, 19, 0),
(2085, 87, 20, 0),
(2086, 87, 21, 0),
(2087, 87, 22, 0),
(2088, 87, 23, 0),
(2089, 88, 0, 0),
(2090, 88, 1, 0),
(2091, 88, 2, 0),
(2092, 88, 3, 0),
(2093, 88, 4, 0),
(2094, 88, 5, 0),
(2095, 88, 6, 0),
(2096, 88, 7, 0),
(2097, 88, 8, 0),
(2098, 88, 9, 0),
(2099, 88, 10, 0),
(2100, 88, 11, 0),
(2101, 88, 12, 0),
(2102, 88, 13, 0),
(2103, 88, 14, 0),
(2104, 88, 15, 0),
(2105, 88, 16, 0),
(2106, 88, 17, 0),
(2107, 88, 18, 0),
(2108, 88, 19, 0),
(2109, 88, 20, 0),
(2110, 88, 21, 0),
(2111, 88, 22, 0),
(2112, 88, 23, 0),
(2113, 89, 0, 0),
(2114, 89, 1, 0),
(2115, 89, 2, 0),
(2116, 89, 3, 0),
(2117, 89, 4, 0),
(2118, 89, 5, 0),
(2119, 89, 6, 0),
(2120, 89, 7, 0),
(2121, 89, 8, 0),
(2122, 89, 9, 0),
(2123, 89, 10, 0),
(2124, 89, 11, 0),
(2125, 89, 12, 0),
(2126, 89, 13, 0),
(2127, 89, 14, 0),
(2128, 89, 15, 0),
(2129, 89, 16, 0),
(2130, 89, 17, 0),
(2131, 89, 18, 0),
(2132, 89, 19, 0),
(2133, 89, 20, 0),
(2134, 89, 21, 0),
(2135, 89, 22, 0),
(2136, 89, 23, 0),
(2137, 90, 0, 0),
(2138, 90, 1, 0),
(2139, 90, 2, 0),
(2140, 90, 3, 0),
(2141, 90, 4, 0),
(2142, 90, 5, 0),
(2143, 90, 6, 0),
(2144, 90, 7, 0),
(2145, 90, 8, 0),
(2146, 90, 9, 0),
(2147, 90, 10, 0),
(2148, 90, 11, 0),
(2149, 90, 12, 0),
(2150, 90, 13, 0),
(2151, 90, 14, 0),
(2152, 90, 15, 0),
(2153, 90, 16, 0),
(2154, 90, 17, 0),
(2155, 90, 18, 0),
(2156, 90, 19, 0),
(2157, 90, 20, 0),
(2158, 90, 21, 0),
(2159, 90, 22, 0),
(2160, 90, 23, 0),
(2161, 91, 0, 0),
(2162, 91, 1, 0),
(2163, 91, 2, 0),
(2164, 91, 3, 0),
(2165, 91, 4, 0),
(2166, 91, 5, 0),
(2167, 91, 6, 0),
(2168, 91, 7, 0),
(2169, 91, 8, 0),
(2170, 91, 9, 0),
(2171, 91, 10, 0),
(2172, 91, 11, 0),
(2173, 91, 12, 0),
(2174, 91, 13, 0),
(2175, 91, 14, 0),
(2176, 91, 15, 0),
(2177, 91, 16, 0),
(2178, 91, 17, 0),
(2179, 91, 18, 0),
(2180, 91, 19, 0),
(2181, 91, 20, 0),
(2182, 91, 21, 0),
(2183, 91, 22, 0),
(2184, 91, 23, 0),
(2185, 92, 0, 0),
(2186, 92, 1, 0),
(2187, 92, 2, 0),
(2188, 92, 3, 0),
(2189, 92, 4, 0),
(2190, 92, 5, 0),
(2191, 92, 6, 0),
(2192, 92, 7, 0),
(2193, 92, 8, 0),
(2194, 92, 9, 0),
(2195, 92, 10, 0),
(2196, 92, 11, 0),
(2197, 92, 12, 0),
(2198, 92, 13, 0),
(2199, 92, 14, 0),
(2200, 92, 15, 0),
(2201, 92, 16, 0),
(2202, 92, 17, 0),
(2203, 92, 18, 0),
(2204, 92, 19, 0),
(2205, 92, 20, 0),
(2206, 92, 21, 0),
(2207, 92, 22, 0),
(2208, 92, 23, 0),
(2209, 93, 0, 0),
(2210, 93, 1, 0),
(2211, 93, 2, 0),
(2212, 93, 3, 0),
(2213, 93, 4, 0),
(2214, 93, 5, 0),
(2215, 93, 6, 0),
(2216, 93, 7, 0),
(2217, 93, 8, 0),
(2218, 93, 9, 0),
(2219, 93, 10, 0),
(2220, 93, 11, 0),
(2221, 93, 12, 0),
(2222, 93, 13, 0),
(2223, 93, 14, 0),
(2224, 93, 15, 0),
(2225, 93, 16, 0),
(2226, 93, 17, 0),
(2227, 93, 18, 0),
(2228, 93, 19, 0),
(2229, 93, 20, 0),
(2230, 93, 21, 0),
(2231, 93, 22, 0),
(2232, 93, 23, 0),
(2233, 94, 0, 0),
(2234, 94, 1, 0),
(2235, 94, 2, 0),
(2236, 94, 3, 0),
(2237, 94, 4, 0),
(2238, 94, 5, 0),
(2239, 94, 6, 0),
(2240, 94, 7, 0),
(2241, 94, 8, 0),
(2242, 94, 9, 0),
(2243, 94, 10, 0),
(2244, 94, 11, 0),
(2245, 94, 12, 0),
(2246, 94, 13, 0),
(2247, 94, 14, 0),
(2248, 94, 15, 0),
(2249, 94, 16, 0),
(2250, 94, 17, 0),
(2251, 94, 18, 0),
(2252, 94, 19, 0),
(2253, 94, 20, 0),
(2254, 94, 21, 0),
(2255, 94, 22, 0),
(2256, 94, 23, 0),
(2257, 95, 0, 0),
(2258, 95, 1, 0),
(2259, 95, 2, 0),
(2260, 95, 3, 0),
(2261, 95, 4, 0),
(2262, 95, 5, 0),
(2263, 95, 6, 0),
(2264, 95, 7, 0),
(2265, 95, 8, 0),
(2266, 95, 9, 0),
(2267, 95, 10, 0),
(2268, 95, 11, 0),
(2269, 95, 12, 0),
(2270, 95, 13, 0),
(2271, 95, 14, 0),
(2272, 95, 15, 0),
(2273, 95, 16, 0),
(2274, 95, 17, 0),
(2275, 95, 18, 0),
(2276, 95, 19, 0),
(2277, 95, 20, 0),
(2278, 95, 21, 0),
(2279, 95, 22, 0),
(2280, 95, 23, 0),
(2281, 96, 0, 0),
(2282, 96, 1, 0),
(2283, 96, 2, 0),
(2284, 96, 3, 0),
(2285, 96, 4, 0),
(2286, 96, 5, 0),
(2287, 96, 6, 0),
(2288, 96, 7, 0),
(2289, 96, 8, 0),
(2290, 96, 9, 0),
(2291, 96, 10, 0),
(2292, 96, 11, 0),
(2293, 96, 12, 0),
(2294, 96, 13, 0),
(2295, 96, 14, 0),
(2296, 96, 15, 0),
(2297, 96, 16, 0),
(2298, 96, 17, 0),
(2299, 96, 18, 0),
(2300, 96, 19, 0),
(2301, 96, 20, 0),
(2302, 96, 21, 0),
(2303, 96, 22, 0),
(2304, 96, 23, 0),
(2305, 97, 0, 0),
(2306, 97, 1, 0),
(2307, 97, 2, 0),
(2308, 97, 3, 0),
(2309, 97, 4, 0),
(2310, 97, 5, 0),
(2311, 97, 6, 0),
(2312, 97, 7, 0),
(2313, 97, 8, 0),
(2314, 97, 9, 0),
(2315, 97, 10, 0),
(2316, 97, 11, 0),
(2317, 97, 12, 0),
(2318, 97, 13, 0),
(2319, 97, 14, 0),
(2320, 97, 15, 0),
(2321, 97, 16, 0),
(2322, 97, 17, 0),
(2323, 97, 18, 0),
(2324, 97, 19, 0),
(2325, 97, 20, 0),
(2326, 97, 21, 0),
(2327, 97, 22, 0),
(2328, 97, 23, 0),
(2329, 98, 0, 0),
(2330, 98, 1, 0),
(2331, 98, 2, 0),
(2332, 98, 3, 0),
(2333, 98, 4, 0),
(2334, 98, 5, 0),
(2335, 98, 6, 0),
(2336, 98, 7, 0),
(2337, 98, 8, 0),
(2338, 98, 9, 0),
(2339, 98, 10, 0),
(2340, 98, 11, 0),
(2341, 98, 12, 0),
(2342, 98, 13, 0),
(2343, 98, 14, 0),
(2344, 98, 15, 0),
(2345, 98, 16, 0),
(2346, 98, 17, 0),
(2347, 98, 18, 0),
(2348, 98, 19, 0),
(2349, 98, 20, 0),
(2350, 98, 21, 0),
(2351, 98, 22, 0),
(2352, 98, 23, 0),
(2353, 99, 0, 0),
(2354, 99, 1, 0),
(2355, 99, 2, 0),
(2356, 99, 3, 0),
(2357, 99, 4, 0),
(2358, 99, 5, 0),
(2359, 99, 6, 0),
(2360, 99, 7, 0),
(2361, 99, 8, 0),
(2362, 99, 9, 0),
(2363, 99, 10, 0),
(2364, 99, 11, 0),
(2365, 99, 12, 0),
(2366, 99, 13, 0),
(2367, 99, 14, 0),
(2368, 99, 15, 0),
(2369, 99, 16, 0),
(2370, 99, 17, 0),
(2371, 99, 18, 0),
(2372, 99, 19, 0),
(2373, 99, 20, 0),
(2374, 99, 21, 0),
(2375, 99, 22, 0),
(2376, 99, 23, 0),
(2377, 100, 0, 0),
(2378, 100, 1, 0),
(2379, 100, 2, 0),
(2380, 100, 3, 0),
(2381, 100, 4, 0),
(2382, 100, 5, 0),
(2383, 100, 6, 0),
(2384, 100, 7, 0),
(2385, 100, 8, 0),
(2386, 100, 9, 0),
(2387, 100, 10, 0),
(2388, 100, 11, 0),
(2389, 100, 12, 0),
(2390, 100, 13, 0),
(2391, 100, 14, 0),
(2392, 100, 15, 0),
(2393, 100, 16, 0),
(2394, 100, 17, 0),
(2395, 100, 18, 0),
(2396, 100, 19, 0),
(2397, 100, 20, 0),
(2398, 100, 21, 0),
(2399, 100, 22, 0),
(2400, 100, 23, 0),
(2401, 101, 0, 0),
(2402, 101, 1, 0),
(2403, 101, 2, 0),
(2404, 101, 3, 0),
(2405, 101, 4, 0),
(2406, 101, 5, 0),
(2407, 101, 6, 0),
(2408, 101, 7, 0),
(2409, 101, 8, 0),
(2410, 101, 9, 0),
(2411, 101, 10, 0),
(2412, 101, 11, 0),
(2413, 101, 12, 0),
(2414, 101, 13, 0),
(2415, 101, 14, 0),
(2416, 101, 15, 0),
(2417, 101, 16, 0),
(2418, 101, 17, 0),
(2419, 101, 18, 0),
(2420, 101, 19, 0),
(2421, 101, 20, 0),
(2422, 101, 21, 0),
(2423, 101, 22, 0),
(2424, 101, 23, 0),
(2425, 102, 0, 0),
(2426, 102, 1, 0),
(2427, 102, 2, 0),
(2428, 102, 3, 0),
(2429, 102, 4, 0),
(2430, 102, 5, 0),
(2431, 102, 6, 0),
(2432, 102, 7, 0),
(2433, 102, 8, 0),
(2434, 102, 9, 0),
(2435, 102, 10, 0),
(2436, 102, 11, 0),
(2437, 102, 12, 0),
(2438, 102, 13, 0),
(2439, 102, 14, 0),
(2440, 102, 15, 0),
(2441, 102, 16, 0),
(2442, 102, 17, 0),
(2443, 102, 18, 0),
(2444, 102, 19, 0),
(2445, 102, 20, 0),
(2446, 102, 21, 0),
(2447, 102, 22, 0),
(2448, 102, 23, 0),
(2449, 103, 0, 0),
(2450, 103, 1, 0),
(2451, 103, 2, 0),
(2452, 103, 3, 0),
(2453, 103, 4, 0),
(2454, 103, 5, 0),
(2455, 103, 6, 0),
(2456, 103, 7, 0),
(2457, 103, 8, 0),
(2458, 103, 9, 0),
(2459, 103, 10, 0),
(2460, 103, 11, 0),
(2461, 103, 12, 0),
(2462, 103, 13, 0),
(2463, 103, 14, 0),
(2464, 103, 15, 0),
(2465, 103, 16, 0),
(2466, 103, 17, 0),
(2467, 103, 18, 0),
(2468, 103, 19, 0),
(2469, 103, 20, 0),
(2470, 103, 21, 0),
(2471, 103, 22, 0),
(2472, 103, 23, 0),
(2473, 104, 0, 0),
(2474, 104, 1, 0),
(2475, 104, 2, 0),
(2476, 104, 3, 0),
(2477, 104, 4, 0),
(2478, 104, 5, 0),
(2479, 104, 6, 0),
(2480, 104, 7, 0),
(2481, 104, 8, 0),
(2482, 104, 9, 0),
(2483, 104, 10, 0),
(2484, 104, 11, 0),
(2485, 104, 12, 0),
(2486, 104, 13, 0),
(2487, 104, 14, 0),
(2488, 104, 15, 0),
(2489, 104, 16, 0),
(2490, 104, 17, 0),
(2491, 104, 18, 0),
(2492, 104, 19, 0),
(2493, 104, 20, 0),
(2494, 104, 21, 0),
(2495, 104, 22, 0),
(2496, 104, 23, 0),
(2497, 105, 0, 0),
(2498, 105, 1, 0),
(2499, 105, 2, 0),
(2500, 105, 3, 0),
(2501, 105, 4, 0),
(2502, 105, 5, 0),
(2503, 105, 6, 0),
(2504, 105, 7, 0),
(2505, 105, 8, 0),
(2506, 105, 9, 0),
(2507, 105, 10, 0),
(2508, 105, 11, 0),
(2509, 105, 12, 0),
(2510, 105, 13, 0),
(2511, 105, 14, 0),
(2512, 105, 15, 0),
(2513, 105, 16, 0),
(2514, 105, 17, 0),
(2515, 105, 18, 0),
(2516, 105, 19, 0),
(2517, 105, 20, 0),
(2518, 105, 21, 0),
(2519, 105, 22, 0),
(2520, 105, 23, 0),
(2521, 106, 0, 0),
(2522, 106, 1, 0),
(2523, 106, 2, 0),
(2524, 106, 3, 0),
(2525, 106, 4, 0),
(2526, 106, 5, 0),
(2527, 106, 6, 0),
(2528, 106, 7, 0),
(2529, 106, 8, 0),
(2530, 106, 9, 0),
(2531, 106, 10, 0),
(2532, 106, 11, 0),
(2533, 106, 12, 0),
(2534, 106, 13, 0),
(2535, 106, 14, 0),
(2536, 106, 15, 0),
(2537, 106, 16, 0),
(2538, 106, 17, 0),
(2539, 106, 18, 0),
(2540, 106, 19, 0),
(2541, 106, 20, 0),
(2542, 106, 21, 0),
(2543, 106, 22, 0),
(2544, 106, 23, 0),
(2545, 107, 0, 0),
(2546, 107, 1, 0),
(2547, 107, 2, 0),
(2548, 107, 3, 0),
(2549, 107, 4, 0),
(2550, 107, 5, 0),
(2551, 107, 6, 0),
(2552, 107, 7, 0),
(2553, 107, 8, 0),
(2554, 107, 9, 0),
(2555, 107, 10, 0),
(2556, 107, 11, 0),
(2557, 107, 12, 0),
(2558, 107, 13, 0),
(2559, 107, 14, 0),
(2560, 107, 15, 0),
(2561, 107, 16, 0),
(2562, 107, 17, 0),
(2563, 107, 18, 0),
(2564, 107, 19, 0),
(2565, 107, 20, 0),
(2566, 107, 21, 0),
(2567, 107, 22, 0),
(2568, 107, 23, 0),
(2569, 108, 0, 0),
(2570, 108, 1, 0),
(2571, 108, 2, 0),
(2572, 108, 3, 0),
(2573, 108, 4, 0),
(2574, 108, 5, 0),
(2575, 108, 6, 0),
(2576, 108, 7, 0),
(2577, 108, 8, 0),
(2578, 108, 9, 0),
(2579, 108, 10, 0),
(2580, 108, 11, 0),
(2581, 108, 12, 0),
(2582, 108, 13, 0),
(2583, 108, 14, 0),
(2584, 108, 15, 0),
(2585, 108, 16, 0),
(2586, 108, 17, 0),
(2587, 108, 18, 0),
(2588, 108, 19, 0),
(2589, 108, 20, 0),
(2590, 108, 21, 0),
(2591, 108, 22, 0),
(2592, 108, 23, 0),
(2593, 109, 0, 0),
(2594, 109, 1, 0),
(2595, 109, 2, 0),
(2596, 109, 3, 0),
(2597, 109, 4, 0),
(2598, 109, 5, 0),
(2599, 109, 6, 0),
(2600, 109, 7, 0),
(2601, 109, 8, 0),
(2602, 109, 9, 0),
(2603, 109, 10, 0),
(2604, 109, 11, 0),
(2605, 109, 12, 0),
(2606, 109, 13, 0),
(2607, 109, 14, 0),
(2608, 109, 15, 0),
(2609, 109, 16, 0),
(2610, 109, 17, 0),
(2611, 109, 18, 0),
(2612, 109, 19, 0),
(2613, 109, 20, 0),
(2614, 109, 21, 0),
(2615, 109, 22, 0),
(2616, 109, 23, 0),
(2617, 110, 0, 0),
(2618, 110, 1, 0),
(2619, 110, 2, 0),
(2620, 110, 3, 0),
(2621, 110, 4, 0),
(2622, 110, 5, 0),
(2623, 110, 6, 0),
(2624, 110, 7, 0),
(2625, 110, 8, 0),
(2626, 110, 9, 0),
(2627, 110, 10, 0),
(2628, 110, 11, 0),
(2629, 110, 12, 0),
(2630, 110, 13, 0),
(2631, 110, 14, 0),
(2632, 110, 15, 0),
(2633, 110, 16, 0),
(2634, 110, 17, 0),
(2635, 110, 18, 0),
(2636, 110, 19, 0),
(2637, 110, 20, 0),
(2638, 110, 21, 0),
(2639, 110, 22, 0),
(2640, 110, 23, 0),
(2641, 111, 0, 0),
(2642, 111, 1, 0),
(2643, 111, 2, 0),
(2644, 111, 3, 0),
(2645, 111, 4, 0),
(2646, 111, 5, 0),
(2647, 111, 6, 0),
(2648, 111, 7, 0),
(2649, 111, 8, 0),
(2650, 111, 9, 0),
(2651, 111, 10, 0),
(2652, 111, 11, 0),
(2653, 111, 12, 0),
(2654, 111, 13, 0),
(2655, 111, 14, 0),
(2656, 111, 15, 0),
(2657, 111, 16, 0),
(2658, 111, 17, 0),
(2659, 111, 18, 0),
(2660, 111, 19, 0),
(2661, 111, 20, 0),
(2662, 111, 21, 0),
(2663, 111, 22, 0),
(2664, 111, 23, 0),
(2665, 112, 0, 0),
(2666, 112, 1, 0),
(2667, 112, 2, 0),
(2668, 112, 3, 0),
(2669, 112, 4, 0),
(2670, 112, 5, 0),
(2671, 112, 6, 0),
(2672, 112, 7, 0),
(2673, 112, 8, 0),
(2674, 112, 9, 0),
(2675, 112, 10, 0),
(2676, 112, 11, 0),
(2677, 112, 12, 0),
(2678, 112, 13, 0),
(2679, 112, 14, 0),
(2680, 112, 15, 0),
(2681, 112, 16, 0),
(2682, 112, 17, 0),
(2683, 112, 18, 0),
(2684, 112, 19, 0),
(2685, 112, 20, 0),
(2686, 112, 21, 0),
(2687, 112, 22, 0),
(2688, 112, 23, 0),
(2689, 113, 0, 0),
(2690, 113, 1, 0),
(2691, 113, 2, 0),
(2692, 113, 3, 0),
(2693, 113, 4, 0),
(2694, 113, 5, 0),
(2695, 113, 6, 0),
(2696, 113, 7, 0),
(2697, 113, 8, 0),
(2698, 113, 9, 0),
(2699, 113, 10, 0),
(2700, 113, 11, 0),
(2701, 113, 12, 0),
(2702, 113, 13, 0),
(2703, 113, 14, 0),
(2704, 113, 15, 0),
(2705, 113, 16, 0),
(2706, 113, 17, 0),
(2707, 113, 18, 0),
(2708, 113, 19, 0),
(2709, 113, 20, 0),
(2710, 113, 21, 0),
(2711, 113, 22, 0),
(2712, 113, 23, 0),
(2713, 114, 0, 0),
(2714, 114, 1, 0),
(2715, 114, 2, 0),
(2716, 114, 3, 0),
(2717, 114, 4, 0),
(2718, 114, 5, 0),
(2719, 114, 6, 0),
(2720, 114, 7, 0),
(2721, 114, 8, 0),
(2722, 114, 9, 0),
(2723, 114, 10, 0),
(2724, 114, 11, 0),
(2725, 114, 12, 0),
(2726, 114, 13, 0),
(2727, 114, 14, 0),
(2728, 114, 15, 0),
(2729, 114, 16, 0),
(2730, 114, 17, 0),
(2731, 114, 18, 0),
(2732, 114, 19, 0),
(2733, 114, 20, 0),
(2734, 114, 21, 0),
(2735, 114, 22, 0),
(2736, 114, 23, 0),
(2737, 115, 0, 0),
(2738, 115, 1, 0),
(2739, 115, 2, 0),
(2740, 115, 3, 0),
(2741, 115, 4, 0),
(2742, 115, 5, 0),
(2743, 115, 6, 0),
(2744, 115, 7, 0),
(2745, 115, 8, 0),
(2746, 115, 9, 0),
(2747, 115, 10, 0),
(2748, 115, 11, 0),
(2749, 115, 12, 0),
(2750, 115, 13, 0),
(2751, 115, 14, 0),
(2752, 115, 15, 0),
(2753, 115, 16, 0),
(2754, 115, 17, 0),
(2755, 115, 18, 0),
(2756, 115, 19, 0),
(2757, 115, 20, 0),
(2758, 115, 21, 0),
(2759, 115, 22, 0),
(2760, 115, 23, 0),
(2761, 116, 0, 0),
(2762, 116, 1, 0),
(2763, 116, 2, 0),
(2764, 116, 3, 0),
(2765, 116, 4, 0),
(2766, 116, 5, 0),
(2767, 116, 6, 0),
(2768, 116, 7, 0),
(2769, 116, 8, 0),
(2770, 116, 9, 0),
(2771, 116, 10, 0),
(2772, 116, 11, 0),
(2773, 116, 12, 0),
(2774, 116, 13, 0),
(2775, 116, 14, 0),
(2776, 116, 15, 0),
(2777, 116, 16, 0),
(2778, 116, 17, 0),
(2779, 116, 18, 0),
(2780, 116, 19, 0),
(2781, 116, 20, 0),
(2782, 116, 21, 0),
(2783, 116, 22, 0),
(2784, 116, 23, 0),
(2785, 117, 0, 0),
(2786, 117, 1, 0),
(2787, 117, 2, 0),
(2788, 117, 3, 0),
(2789, 117, 4, 0),
(2790, 117, 5, 0),
(2791, 117, 6, 0),
(2792, 117, 7, 0),
(2793, 117, 8, 0),
(2794, 117, 9, 0),
(2795, 117, 10, 0),
(2796, 117, 11, 0),
(2797, 117, 12, 0),
(2798, 117, 13, 0),
(2799, 117, 14, 0),
(2800, 117, 15, 0),
(2801, 117, 16, 0),
(2802, 117, 17, 0),
(2803, 117, 18, 0),
(2804, 117, 19, 0),
(2805, 117, 20, 0),
(2806, 117, 21, 0),
(2807, 117, 22, 0),
(2808, 117, 23, 0),
(2809, 118, 0, 0),
(2810, 118, 1, 0),
(2811, 118, 2, 0),
(2812, 118, 3, 0),
(2813, 118, 4, 0),
(2814, 118, 5, 0),
(2815, 118, 6, 0),
(2816, 118, 7, 0),
(2817, 118, 8, 0),
(2818, 118, 9, 0),
(2819, 118, 10, 0),
(2820, 118, 11, 0),
(2821, 118, 12, 0),
(2822, 118, 13, 0),
(2823, 118, 14, 0),
(2824, 118, 15, 0),
(2825, 118, 16, 0),
(2826, 118, 17, 0),
(2827, 118, 18, 0),
(2828, 118, 19, 0),
(2829, 118, 20, 0),
(2830, 118, 21, 0),
(2831, 118, 22, 0),
(2832, 118, 23, 0),
(2833, 119, 0, 0),
(2834, 119, 1, 0),
(2835, 119, 2, 0),
(2836, 119, 3, 0),
(2837, 119, 4, 0),
(2838, 119, 5, 0),
(2839, 119, 6, 0),
(2840, 119, 7, 0),
(2841, 119, 8, 0),
(2842, 119, 9, 0),
(2843, 119, 10, 0),
(2844, 119, 11, 0),
(2845, 119, 12, 0),
(2846, 119, 13, 0),
(2847, 119, 14, 0),
(2848, 119, 15, 0),
(2849, 119, 16, 0),
(2850, 119, 17, 0),
(2851, 119, 18, 0),
(2852, 119, 19, 0),
(2853, 119, 20, 0),
(2854, 119, 21, 0),
(2855, 119, 22, 0),
(2856, 119, 23, 0),
(2857, 120, 0, 0),
(2858, 120, 1, 0),
(2859, 120, 2, 0),
(2860, 120, 3, 0),
(2861, 120, 4, 0),
(2862, 120, 5, 0),
(2863, 120, 6, 0),
(2864, 120, 7, 0),
(2865, 120, 8, 0),
(2866, 120, 9, 0),
(2867, 120, 10, 0),
(2868, 120, 11, 0),
(2869, 120, 12, 0),
(2870, 120, 13, 0),
(2871, 120, 14, 0),
(2872, 120, 15, 0),
(2873, 120, 16, 0),
(2874, 120, 17, 0),
(2875, 120, 18, 0),
(2876, 120, 19, 0),
(2877, 120, 20, 0),
(2878, 120, 21, 0),
(2879, 120, 22, 0),
(2880, 120, 23, 0),
(2881, 121, 0, 0),
(2882, 121, 1, 0),
(2883, 121, 2, 0),
(2884, 121, 3, 0),
(2885, 121, 4, 0),
(2886, 121, 5, 0),
(2887, 121, 6, 0),
(2888, 121, 7, 0),
(2889, 121, 8, 0),
(2890, 121, 9, 0),
(2891, 121, 10, 0),
(2892, 121, 11, 0),
(2893, 121, 12, 0),
(2894, 121, 13, 0),
(2895, 121, 14, 0),
(2896, 121, 15, 0),
(2897, 121, 16, 0),
(2898, 121, 17, 0),
(2899, 121, 18, 0),
(2900, 121, 19, 0),
(2901, 121, 20, 0),
(2902, 121, 21, 0),
(2903, 121, 22, 0),
(2904, 121, 23, 0),
(2905, 122, 0, 0),
(2906, 122, 1, 0),
(2907, 122, 2, 0),
(2908, 122, 3, 0),
(2909, 122, 4, 0),
(2910, 122, 5, 0),
(2911, 122, 6, 0),
(2912, 122, 7, 0),
(2913, 122, 8, 0),
(2914, 122, 9, 0),
(2915, 122, 10, 0),
(2916, 122, 11, 0),
(2917, 122, 12, 0),
(2918, 122, 13, 0),
(2919, 122, 14, 0),
(2920, 122, 15, 0),
(2921, 122, 16, 0),
(2922, 122, 17, 0),
(2923, 122, 18, 0),
(2924, 122, 19, 0),
(2925, 122, 20, 0),
(2926, 122, 21, 0),
(2927, 122, 22, 0),
(2928, 122, 23, 0),
(2929, 123, 0, 0),
(2930, 123, 1, 0),
(2931, 123, 2, 0),
(2932, 123, 3, 0),
(2933, 123, 4, 0),
(2934, 123, 5, 0),
(2935, 123, 6, 0),
(2936, 123, 7, 0),
(2937, 123, 8, 0),
(2938, 123, 9, 0),
(2939, 123, 10, 0),
(2940, 123, 11, 0),
(2941, 123, 12, 0),
(2942, 123, 13, 0),
(2943, 123, 14, 0),
(2944, 123, 15, 0),
(2945, 123, 16, 0),
(2946, 123, 17, 0),
(2947, 123, 18, 0),
(2948, 123, 19, 0),
(2949, 123, 20, 0),
(2950, 123, 21, 0),
(2951, 123, 22, 0),
(2952, 123, 23, 0),
(2953, 124, 0, 0),
(2954, 124, 1, 0),
(2955, 124, 2, 0),
(2956, 124, 3, 0),
(2957, 124, 4, 0),
(2958, 124, 5, 0),
(2959, 124, 6, 0),
(2960, 124, 7, 0),
(2961, 124, 8, 0),
(2962, 124, 9, 0),
(2963, 124, 10, 0),
(2964, 124, 11, 0),
(2965, 124, 12, 0),
(2966, 124, 13, 0),
(2967, 124, 14, 0),
(2968, 124, 15, 0),
(2969, 124, 16, 0),
(2970, 124, 17, 0),
(2971, 124, 18, 0),
(2972, 124, 19, 0),
(2973, 124, 20, 0),
(2974, 124, 21, 0),
(2975, 124, 22, 0),
(2976, 124, 23, 0),
(2977, 125, 0, 0),
(2978, 125, 1, 0),
(2979, 125, 2, 0),
(2980, 125, 3, 0),
(2981, 125, 4, 0),
(2982, 125, 5, 0),
(2983, 125, 6, 0),
(2984, 125, 7, 0),
(2985, 125, 8, 0),
(2986, 125, 9, 0),
(2987, 125, 10, 0),
(2988, 125, 11, 0),
(2989, 125, 12, 0),
(2990, 125, 13, 0),
(2991, 125, 14, 0),
(2992, 125, 15, 0),
(2993, 125, 16, 0),
(2994, 125, 17, 0),
(2995, 125, 18, 0),
(2996, 125, 19, 0),
(2997, 125, 20, 0),
(2998, 125, 21, 0),
(2999, 125, 22, 0),
(3000, 125, 23, 0),
(3001, 126, 0, 0),
(3002, 126, 1, 0),
(3003, 126, 2, 0),
(3004, 126, 3, 0),
(3005, 126, 4, 0),
(3006, 126, 5, 0),
(3007, 126, 6, 0),
(3008, 126, 7, 0),
(3009, 126, 8, 0),
(3010, 126, 9, 0),
(3011, 126, 10, 0),
(3012, 126, 11, 0),
(3013, 126, 12, 0),
(3014, 126, 13, 0),
(3015, 126, 14, 0),
(3016, 126, 15, 0),
(3017, 126, 16, 0),
(3018, 126, 17, 0),
(3019, 126, 18, 0),
(3020, 126, 19, 0),
(3021, 126, 20, 0),
(3022, 126, 21, 0),
(3023, 126, 22, 0),
(3024, 126, 23, 0),
(3025, 127, 0, 0),
(3026, 127, 1, 0),
(3027, 127, 2, 0),
(3028, 127, 3, 0),
(3029, 127, 4, 0),
(3030, 127, 5, 0),
(3031, 127, 6, 0),
(3032, 127, 7, 0),
(3033, 127, 8, 0),
(3034, 127, 9, 0),
(3035, 127, 10, 0),
(3036, 127, 11, 0),
(3037, 127, 12, 0),
(3038, 127, 13, 0),
(3039, 127, 14, 0),
(3040, 127, 15, 0),
(3041, 127, 16, 0),
(3042, 127, 17, 0),
(3043, 127, 18, 0),
(3044, 127, 19, 0),
(3045, 127, 20, 0),
(3046, 127, 21, 0),
(3047, 127, 22, 0),
(3048, 127, 23, 0);
INSERT INTO `glpi_plugin_glpiinventory_inventorycomputerstats` (`id`, `day`, `hour`, `counter`) VALUES
(3049, 128, 0, 0),
(3050, 128, 1, 0),
(3051, 128, 2, 0),
(3052, 128, 3, 0),
(3053, 128, 4, 0),
(3054, 128, 5, 0),
(3055, 128, 6, 0),
(3056, 128, 7, 0),
(3057, 128, 8, 0),
(3058, 128, 9, 0),
(3059, 128, 10, 0),
(3060, 128, 11, 0),
(3061, 128, 12, 0),
(3062, 128, 13, 0),
(3063, 128, 14, 0),
(3064, 128, 15, 0),
(3065, 128, 16, 0),
(3066, 128, 17, 0),
(3067, 128, 18, 0),
(3068, 128, 19, 0),
(3069, 128, 20, 0),
(3070, 128, 21, 0),
(3071, 128, 22, 0),
(3072, 128, 23, 0),
(3073, 129, 0, 0),
(3074, 129, 1, 0),
(3075, 129, 2, 0),
(3076, 129, 3, 0),
(3077, 129, 4, 0),
(3078, 129, 5, 0),
(3079, 129, 6, 0),
(3080, 129, 7, 0),
(3081, 129, 8, 0),
(3082, 129, 9, 0),
(3083, 129, 10, 0),
(3084, 129, 11, 0),
(3085, 129, 12, 0),
(3086, 129, 13, 0),
(3087, 129, 14, 0),
(3088, 129, 15, 0),
(3089, 129, 16, 0),
(3090, 129, 17, 0),
(3091, 129, 18, 0),
(3092, 129, 19, 0),
(3093, 129, 20, 0),
(3094, 129, 21, 0),
(3095, 129, 22, 0),
(3096, 129, 23, 0),
(3097, 130, 0, 0),
(3098, 130, 1, 0),
(3099, 130, 2, 0),
(3100, 130, 3, 0),
(3101, 130, 4, 0),
(3102, 130, 5, 0),
(3103, 130, 6, 0),
(3104, 130, 7, 0),
(3105, 130, 8, 0),
(3106, 130, 9, 0),
(3107, 130, 10, 0),
(3108, 130, 11, 0),
(3109, 130, 12, 0),
(3110, 130, 13, 0),
(3111, 130, 14, 0),
(3112, 130, 15, 0),
(3113, 130, 16, 0),
(3114, 130, 17, 0),
(3115, 130, 18, 0),
(3116, 130, 19, 0),
(3117, 130, 20, 0),
(3118, 130, 21, 0),
(3119, 130, 22, 0),
(3120, 130, 23, 0),
(3121, 131, 0, 0),
(3122, 131, 1, 0),
(3123, 131, 2, 0),
(3124, 131, 3, 0),
(3125, 131, 4, 0),
(3126, 131, 5, 0),
(3127, 131, 6, 0),
(3128, 131, 7, 0),
(3129, 131, 8, 0),
(3130, 131, 9, 0),
(3131, 131, 10, 0),
(3132, 131, 11, 0),
(3133, 131, 12, 0),
(3134, 131, 13, 0),
(3135, 131, 14, 0),
(3136, 131, 15, 0),
(3137, 131, 16, 0),
(3138, 131, 17, 0),
(3139, 131, 18, 0),
(3140, 131, 19, 0),
(3141, 131, 20, 0),
(3142, 131, 21, 0),
(3143, 131, 22, 0),
(3144, 131, 23, 0),
(3145, 132, 0, 0),
(3146, 132, 1, 0),
(3147, 132, 2, 0),
(3148, 132, 3, 0),
(3149, 132, 4, 0),
(3150, 132, 5, 0),
(3151, 132, 6, 0),
(3152, 132, 7, 0),
(3153, 132, 8, 0),
(3154, 132, 9, 0),
(3155, 132, 10, 0),
(3156, 132, 11, 0),
(3157, 132, 12, 0),
(3158, 132, 13, 0),
(3159, 132, 14, 0),
(3160, 132, 15, 0),
(3161, 132, 16, 0),
(3162, 132, 17, 0),
(3163, 132, 18, 0),
(3164, 132, 19, 0),
(3165, 132, 20, 0),
(3166, 132, 21, 0),
(3167, 132, 22, 0),
(3168, 132, 23, 0),
(3169, 133, 0, 0),
(3170, 133, 1, 0),
(3171, 133, 2, 0),
(3172, 133, 3, 0),
(3173, 133, 4, 0),
(3174, 133, 5, 0),
(3175, 133, 6, 0),
(3176, 133, 7, 0),
(3177, 133, 8, 0),
(3178, 133, 9, 0),
(3179, 133, 10, 0),
(3180, 133, 11, 0),
(3181, 133, 12, 0),
(3182, 133, 13, 0),
(3183, 133, 14, 0),
(3184, 133, 15, 0),
(3185, 133, 16, 0),
(3186, 133, 17, 0),
(3187, 133, 18, 0),
(3188, 133, 19, 0),
(3189, 133, 20, 0),
(3190, 133, 21, 0),
(3191, 133, 22, 0),
(3192, 133, 23, 0),
(3193, 134, 0, 0),
(3194, 134, 1, 0),
(3195, 134, 2, 0),
(3196, 134, 3, 0),
(3197, 134, 4, 0),
(3198, 134, 5, 0),
(3199, 134, 6, 0),
(3200, 134, 7, 0),
(3201, 134, 8, 0),
(3202, 134, 9, 0),
(3203, 134, 10, 0),
(3204, 134, 11, 0),
(3205, 134, 12, 0),
(3206, 134, 13, 0),
(3207, 134, 14, 0),
(3208, 134, 15, 0),
(3209, 134, 16, 0),
(3210, 134, 17, 0),
(3211, 134, 18, 0),
(3212, 134, 19, 0),
(3213, 134, 20, 0),
(3214, 134, 21, 0),
(3215, 134, 22, 0),
(3216, 134, 23, 0),
(3217, 135, 0, 0),
(3218, 135, 1, 0),
(3219, 135, 2, 0),
(3220, 135, 3, 0),
(3221, 135, 4, 0),
(3222, 135, 5, 0),
(3223, 135, 6, 0),
(3224, 135, 7, 0),
(3225, 135, 8, 0),
(3226, 135, 9, 0),
(3227, 135, 10, 0),
(3228, 135, 11, 0),
(3229, 135, 12, 0),
(3230, 135, 13, 0),
(3231, 135, 14, 0),
(3232, 135, 15, 0),
(3233, 135, 16, 0),
(3234, 135, 17, 0),
(3235, 135, 18, 0),
(3236, 135, 19, 0),
(3237, 135, 20, 0),
(3238, 135, 21, 0),
(3239, 135, 22, 0),
(3240, 135, 23, 0),
(3241, 136, 0, 0),
(3242, 136, 1, 0),
(3243, 136, 2, 0),
(3244, 136, 3, 0),
(3245, 136, 4, 0),
(3246, 136, 5, 0),
(3247, 136, 6, 0),
(3248, 136, 7, 0),
(3249, 136, 8, 0),
(3250, 136, 9, 0),
(3251, 136, 10, 0),
(3252, 136, 11, 0),
(3253, 136, 12, 0),
(3254, 136, 13, 0),
(3255, 136, 14, 0),
(3256, 136, 15, 0),
(3257, 136, 16, 0),
(3258, 136, 17, 0),
(3259, 136, 18, 0),
(3260, 136, 19, 0),
(3261, 136, 20, 0),
(3262, 136, 21, 0),
(3263, 136, 22, 0),
(3264, 136, 23, 0),
(3265, 137, 0, 0),
(3266, 137, 1, 0),
(3267, 137, 2, 0),
(3268, 137, 3, 0),
(3269, 137, 4, 0),
(3270, 137, 5, 0),
(3271, 137, 6, 0),
(3272, 137, 7, 0),
(3273, 137, 8, 0),
(3274, 137, 9, 0),
(3275, 137, 10, 0),
(3276, 137, 11, 0),
(3277, 137, 12, 0),
(3278, 137, 13, 0),
(3279, 137, 14, 0),
(3280, 137, 15, 0),
(3281, 137, 16, 0),
(3282, 137, 17, 0),
(3283, 137, 18, 0),
(3284, 137, 19, 0),
(3285, 137, 20, 0),
(3286, 137, 21, 0),
(3287, 137, 22, 0),
(3288, 137, 23, 0),
(3289, 138, 0, 0),
(3290, 138, 1, 0),
(3291, 138, 2, 0),
(3292, 138, 3, 0),
(3293, 138, 4, 0),
(3294, 138, 5, 0),
(3295, 138, 6, 0),
(3296, 138, 7, 0),
(3297, 138, 8, 0),
(3298, 138, 9, 0),
(3299, 138, 10, 0),
(3300, 138, 11, 0),
(3301, 138, 12, 0),
(3302, 138, 13, 0),
(3303, 138, 14, 0),
(3304, 138, 15, 0),
(3305, 138, 16, 0),
(3306, 138, 17, 0),
(3307, 138, 18, 0),
(3308, 138, 19, 0),
(3309, 138, 20, 0),
(3310, 138, 21, 0),
(3311, 138, 22, 0),
(3312, 138, 23, 0),
(3313, 139, 0, 0),
(3314, 139, 1, 0),
(3315, 139, 2, 0),
(3316, 139, 3, 0),
(3317, 139, 4, 0),
(3318, 139, 5, 0),
(3319, 139, 6, 0),
(3320, 139, 7, 0),
(3321, 139, 8, 0),
(3322, 139, 9, 0),
(3323, 139, 10, 0),
(3324, 139, 11, 0),
(3325, 139, 12, 0),
(3326, 139, 13, 0),
(3327, 139, 14, 0),
(3328, 139, 15, 0),
(3329, 139, 16, 0),
(3330, 139, 17, 0),
(3331, 139, 18, 0),
(3332, 139, 19, 0),
(3333, 139, 20, 0),
(3334, 139, 21, 0),
(3335, 139, 22, 0),
(3336, 139, 23, 0),
(3337, 140, 0, 0),
(3338, 140, 1, 0),
(3339, 140, 2, 0),
(3340, 140, 3, 0),
(3341, 140, 4, 0),
(3342, 140, 5, 0),
(3343, 140, 6, 0),
(3344, 140, 7, 0),
(3345, 140, 8, 0),
(3346, 140, 9, 0),
(3347, 140, 10, 0),
(3348, 140, 11, 0),
(3349, 140, 12, 0),
(3350, 140, 13, 0),
(3351, 140, 14, 0),
(3352, 140, 15, 0),
(3353, 140, 16, 0),
(3354, 140, 17, 0),
(3355, 140, 18, 0),
(3356, 140, 19, 0),
(3357, 140, 20, 0),
(3358, 140, 21, 0),
(3359, 140, 22, 0),
(3360, 140, 23, 0),
(3361, 141, 0, 0),
(3362, 141, 1, 0),
(3363, 141, 2, 0),
(3364, 141, 3, 0),
(3365, 141, 4, 0),
(3366, 141, 5, 0),
(3367, 141, 6, 0),
(3368, 141, 7, 0),
(3369, 141, 8, 0),
(3370, 141, 9, 0),
(3371, 141, 10, 0),
(3372, 141, 11, 0),
(3373, 141, 12, 0),
(3374, 141, 13, 0),
(3375, 141, 14, 0),
(3376, 141, 15, 0),
(3377, 141, 16, 0),
(3378, 141, 17, 0),
(3379, 141, 18, 0),
(3380, 141, 19, 0),
(3381, 141, 20, 0),
(3382, 141, 21, 0),
(3383, 141, 22, 0),
(3384, 141, 23, 0),
(3385, 142, 0, 0),
(3386, 142, 1, 0),
(3387, 142, 2, 0),
(3388, 142, 3, 0),
(3389, 142, 4, 0),
(3390, 142, 5, 0),
(3391, 142, 6, 0),
(3392, 142, 7, 0),
(3393, 142, 8, 0),
(3394, 142, 9, 0),
(3395, 142, 10, 0),
(3396, 142, 11, 0),
(3397, 142, 12, 0),
(3398, 142, 13, 0),
(3399, 142, 14, 0),
(3400, 142, 15, 0),
(3401, 142, 16, 0),
(3402, 142, 17, 0),
(3403, 142, 18, 0),
(3404, 142, 19, 0),
(3405, 142, 20, 0),
(3406, 142, 21, 0),
(3407, 142, 22, 0),
(3408, 142, 23, 0),
(3409, 143, 0, 0),
(3410, 143, 1, 0),
(3411, 143, 2, 0),
(3412, 143, 3, 0),
(3413, 143, 4, 0),
(3414, 143, 5, 0),
(3415, 143, 6, 0),
(3416, 143, 7, 0),
(3417, 143, 8, 0),
(3418, 143, 9, 0),
(3419, 143, 10, 0),
(3420, 143, 11, 0),
(3421, 143, 12, 0),
(3422, 143, 13, 0),
(3423, 143, 14, 0),
(3424, 143, 15, 0),
(3425, 143, 16, 0),
(3426, 143, 17, 0),
(3427, 143, 18, 0),
(3428, 143, 19, 0),
(3429, 143, 20, 0),
(3430, 143, 21, 0),
(3431, 143, 22, 0),
(3432, 143, 23, 0),
(3433, 144, 0, 0),
(3434, 144, 1, 0),
(3435, 144, 2, 0),
(3436, 144, 3, 0),
(3437, 144, 4, 0),
(3438, 144, 5, 0),
(3439, 144, 6, 0),
(3440, 144, 7, 0),
(3441, 144, 8, 0),
(3442, 144, 9, 0),
(3443, 144, 10, 0),
(3444, 144, 11, 0),
(3445, 144, 12, 0),
(3446, 144, 13, 0),
(3447, 144, 14, 0),
(3448, 144, 15, 0),
(3449, 144, 16, 0),
(3450, 144, 17, 0),
(3451, 144, 18, 0),
(3452, 144, 19, 0),
(3453, 144, 20, 0),
(3454, 144, 21, 0),
(3455, 144, 22, 0),
(3456, 144, 23, 0),
(3457, 145, 0, 0),
(3458, 145, 1, 0),
(3459, 145, 2, 0),
(3460, 145, 3, 0),
(3461, 145, 4, 0),
(3462, 145, 5, 0),
(3463, 145, 6, 0),
(3464, 145, 7, 0),
(3465, 145, 8, 0),
(3466, 145, 9, 0),
(3467, 145, 10, 0),
(3468, 145, 11, 0),
(3469, 145, 12, 0),
(3470, 145, 13, 0),
(3471, 145, 14, 0),
(3472, 145, 15, 0),
(3473, 145, 16, 0),
(3474, 145, 17, 0),
(3475, 145, 18, 0),
(3476, 145, 19, 0),
(3477, 145, 20, 0),
(3478, 145, 21, 0),
(3479, 145, 22, 0),
(3480, 145, 23, 0),
(3481, 146, 0, 0),
(3482, 146, 1, 0),
(3483, 146, 2, 0),
(3484, 146, 3, 0),
(3485, 146, 4, 0),
(3486, 146, 5, 0),
(3487, 146, 6, 0),
(3488, 146, 7, 0),
(3489, 146, 8, 0),
(3490, 146, 9, 0),
(3491, 146, 10, 0),
(3492, 146, 11, 0),
(3493, 146, 12, 0),
(3494, 146, 13, 0),
(3495, 146, 14, 0),
(3496, 146, 15, 0),
(3497, 146, 16, 0),
(3498, 146, 17, 0),
(3499, 146, 18, 0),
(3500, 146, 19, 0),
(3501, 146, 20, 0),
(3502, 146, 21, 0),
(3503, 146, 22, 0),
(3504, 146, 23, 0),
(3505, 147, 0, 0),
(3506, 147, 1, 0),
(3507, 147, 2, 0),
(3508, 147, 3, 0),
(3509, 147, 4, 0),
(3510, 147, 5, 0),
(3511, 147, 6, 0),
(3512, 147, 7, 0),
(3513, 147, 8, 0),
(3514, 147, 9, 0),
(3515, 147, 10, 0),
(3516, 147, 11, 0),
(3517, 147, 12, 0),
(3518, 147, 13, 0),
(3519, 147, 14, 0),
(3520, 147, 15, 0),
(3521, 147, 16, 0),
(3522, 147, 17, 0),
(3523, 147, 18, 0),
(3524, 147, 19, 0),
(3525, 147, 20, 0),
(3526, 147, 21, 0),
(3527, 147, 22, 0),
(3528, 147, 23, 0),
(3529, 148, 0, 0),
(3530, 148, 1, 0),
(3531, 148, 2, 0),
(3532, 148, 3, 0),
(3533, 148, 4, 0),
(3534, 148, 5, 0),
(3535, 148, 6, 0),
(3536, 148, 7, 0),
(3537, 148, 8, 0),
(3538, 148, 9, 0),
(3539, 148, 10, 0),
(3540, 148, 11, 0),
(3541, 148, 12, 0),
(3542, 148, 13, 0),
(3543, 148, 14, 0),
(3544, 148, 15, 0),
(3545, 148, 16, 0),
(3546, 148, 17, 0),
(3547, 148, 18, 0),
(3548, 148, 19, 0),
(3549, 148, 20, 0),
(3550, 148, 21, 0),
(3551, 148, 22, 0),
(3552, 148, 23, 0),
(3553, 149, 0, 0),
(3554, 149, 1, 0),
(3555, 149, 2, 0),
(3556, 149, 3, 0),
(3557, 149, 4, 0),
(3558, 149, 5, 0),
(3559, 149, 6, 0),
(3560, 149, 7, 0),
(3561, 149, 8, 0),
(3562, 149, 9, 0),
(3563, 149, 10, 0),
(3564, 149, 11, 0),
(3565, 149, 12, 0),
(3566, 149, 13, 0),
(3567, 149, 14, 0),
(3568, 149, 15, 0),
(3569, 149, 16, 0),
(3570, 149, 17, 0),
(3571, 149, 18, 0),
(3572, 149, 19, 0),
(3573, 149, 20, 0),
(3574, 149, 21, 0),
(3575, 149, 22, 0),
(3576, 149, 23, 0),
(3577, 150, 0, 0),
(3578, 150, 1, 0),
(3579, 150, 2, 0),
(3580, 150, 3, 0),
(3581, 150, 4, 0),
(3582, 150, 5, 0),
(3583, 150, 6, 0),
(3584, 150, 7, 0),
(3585, 150, 8, 0),
(3586, 150, 9, 0),
(3587, 150, 10, 0),
(3588, 150, 11, 0),
(3589, 150, 12, 0),
(3590, 150, 13, 0),
(3591, 150, 14, 0),
(3592, 150, 15, 0),
(3593, 150, 16, 0),
(3594, 150, 17, 0),
(3595, 150, 18, 0),
(3596, 150, 19, 0),
(3597, 150, 20, 0),
(3598, 150, 21, 0),
(3599, 150, 22, 0),
(3600, 150, 23, 0),
(3601, 151, 0, 0),
(3602, 151, 1, 0),
(3603, 151, 2, 0),
(3604, 151, 3, 0),
(3605, 151, 4, 0),
(3606, 151, 5, 0),
(3607, 151, 6, 0),
(3608, 151, 7, 0),
(3609, 151, 8, 0),
(3610, 151, 9, 0),
(3611, 151, 10, 0),
(3612, 151, 11, 0),
(3613, 151, 12, 0),
(3614, 151, 13, 0),
(3615, 151, 14, 0),
(3616, 151, 15, 0),
(3617, 151, 16, 0),
(3618, 151, 17, 0),
(3619, 151, 18, 0),
(3620, 151, 19, 0),
(3621, 151, 20, 0),
(3622, 151, 21, 0),
(3623, 151, 22, 0),
(3624, 151, 23, 0),
(3625, 152, 0, 0),
(3626, 152, 1, 0),
(3627, 152, 2, 0),
(3628, 152, 3, 0),
(3629, 152, 4, 0),
(3630, 152, 5, 0),
(3631, 152, 6, 0),
(3632, 152, 7, 0),
(3633, 152, 8, 0),
(3634, 152, 9, 0),
(3635, 152, 10, 0),
(3636, 152, 11, 0),
(3637, 152, 12, 0),
(3638, 152, 13, 0),
(3639, 152, 14, 0),
(3640, 152, 15, 0),
(3641, 152, 16, 0),
(3642, 152, 17, 0),
(3643, 152, 18, 0),
(3644, 152, 19, 0),
(3645, 152, 20, 0),
(3646, 152, 21, 0),
(3647, 152, 22, 0),
(3648, 152, 23, 0),
(3649, 153, 0, 0),
(3650, 153, 1, 0),
(3651, 153, 2, 0),
(3652, 153, 3, 0),
(3653, 153, 4, 0),
(3654, 153, 5, 0),
(3655, 153, 6, 0),
(3656, 153, 7, 0),
(3657, 153, 8, 0),
(3658, 153, 9, 0),
(3659, 153, 10, 0),
(3660, 153, 11, 0),
(3661, 153, 12, 0),
(3662, 153, 13, 0),
(3663, 153, 14, 0),
(3664, 153, 15, 0),
(3665, 153, 16, 0),
(3666, 153, 17, 0),
(3667, 153, 18, 0),
(3668, 153, 19, 0),
(3669, 153, 20, 0),
(3670, 153, 21, 0),
(3671, 153, 22, 0),
(3672, 153, 23, 0),
(3673, 154, 0, 0),
(3674, 154, 1, 0),
(3675, 154, 2, 0),
(3676, 154, 3, 0),
(3677, 154, 4, 0),
(3678, 154, 5, 0),
(3679, 154, 6, 0),
(3680, 154, 7, 0),
(3681, 154, 8, 0),
(3682, 154, 9, 0),
(3683, 154, 10, 0),
(3684, 154, 11, 0),
(3685, 154, 12, 0),
(3686, 154, 13, 0),
(3687, 154, 14, 0),
(3688, 154, 15, 0),
(3689, 154, 16, 0),
(3690, 154, 17, 0),
(3691, 154, 18, 0),
(3692, 154, 19, 0),
(3693, 154, 20, 0),
(3694, 154, 21, 0),
(3695, 154, 22, 0),
(3696, 154, 23, 0),
(3697, 155, 0, 0),
(3698, 155, 1, 0),
(3699, 155, 2, 0),
(3700, 155, 3, 0),
(3701, 155, 4, 0),
(3702, 155, 5, 0),
(3703, 155, 6, 0),
(3704, 155, 7, 0),
(3705, 155, 8, 0),
(3706, 155, 9, 0),
(3707, 155, 10, 0),
(3708, 155, 11, 0),
(3709, 155, 12, 0),
(3710, 155, 13, 0),
(3711, 155, 14, 0),
(3712, 155, 15, 0),
(3713, 155, 16, 0),
(3714, 155, 17, 0),
(3715, 155, 18, 0),
(3716, 155, 19, 0),
(3717, 155, 20, 0),
(3718, 155, 21, 0),
(3719, 155, 22, 0),
(3720, 155, 23, 0),
(3721, 156, 0, 0),
(3722, 156, 1, 0),
(3723, 156, 2, 0),
(3724, 156, 3, 0),
(3725, 156, 4, 0),
(3726, 156, 5, 0),
(3727, 156, 6, 0),
(3728, 156, 7, 0),
(3729, 156, 8, 0),
(3730, 156, 9, 0),
(3731, 156, 10, 0),
(3732, 156, 11, 0),
(3733, 156, 12, 0),
(3734, 156, 13, 0),
(3735, 156, 14, 0),
(3736, 156, 15, 0),
(3737, 156, 16, 0),
(3738, 156, 17, 0),
(3739, 156, 18, 0),
(3740, 156, 19, 0),
(3741, 156, 20, 0),
(3742, 156, 21, 0),
(3743, 156, 22, 0),
(3744, 156, 23, 0),
(3745, 157, 0, 0),
(3746, 157, 1, 0),
(3747, 157, 2, 0),
(3748, 157, 3, 0),
(3749, 157, 4, 0),
(3750, 157, 5, 0),
(3751, 157, 6, 0),
(3752, 157, 7, 0),
(3753, 157, 8, 0),
(3754, 157, 9, 0),
(3755, 157, 10, 0),
(3756, 157, 11, 0),
(3757, 157, 12, 0),
(3758, 157, 13, 0),
(3759, 157, 14, 0),
(3760, 157, 15, 0),
(3761, 157, 16, 0),
(3762, 157, 17, 0),
(3763, 157, 18, 0),
(3764, 157, 19, 0),
(3765, 157, 20, 0),
(3766, 157, 21, 0),
(3767, 157, 22, 0),
(3768, 157, 23, 0),
(3769, 158, 0, 0),
(3770, 158, 1, 0),
(3771, 158, 2, 0),
(3772, 158, 3, 0),
(3773, 158, 4, 0),
(3774, 158, 5, 0),
(3775, 158, 6, 0),
(3776, 158, 7, 0),
(3777, 158, 8, 0),
(3778, 158, 9, 0),
(3779, 158, 10, 0),
(3780, 158, 11, 0),
(3781, 158, 12, 0),
(3782, 158, 13, 0),
(3783, 158, 14, 0),
(3784, 158, 15, 0),
(3785, 158, 16, 0),
(3786, 158, 17, 0),
(3787, 158, 18, 0),
(3788, 158, 19, 0),
(3789, 158, 20, 0),
(3790, 158, 21, 0),
(3791, 158, 22, 0),
(3792, 158, 23, 0),
(3793, 159, 0, 0),
(3794, 159, 1, 0),
(3795, 159, 2, 0),
(3796, 159, 3, 0),
(3797, 159, 4, 0),
(3798, 159, 5, 0),
(3799, 159, 6, 0),
(3800, 159, 7, 0),
(3801, 159, 8, 0),
(3802, 159, 9, 0),
(3803, 159, 10, 0),
(3804, 159, 11, 0),
(3805, 159, 12, 0),
(3806, 159, 13, 0),
(3807, 159, 14, 0),
(3808, 159, 15, 0),
(3809, 159, 16, 0),
(3810, 159, 17, 0),
(3811, 159, 18, 0),
(3812, 159, 19, 0),
(3813, 159, 20, 0),
(3814, 159, 21, 0),
(3815, 159, 22, 0),
(3816, 159, 23, 0),
(3817, 160, 0, 0),
(3818, 160, 1, 0),
(3819, 160, 2, 0),
(3820, 160, 3, 0),
(3821, 160, 4, 0),
(3822, 160, 5, 0),
(3823, 160, 6, 0),
(3824, 160, 7, 0),
(3825, 160, 8, 0),
(3826, 160, 9, 0),
(3827, 160, 10, 0),
(3828, 160, 11, 0),
(3829, 160, 12, 0),
(3830, 160, 13, 0),
(3831, 160, 14, 0),
(3832, 160, 15, 0),
(3833, 160, 16, 0),
(3834, 160, 17, 0),
(3835, 160, 18, 0),
(3836, 160, 19, 0),
(3837, 160, 20, 0),
(3838, 160, 21, 0),
(3839, 160, 22, 0),
(3840, 160, 23, 0),
(3841, 161, 0, 0),
(3842, 161, 1, 0),
(3843, 161, 2, 0),
(3844, 161, 3, 0),
(3845, 161, 4, 0),
(3846, 161, 5, 0),
(3847, 161, 6, 0),
(3848, 161, 7, 0),
(3849, 161, 8, 0),
(3850, 161, 9, 0),
(3851, 161, 10, 0),
(3852, 161, 11, 0),
(3853, 161, 12, 0),
(3854, 161, 13, 0),
(3855, 161, 14, 0),
(3856, 161, 15, 0),
(3857, 161, 16, 0),
(3858, 161, 17, 0),
(3859, 161, 18, 0),
(3860, 161, 19, 0),
(3861, 161, 20, 0),
(3862, 161, 21, 0),
(3863, 161, 22, 0),
(3864, 161, 23, 0),
(3865, 162, 0, 0),
(3866, 162, 1, 0),
(3867, 162, 2, 0),
(3868, 162, 3, 0),
(3869, 162, 4, 0),
(3870, 162, 5, 0),
(3871, 162, 6, 0),
(3872, 162, 7, 0),
(3873, 162, 8, 0),
(3874, 162, 9, 0),
(3875, 162, 10, 0),
(3876, 162, 11, 0),
(3877, 162, 12, 0),
(3878, 162, 13, 0),
(3879, 162, 14, 0),
(3880, 162, 15, 0),
(3881, 162, 16, 0),
(3882, 162, 17, 0),
(3883, 162, 18, 0),
(3884, 162, 19, 0),
(3885, 162, 20, 0),
(3886, 162, 21, 0),
(3887, 162, 22, 0),
(3888, 162, 23, 0),
(3889, 163, 0, 0),
(3890, 163, 1, 0),
(3891, 163, 2, 0),
(3892, 163, 3, 0),
(3893, 163, 4, 0),
(3894, 163, 5, 0),
(3895, 163, 6, 0),
(3896, 163, 7, 0),
(3897, 163, 8, 0),
(3898, 163, 9, 0),
(3899, 163, 10, 0),
(3900, 163, 11, 0),
(3901, 163, 12, 0),
(3902, 163, 13, 0),
(3903, 163, 14, 0),
(3904, 163, 15, 0),
(3905, 163, 16, 0),
(3906, 163, 17, 0),
(3907, 163, 18, 0),
(3908, 163, 19, 0),
(3909, 163, 20, 0),
(3910, 163, 21, 0),
(3911, 163, 22, 0),
(3912, 163, 23, 0),
(3913, 164, 0, 0),
(3914, 164, 1, 0),
(3915, 164, 2, 0),
(3916, 164, 3, 0),
(3917, 164, 4, 0),
(3918, 164, 5, 0),
(3919, 164, 6, 0),
(3920, 164, 7, 0),
(3921, 164, 8, 0),
(3922, 164, 9, 0),
(3923, 164, 10, 0),
(3924, 164, 11, 0),
(3925, 164, 12, 0),
(3926, 164, 13, 0),
(3927, 164, 14, 0),
(3928, 164, 15, 0),
(3929, 164, 16, 0),
(3930, 164, 17, 0),
(3931, 164, 18, 0),
(3932, 164, 19, 0),
(3933, 164, 20, 0),
(3934, 164, 21, 0),
(3935, 164, 22, 0),
(3936, 164, 23, 0),
(3937, 165, 0, 0),
(3938, 165, 1, 0),
(3939, 165, 2, 0),
(3940, 165, 3, 0),
(3941, 165, 4, 0),
(3942, 165, 5, 0),
(3943, 165, 6, 0),
(3944, 165, 7, 0),
(3945, 165, 8, 0),
(3946, 165, 9, 0),
(3947, 165, 10, 0),
(3948, 165, 11, 0),
(3949, 165, 12, 0),
(3950, 165, 13, 0),
(3951, 165, 14, 0),
(3952, 165, 15, 0),
(3953, 165, 16, 0),
(3954, 165, 17, 0),
(3955, 165, 18, 0),
(3956, 165, 19, 0),
(3957, 165, 20, 0),
(3958, 165, 21, 0),
(3959, 165, 22, 0),
(3960, 165, 23, 0),
(3961, 166, 0, 0),
(3962, 166, 1, 0),
(3963, 166, 2, 0),
(3964, 166, 3, 0),
(3965, 166, 4, 0),
(3966, 166, 5, 0),
(3967, 166, 6, 0),
(3968, 166, 7, 0),
(3969, 166, 8, 0),
(3970, 166, 9, 0),
(3971, 166, 10, 0),
(3972, 166, 11, 0),
(3973, 166, 12, 0),
(3974, 166, 13, 0),
(3975, 166, 14, 0),
(3976, 166, 15, 0),
(3977, 166, 16, 0),
(3978, 166, 17, 0),
(3979, 166, 18, 0),
(3980, 166, 19, 0),
(3981, 166, 20, 0),
(3982, 166, 21, 0),
(3983, 166, 22, 0),
(3984, 166, 23, 0),
(3985, 167, 0, 0),
(3986, 167, 1, 0),
(3987, 167, 2, 0),
(3988, 167, 3, 0),
(3989, 167, 4, 0),
(3990, 167, 5, 0),
(3991, 167, 6, 0),
(3992, 167, 7, 0),
(3993, 167, 8, 0),
(3994, 167, 9, 0),
(3995, 167, 10, 0),
(3996, 167, 11, 0),
(3997, 167, 12, 0),
(3998, 167, 13, 0),
(3999, 167, 14, 0),
(4000, 167, 15, 0),
(4001, 167, 16, 0),
(4002, 167, 17, 0),
(4003, 167, 18, 0),
(4004, 167, 19, 0),
(4005, 167, 20, 0),
(4006, 167, 21, 0),
(4007, 167, 22, 0),
(4008, 167, 23, 0),
(4009, 168, 0, 0),
(4010, 168, 1, 0),
(4011, 168, 2, 0),
(4012, 168, 3, 0),
(4013, 168, 4, 0),
(4014, 168, 5, 0),
(4015, 168, 6, 0),
(4016, 168, 7, 0),
(4017, 168, 8, 0),
(4018, 168, 9, 0),
(4019, 168, 10, 0),
(4020, 168, 11, 0),
(4021, 168, 12, 0),
(4022, 168, 13, 0),
(4023, 168, 14, 0),
(4024, 168, 15, 0),
(4025, 168, 16, 0),
(4026, 168, 17, 0),
(4027, 168, 18, 0),
(4028, 168, 19, 0),
(4029, 168, 20, 0),
(4030, 168, 21, 0),
(4031, 168, 22, 0),
(4032, 168, 23, 0),
(4033, 169, 0, 0),
(4034, 169, 1, 0),
(4035, 169, 2, 0),
(4036, 169, 3, 0),
(4037, 169, 4, 0),
(4038, 169, 5, 0),
(4039, 169, 6, 0),
(4040, 169, 7, 0),
(4041, 169, 8, 0),
(4042, 169, 9, 0),
(4043, 169, 10, 0),
(4044, 169, 11, 0),
(4045, 169, 12, 0),
(4046, 169, 13, 0),
(4047, 169, 14, 0),
(4048, 169, 15, 0),
(4049, 169, 16, 0),
(4050, 169, 17, 0),
(4051, 169, 18, 0),
(4052, 169, 19, 0),
(4053, 169, 20, 0),
(4054, 169, 21, 0),
(4055, 169, 22, 0),
(4056, 169, 23, 0),
(4057, 170, 0, 0),
(4058, 170, 1, 0),
(4059, 170, 2, 0),
(4060, 170, 3, 0),
(4061, 170, 4, 0),
(4062, 170, 5, 0),
(4063, 170, 6, 0),
(4064, 170, 7, 0),
(4065, 170, 8, 0),
(4066, 170, 9, 0),
(4067, 170, 10, 0),
(4068, 170, 11, 0),
(4069, 170, 12, 0),
(4070, 170, 13, 0),
(4071, 170, 14, 0),
(4072, 170, 15, 0),
(4073, 170, 16, 0),
(4074, 170, 17, 0),
(4075, 170, 18, 0),
(4076, 170, 19, 0),
(4077, 170, 20, 0),
(4078, 170, 21, 0),
(4079, 170, 22, 0),
(4080, 170, 23, 0),
(4081, 171, 0, 0),
(4082, 171, 1, 0),
(4083, 171, 2, 0),
(4084, 171, 3, 0),
(4085, 171, 4, 0),
(4086, 171, 5, 0),
(4087, 171, 6, 0),
(4088, 171, 7, 0),
(4089, 171, 8, 0),
(4090, 171, 9, 0),
(4091, 171, 10, 0),
(4092, 171, 11, 0),
(4093, 171, 12, 0),
(4094, 171, 13, 0),
(4095, 171, 14, 0),
(4096, 171, 15, 0),
(4097, 171, 16, 0),
(4098, 171, 17, 0),
(4099, 171, 18, 0),
(4100, 171, 19, 0),
(4101, 171, 20, 0),
(4102, 171, 21, 0),
(4103, 171, 22, 0),
(4104, 171, 23, 0),
(4105, 172, 0, 0),
(4106, 172, 1, 0),
(4107, 172, 2, 0),
(4108, 172, 3, 0),
(4109, 172, 4, 0),
(4110, 172, 5, 0),
(4111, 172, 6, 0),
(4112, 172, 7, 0),
(4113, 172, 8, 0),
(4114, 172, 9, 0),
(4115, 172, 10, 0),
(4116, 172, 11, 0),
(4117, 172, 12, 0),
(4118, 172, 13, 0),
(4119, 172, 14, 0),
(4120, 172, 15, 0),
(4121, 172, 16, 0),
(4122, 172, 17, 0),
(4123, 172, 18, 0),
(4124, 172, 19, 0),
(4125, 172, 20, 0),
(4126, 172, 21, 0),
(4127, 172, 22, 0),
(4128, 172, 23, 0),
(4129, 173, 0, 0),
(4130, 173, 1, 0),
(4131, 173, 2, 0),
(4132, 173, 3, 0),
(4133, 173, 4, 0),
(4134, 173, 5, 0),
(4135, 173, 6, 0),
(4136, 173, 7, 0),
(4137, 173, 8, 0),
(4138, 173, 9, 0),
(4139, 173, 10, 0),
(4140, 173, 11, 0),
(4141, 173, 12, 0),
(4142, 173, 13, 0),
(4143, 173, 14, 0),
(4144, 173, 15, 0),
(4145, 173, 16, 0),
(4146, 173, 17, 0),
(4147, 173, 18, 0),
(4148, 173, 19, 0),
(4149, 173, 20, 0),
(4150, 173, 21, 0),
(4151, 173, 22, 0),
(4152, 173, 23, 0),
(4153, 174, 0, 0),
(4154, 174, 1, 0),
(4155, 174, 2, 0),
(4156, 174, 3, 0),
(4157, 174, 4, 0),
(4158, 174, 5, 0),
(4159, 174, 6, 0),
(4160, 174, 7, 0),
(4161, 174, 8, 0),
(4162, 174, 9, 0),
(4163, 174, 10, 0),
(4164, 174, 11, 0),
(4165, 174, 12, 0),
(4166, 174, 13, 0),
(4167, 174, 14, 0),
(4168, 174, 15, 0),
(4169, 174, 16, 0),
(4170, 174, 17, 0),
(4171, 174, 18, 0),
(4172, 174, 19, 0),
(4173, 174, 20, 0),
(4174, 174, 21, 0),
(4175, 174, 22, 0),
(4176, 174, 23, 0),
(4177, 175, 0, 0),
(4178, 175, 1, 0),
(4179, 175, 2, 0),
(4180, 175, 3, 0),
(4181, 175, 4, 0),
(4182, 175, 5, 0),
(4183, 175, 6, 0),
(4184, 175, 7, 0),
(4185, 175, 8, 0),
(4186, 175, 9, 0),
(4187, 175, 10, 0),
(4188, 175, 11, 0),
(4189, 175, 12, 0),
(4190, 175, 13, 0),
(4191, 175, 14, 0),
(4192, 175, 15, 0),
(4193, 175, 16, 0),
(4194, 175, 17, 0),
(4195, 175, 18, 0),
(4196, 175, 19, 0),
(4197, 175, 20, 0),
(4198, 175, 21, 0),
(4199, 175, 22, 0),
(4200, 175, 23, 0),
(4201, 176, 0, 0),
(4202, 176, 1, 0),
(4203, 176, 2, 0),
(4204, 176, 3, 0),
(4205, 176, 4, 0),
(4206, 176, 5, 0),
(4207, 176, 6, 0),
(4208, 176, 7, 0),
(4209, 176, 8, 0),
(4210, 176, 9, 0),
(4211, 176, 10, 0),
(4212, 176, 11, 0),
(4213, 176, 12, 0),
(4214, 176, 13, 0),
(4215, 176, 14, 0),
(4216, 176, 15, 0),
(4217, 176, 16, 0),
(4218, 176, 17, 0),
(4219, 176, 18, 0),
(4220, 176, 19, 0),
(4221, 176, 20, 0),
(4222, 176, 21, 0),
(4223, 176, 22, 0),
(4224, 176, 23, 0),
(4225, 177, 0, 0),
(4226, 177, 1, 0),
(4227, 177, 2, 0),
(4228, 177, 3, 0),
(4229, 177, 4, 0),
(4230, 177, 5, 0),
(4231, 177, 6, 0),
(4232, 177, 7, 0),
(4233, 177, 8, 0),
(4234, 177, 9, 0),
(4235, 177, 10, 0),
(4236, 177, 11, 0),
(4237, 177, 12, 0),
(4238, 177, 13, 0),
(4239, 177, 14, 0),
(4240, 177, 15, 0),
(4241, 177, 16, 0),
(4242, 177, 17, 0),
(4243, 177, 18, 0),
(4244, 177, 19, 0),
(4245, 177, 20, 0),
(4246, 177, 21, 0),
(4247, 177, 22, 0),
(4248, 177, 23, 0),
(4249, 178, 0, 0),
(4250, 178, 1, 0),
(4251, 178, 2, 0),
(4252, 178, 3, 0),
(4253, 178, 4, 0),
(4254, 178, 5, 0),
(4255, 178, 6, 0),
(4256, 178, 7, 0),
(4257, 178, 8, 0),
(4258, 178, 9, 0),
(4259, 178, 10, 0),
(4260, 178, 11, 0),
(4261, 178, 12, 0),
(4262, 178, 13, 0),
(4263, 178, 14, 0),
(4264, 178, 15, 0),
(4265, 178, 16, 0),
(4266, 178, 17, 0),
(4267, 178, 18, 0),
(4268, 178, 19, 0),
(4269, 178, 20, 0),
(4270, 178, 21, 0),
(4271, 178, 22, 0),
(4272, 178, 23, 0),
(4273, 179, 0, 0),
(4274, 179, 1, 0),
(4275, 179, 2, 0),
(4276, 179, 3, 0),
(4277, 179, 4, 0),
(4278, 179, 5, 0),
(4279, 179, 6, 0),
(4280, 179, 7, 0),
(4281, 179, 8, 0),
(4282, 179, 9, 0),
(4283, 179, 10, 0),
(4284, 179, 11, 0),
(4285, 179, 12, 0),
(4286, 179, 13, 0),
(4287, 179, 14, 0),
(4288, 179, 15, 0),
(4289, 179, 16, 0),
(4290, 179, 17, 0),
(4291, 179, 18, 0),
(4292, 179, 19, 0),
(4293, 179, 20, 0),
(4294, 179, 21, 0),
(4295, 179, 22, 0),
(4296, 179, 23, 0),
(4297, 180, 0, 0),
(4298, 180, 1, 0),
(4299, 180, 2, 0),
(4300, 180, 3, 0),
(4301, 180, 4, 0),
(4302, 180, 5, 0),
(4303, 180, 6, 0),
(4304, 180, 7, 0),
(4305, 180, 8, 0),
(4306, 180, 9, 0),
(4307, 180, 10, 0),
(4308, 180, 11, 0),
(4309, 180, 12, 0),
(4310, 180, 13, 0),
(4311, 180, 14, 0),
(4312, 180, 15, 0),
(4313, 180, 16, 0),
(4314, 180, 17, 0),
(4315, 180, 18, 0),
(4316, 180, 19, 0),
(4317, 180, 20, 0),
(4318, 180, 21, 0),
(4319, 180, 22, 0),
(4320, 180, 23, 0),
(4321, 181, 0, 0),
(4322, 181, 1, 0),
(4323, 181, 2, 0),
(4324, 181, 3, 0),
(4325, 181, 4, 0),
(4326, 181, 5, 0),
(4327, 181, 6, 0),
(4328, 181, 7, 0),
(4329, 181, 8, 0),
(4330, 181, 9, 0),
(4331, 181, 10, 0),
(4332, 181, 11, 0),
(4333, 181, 12, 0),
(4334, 181, 13, 0),
(4335, 181, 14, 0),
(4336, 181, 15, 0),
(4337, 181, 16, 0),
(4338, 181, 17, 0),
(4339, 181, 18, 0),
(4340, 181, 19, 0),
(4341, 181, 20, 0),
(4342, 181, 21, 0),
(4343, 181, 22, 0),
(4344, 181, 23, 0),
(4345, 182, 0, 0),
(4346, 182, 1, 0),
(4347, 182, 2, 0),
(4348, 182, 3, 0),
(4349, 182, 4, 0),
(4350, 182, 5, 0),
(4351, 182, 6, 0),
(4352, 182, 7, 0),
(4353, 182, 8, 0),
(4354, 182, 9, 0),
(4355, 182, 10, 0),
(4356, 182, 11, 0),
(4357, 182, 12, 0),
(4358, 182, 13, 0),
(4359, 182, 14, 0),
(4360, 182, 15, 0),
(4361, 182, 16, 0),
(4362, 182, 17, 0),
(4363, 182, 18, 0),
(4364, 182, 19, 0),
(4365, 182, 20, 0),
(4366, 182, 21, 0),
(4367, 182, 22, 0),
(4368, 182, 23, 0),
(4369, 183, 0, 0),
(4370, 183, 1, 0),
(4371, 183, 2, 0),
(4372, 183, 3, 0),
(4373, 183, 4, 0),
(4374, 183, 5, 0),
(4375, 183, 6, 0),
(4376, 183, 7, 0),
(4377, 183, 8, 0),
(4378, 183, 9, 0),
(4379, 183, 10, 0),
(4380, 183, 11, 0),
(4381, 183, 12, 0),
(4382, 183, 13, 0),
(4383, 183, 14, 0),
(4384, 183, 15, 0),
(4385, 183, 16, 0),
(4386, 183, 17, 0),
(4387, 183, 18, 0),
(4388, 183, 19, 0),
(4389, 183, 20, 0),
(4390, 183, 21, 0),
(4391, 183, 22, 0),
(4392, 183, 23, 0),
(4393, 184, 0, 0),
(4394, 184, 1, 0),
(4395, 184, 2, 0),
(4396, 184, 3, 0),
(4397, 184, 4, 0),
(4398, 184, 5, 0),
(4399, 184, 6, 0),
(4400, 184, 7, 0),
(4401, 184, 8, 0),
(4402, 184, 9, 0),
(4403, 184, 10, 0),
(4404, 184, 11, 0),
(4405, 184, 12, 0),
(4406, 184, 13, 0),
(4407, 184, 14, 0),
(4408, 184, 15, 0),
(4409, 184, 16, 0),
(4410, 184, 17, 0),
(4411, 184, 18, 0),
(4412, 184, 19, 0),
(4413, 184, 20, 0),
(4414, 184, 21, 0),
(4415, 184, 22, 0),
(4416, 184, 23, 0),
(4417, 185, 0, 0),
(4418, 185, 1, 0),
(4419, 185, 2, 0),
(4420, 185, 3, 0),
(4421, 185, 4, 0),
(4422, 185, 5, 0),
(4423, 185, 6, 0),
(4424, 185, 7, 0),
(4425, 185, 8, 0),
(4426, 185, 9, 0),
(4427, 185, 10, 0),
(4428, 185, 11, 0),
(4429, 185, 12, 0),
(4430, 185, 13, 0),
(4431, 185, 14, 0),
(4432, 185, 15, 0),
(4433, 185, 16, 0),
(4434, 185, 17, 0),
(4435, 185, 18, 0),
(4436, 185, 19, 0),
(4437, 185, 20, 0),
(4438, 185, 21, 0),
(4439, 185, 22, 0),
(4440, 185, 23, 0),
(4441, 186, 0, 0),
(4442, 186, 1, 0),
(4443, 186, 2, 0),
(4444, 186, 3, 0),
(4445, 186, 4, 0),
(4446, 186, 5, 0),
(4447, 186, 6, 0),
(4448, 186, 7, 0),
(4449, 186, 8, 0),
(4450, 186, 9, 0),
(4451, 186, 10, 0),
(4452, 186, 11, 0),
(4453, 186, 12, 0),
(4454, 186, 13, 0),
(4455, 186, 14, 0),
(4456, 186, 15, 0),
(4457, 186, 16, 0),
(4458, 186, 17, 0),
(4459, 186, 18, 0),
(4460, 186, 19, 0),
(4461, 186, 20, 0),
(4462, 186, 21, 0),
(4463, 186, 22, 0),
(4464, 186, 23, 0),
(4465, 187, 0, 0),
(4466, 187, 1, 0),
(4467, 187, 2, 0),
(4468, 187, 3, 0),
(4469, 187, 4, 0),
(4470, 187, 5, 0),
(4471, 187, 6, 0),
(4472, 187, 7, 0),
(4473, 187, 8, 0),
(4474, 187, 9, 0),
(4475, 187, 10, 0),
(4476, 187, 11, 0),
(4477, 187, 12, 0),
(4478, 187, 13, 0),
(4479, 187, 14, 0),
(4480, 187, 15, 0),
(4481, 187, 16, 0),
(4482, 187, 17, 0),
(4483, 187, 18, 0),
(4484, 187, 19, 0),
(4485, 187, 20, 0),
(4486, 187, 21, 0),
(4487, 187, 22, 0),
(4488, 187, 23, 0),
(4489, 188, 0, 0),
(4490, 188, 1, 0),
(4491, 188, 2, 0),
(4492, 188, 3, 0),
(4493, 188, 4, 0),
(4494, 188, 5, 0),
(4495, 188, 6, 0),
(4496, 188, 7, 0),
(4497, 188, 8, 0),
(4498, 188, 9, 0),
(4499, 188, 10, 0),
(4500, 188, 11, 0),
(4501, 188, 12, 0),
(4502, 188, 13, 0),
(4503, 188, 14, 0),
(4504, 188, 15, 0),
(4505, 188, 16, 0),
(4506, 188, 17, 0),
(4507, 188, 18, 0),
(4508, 188, 19, 0),
(4509, 188, 20, 0),
(4510, 188, 21, 0),
(4511, 188, 22, 0),
(4512, 188, 23, 0),
(4513, 189, 0, 0),
(4514, 189, 1, 0),
(4515, 189, 2, 0),
(4516, 189, 3, 0),
(4517, 189, 4, 0),
(4518, 189, 5, 0),
(4519, 189, 6, 0),
(4520, 189, 7, 0),
(4521, 189, 8, 0),
(4522, 189, 9, 0),
(4523, 189, 10, 0),
(4524, 189, 11, 0),
(4525, 189, 12, 0),
(4526, 189, 13, 0),
(4527, 189, 14, 0),
(4528, 189, 15, 0),
(4529, 189, 16, 0),
(4530, 189, 17, 0),
(4531, 189, 18, 0),
(4532, 189, 19, 0),
(4533, 189, 20, 0),
(4534, 189, 21, 0),
(4535, 189, 22, 0),
(4536, 189, 23, 0),
(4537, 190, 0, 0),
(4538, 190, 1, 0),
(4539, 190, 2, 0),
(4540, 190, 3, 0),
(4541, 190, 4, 0),
(4542, 190, 5, 0),
(4543, 190, 6, 0),
(4544, 190, 7, 0),
(4545, 190, 8, 0),
(4546, 190, 9, 0),
(4547, 190, 10, 0),
(4548, 190, 11, 0),
(4549, 190, 12, 0),
(4550, 190, 13, 0),
(4551, 190, 14, 0),
(4552, 190, 15, 0),
(4553, 190, 16, 0),
(4554, 190, 17, 0),
(4555, 190, 18, 0),
(4556, 190, 19, 0),
(4557, 190, 20, 0),
(4558, 190, 21, 0),
(4559, 190, 22, 0),
(4560, 190, 23, 0),
(4561, 191, 0, 0),
(4562, 191, 1, 0),
(4563, 191, 2, 0),
(4564, 191, 3, 0),
(4565, 191, 4, 0),
(4566, 191, 5, 0),
(4567, 191, 6, 0),
(4568, 191, 7, 0),
(4569, 191, 8, 0),
(4570, 191, 9, 0),
(4571, 191, 10, 0),
(4572, 191, 11, 0),
(4573, 191, 12, 0),
(4574, 191, 13, 0),
(4575, 191, 14, 0),
(4576, 191, 15, 0),
(4577, 191, 16, 0),
(4578, 191, 17, 0),
(4579, 191, 18, 0),
(4580, 191, 19, 0),
(4581, 191, 20, 0),
(4582, 191, 21, 0),
(4583, 191, 22, 0),
(4584, 191, 23, 0),
(4585, 192, 0, 0),
(4586, 192, 1, 0),
(4587, 192, 2, 0),
(4588, 192, 3, 0),
(4589, 192, 4, 0),
(4590, 192, 5, 0),
(4591, 192, 6, 0),
(4592, 192, 7, 0),
(4593, 192, 8, 0),
(4594, 192, 9, 0),
(4595, 192, 10, 0),
(4596, 192, 11, 0),
(4597, 192, 12, 0),
(4598, 192, 13, 0),
(4599, 192, 14, 0),
(4600, 192, 15, 0),
(4601, 192, 16, 0),
(4602, 192, 17, 0),
(4603, 192, 18, 0),
(4604, 192, 19, 0),
(4605, 192, 20, 0),
(4606, 192, 21, 0),
(4607, 192, 22, 0),
(4608, 192, 23, 0),
(4609, 193, 0, 0),
(4610, 193, 1, 0),
(4611, 193, 2, 0),
(4612, 193, 3, 0),
(4613, 193, 4, 0),
(4614, 193, 5, 0),
(4615, 193, 6, 0),
(4616, 193, 7, 0),
(4617, 193, 8, 0),
(4618, 193, 9, 0),
(4619, 193, 10, 0),
(4620, 193, 11, 0),
(4621, 193, 12, 0),
(4622, 193, 13, 0),
(4623, 193, 14, 0),
(4624, 193, 15, 0),
(4625, 193, 16, 0),
(4626, 193, 17, 0),
(4627, 193, 18, 0),
(4628, 193, 19, 0),
(4629, 193, 20, 0),
(4630, 193, 21, 0),
(4631, 193, 22, 0),
(4632, 193, 23, 0),
(4633, 194, 0, 0),
(4634, 194, 1, 0),
(4635, 194, 2, 0),
(4636, 194, 3, 0),
(4637, 194, 4, 0),
(4638, 194, 5, 0),
(4639, 194, 6, 0),
(4640, 194, 7, 0),
(4641, 194, 8, 0),
(4642, 194, 9, 0),
(4643, 194, 10, 0),
(4644, 194, 11, 0),
(4645, 194, 12, 0),
(4646, 194, 13, 0),
(4647, 194, 14, 0),
(4648, 194, 15, 0),
(4649, 194, 16, 0),
(4650, 194, 17, 0),
(4651, 194, 18, 0),
(4652, 194, 19, 0),
(4653, 194, 20, 0),
(4654, 194, 21, 0),
(4655, 194, 22, 0),
(4656, 194, 23, 0),
(4657, 195, 0, 0),
(4658, 195, 1, 0),
(4659, 195, 2, 0),
(4660, 195, 3, 0),
(4661, 195, 4, 0),
(4662, 195, 5, 0),
(4663, 195, 6, 0),
(4664, 195, 7, 0),
(4665, 195, 8, 0),
(4666, 195, 9, 0),
(4667, 195, 10, 0),
(4668, 195, 11, 0),
(4669, 195, 12, 0),
(4670, 195, 13, 0),
(4671, 195, 14, 0),
(4672, 195, 15, 0),
(4673, 195, 16, 0),
(4674, 195, 17, 0),
(4675, 195, 18, 0),
(4676, 195, 19, 0),
(4677, 195, 20, 0),
(4678, 195, 21, 0),
(4679, 195, 22, 0),
(4680, 195, 23, 0),
(4681, 196, 0, 0),
(4682, 196, 1, 0),
(4683, 196, 2, 0),
(4684, 196, 3, 0),
(4685, 196, 4, 0),
(4686, 196, 5, 0),
(4687, 196, 6, 0),
(4688, 196, 7, 0),
(4689, 196, 8, 0),
(4690, 196, 9, 0),
(4691, 196, 10, 0),
(4692, 196, 11, 0),
(4693, 196, 12, 0),
(4694, 196, 13, 0),
(4695, 196, 14, 0),
(4696, 196, 15, 0),
(4697, 196, 16, 0),
(4698, 196, 17, 0),
(4699, 196, 18, 0),
(4700, 196, 19, 0),
(4701, 196, 20, 0),
(4702, 196, 21, 0),
(4703, 196, 22, 0),
(4704, 196, 23, 0),
(4705, 197, 0, 0),
(4706, 197, 1, 0),
(4707, 197, 2, 0),
(4708, 197, 3, 0),
(4709, 197, 4, 0),
(4710, 197, 5, 0),
(4711, 197, 6, 0),
(4712, 197, 7, 0),
(4713, 197, 8, 0),
(4714, 197, 9, 0),
(4715, 197, 10, 0),
(4716, 197, 11, 0),
(4717, 197, 12, 0),
(4718, 197, 13, 0),
(4719, 197, 14, 0),
(4720, 197, 15, 0),
(4721, 197, 16, 0),
(4722, 197, 17, 0),
(4723, 197, 18, 0),
(4724, 197, 19, 0),
(4725, 197, 20, 0),
(4726, 197, 21, 0),
(4727, 197, 22, 0),
(4728, 197, 23, 0),
(4729, 198, 0, 0),
(4730, 198, 1, 0),
(4731, 198, 2, 0),
(4732, 198, 3, 0),
(4733, 198, 4, 0),
(4734, 198, 5, 0),
(4735, 198, 6, 0),
(4736, 198, 7, 0),
(4737, 198, 8, 0),
(4738, 198, 9, 0),
(4739, 198, 10, 0),
(4740, 198, 11, 0),
(4741, 198, 12, 0),
(4742, 198, 13, 0),
(4743, 198, 14, 0),
(4744, 198, 15, 0),
(4745, 198, 16, 0),
(4746, 198, 17, 0),
(4747, 198, 18, 0),
(4748, 198, 19, 0),
(4749, 198, 20, 0),
(4750, 198, 21, 0),
(4751, 198, 22, 0),
(4752, 198, 23, 0),
(4753, 199, 0, 0),
(4754, 199, 1, 0),
(4755, 199, 2, 0),
(4756, 199, 3, 0),
(4757, 199, 4, 0),
(4758, 199, 5, 0),
(4759, 199, 6, 0),
(4760, 199, 7, 0),
(4761, 199, 8, 0),
(4762, 199, 9, 0),
(4763, 199, 10, 0),
(4764, 199, 11, 0),
(4765, 199, 12, 0),
(4766, 199, 13, 0),
(4767, 199, 14, 0),
(4768, 199, 15, 0),
(4769, 199, 16, 0),
(4770, 199, 17, 0),
(4771, 199, 18, 0),
(4772, 199, 19, 0),
(4773, 199, 20, 0),
(4774, 199, 21, 0),
(4775, 199, 22, 0),
(4776, 199, 23, 0),
(4777, 200, 0, 0),
(4778, 200, 1, 0),
(4779, 200, 2, 0),
(4780, 200, 3, 0),
(4781, 200, 4, 0),
(4782, 200, 5, 0),
(4783, 200, 6, 0),
(4784, 200, 7, 0),
(4785, 200, 8, 0),
(4786, 200, 9, 0),
(4787, 200, 10, 0),
(4788, 200, 11, 0),
(4789, 200, 12, 0),
(4790, 200, 13, 0),
(4791, 200, 14, 0),
(4792, 200, 15, 0),
(4793, 200, 16, 0),
(4794, 200, 17, 0),
(4795, 200, 18, 0),
(4796, 200, 19, 0),
(4797, 200, 20, 0),
(4798, 200, 21, 0),
(4799, 200, 22, 0),
(4800, 200, 23, 0),
(4801, 201, 0, 0),
(4802, 201, 1, 0),
(4803, 201, 2, 0),
(4804, 201, 3, 0),
(4805, 201, 4, 0),
(4806, 201, 5, 0),
(4807, 201, 6, 0),
(4808, 201, 7, 0),
(4809, 201, 8, 0),
(4810, 201, 9, 0),
(4811, 201, 10, 0),
(4812, 201, 11, 0),
(4813, 201, 12, 0),
(4814, 201, 13, 0),
(4815, 201, 14, 0),
(4816, 201, 15, 0),
(4817, 201, 16, 0),
(4818, 201, 17, 0),
(4819, 201, 18, 0),
(4820, 201, 19, 0),
(4821, 201, 20, 0),
(4822, 201, 21, 0),
(4823, 201, 22, 0),
(4824, 201, 23, 0),
(4825, 202, 0, 0),
(4826, 202, 1, 0),
(4827, 202, 2, 0),
(4828, 202, 3, 0),
(4829, 202, 4, 0),
(4830, 202, 5, 0),
(4831, 202, 6, 0),
(4832, 202, 7, 0),
(4833, 202, 8, 0),
(4834, 202, 9, 0),
(4835, 202, 10, 0),
(4836, 202, 11, 0),
(4837, 202, 12, 0),
(4838, 202, 13, 0),
(4839, 202, 14, 0),
(4840, 202, 15, 0),
(4841, 202, 16, 0),
(4842, 202, 17, 0),
(4843, 202, 18, 0),
(4844, 202, 19, 0),
(4845, 202, 20, 0),
(4846, 202, 21, 0),
(4847, 202, 22, 0),
(4848, 202, 23, 0),
(4849, 203, 0, 0),
(4850, 203, 1, 0),
(4851, 203, 2, 0),
(4852, 203, 3, 0),
(4853, 203, 4, 0),
(4854, 203, 5, 0),
(4855, 203, 6, 0),
(4856, 203, 7, 0),
(4857, 203, 8, 0),
(4858, 203, 9, 0),
(4859, 203, 10, 0),
(4860, 203, 11, 0),
(4861, 203, 12, 0),
(4862, 203, 13, 0),
(4863, 203, 14, 0),
(4864, 203, 15, 0),
(4865, 203, 16, 0),
(4866, 203, 17, 0),
(4867, 203, 18, 0),
(4868, 203, 19, 0),
(4869, 203, 20, 0),
(4870, 203, 21, 0),
(4871, 203, 22, 0),
(4872, 203, 23, 0),
(4873, 204, 0, 0),
(4874, 204, 1, 0),
(4875, 204, 2, 0),
(4876, 204, 3, 0),
(4877, 204, 4, 0),
(4878, 204, 5, 0),
(4879, 204, 6, 0),
(4880, 204, 7, 0),
(4881, 204, 8, 0),
(4882, 204, 9, 0),
(4883, 204, 10, 0),
(4884, 204, 11, 0),
(4885, 204, 12, 0),
(4886, 204, 13, 0),
(4887, 204, 14, 0),
(4888, 204, 15, 0),
(4889, 204, 16, 0),
(4890, 204, 17, 0),
(4891, 204, 18, 0),
(4892, 204, 19, 0),
(4893, 204, 20, 0),
(4894, 204, 21, 0),
(4895, 204, 22, 0),
(4896, 204, 23, 0),
(4897, 205, 0, 0),
(4898, 205, 1, 0),
(4899, 205, 2, 0),
(4900, 205, 3, 0),
(4901, 205, 4, 0),
(4902, 205, 5, 0),
(4903, 205, 6, 0),
(4904, 205, 7, 0),
(4905, 205, 8, 0),
(4906, 205, 9, 0),
(4907, 205, 10, 0),
(4908, 205, 11, 0),
(4909, 205, 12, 0),
(4910, 205, 13, 0),
(4911, 205, 14, 0),
(4912, 205, 15, 0),
(4913, 205, 16, 0),
(4914, 205, 17, 0),
(4915, 205, 18, 0),
(4916, 205, 19, 0),
(4917, 205, 20, 0),
(4918, 205, 21, 0),
(4919, 205, 22, 0),
(4920, 205, 23, 0),
(4921, 206, 0, 0),
(4922, 206, 1, 0),
(4923, 206, 2, 0),
(4924, 206, 3, 0),
(4925, 206, 4, 0),
(4926, 206, 5, 0),
(4927, 206, 6, 0),
(4928, 206, 7, 0),
(4929, 206, 8, 0),
(4930, 206, 9, 0),
(4931, 206, 10, 0),
(4932, 206, 11, 0),
(4933, 206, 12, 0),
(4934, 206, 13, 0),
(4935, 206, 14, 0),
(4936, 206, 15, 0),
(4937, 206, 16, 0),
(4938, 206, 17, 0),
(4939, 206, 18, 0),
(4940, 206, 19, 0),
(4941, 206, 20, 0),
(4942, 206, 21, 0),
(4943, 206, 22, 0),
(4944, 206, 23, 0),
(4945, 207, 0, 0),
(4946, 207, 1, 0),
(4947, 207, 2, 0),
(4948, 207, 3, 0),
(4949, 207, 4, 0),
(4950, 207, 5, 0),
(4951, 207, 6, 0),
(4952, 207, 7, 0),
(4953, 207, 8, 0),
(4954, 207, 9, 0),
(4955, 207, 10, 0),
(4956, 207, 11, 0),
(4957, 207, 12, 0),
(4958, 207, 13, 0),
(4959, 207, 14, 0),
(4960, 207, 15, 0),
(4961, 207, 16, 0),
(4962, 207, 17, 0),
(4963, 207, 18, 0),
(4964, 207, 19, 0),
(4965, 207, 20, 0),
(4966, 207, 21, 0),
(4967, 207, 22, 0),
(4968, 207, 23, 0),
(4969, 208, 0, 0),
(4970, 208, 1, 0),
(4971, 208, 2, 0),
(4972, 208, 3, 0),
(4973, 208, 4, 0),
(4974, 208, 5, 0),
(4975, 208, 6, 0),
(4976, 208, 7, 0),
(4977, 208, 8, 0),
(4978, 208, 9, 0),
(4979, 208, 10, 0),
(4980, 208, 11, 0),
(4981, 208, 12, 0),
(4982, 208, 13, 0),
(4983, 208, 14, 0),
(4984, 208, 15, 0),
(4985, 208, 16, 0),
(4986, 208, 17, 0),
(4987, 208, 18, 0),
(4988, 208, 19, 0),
(4989, 208, 20, 0),
(4990, 208, 21, 0),
(4991, 208, 22, 0),
(4992, 208, 23, 0),
(4993, 209, 0, 0),
(4994, 209, 1, 0),
(4995, 209, 2, 0),
(4996, 209, 3, 0),
(4997, 209, 4, 0),
(4998, 209, 5, 0),
(4999, 209, 6, 0),
(5000, 209, 7, 0),
(5001, 209, 8, 0),
(5002, 209, 9, 0),
(5003, 209, 10, 0),
(5004, 209, 11, 0),
(5005, 209, 12, 0),
(5006, 209, 13, 0),
(5007, 209, 14, 0),
(5008, 209, 15, 0),
(5009, 209, 16, 0),
(5010, 209, 17, 0),
(5011, 209, 18, 0),
(5012, 209, 19, 0),
(5013, 209, 20, 0),
(5014, 209, 21, 0),
(5015, 209, 22, 0),
(5016, 209, 23, 0),
(5017, 210, 0, 0),
(5018, 210, 1, 0),
(5019, 210, 2, 0),
(5020, 210, 3, 0),
(5021, 210, 4, 0),
(5022, 210, 5, 0),
(5023, 210, 6, 0),
(5024, 210, 7, 0),
(5025, 210, 8, 0),
(5026, 210, 9, 0),
(5027, 210, 10, 0),
(5028, 210, 11, 0),
(5029, 210, 12, 0),
(5030, 210, 13, 0),
(5031, 210, 14, 0),
(5032, 210, 15, 0),
(5033, 210, 16, 0),
(5034, 210, 17, 0),
(5035, 210, 18, 0),
(5036, 210, 19, 0),
(5037, 210, 20, 0),
(5038, 210, 21, 0),
(5039, 210, 22, 0),
(5040, 210, 23, 0),
(5041, 211, 0, 0),
(5042, 211, 1, 0),
(5043, 211, 2, 0),
(5044, 211, 3, 0),
(5045, 211, 4, 0),
(5046, 211, 5, 0),
(5047, 211, 6, 0),
(5048, 211, 7, 0),
(5049, 211, 8, 0),
(5050, 211, 9, 0),
(5051, 211, 10, 0),
(5052, 211, 11, 0),
(5053, 211, 12, 0),
(5054, 211, 13, 0),
(5055, 211, 14, 0),
(5056, 211, 15, 0),
(5057, 211, 16, 0),
(5058, 211, 17, 0),
(5059, 211, 18, 0),
(5060, 211, 19, 0),
(5061, 211, 20, 0),
(5062, 211, 21, 0),
(5063, 211, 22, 0),
(5064, 211, 23, 0),
(5065, 212, 0, 0),
(5066, 212, 1, 0),
(5067, 212, 2, 0),
(5068, 212, 3, 0),
(5069, 212, 4, 0),
(5070, 212, 5, 0),
(5071, 212, 6, 0),
(5072, 212, 7, 0),
(5073, 212, 8, 0),
(5074, 212, 9, 0),
(5075, 212, 10, 0),
(5076, 212, 11, 0),
(5077, 212, 12, 0),
(5078, 212, 13, 0),
(5079, 212, 14, 0),
(5080, 212, 15, 0),
(5081, 212, 16, 0),
(5082, 212, 17, 0),
(5083, 212, 18, 0),
(5084, 212, 19, 0),
(5085, 212, 20, 0),
(5086, 212, 21, 0),
(5087, 212, 22, 0),
(5088, 212, 23, 0),
(5089, 213, 0, 0),
(5090, 213, 1, 0),
(5091, 213, 2, 0),
(5092, 213, 3, 0),
(5093, 213, 4, 0),
(5094, 213, 5, 0),
(5095, 213, 6, 0),
(5096, 213, 7, 0),
(5097, 213, 8, 0),
(5098, 213, 9, 0),
(5099, 213, 10, 0),
(5100, 213, 11, 0),
(5101, 213, 12, 0),
(5102, 213, 13, 0),
(5103, 213, 14, 0),
(5104, 213, 15, 0),
(5105, 213, 16, 0),
(5106, 213, 17, 0),
(5107, 213, 18, 0),
(5108, 213, 19, 0),
(5109, 213, 20, 0),
(5110, 213, 21, 0),
(5111, 213, 22, 0),
(5112, 213, 23, 0),
(5113, 214, 0, 0),
(5114, 214, 1, 0),
(5115, 214, 2, 0),
(5116, 214, 3, 0),
(5117, 214, 4, 0),
(5118, 214, 5, 0),
(5119, 214, 6, 0),
(5120, 214, 7, 0),
(5121, 214, 8, 0),
(5122, 214, 9, 0),
(5123, 214, 10, 0),
(5124, 214, 11, 0),
(5125, 214, 12, 0),
(5126, 214, 13, 0),
(5127, 214, 14, 0),
(5128, 214, 15, 0),
(5129, 214, 16, 0),
(5130, 214, 17, 0),
(5131, 214, 18, 0),
(5132, 214, 19, 0),
(5133, 214, 20, 0),
(5134, 214, 21, 0),
(5135, 214, 22, 0),
(5136, 214, 23, 0),
(5137, 215, 0, 0),
(5138, 215, 1, 0),
(5139, 215, 2, 0),
(5140, 215, 3, 0),
(5141, 215, 4, 0),
(5142, 215, 5, 0),
(5143, 215, 6, 0),
(5144, 215, 7, 0),
(5145, 215, 8, 0),
(5146, 215, 9, 0),
(5147, 215, 10, 0),
(5148, 215, 11, 0),
(5149, 215, 12, 0),
(5150, 215, 13, 0),
(5151, 215, 14, 0),
(5152, 215, 15, 0),
(5153, 215, 16, 0),
(5154, 215, 17, 0),
(5155, 215, 18, 0),
(5156, 215, 19, 0),
(5157, 215, 20, 0),
(5158, 215, 21, 0),
(5159, 215, 22, 0),
(5160, 215, 23, 0),
(5161, 216, 0, 0),
(5162, 216, 1, 0),
(5163, 216, 2, 0),
(5164, 216, 3, 0),
(5165, 216, 4, 0),
(5166, 216, 5, 0),
(5167, 216, 6, 0),
(5168, 216, 7, 0),
(5169, 216, 8, 0),
(5170, 216, 9, 0),
(5171, 216, 10, 0),
(5172, 216, 11, 0),
(5173, 216, 12, 0),
(5174, 216, 13, 0),
(5175, 216, 14, 0),
(5176, 216, 15, 0),
(5177, 216, 16, 0),
(5178, 216, 17, 0),
(5179, 216, 18, 0),
(5180, 216, 19, 0),
(5181, 216, 20, 0),
(5182, 216, 21, 0),
(5183, 216, 22, 0),
(5184, 216, 23, 0),
(5185, 217, 0, 0),
(5186, 217, 1, 0),
(5187, 217, 2, 0),
(5188, 217, 3, 0),
(5189, 217, 4, 0),
(5190, 217, 5, 0),
(5191, 217, 6, 0),
(5192, 217, 7, 0),
(5193, 217, 8, 0),
(5194, 217, 9, 0),
(5195, 217, 10, 0),
(5196, 217, 11, 0),
(5197, 217, 12, 0),
(5198, 217, 13, 0),
(5199, 217, 14, 0),
(5200, 217, 15, 0),
(5201, 217, 16, 0),
(5202, 217, 17, 0),
(5203, 217, 18, 0),
(5204, 217, 19, 0),
(5205, 217, 20, 0),
(5206, 217, 21, 0),
(5207, 217, 22, 0),
(5208, 217, 23, 0),
(5209, 218, 0, 0),
(5210, 218, 1, 0),
(5211, 218, 2, 0),
(5212, 218, 3, 0),
(5213, 218, 4, 0),
(5214, 218, 5, 0),
(5215, 218, 6, 0),
(5216, 218, 7, 0),
(5217, 218, 8, 0),
(5218, 218, 9, 0),
(5219, 218, 10, 0),
(5220, 218, 11, 0),
(5221, 218, 12, 0),
(5222, 218, 13, 0),
(5223, 218, 14, 0),
(5224, 218, 15, 0),
(5225, 218, 16, 0),
(5226, 218, 17, 0),
(5227, 218, 18, 0),
(5228, 218, 19, 0),
(5229, 218, 20, 0),
(5230, 218, 21, 0),
(5231, 218, 22, 0),
(5232, 218, 23, 0),
(5233, 219, 0, 0),
(5234, 219, 1, 0),
(5235, 219, 2, 0),
(5236, 219, 3, 0),
(5237, 219, 4, 0),
(5238, 219, 5, 0),
(5239, 219, 6, 0),
(5240, 219, 7, 0),
(5241, 219, 8, 0),
(5242, 219, 9, 0),
(5243, 219, 10, 0),
(5244, 219, 11, 0),
(5245, 219, 12, 0),
(5246, 219, 13, 0),
(5247, 219, 14, 0),
(5248, 219, 15, 0),
(5249, 219, 16, 0),
(5250, 219, 17, 0),
(5251, 219, 18, 0),
(5252, 219, 19, 0),
(5253, 219, 20, 0),
(5254, 219, 21, 0),
(5255, 219, 22, 0),
(5256, 219, 23, 0),
(5257, 220, 0, 0),
(5258, 220, 1, 0),
(5259, 220, 2, 0),
(5260, 220, 3, 0),
(5261, 220, 4, 0),
(5262, 220, 5, 0),
(5263, 220, 6, 0),
(5264, 220, 7, 0),
(5265, 220, 8, 0),
(5266, 220, 9, 0),
(5267, 220, 10, 0),
(5268, 220, 11, 0),
(5269, 220, 12, 0),
(5270, 220, 13, 0),
(5271, 220, 14, 0),
(5272, 220, 15, 0),
(5273, 220, 16, 0),
(5274, 220, 17, 0),
(5275, 220, 18, 0),
(5276, 220, 19, 0),
(5277, 220, 20, 0),
(5278, 220, 21, 0),
(5279, 220, 22, 0),
(5280, 220, 23, 0),
(5281, 221, 0, 0),
(5282, 221, 1, 0),
(5283, 221, 2, 0),
(5284, 221, 3, 0),
(5285, 221, 4, 0),
(5286, 221, 5, 0),
(5287, 221, 6, 0),
(5288, 221, 7, 0),
(5289, 221, 8, 0),
(5290, 221, 9, 0),
(5291, 221, 10, 0),
(5292, 221, 11, 0),
(5293, 221, 12, 0),
(5294, 221, 13, 0),
(5295, 221, 14, 0),
(5296, 221, 15, 0),
(5297, 221, 16, 0),
(5298, 221, 17, 0),
(5299, 221, 18, 0),
(5300, 221, 19, 0),
(5301, 221, 20, 0),
(5302, 221, 21, 0),
(5303, 221, 22, 0),
(5304, 221, 23, 0),
(5305, 222, 0, 0),
(5306, 222, 1, 0),
(5307, 222, 2, 0),
(5308, 222, 3, 0),
(5309, 222, 4, 0),
(5310, 222, 5, 0),
(5311, 222, 6, 0),
(5312, 222, 7, 0),
(5313, 222, 8, 0),
(5314, 222, 9, 0),
(5315, 222, 10, 0),
(5316, 222, 11, 0),
(5317, 222, 12, 0),
(5318, 222, 13, 0),
(5319, 222, 14, 0),
(5320, 222, 15, 0),
(5321, 222, 16, 0),
(5322, 222, 17, 0),
(5323, 222, 18, 0),
(5324, 222, 19, 0),
(5325, 222, 20, 0),
(5326, 222, 21, 0),
(5327, 222, 22, 0),
(5328, 222, 23, 0),
(5329, 223, 0, 0),
(5330, 223, 1, 0),
(5331, 223, 2, 0),
(5332, 223, 3, 0),
(5333, 223, 4, 0),
(5334, 223, 5, 0),
(5335, 223, 6, 0),
(5336, 223, 7, 0),
(5337, 223, 8, 0),
(5338, 223, 9, 0),
(5339, 223, 10, 0),
(5340, 223, 11, 0),
(5341, 223, 12, 0),
(5342, 223, 13, 0),
(5343, 223, 14, 0),
(5344, 223, 15, 0),
(5345, 223, 16, 0),
(5346, 223, 17, 0),
(5347, 223, 18, 0),
(5348, 223, 19, 0),
(5349, 223, 20, 0),
(5350, 223, 21, 0),
(5351, 223, 22, 0),
(5352, 223, 23, 0),
(5353, 224, 0, 0),
(5354, 224, 1, 0),
(5355, 224, 2, 0),
(5356, 224, 3, 0),
(5357, 224, 4, 0),
(5358, 224, 5, 0),
(5359, 224, 6, 0),
(5360, 224, 7, 0),
(5361, 224, 8, 0),
(5362, 224, 9, 0),
(5363, 224, 10, 0),
(5364, 224, 11, 0),
(5365, 224, 12, 0),
(5366, 224, 13, 0),
(5367, 224, 14, 0),
(5368, 224, 15, 0),
(5369, 224, 16, 0),
(5370, 224, 17, 0),
(5371, 224, 18, 0),
(5372, 224, 19, 0),
(5373, 224, 20, 0),
(5374, 224, 21, 0),
(5375, 224, 22, 0),
(5376, 224, 23, 0),
(5377, 225, 0, 0),
(5378, 225, 1, 0),
(5379, 225, 2, 0),
(5380, 225, 3, 0),
(5381, 225, 4, 0),
(5382, 225, 5, 0),
(5383, 225, 6, 0),
(5384, 225, 7, 0),
(5385, 225, 8, 0),
(5386, 225, 9, 0),
(5387, 225, 10, 0),
(5388, 225, 11, 0),
(5389, 225, 12, 0),
(5390, 225, 13, 0),
(5391, 225, 14, 0),
(5392, 225, 15, 0),
(5393, 225, 16, 0),
(5394, 225, 17, 0),
(5395, 225, 18, 0),
(5396, 225, 19, 0),
(5397, 225, 20, 0),
(5398, 225, 21, 0),
(5399, 225, 22, 0),
(5400, 225, 23, 0),
(5401, 226, 0, 0),
(5402, 226, 1, 0),
(5403, 226, 2, 0),
(5404, 226, 3, 0),
(5405, 226, 4, 0),
(5406, 226, 5, 0),
(5407, 226, 6, 0),
(5408, 226, 7, 0),
(5409, 226, 8, 0),
(5410, 226, 9, 0),
(5411, 226, 10, 0),
(5412, 226, 11, 0),
(5413, 226, 12, 0),
(5414, 226, 13, 0),
(5415, 226, 14, 0),
(5416, 226, 15, 0),
(5417, 226, 16, 0),
(5418, 226, 17, 0),
(5419, 226, 18, 0),
(5420, 226, 19, 0),
(5421, 226, 20, 0),
(5422, 226, 21, 0),
(5423, 226, 22, 0),
(5424, 226, 23, 0),
(5425, 227, 0, 0),
(5426, 227, 1, 0),
(5427, 227, 2, 0),
(5428, 227, 3, 0),
(5429, 227, 4, 0),
(5430, 227, 5, 0),
(5431, 227, 6, 0),
(5432, 227, 7, 0),
(5433, 227, 8, 0),
(5434, 227, 9, 0),
(5435, 227, 10, 0),
(5436, 227, 11, 0),
(5437, 227, 12, 0),
(5438, 227, 13, 0),
(5439, 227, 14, 0),
(5440, 227, 15, 0),
(5441, 227, 16, 0),
(5442, 227, 17, 0),
(5443, 227, 18, 0),
(5444, 227, 19, 0),
(5445, 227, 20, 0),
(5446, 227, 21, 0),
(5447, 227, 22, 0),
(5448, 227, 23, 0),
(5449, 228, 0, 0),
(5450, 228, 1, 0),
(5451, 228, 2, 0),
(5452, 228, 3, 0),
(5453, 228, 4, 0),
(5454, 228, 5, 0),
(5455, 228, 6, 0),
(5456, 228, 7, 0),
(5457, 228, 8, 0),
(5458, 228, 9, 0),
(5459, 228, 10, 0),
(5460, 228, 11, 0),
(5461, 228, 12, 0),
(5462, 228, 13, 0),
(5463, 228, 14, 0),
(5464, 228, 15, 0),
(5465, 228, 16, 0),
(5466, 228, 17, 0),
(5467, 228, 18, 0),
(5468, 228, 19, 0),
(5469, 228, 20, 0),
(5470, 228, 21, 0),
(5471, 228, 22, 0),
(5472, 228, 23, 0),
(5473, 229, 0, 0),
(5474, 229, 1, 0),
(5475, 229, 2, 0),
(5476, 229, 3, 0),
(5477, 229, 4, 0),
(5478, 229, 5, 0),
(5479, 229, 6, 0),
(5480, 229, 7, 0),
(5481, 229, 8, 0),
(5482, 229, 9, 0),
(5483, 229, 10, 0),
(5484, 229, 11, 0),
(5485, 229, 12, 0),
(5486, 229, 13, 0),
(5487, 229, 14, 0),
(5488, 229, 15, 0),
(5489, 229, 16, 0),
(5490, 229, 17, 0),
(5491, 229, 18, 0),
(5492, 229, 19, 0),
(5493, 229, 20, 0),
(5494, 229, 21, 0),
(5495, 229, 22, 0),
(5496, 229, 23, 0),
(5497, 230, 0, 0),
(5498, 230, 1, 0),
(5499, 230, 2, 0),
(5500, 230, 3, 0),
(5501, 230, 4, 0),
(5502, 230, 5, 0),
(5503, 230, 6, 0),
(5504, 230, 7, 0),
(5505, 230, 8, 0),
(5506, 230, 9, 0),
(5507, 230, 10, 0),
(5508, 230, 11, 0),
(5509, 230, 12, 0),
(5510, 230, 13, 0),
(5511, 230, 14, 0),
(5512, 230, 15, 0),
(5513, 230, 16, 0),
(5514, 230, 17, 0),
(5515, 230, 18, 0),
(5516, 230, 19, 0),
(5517, 230, 20, 0),
(5518, 230, 21, 0),
(5519, 230, 22, 0),
(5520, 230, 23, 0),
(5521, 231, 0, 0),
(5522, 231, 1, 0),
(5523, 231, 2, 0),
(5524, 231, 3, 0),
(5525, 231, 4, 0),
(5526, 231, 5, 0),
(5527, 231, 6, 0),
(5528, 231, 7, 0),
(5529, 231, 8, 0),
(5530, 231, 9, 0),
(5531, 231, 10, 0),
(5532, 231, 11, 0),
(5533, 231, 12, 0),
(5534, 231, 13, 0),
(5535, 231, 14, 0),
(5536, 231, 15, 0),
(5537, 231, 16, 0),
(5538, 231, 17, 0),
(5539, 231, 18, 0),
(5540, 231, 19, 0),
(5541, 231, 20, 0),
(5542, 231, 21, 0),
(5543, 231, 22, 0),
(5544, 231, 23, 0),
(5545, 232, 0, 0),
(5546, 232, 1, 0),
(5547, 232, 2, 0),
(5548, 232, 3, 0),
(5549, 232, 4, 0),
(5550, 232, 5, 0),
(5551, 232, 6, 0),
(5552, 232, 7, 0),
(5553, 232, 8, 0),
(5554, 232, 9, 0),
(5555, 232, 10, 0),
(5556, 232, 11, 0),
(5557, 232, 12, 0),
(5558, 232, 13, 0),
(5559, 232, 14, 0),
(5560, 232, 15, 0),
(5561, 232, 16, 0),
(5562, 232, 17, 0),
(5563, 232, 18, 0),
(5564, 232, 19, 0),
(5565, 232, 20, 0),
(5566, 232, 21, 0),
(5567, 232, 22, 0),
(5568, 232, 23, 0),
(5569, 233, 0, 0),
(5570, 233, 1, 0),
(5571, 233, 2, 0),
(5572, 233, 3, 0),
(5573, 233, 4, 0),
(5574, 233, 5, 0),
(5575, 233, 6, 0),
(5576, 233, 7, 0),
(5577, 233, 8, 0),
(5578, 233, 9, 0),
(5579, 233, 10, 0),
(5580, 233, 11, 0),
(5581, 233, 12, 0),
(5582, 233, 13, 0),
(5583, 233, 14, 0),
(5584, 233, 15, 0),
(5585, 233, 16, 0),
(5586, 233, 17, 0),
(5587, 233, 18, 0),
(5588, 233, 19, 0),
(5589, 233, 20, 0),
(5590, 233, 21, 0),
(5591, 233, 22, 0),
(5592, 233, 23, 0),
(5593, 234, 0, 0),
(5594, 234, 1, 0),
(5595, 234, 2, 0),
(5596, 234, 3, 0),
(5597, 234, 4, 0),
(5598, 234, 5, 0),
(5599, 234, 6, 0),
(5600, 234, 7, 0),
(5601, 234, 8, 0),
(5602, 234, 9, 0),
(5603, 234, 10, 0),
(5604, 234, 11, 0),
(5605, 234, 12, 0),
(5606, 234, 13, 0),
(5607, 234, 14, 0),
(5608, 234, 15, 0),
(5609, 234, 16, 0),
(5610, 234, 17, 0),
(5611, 234, 18, 0),
(5612, 234, 19, 0),
(5613, 234, 20, 0),
(5614, 234, 21, 0),
(5615, 234, 22, 0),
(5616, 234, 23, 0),
(5617, 235, 0, 0),
(5618, 235, 1, 0),
(5619, 235, 2, 0),
(5620, 235, 3, 0),
(5621, 235, 4, 0),
(5622, 235, 5, 0),
(5623, 235, 6, 0),
(5624, 235, 7, 0),
(5625, 235, 8, 0),
(5626, 235, 9, 0),
(5627, 235, 10, 0),
(5628, 235, 11, 0),
(5629, 235, 12, 0),
(5630, 235, 13, 0),
(5631, 235, 14, 0),
(5632, 235, 15, 0),
(5633, 235, 16, 0),
(5634, 235, 17, 0),
(5635, 235, 18, 0),
(5636, 235, 19, 0),
(5637, 235, 20, 0),
(5638, 235, 21, 0),
(5639, 235, 22, 0),
(5640, 235, 23, 0),
(5641, 236, 0, 0),
(5642, 236, 1, 0),
(5643, 236, 2, 0),
(5644, 236, 3, 0),
(5645, 236, 4, 0),
(5646, 236, 5, 0),
(5647, 236, 6, 0),
(5648, 236, 7, 0),
(5649, 236, 8, 0),
(5650, 236, 9, 0),
(5651, 236, 10, 0),
(5652, 236, 11, 0),
(5653, 236, 12, 0),
(5654, 236, 13, 0),
(5655, 236, 14, 0),
(5656, 236, 15, 0),
(5657, 236, 16, 0),
(5658, 236, 17, 0),
(5659, 236, 18, 0),
(5660, 236, 19, 0),
(5661, 236, 20, 0),
(5662, 236, 21, 0),
(5663, 236, 22, 0),
(5664, 236, 23, 0),
(5665, 237, 0, 0),
(5666, 237, 1, 0),
(5667, 237, 2, 0),
(5668, 237, 3, 0),
(5669, 237, 4, 0),
(5670, 237, 5, 0),
(5671, 237, 6, 0),
(5672, 237, 7, 0),
(5673, 237, 8, 0),
(5674, 237, 9, 0),
(5675, 237, 10, 0),
(5676, 237, 11, 0),
(5677, 237, 12, 0),
(5678, 237, 13, 0),
(5679, 237, 14, 0),
(5680, 237, 15, 0),
(5681, 237, 16, 0),
(5682, 237, 17, 0),
(5683, 237, 18, 0),
(5684, 237, 19, 0),
(5685, 237, 20, 0),
(5686, 237, 21, 0),
(5687, 237, 22, 0),
(5688, 237, 23, 0),
(5689, 238, 0, 0),
(5690, 238, 1, 0),
(5691, 238, 2, 0),
(5692, 238, 3, 0),
(5693, 238, 4, 0),
(5694, 238, 5, 0),
(5695, 238, 6, 0),
(5696, 238, 7, 0),
(5697, 238, 8, 0),
(5698, 238, 9, 0),
(5699, 238, 10, 0),
(5700, 238, 11, 0),
(5701, 238, 12, 0),
(5702, 238, 13, 0),
(5703, 238, 14, 0),
(5704, 238, 15, 0),
(5705, 238, 16, 0),
(5706, 238, 17, 0),
(5707, 238, 18, 0),
(5708, 238, 19, 0),
(5709, 238, 20, 0),
(5710, 238, 21, 0),
(5711, 238, 22, 0),
(5712, 238, 23, 0),
(5713, 239, 0, 0),
(5714, 239, 1, 0),
(5715, 239, 2, 0),
(5716, 239, 3, 0),
(5717, 239, 4, 0),
(5718, 239, 5, 0),
(5719, 239, 6, 0),
(5720, 239, 7, 0),
(5721, 239, 8, 0),
(5722, 239, 9, 0),
(5723, 239, 10, 0),
(5724, 239, 11, 0),
(5725, 239, 12, 0),
(5726, 239, 13, 0),
(5727, 239, 14, 0),
(5728, 239, 15, 0),
(5729, 239, 16, 0),
(5730, 239, 17, 0),
(5731, 239, 18, 0),
(5732, 239, 19, 0),
(5733, 239, 20, 0),
(5734, 239, 21, 0),
(5735, 239, 22, 0),
(5736, 239, 23, 0),
(5737, 240, 0, 0),
(5738, 240, 1, 0),
(5739, 240, 2, 0),
(5740, 240, 3, 0),
(5741, 240, 4, 0),
(5742, 240, 5, 0),
(5743, 240, 6, 0),
(5744, 240, 7, 0),
(5745, 240, 8, 0),
(5746, 240, 9, 0),
(5747, 240, 10, 0),
(5748, 240, 11, 0),
(5749, 240, 12, 0),
(5750, 240, 13, 0),
(5751, 240, 14, 0),
(5752, 240, 15, 0),
(5753, 240, 16, 0),
(5754, 240, 17, 0),
(5755, 240, 18, 0),
(5756, 240, 19, 0),
(5757, 240, 20, 0),
(5758, 240, 21, 0),
(5759, 240, 22, 0),
(5760, 240, 23, 0),
(5761, 241, 0, 0),
(5762, 241, 1, 0),
(5763, 241, 2, 0),
(5764, 241, 3, 0),
(5765, 241, 4, 0),
(5766, 241, 5, 0),
(5767, 241, 6, 0),
(5768, 241, 7, 0),
(5769, 241, 8, 0),
(5770, 241, 9, 0),
(5771, 241, 10, 0),
(5772, 241, 11, 0),
(5773, 241, 12, 0),
(5774, 241, 13, 0),
(5775, 241, 14, 0),
(5776, 241, 15, 0),
(5777, 241, 16, 0),
(5778, 241, 17, 0),
(5779, 241, 18, 0),
(5780, 241, 19, 0),
(5781, 241, 20, 0),
(5782, 241, 21, 0),
(5783, 241, 22, 0),
(5784, 241, 23, 0),
(5785, 242, 0, 0),
(5786, 242, 1, 0),
(5787, 242, 2, 0),
(5788, 242, 3, 0),
(5789, 242, 4, 0),
(5790, 242, 5, 0),
(5791, 242, 6, 0),
(5792, 242, 7, 0),
(5793, 242, 8, 0),
(5794, 242, 9, 0),
(5795, 242, 10, 0),
(5796, 242, 11, 0),
(5797, 242, 12, 0),
(5798, 242, 13, 0),
(5799, 242, 14, 0),
(5800, 242, 15, 0),
(5801, 242, 16, 0),
(5802, 242, 17, 0),
(5803, 242, 18, 0),
(5804, 242, 19, 0),
(5805, 242, 20, 0),
(5806, 242, 21, 0),
(5807, 242, 22, 0),
(5808, 242, 23, 0),
(5809, 243, 0, 0),
(5810, 243, 1, 0),
(5811, 243, 2, 0),
(5812, 243, 3, 0),
(5813, 243, 4, 0),
(5814, 243, 5, 0),
(5815, 243, 6, 0),
(5816, 243, 7, 0),
(5817, 243, 8, 0),
(5818, 243, 9, 0),
(5819, 243, 10, 0),
(5820, 243, 11, 0),
(5821, 243, 12, 0),
(5822, 243, 13, 0),
(5823, 243, 14, 0),
(5824, 243, 15, 0),
(5825, 243, 16, 0),
(5826, 243, 17, 0),
(5827, 243, 18, 0),
(5828, 243, 19, 0),
(5829, 243, 20, 0),
(5830, 243, 21, 0),
(5831, 243, 22, 0),
(5832, 243, 23, 0),
(5833, 244, 0, 0),
(5834, 244, 1, 0),
(5835, 244, 2, 0),
(5836, 244, 3, 0),
(5837, 244, 4, 0),
(5838, 244, 5, 0),
(5839, 244, 6, 0),
(5840, 244, 7, 0),
(5841, 244, 8, 0),
(5842, 244, 9, 0),
(5843, 244, 10, 0),
(5844, 244, 11, 0),
(5845, 244, 12, 0),
(5846, 244, 13, 0),
(5847, 244, 14, 0),
(5848, 244, 15, 0),
(5849, 244, 16, 0),
(5850, 244, 17, 0),
(5851, 244, 18, 0),
(5852, 244, 19, 0),
(5853, 244, 20, 0),
(5854, 244, 21, 0),
(5855, 244, 22, 0),
(5856, 244, 23, 0),
(5857, 245, 0, 0),
(5858, 245, 1, 0),
(5859, 245, 2, 0),
(5860, 245, 3, 0),
(5861, 245, 4, 0),
(5862, 245, 5, 0),
(5863, 245, 6, 0),
(5864, 245, 7, 0),
(5865, 245, 8, 0),
(5866, 245, 9, 0),
(5867, 245, 10, 0),
(5868, 245, 11, 0),
(5869, 245, 12, 0),
(5870, 245, 13, 0),
(5871, 245, 14, 0),
(5872, 245, 15, 0),
(5873, 245, 16, 0),
(5874, 245, 17, 0),
(5875, 245, 18, 0),
(5876, 245, 19, 0),
(5877, 245, 20, 0),
(5878, 245, 21, 0),
(5879, 245, 22, 0),
(5880, 245, 23, 0),
(5881, 246, 0, 0),
(5882, 246, 1, 0),
(5883, 246, 2, 0),
(5884, 246, 3, 0),
(5885, 246, 4, 0);
INSERT INTO `glpi_plugin_glpiinventory_inventorycomputerstats` (`id`, `day`, `hour`, `counter`) VALUES
(5886, 246, 5, 0),
(5887, 246, 6, 0),
(5888, 246, 7, 0),
(5889, 246, 8, 0),
(5890, 246, 9, 0),
(5891, 246, 10, 0),
(5892, 246, 11, 0),
(5893, 246, 12, 0),
(5894, 246, 13, 0),
(5895, 246, 14, 0),
(5896, 246, 15, 0),
(5897, 246, 16, 0),
(5898, 246, 17, 0),
(5899, 246, 18, 0),
(5900, 246, 19, 0),
(5901, 246, 20, 0),
(5902, 246, 21, 0),
(5903, 246, 22, 0),
(5904, 246, 23, 0),
(5905, 247, 0, 0),
(5906, 247, 1, 0),
(5907, 247, 2, 0),
(5908, 247, 3, 0),
(5909, 247, 4, 0),
(5910, 247, 5, 0),
(5911, 247, 6, 0),
(5912, 247, 7, 0),
(5913, 247, 8, 0),
(5914, 247, 9, 0),
(5915, 247, 10, 0),
(5916, 247, 11, 0),
(5917, 247, 12, 0),
(5918, 247, 13, 0),
(5919, 247, 14, 0),
(5920, 247, 15, 0),
(5921, 247, 16, 0),
(5922, 247, 17, 0),
(5923, 247, 18, 0),
(5924, 247, 19, 0),
(5925, 247, 20, 0),
(5926, 247, 21, 0),
(5927, 247, 22, 0),
(5928, 247, 23, 0),
(5929, 248, 0, 0),
(5930, 248, 1, 0),
(5931, 248, 2, 0),
(5932, 248, 3, 0),
(5933, 248, 4, 0),
(5934, 248, 5, 0),
(5935, 248, 6, 0),
(5936, 248, 7, 0),
(5937, 248, 8, 0),
(5938, 248, 9, 0),
(5939, 248, 10, 0),
(5940, 248, 11, 0),
(5941, 248, 12, 0),
(5942, 248, 13, 0),
(5943, 248, 14, 0),
(5944, 248, 15, 0),
(5945, 248, 16, 0),
(5946, 248, 17, 0),
(5947, 248, 18, 0),
(5948, 248, 19, 0),
(5949, 248, 20, 0),
(5950, 248, 21, 0),
(5951, 248, 22, 0),
(5952, 248, 23, 0),
(5953, 249, 0, 0),
(5954, 249, 1, 0),
(5955, 249, 2, 0),
(5956, 249, 3, 0),
(5957, 249, 4, 0),
(5958, 249, 5, 0),
(5959, 249, 6, 0),
(5960, 249, 7, 0),
(5961, 249, 8, 0),
(5962, 249, 9, 0),
(5963, 249, 10, 0),
(5964, 249, 11, 0),
(5965, 249, 12, 0),
(5966, 249, 13, 0),
(5967, 249, 14, 0),
(5968, 249, 15, 0),
(5969, 249, 16, 0),
(5970, 249, 17, 0),
(5971, 249, 18, 0),
(5972, 249, 19, 0),
(5973, 249, 20, 0),
(5974, 249, 21, 0),
(5975, 249, 22, 0),
(5976, 249, 23, 0),
(5977, 250, 0, 0),
(5978, 250, 1, 0),
(5979, 250, 2, 0),
(5980, 250, 3, 0),
(5981, 250, 4, 0),
(5982, 250, 5, 0),
(5983, 250, 6, 0),
(5984, 250, 7, 0),
(5985, 250, 8, 0),
(5986, 250, 9, 0),
(5987, 250, 10, 0),
(5988, 250, 11, 0),
(5989, 250, 12, 0),
(5990, 250, 13, 0),
(5991, 250, 14, 0),
(5992, 250, 15, 0),
(5993, 250, 16, 0),
(5994, 250, 17, 0),
(5995, 250, 18, 0),
(5996, 250, 19, 0),
(5997, 250, 20, 0),
(5998, 250, 21, 0),
(5999, 250, 22, 0),
(6000, 250, 23, 0),
(6001, 251, 0, 0),
(6002, 251, 1, 0),
(6003, 251, 2, 0),
(6004, 251, 3, 0),
(6005, 251, 4, 0),
(6006, 251, 5, 0),
(6007, 251, 6, 0),
(6008, 251, 7, 0),
(6009, 251, 8, 0),
(6010, 251, 9, 0),
(6011, 251, 10, 0),
(6012, 251, 11, 0),
(6013, 251, 12, 0),
(6014, 251, 13, 0),
(6015, 251, 14, 0),
(6016, 251, 15, 0),
(6017, 251, 16, 0),
(6018, 251, 17, 0),
(6019, 251, 18, 0),
(6020, 251, 19, 0),
(6021, 251, 20, 0),
(6022, 251, 21, 0),
(6023, 251, 22, 0),
(6024, 251, 23, 0),
(6025, 252, 0, 0),
(6026, 252, 1, 0),
(6027, 252, 2, 0),
(6028, 252, 3, 0),
(6029, 252, 4, 0),
(6030, 252, 5, 0),
(6031, 252, 6, 0),
(6032, 252, 7, 0),
(6033, 252, 8, 0),
(6034, 252, 9, 0),
(6035, 252, 10, 0),
(6036, 252, 11, 0),
(6037, 252, 12, 0),
(6038, 252, 13, 0),
(6039, 252, 14, 0),
(6040, 252, 15, 0),
(6041, 252, 16, 0),
(6042, 252, 17, 0),
(6043, 252, 18, 0),
(6044, 252, 19, 0),
(6045, 252, 20, 0),
(6046, 252, 21, 0),
(6047, 252, 22, 0),
(6048, 252, 23, 0),
(6049, 253, 0, 0),
(6050, 253, 1, 0),
(6051, 253, 2, 0),
(6052, 253, 3, 0),
(6053, 253, 4, 0),
(6054, 253, 5, 0),
(6055, 253, 6, 0),
(6056, 253, 7, 0),
(6057, 253, 8, 0),
(6058, 253, 9, 0),
(6059, 253, 10, 0),
(6060, 253, 11, 0),
(6061, 253, 12, 0),
(6062, 253, 13, 0),
(6063, 253, 14, 0),
(6064, 253, 15, 0),
(6065, 253, 16, 0),
(6066, 253, 17, 0),
(6067, 253, 18, 0),
(6068, 253, 19, 0),
(6069, 253, 20, 0),
(6070, 253, 21, 0),
(6071, 253, 22, 0),
(6072, 253, 23, 0),
(6073, 254, 0, 0),
(6074, 254, 1, 0),
(6075, 254, 2, 0),
(6076, 254, 3, 0),
(6077, 254, 4, 0),
(6078, 254, 5, 0),
(6079, 254, 6, 0),
(6080, 254, 7, 0),
(6081, 254, 8, 0),
(6082, 254, 9, 0),
(6083, 254, 10, 0),
(6084, 254, 11, 0),
(6085, 254, 12, 0),
(6086, 254, 13, 0),
(6087, 254, 14, 0),
(6088, 254, 15, 0),
(6089, 254, 16, 0),
(6090, 254, 17, 0),
(6091, 254, 18, 0),
(6092, 254, 19, 0),
(6093, 254, 20, 0),
(6094, 254, 21, 0),
(6095, 254, 22, 0),
(6096, 254, 23, 0),
(6097, 255, 0, 0),
(6098, 255, 1, 0),
(6099, 255, 2, 0),
(6100, 255, 3, 0),
(6101, 255, 4, 0),
(6102, 255, 5, 0),
(6103, 255, 6, 0),
(6104, 255, 7, 0),
(6105, 255, 8, 0),
(6106, 255, 9, 0),
(6107, 255, 10, 0),
(6108, 255, 11, 0),
(6109, 255, 12, 0),
(6110, 255, 13, 0),
(6111, 255, 14, 0),
(6112, 255, 15, 0),
(6113, 255, 16, 0),
(6114, 255, 17, 0),
(6115, 255, 18, 0),
(6116, 255, 19, 0),
(6117, 255, 20, 0),
(6118, 255, 21, 0),
(6119, 255, 22, 0),
(6120, 255, 23, 0),
(6121, 256, 0, 0),
(6122, 256, 1, 0),
(6123, 256, 2, 0),
(6124, 256, 3, 0),
(6125, 256, 4, 0),
(6126, 256, 5, 0),
(6127, 256, 6, 0),
(6128, 256, 7, 0),
(6129, 256, 8, 0),
(6130, 256, 9, 0),
(6131, 256, 10, 0),
(6132, 256, 11, 0),
(6133, 256, 12, 0),
(6134, 256, 13, 0),
(6135, 256, 14, 0),
(6136, 256, 15, 0),
(6137, 256, 16, 0),
(6138, 256, 17, 0),
(6139, 256, 18, 0),
(6140, 256, 19, 0),
(6141, 256, 20, 0),
(6142, 256, 21, 0),
(6143, 256, 22, 0),
(6144, 256, 23, 0),
(6145, 257, 0, 0),
(6146, 257, 1, 0),
(6147, 257, 2, 0),
(6148, 257, 3, 0),
(6149, 257, 4, 0),
(6150, 257, 5, 0),
(6151, 257, 6, 0),
(6152, 257, 7, 0),
(6153, 257, 8, 0),
(6154, 257, 9, 0),
(6155, 257, 10, 0),
(6156, 257, 11, 0),
(6157, 257, 12, 0),
(6158, 257, 13, 0),
(6159, 257, 14, 0),
(6160, 257, 15, 0),
(6161, 257, 16, 0),
(6162, 257, 17, 0),
(6163, 257, 18, 0),
(6164, 257, 19, 0),
(6165, 257, 20, 0),
(6166, 257, 21, 0),
(6167, 257, 22, 0),
(6168, 257, 23, 0),
(6169, 258, 0, 0),
(6170, 258, 1, 0),
(6171, 258, 2, 0),
(6172, 258, 3, 0),
(6173, 258, 4, 0),
(6174, 258, 5, 0),
(6175, 258, 6, 0),
(6176, 258, 7, 0),
(6177, 258, 8, 0),
(6178, 258, 9, 0),
(6179, 258, 10, 0),
(6180, 258, 11, 0),
(6181, 258, 12, 0),
(6182, 258, 13, 0),
(6183, 258, 14, 0),
(6184, 258, 15, 0),
(6185, 258, 16, 0),
(6186, 258, 17, 0),
(6187, 258, 18, 0),
(6188, 258, 19, 0),
(6189, 258, 20, 0),
(6190, 258, 21, 0),
(6191, 258, 22, 0),
(6192, 258, 23, 0),
(6193, 259, 0, 0),
(6194, 259, 1, 0),
(6195, 259, 2, 0),
(6196, 259, 3, 0),
(6197, 259, 4, 0),
(6198, 259, 5, 0),
(6199, 259, 6, 0),
(6200, 259, 7, 0),
(6201, 259, 8, 0),
(6202, 259, 9, 0),
(6203, 259, 10, 0),
(6204, 259, 11, 0),
(6205, 259, 12, 0),
(6206, 259, 13, 0),
(6207, 259, 14, 0),
(6208, 259, 15, 0),
(6209, 259, 16, 0),
(6210, 259, 17, 0),
(6211, 259, 18, 0),
(6212, 259, 19, 0),
(6213, 259, 20, 0),
(6214, 259, 21, 0),
(6215, 259, 22, 0),
(6216, 259, 23, 0),
(6217, 260, 0, 0),
(6218, 260, 1, 0),
(6219, 260, 2, 0),
(6220, 260, 3, 0),
(6221, 260, 4, 0),
(6222, 260, 5, 0),
(6223, 260, 6, 0),
(6224, 260, 7, 0),
(6225, 260, 8, 0),
(6226, 260, 9, 0),
(6227, 260, 10, 0),
(6228, 260, 11, 0),
(6229, 260, 12, 0),
(6230, 260, 13, 0),
(6231, 260, 14, 0),
(6232, 260, 15, 0),
(6233, 260, 16, 0),
(6234, 260, 17, 0),
(6235, 260, 18, 0),
(6236, 260, 19, 0),
(6237, 260, 20, 0),
(6238, 260, 21, 0),
(6239, 260, 22, 0),
(6240, 260, 23, 0),
(6241, 261, 0, 0),
(6242, 261, 1, 0),
(6243, 261, 2, 0),
(6244, 261, 3, 0),
(6245, 261, 4, 0),
(6246, 261, 5, 0),
(6247, 261, 6, 0),
(6248, 261, 7, 0),
(6249, 261, 8, 0),
(6250, 261, 9, 0),
(6251, 261, 10, 0),
(6252, 261, 11, 0),
(6253, 261, 12, 0),
(6254, 261, 13, 0),
(6255, 261, 14, 0),
(6256, 261, 15, 0),
(6257, 261, 16, 0),
(6258, 261, 17, 0),
(6259, 261, 18, 0),
(6260, 261, 19, 0),
(6261, 261, 20, 0),
(6262, 261, 21, 0),
(6263, 261, 22, 0),
(6264, 261, 23, 0),
(6265, 262, 0, 0),
(6266, 262, 1, 0),
(6267, 262, 2, 0),
(6268, 262, 3, 0),
(6269, 262, 4, 0),
(6270, 262, 5, 0),
(6271, 262, 6, 0),
(6272, 262, 7, 0),
(6273, 262, 8, 0),
(6274, 262, 9, 0),
(6275, 262, 10, 0),
(6276, 262, 11, 0),
(6277, 262, 12, 0),
(6278, 262, 13, 0),
(6279, 262, 14, 0),
(6280, 262, 15, 0),
(6281, 262, 16, 0),
(6282, 262, 17, 0),
(6283, 262, 18, 0),
(6284, 262, 19, 0),
(6285, 262, 20, 0),
(6286, 262, 21, 0),
(6287, 262, 22, 0),
(6288, 262, 23, 0),
(6289, 263, 0, 0),
(6290, 263, 1, 0),
(6291, 263, 2, 0),
(6292, 263, 3, 0),
(6293, 263, 4, 0),
(6294, 263, 5, 0),
(6295, 263, 6, 0),
(6296, 263, 7, 0),
(6297, 263, 8, 0),
(6298, 263, 9, 0),
(6299, 263, 10, 0),
(6300, 263, 11, 0),
(6301, 263, 12, 0),
(6302, 263, 13, 0),
(6303, 263, 14, 0),
(6304, 263, 15, 0),
(6305, 263, 16, 0),
(6306, 263, 17, 0),
(6307, 263, 18, 0),
(6308, 263, 19, 0),
(6309, 263, 20, 0),
(6310, 263, 21, 0),
(6311, 263, 22, 0),
(6312, 263, 23, 0),
(6313, 264, 0, 0),
(6314, 264, 1, 0),
(6315, 264, 2, 0),
(6316, 264, 3, 0),
(6317, 264, 4, 0),
(6318, 264, 5, 0),
(6319, 264, 6, 0),
(6320, 264, 7, 0),
(6321, 264, 8, 0),
(6322, 264, 9, 0),
(6323, 264, 10, 0),
(6324, 264, 11, 0),
(6325, 264, 12, 0),
(6326, 264, 13, 0),
(6327, 264, 14, 0),
(6328, 264, 15, 0),
(6329, 264, 16, 0),
(6330, 264, 17, 0),
(6331, 264, 18, 0),
(6332, 264, 19, 0),
(6333, 264, 20, 0),
(6334, 264, 21, 0),
(6335, 264, 22, 0),
(6336, 264, 23, 0),
(6337, 265, 0, 0),
(6338, 265, 1, 0),
(6339, 265, 2, 0),
(6340, 265, 3, 0),
(6341, 265, 4, 0),
(6342, 265, 5, 0),
(6343, 265, 6, 0),
(6344, 265, 7, 0),
(6345, 265, 8, 0),
(6346, 265, 9, 0),
(6347, 265, 10, 0),
(6348, 265, 11, 0),
(6349, 265, 12, 0),
(6350, 265, 13, 0),
(6351, 265, 14, 0),
(6352, 265, 15, 0),
(6353, 265, 16, 0),
(6354, 265, 17, 0),
(6355, 265, 18, 0),
(6356, 265, 19, 0),
(6357, 265, 20, 0),
(6358, 265, 21, 0),
(6359, 265, 22, 0),
(6360, 265, 23, 0),
(6361, 266, 0, 0),
(6362, 266, 1, 0),
(6363, 266, 2, 0),
(6364, 266, 3, 0),
(6365, 266, 4, 0),
(6366, 266, 5, 0),
(6367, 266, 6, 0),
(6368, 266, 7, 0),
(6369, 266, 8, 0),
(6370, 266, 9, 0),
(6371, 266, 10, 0),
(6372, 266, 11, 0),
(6373, 266, 12, 0),
(6374, 266, 13, 0),
(6375, 266, 14, 0),
(6376, 266, 15, 0),
(6377, 266, 16, 0),
(6378, 266, 17, 0),
(6379, 266, 18, 0),
(6380, 266, 19, 0),
(6381, 266, 20, 0),
(6382, 266, 21, 0),
(6383, 266, 22, 0),
(6384, 266, 23, 0),
(6385, 267, 0, 0),
(6386, 267, 1, 0),
(6387, 267, 2, 0),
(6388, 267, 3, 0),
(6389, 267, 4, 0),
(6390, 267, 5, 0),
(6391, 267, 6, 0),
(6392, 267, 7, 0),
(6393, 267, 8, 0),
(6394, 267, 9, 0),
(6395, 267, 10, 0),
(6396, 267, 11, 0),
(6397, 267, 12, 0),
(6398, 267, 13, 0),
(6399, 267, 14, 0),
(6400, 267, 15, 0),
(6401, 267, 16, 0),
(6402, 267, 17, 0),
(6403, 267, 18, 0),
(6404, 267, 19, 0),
(6405, 267, 20, 0),
(6406, 267, 21, 0),
(6407, 267, 22, 0),
(6408, 267, 23, 0),
(6409, 268, 0, 0),
(6410, 268, 1, 0),
(6411, 268, 2, 0),
(6412, 268, 3, 0),
(6413, 268, 4, 0),
(6414, 268, 5, 0),
(6415, 268, 6, 0),
(6416, 268, 7, 0),
(6417, 268, 8, 0),
(6418, 268, 9, 0),
(6419, 268, 10, 0),
(6420, 268, 11, 0),
(6421, 268, 12, 0),
(6422, 268, 13, 0),
(6423, 268, 14, 0),
(6424, 268, 15, 0),
(6425, 268, 16, 0),
(6426, 268, 17, 0),
(6427, 268, 18, 0),
(6428, 268, 19, 0),
(6429, 268, 20, 0),
(6430, 268, 21, 0),
(6431, 268, 22, 0),
(6432, 268, 23, 0),
(6433, 269, 0, 0),
(6434, 269, 1, 0),
(6435, 269, 2, 0),
(6436, 269, 3, 0),
(6437, 269, 4, 0),
(6438, 269, 5, 0),
(6439, 269, 6, 0),
(6440, 269, 7, 0),
(6441, 269, 8, 0),
(6442, 269, 9, 0),
(6443, 269, 10, 0),
(6444, 269, 11, 0),
(6445, 269, 12, 0),
(6446, 269, 13, 0),
(6447, 269, 14, 0),
(6448, 269, 15, 0),
(6449, 269, 16, 0),
(6450, 269, 17, 0),
(6451, 269, 18, 0),
(6452, 269, 19, 0),
(6453, 269, 20, 0),
(6454, 269, 21, 0),
(6455, 269, 22, 0),
(6456, 269, 23, 0),
(6457, 270, 0, 0),
(6458, 270, 1, 0),
(6459, 270, 2, 0),
(6460, 270, 3, 0),
(6461, 270, 4, 0),
(6462, 270, 5, 0),
(6463, 270, 6, 0),
(6464, 270, 7, 0),
(6465, 270, 8, 0),
(6466, 270, 9, 0),
(6467, 270, 10, 0),
(6468, 270, 11, 0),
(6469, 270, 12, 0),
(6470, 270, 13, 0),
(6471, 270, 14, 0),
(6472, 270, 15, 0),
(6473, 270, 16, 0),
(6474, 270, 17, 0),
(6475, 270, 18, 0),
(6476, 270, 19, 0),
(6477, 270, 20, 0),
(6478, 270, 21, 0),
(6479, 270, 22, 0),
(6480, 270, 23, 0),
(6481, 271, 0, 0),
(6482, 271, 1, 0),
(6483, 271, 2, 0),
(6484, 271, 3, 0),
(6485, 271, 4, 0),
(6486, 271, 5, 0),
(6487, 271, 6, 0),
(6488, 271, 7, 0),
(6489, 271, 8, 0),
(6490, 271, 9, 0),
(6491, 271, 10, 0),
(6492, 271, 11, 0),
(6493, 271, 12, 0),
(6494, 271, 13, 0),
(6495, 271, 14, 0),
(6496, 271, 15, 0),
(6497, 271, 16, 0),
(6498, 271, 17, 0),
(6499, 271, 18, 0),
(6500, 271, 19, 0),
(6501, 271, 20, 0),
(6502, 271, 21, 0),
(6503, 271, 22, 0),
(6504, 271, 23, 0),
(6505, 272, 0, 0),
(6506, 272, 1, 0),
(6507, 272, 2, 0),
(6508, 272, 3, 0),
(6509, 272, 4, 0),
(6510, 272, 5, 0),
(6511, 272, 6, 0),
(6512, 272, 7, 0),
(6513, 272, 8, 0),
(6514, 272, 9, 0),
(6515, 272, 10, 0),
(6516, 272, 11, 0),
(6517, 272, 12, 0),
(6518, 272, 13, 0),
(6519, 272, 14, 0),
(6520, 272, 15, 0),
(6521, 272, 16, 0),
(6522, 272, 17, 0),
(6523, 272, 18, 0),
(6524, 272, 19, 0),
(6525, 272, 20, 0),
(6526, 272, 21, 0),
(6527, 272, 22, 0),
(6528, 272, 23, 0),
(6529, 273, 0, 0),
(6530, 273, 1, 0),
(6531, 273, 2, 0),
(6532, 273, 3, 0),
(6533, 273, 4, 0),
(6534, 273, 5, 0),
(6535, 273, 6, 0),
(6536, 273, 7, 0),
(6537, 273, 8, 0),
(6538, 273, 9, 0),
(6539, 273, 10, 0),
(6540, 273, 11, 0),
(6541, 273, 12, 0),
(6542, 273, 13, 0),
(6543, 273, 14, 0),
(6544, 273, 15, 0),
(6545, 273, 16, 0),
(6546, 273, 17, 0),
(6547, 273, 18, 0),
(6548, 273, 19, 0),
(6549, 273, 20, 0),
(6550, 273, 21, 0),
(6551, 273, 22, 0),
(6552, 273, 23, 0),
(6553, 274, 0, 0),
(6554, 274, 1, 0),
(6555, 274, 2, 0),
(6556, 274, 3, 0),
(6557, 274, 4, 0),
(6558, 274, 5, 0),
(6559, 274, 6, 0),
(6560, 274, 7, 0),
(6561, 274, 8, 0),
(6562, 274, 9, 0),
(6563, 274, 10, 0),
(6564, 274, 11, 0),
(6565, 274, 12, 0),
(6566, 274, 13, 0),
(6567, 274, 14, 0),
(6568, 274, 15, 0),
(6569, 274, 16, 0),
(6570, 274, 17, 0),
(6571, 274, 18, 0),
(6572, 274, 19, 0),
(6573, 274, 20, 0),
(6574, 274, 21, 0),
(6575, 274, 22, 0),
(6576, 274, 23, 0),
(6577, 275, 0, 0),
(6578, 275, 1, 0),
(6579, 275, 2, 0),
(6580, 275, 3, 0),
(6581, 275, 4, 0),
(6582, 275, 5, 0),
(6583, 275, 6, 0),
(6584, 275, 7, 0),
(6585, 275, 8, 0),
(6586, 275, 9, 0),
(6587, 275, 10, 0),
(6588, 275, 11, 0),
(6589, 275, 12, 0),
(6590, 275, 13, 0),
(6591, 275, 14, 0),
(6592, 275, 15, 0),
(6593, 275, 16, 0),
(6594, 275, 17, 0),
(6595, 275, 18, 0),
(6596, 275, 19, 0),
(6597, 275, 20, 0),
(6598, 275, 21, 0),
(6599, 275, 22, 0),
(6600, 275, 23, 0),
(6601, 276, 0, 0),
(6602, 276, 1, 0),
(6603, 276, 2, 0),
(6604, 276, 3, 0),
(6605, 276, 4, 0),
(6606, 276, 5, 0),
(6607, 276, 6, 0),
(6608, 276, 7, 0),
(6609, 276, 8, 0),
(6610, 276, 9, 0),
(6611, 276, 10, 0),
(6612, 276, 11, 0),
(6613, 276, 12, 0),
(6614, 276, 13, 0),
(6615, 276, 14, 0),
(6616, 276, 15, 0),
(6617, 276, 16, 0),
(6618, 276, 17, 0),
(6619, 276, 18, 0),
(6620, 276, 19, 0),
(6621, 276, 20, 0),
(6622, 276, 21, 0),
(6623, 276, 22, 0),
(6624, 276, 23, 0),
(6625, 277, 0, 0),
(6626, 277, 1, 0),
(6627, 277, 2, 0),
(6628, 277, 3, 0),
(6629, 277, 4, 0),
(6630, 277, 5, 0),
(6631, 277, 6, 0),
(6632, 277, 7, 0),
(6633, 277, 8, 0),
(6634, 277, 9, 0),
(6635, 277, 10, 0),
(6636, 277, 11, 0),
(6637, 277, 12, 0),
(6638, 277, 13, 0),
(6639, 277, 14, 0),
(6640, 277, 15, 0),
(6641, 277, 16, 0),
(6642, 277, 17, 0),
(6643, 277, 18, 0),
(6644, 277, 19, 0),
(6645, 277, 20, 0),
(6646, 277, 21, 0),
(6647, 277, 22, 0),
(6648, 277, 23, 0),
(6649, 278, 0, 0),
(6650, 278, 1, 0),
(6651, 278, 2, 0),
(6652, 278, 3, 0),
(6653, 278, 4, 0),
(6654, 278, 5, 0),
(6655, 278, 6, 0),
(6656, 278, 7, 0),
(6657, 278, 8, 0),
(6658, 278, 9, 0),
(6659, 278, 10, 0),
(6660, 278, 11, 0),
(6661, 278, 12, 0),
(6662, 278, 13, 0),
(6663, 278, 14, 0),
(6664, 278, 15, 0),
(6665, 278, 16, 0),
(6666, 278, 17, 0),
(6667, 278, 18, 0),
(6668, 278, 19, 0),
(6669, 278, 20, 0),
(6670, 278, 21, 0),
(6671, 278, 22, 0),
(6672, 278, 23, 0),
(6673, 279, 0, 0),
(6674, 279, 1, 0),
(6675, 279, 2, 0),
(6676, 279, 3, 0),
(6677, 279, 4, 0),
(6678, 279, 5, 0),
(6679, 279, 6, 0),
(6680, 279, 7, 0),
(6681, 279, 8, 0),
(6682, 279, 9, 0),
(6683, 279, 10, 0),
(6684, 279, 11, 0),
(6685, 279, 12, 0),
(6686, 279, 13, 0),
(6687, 279, 14, 0),
(6688, 279, 15, 0),
(6689, 279, 16, 0),
(6690, 279, 17, 0),
(6691, 279, 18, 0),
(6692, 279, 19, 0),
(6693, 279, 20, 0),
(6694, 279, 21, 0),
(6695, 279, 22, 0),
(6696, 279, 23, 0),
(6697, 280, 0, 0),
(6698, 280, 1, 0),
(6699, 280, 2, 0),
(6700, 280, 3, 0),
(6701, 280, 4, 0),
(6702, 280, 5, 0),
(6703, 280, 6, 0),
(6704, 280, 7, 0),
(6705, 280, 8, 0),
(6706, 280, 9, 0),
(6707, 280, 10, 0),
(6708, 280, 11, 0),
(6709, 280, 12, 0),
(6710, 280, 13, 0),
(6711, 280, 14, 0),
(6712, 280, 15, 0),
(6713, 280, 16, 0),
(6714, 280, 17, 0),
(6715, 280, 18, 0),
(6716, 280, 19, 0),
(6717, 280, 20, 0),
(6718, 280, 21, 0),
(6719, 280, 22, 0),
(6720, 280, 23, 0),
(6721, 281, 0, 0),
(6722, 281, 1, 0),
(6723, 281, 2, 0),
(6724, 281, 3, 0),
(6725, 281, 4, 0),
(6726, 281, 5, 0),
(6727, 281, 6, 0),
(6728, 281, 7, 0),
(6729, 281, 8, 0),
(6730, 281, 9, 0),
(6731, 281, 10, 0),
(6732, 281, 11, 0),
(6733, 281, 12, 0),
(6734, 281, 13, 0),
(6735, 281, 14, 0),
(6736, 281, 15, 0),
(6737, 281, 16, 0),
(6738, 281, 17, 0),
(6739, 281, 18, 0),
(6740, 281, 19, 0),
(6741, 281, 20, 0),
(6742, 281, 21, 0),
(6743, 281, 22, 0),
(6744, 281, 23, 0),
(6745, 282, 0, 0),
(6746, 282, 1, 0),
(6747, 282, 2, 0),
(6748, 282, 3, 0),
(6749, 282, 4, 0),
(6750, 282, 5, 0),
(6751, 282, 6, 0),
(6752, 282, 7, 0),
(6753, 282, 8, 0),
(6754, 282, 9, 0),
(6755, 282, 10, 0),
(6756, 282, 11, 0),
(6757, 282, 12, 0),
(6758, 282, 13, 0),
(6759, 282, 14, 0),
(6760, 282, 15, 0),
(6761, 282, 16, 0),
(6762, 282, 17, 0),
(6763, 282, 18, 0),
(6764, 282, 19, 0),
(6765, 282, 20, 0),
(6766, 282, 21, 0),
(6767, 282, 22, 0),
(6768, 282, 23, 0),
(6769, 283, 0, 0),
(6770, 283, 1, 0),
(6771, 283, 2, 0),
(6772, 283, 3, 0),
(6773, 283, 4, 0),
(6774, 283, 5, 0),
(6775, 283, 6, 0),
(6776, 283, 7, 0),
(6777, 283, 8, 0),
(6778, 283, 9, 0),
(6779, 283, 10, 0),
(6780, 283, 11, 0),
(6781, 283, 12, 0),
(6782, 283, 13, 0),
(6783, 283, 14, 0),
(6784, 283, 15, 0),
(6785, 283, 16, 0),
(6786, 283, 17, 0),
(6787, 283, 18, 0),
(6788, 283, 19, 0),
(6789, 283, 20, 0),
(6790, 283, 21, 0),
(6791, 283, 22, 0),
(6792, 283, 23, 0),
(6793, 284, 0, 0),
(6794, 284, 1, 0),
(6795, 284, 2, 0),
(6796, 284, 3, 0),
(6797, 284, 4, 0),
(6798, 284, 5, 0),
(6799, 284, 6, 0),
(6800, 284, 7, 0),
(6801, 284, 8, 0),
(6802, 284, 9, 0),
(6803, 284, 10, 0),
(6804, 284, 11, 0),
(6805, 284, 12, 0),
(6806, 284, 13, 0),
(6807, 284, 14, 0),
(6808, 284, 15, 0),
(6809, 284, 16, 0),
(6810, 284, 17, 0),
(6811, 284, 18, 0),
(6812, 284, 19, 0),
(6813, 284, 20, 0),
(6814, 284, 21, 0),
(6815, 284, 22, 0),
(6816, 284, 23, 0),
(6817, 285, 0, 0),
(6818, 285, 1, 0),
(6819, 285, 2, 0),
(6820, 285, 3, 0),
(6821, 285, 4, 0),
(6822, 285, 5, 0),
(6823, 285, 6, 0),
(6824, 285, 7, 0),
(6825, 285, 8, 0),
(6826, 285, 9, 0),
(6827, 285, 10, 0),
(6828, 285, 11, 0),
(6829, 285, 12, 0),
(6830, 285, 13, 0),
(6831, 285, 14, 0),
(6832, 285, 15, 0),
(6833, 285, 16, 0),
(6834, 285, 17, 0),
(6835, 285, 18, 0),
(6836, 285, 19, 0),
(6837, 285, 20, 0),
(6838, 285, 21, 0),
(6839, 285, 22, 0),
(6840, 285, 23, 0),
(6841, 286, 0, 0),
(6842, 286, 1, 0),
(6843, 286, 2, 0),
(6844, 286, 3, 0),
(6845, 286, 4, 0),
(6846, 286, 5, 0),
(6847, 286, 6, 0),
(6848, 286, 7, 0),
(6849, 286, 8, 0),
(6850, 286, 9, 0),
(6851, 286, 10, 0),
(6852, 286, 11, 0),
(6853, 286, 12, 0),
(6854, 286, 13, 0),
(6855, 286, 14, 0),
(6856, 286, 15, 0),
(6857, 286, 16, 0),
(6858, 286, 17, 0),
(6859, 286, 18, 0),
(6860, 286, 19, 0),
(6861, 286, 20, 0),
(6862, 286, 21, 0),
(6863, 286, 22, 0),
(6864, 286, 23, 0),
(6865, 287, 0, 0),
(6866, 287, 1, 0),
(6867, 287, 2, 0),
(6868, 287, 3, 0),
(6869, 287, 4, 0),
(6870, 287, 5, 0),
(6871, 287, 6, 0),
(6872, 287, 7, 0),
(6873, 287, 8, 0),
(6874, 287, 9, 0),
(6875, 287, 10, 0),
(6876, 287, 11, 0),
(6877, 287, 12, 0),
(6878, 287, 13, 0),
(6879, 287, 14, 0),
(6880, 287, 15, 0),
(6881, 287, 16, 0),
(6882, 287, 17, 0),
(6883, 287, 18, 0),
(6884, 287, 19, 0),
(6885, 287, 20, 0),
(6886, 287, 21, 0),
(6887, 287, 22, 0),
(6888, 287, 23, 0),
(6889, 288, 0, 0),
(6890, 288, 1, 0),
(6891, 288, 2, 0),
(6892, 288, 3, 0),
(6893, 288, 4, 0),
(6894, 288, 5, 0),
(6895, 288, 6, 0),
(6896, 288, 7, 0),
(6897, 288, 8, 0),
(6898, 288, 9, 0),
(6899, 288, 10, 0),
(6900, 288, 11, 0),
(6901, 288, 12, 0),
(6902, 288, 13, 0),
(6903, 288, 14, 0),
(6904, 288, 15, 0),
(6905, 288, 16, 0),
(6906, 288, 17, 0),
(6907, 288, 18, 0),
(6908, 288, 19, 0),
(6909, 288, 20, 0),
(6910, 288, 21, 0),
(6911, 288, 22, 0),
(6912, 288, 23, 0),
(6913, 289, 0, 0),
(6914, 289, 1, 0),
(6915, 289, 2, 0),
(6916, 289, 3, 0),
(6917, 289, 4, 0),
(6918, 289, 5, 0),
(6919, 289, 6, 0),
(6920, 289, 7, 0),
(6921, 289, 8, 0),
(6922, 289, 9, 0),
(6923, 289, 10, 0),
(6924, 289, 11, 0),
(6925, 289, 12, 0),
(6926, 289, 13, 0),
(6927, 289, 14, 0),
(6928, 289, 15, 0),
(6929, 289, 16, 0),
(6930, 289, 17, 0),
(6931, 289, 18, 0),
(6932, 289, 19, 0),
(6933, 289, 20, 0),
(6934, 289, 21, 0),
(6935, 289, 22, 0),
(6936, 289, 23, 0),
(6937, 290, 0, 0),
(6938, 290, 1, 0),
(6939, 290, 2, 0),
(6940, 290, 3, 0),
(6941, 290, 4, 0),
(6942, 290, 5, 0),
(6943, 290, 6, 0),
(6944, 290, 7, 0),
(6945, 290, 8, 0),
(6946, 290, 9, 0),
(6947, 290, 10, 0),
(6948, 290, 11, 0),
(6949, 290, 12, 0),
(6950, 290, 13, 0),
(6951, 290, 14, 0),
(6952, 290, 15, 0),
(6953, 290, 16, 0),
(6954, 290, 17, 0),
(6955, 290, 18, 0),
(6956, 290, 19, 0),
(6957, 290, 20, 0),
(6958, 290, 21, 0),
(6959, 290, 22, 0),
(6960, 290, 23, 0),
(6961, 291, 0, 0),
(6962, 291, 1, 0),
(6963, 291, 2, 0),
(6964, 291, 3, 0),
(6965, 291, 4, 0),
(6966, 291, 5, 0),
(6967, 291, 6, 0),
(6968, 291, 7, 0),
(6969, 291, 8, 0),
(6970, 291, 9, 0),
(6971, 291, 10, 0),
(6972, 291, 11, 0),
(6973, 291, 12, 0),
(6974, 291, 13, 0),
(6975, 291, 14, 0),
(6976, 291, 15, 0),
(6977, 291, 16, 0),
(6978, 291, 17, 0),
(6979, 291, 18, 0),
(6980, 291, 19, 0),
(6981, 291, 20, 0),
(6982, 291, 21, 0),
(6983, 291, 22, 0),
(6984, 291, 23, 0),
(6985, 292, 0, 0),
(6986, 292, 1, 0),
(6987, 292, 2, 0),
(6988, 292, 3, 0),
(6989, 292, 4, 0),
(6990, 292, 5, 0),
(6991, 292, 6, 0),
(6992, 292, 7, 0),
(6993, 292, 8, 0),
(6994, 292, 9, 0),
(6995, 292, 10, 0),
(6996, 292, 11, 0),
(6997, 292, 12, 0),
(6998, 292, 13, 0),
(6999, 292, 14, 0),
(7000, 292, 15, 0),
(7001, 292, 16, 0),
(7002, 292, 17, 0),
(7003, 292, 18, 0),
(7004, 292, 19, 0),
(7005, 292, 20, 0),
(7006, 292, 21, 0),
(7007, 292, 22, 0),
(7008, 292, 23, 0),
(7009, 293, 0, 0),
(7010, 293, 1, 0),
(7011, 293, 2, 0),
(7012, 293, 3, 0),
(7013, 293, 4, 0),
(7014, 293, 5, 0),
(7015, 293, 6, 0),
(7016, 293, 7, 0),
(7017, 293, 8, 0),
(7018, 293, 9, 0),
(7019, 293, 10, 0),
(7020, 293, 11, 0),
(7021, 293, 12, 0),
(7022, 293, 13, 0),
(7023, 293, 14, 0),
(7024, 293, 15, 0),
(7025, 293, 16, 0),
(7026, 293, 17, 0),
(7027, 293, 18, 0),
(7028, 293, 19, 0),
(7029, 293, 20, 0),
(7030, 293, 21, 0),
(7031, 293, 22, 0),
(7032, 293, 23, 0),
(7033, 294, 0, 0),
(7034, 294, 1, 0),
(7035, 294, 2, 0),
(7036, 294, 3, 0),
(7037, 294, 4, 0),
(7038, 294, 5, 0),
(7039, 294, 6, 0),
(7040, 294, 7, 0),
(7041, 294, 8, 0),
(7042, 294, 9, 0),
(7043, 294, 10, 0),
(7044, 294, 11, 0),
(7045, 294, 12, 0),
(7046, 294, 13, 0),
(7047, 294, 14, 0),
(7048, 294, 15, 0),
(7049, 294, 16, 0),
(7050, 294, 17, 0),
(7051, 294, 18, 0),
(7052, 294, 19, 0),
(7053, 294, 20, 0),
(7054, 294, 21, 0),
(7055, 294, 22, 0),
(7056, 294, 23, 0),
(7057, 295, 0, 0),
(7058, 295, 1, 0),
(7059, 295, 2, 0),
(7060, 295, 3, 0),
(7061, 295, 4, 0),
(7062, 295, 5, 0),
(7063, 295, 6, 0),
(7064, 295, 7, 0),
(7065, 295, 8, 0),
(7066, 295, 9, 0),
(7067, 295, 10, 0),
(7068, 295, 11, 0),
(7069, 295, 12, 0),
(7070, 295, 13, 0),
(7071, 295, 14, 0),
(7072, 295, 15, 0),
(7073, 295, 16, 0),
(7074, 295, 17, 0),
(7075, 295, 18, 0),
(7076, 295, 19, 0),
(7077, 295, 20, 0),
(7078, 295, 21, 0),
(7079, 295, 22, 0),
(7080, 295, 23, 0),
(7081, 296, 0, 0),
(7082, 296, 1, 0),
(7083, 296, 2, 0),
(7084, 296, 3, 0),
(7085, 296, 4, 0),
(7086, 296, 5, 0),
(7087, 296, 6, 0),
(7088, 296, 7, 0),
(7089, 296, 8, 0),
(7090, 296, 9, 0),
(7091, 296, 10, 0),
(7092, 296, 11, 0),
(7093, 296, 12, 0),
(7094, 296, 13, 0),
(7095, 296, 14, 0),
(7096, 296, 15, 0),
(7097, 296, 16, 0),
(7098, 296, 17, 0),
(7099, 296, 18, 0),
(7100, 296, 19, 0),
(7101, 296, 20, 0),
(7102, 296, 21, 0),
(7103, 296, 22, 0),
(7104, 296, 23, 0),
(7105, 297, 0, 0),
(7106, 297, 1, 0),
(7107, 297, 2, 0),
(7108, 297, 3, 0),
(7109, 297, 4, 0),
(7110, 297, 5, 0),
(7111, 297, 6, 0),
(7112, 297, 7, 0),
(7113, 297, 8, 0),
(7114, 297, 9, 0),
(7115, 297, 10, 0),
(7116, 297, 11, 0),
(7117, 297, 12, 0),
(7118, 297, 13, 0),
(7119, 297, 14, 0),
(7120, 297, 15, 0),
(7121, 297, 16, 0),
(7122, 297, 17, 0),
(7123, 297, 18, 0),
(7124, 297, 19, 0),
(7125, 297, 20, 0),
(7126, 297, 21, 0),
(7127, 297, 22, 0),
(7128, 297, 23, 0),
(7129, 298, 0, 0),
(7130, 298, 1, 0),
(7131, 298, 2, 0),
(7132, 298, 3, 0),
(7133, 298, 4, 0),
(7134, 298, 5, 0),
(7135, 298, 6, 0),
(7136, 298, 7, 0),
(7137, 298, 8, 0),
(7138, 298, 9, 0),
(7139, 298, 10, 0),
(7140, 298, 11, 0),
(7141, 298, 12, 0),
(7142, 298, 13, 0),
(7143, 298, 14, 0),
(7144, 298, 15, 0),
(7145, 298, 16, 0),
(7146, 298, 17, 0),
(7147, 298, 18, 0),
(7148, 298, 19, 0),
(7149, 298, 20, 0),
(7150, 298, 21, 0),
(7151, 298, 22, 0),
(7152, 298, 23, 0),
(7153, 299, 0, 0),
(7154, 299, 1, 0),
(7155, 299, 2, 0),
(7156, 299, 3, 0),
(7157, 299, 4, 0),
(7158, 299, 5, 0),
(7159, 299, 6, 0),
(7160, 299, 7, 0),
(7161, 299, 8, 0),
(7162, 299, 9, 0),
(7163, 299, 10, 0),
(7164, 299, 11, 0),
(7165, 299, 12, 0),
(7166, 299, 13, 0),
(7167, 299, 14, 0),
(7168, 299, 15, 0),
(7169, 299, 16, 0),
(7170, 299, 17, 0),
(7171, 299, 18, 0),
(7172, 299, 19, 0),
(7173, 299, 20, 0),
(7174, 299, 21, 0),
(7175, 299, 22, 0),
(7176, 299, 23, 0),
(7177, 300, 0, 0),
(7178, 300, 1, 0),
(7179, 300, 2, 0),
(7180, 300, 3, 0),
(7181, 300, 4, 0),
(7182, 300, 5, 0),
(7183, 300, 6, 0),
(7184, 300, 7, 0),
(7185, 300, 8, 0),
(7186, 300, 9, 0),
(7187, 300, 10, 0),
(7188, 300, 11, 0),
(7189, 300, 12, 0),
(7190, 300, 13, 0),
(7191, 300, 14, 0),
(7192, 300, 15, 0),
(7193, 300, 16, 0),
(7194, 300, 17, 0),
(7195, 300, 18, 0),
(7196, 300, 19, 0),
(7197, 300, 20, 0),
(7198, 300, 21, 0),
(7199, 300, 22, 0),
(7200, 300, 23, 0),
(7201, 301, 0, 0),
(7202, 301, 1, 0),
(7203, 301, 2, 0),
(7204, 301, 3, 0),
(7205, 301, 4, 0),
(7206, 301, 5, 0),
(7207, 301, 6, 0),
(7208, 301, 7, 0),
(7209, 301, 8, 0),
(7210, 301, 9, 0),
(7211, 301, 10, 0),
(7212, 301, 11, 0),
(7213, 301, 12, 0),
(7214, 301, 13, 0),
(7215, 301, 14, 0),
(7216, 301, 15, 0),
(7217, 301, 16, 0),
(7218, 301, 17, 0),
(7219, 301, 18, 0),
(7220, 301, 19, 0),
(7221, 301, 20, 0),
(7222, 301, 21, 0),
(7223, 301, 22, 0),
(7224, 301, 23, 0),
(7225, 302, 0, 0),
(7226, 302, 1, 0),
(7227, 302, 2, 0),
(7228, 302, 3, 0),
(7229, 302, 4, 0),
(7230, 302, 5, 0),
(7231, 302, 6, 0),
(7232, 302, 7, 0),
(7233, 302, 8, 0),
(7234, 302, 9, 0),
(7235, 302, 10, 0),
(7236, 302, 11, 0),
(7237, 302, 12, 0),
(7238, 302, 13, 0),
(7239, 302, 14, 0),
(7240, 302, 15, 0),
(7241, 302, 16, 0),
(7242, 302, 17, 0),
(7243, 302, 18, 0),
(7244, 302, 19, 0),
(7245, 302, 20, 0),
(7246, 302, 21, 0),
(7247, 302, 22, 0),
(7248, 302, 23, 0),
(7249, 303, 0, 0),
(7250, 303, 1, 0),
(7251, 303, 2, 0),
(7252, 303, 3, 0),
(7253, 303, 4, 0),
(7254, 303, 5, 0),
(7255, 303, 6, 0),
(7256, 303, 7, 0),
(7257, 303, 8, 0),
(7258, 303, 9, 0),
(7259, 303, 10, 0),
(7260, 303, 11, 0),
(7261, 303, 12, 0),
(7262, 303, 13, 0),
(7263, 303, 14, 0),
(7264, 303, 15, 0),
(7265, 303, 16, 0),
(7266, 303, 17, 0),
(7267, 303, 18, 0),
(7268, 303, 19, 0),
(7269, 303, 20, 0),
(7270, 303, 21, 0),
(7271, 303, 22, 0),
(7272, 303, 23, 0),
(7273, 304, 0, 0),
(7274, 304, 1, 0),
(7275, 304, 2, 0),
(7276, 304, 3, 0),
(7277, 304, 4, 0),
(7278, 304, 5, 0),
(7279, 304, 6, 0),
(7280, 304, 7, 0),
(7281, 304, 8, 0),
(7282, 304, 9, 0),
(7283, 304, 10, 0),
(7284, 304, 11, 0),
(7285, 304, 12, 0),
(7286, 304, 13, 0),
(7287, 304, 14, 0),
(7288, 304, 15, 0),
(7289, 304, 16, 0),
(7290, 304, 17, 0),
(7291, 304, 18, 0),
(7292, 304, 19, 0),
(7293, 304, 20, 0),
(7294, 304, 21, 0),
(7295, 304, 22, 0),
(7296, 304, 23, 0),
(7297, 305, 0, 0),
(7298, 305, 1, 0),
(7299, 305, 2, 0),
(7300, 305, 3, 0),
(7301, 305, 4, 0),
(7302, 305, 5, 0),
(7303, 305, 6, 0),
(7304, 305, 7, 0),
(7305, 305, 8, 0),
(7306, 305, 9, 0),
(7307, 305, 10, 0),
(7308, 305, 11, 0),
(7309, 305, 12, 0),
(7310, 305, 13, 0),
(7311, 305, 14, 0),
(7312, 305, 15, 0),
(7313, 305, 16, 0),
(7314, 305, 17, 0),
(7315, 305, 18, 0),
(7316, 305, 19, 0),
(7317, 305, 20, 0),
(7318, 305, 21, 0),
(7319, 305, 22, 0),
(7320, 305, 23, 0),
(7321, 306, 0, 0),
(7322, 306, 1, 0),
(7323, 306, 2, 0),
(7324, 306, 3, 0),
(7325, 306, 4, 0),
(7326, 306, 5, 0),
(7327, 306, 6, 0),
(7328, 306, 7, 0),
(7329, 306, 8, 0),
(7330, 306, 9, 0),
(7331, 306, 10, 0),
(7332, 306, 11, 0),
(7333, 306, 12, 0),
(7334, 306, 13, 0),
(7335, 306, 14, 0),
(7336, 306, 15, 0),
(7337, 306, 16, 0),
(7338, 306, 17, 0),
(7339, 306, 18, 0),
(7340, 306, 19, 0),
(7341, 306, 20, 0),
(7342, 306, 21, 0),
(7343, 306, 22, 0),
(7344, 306, 23, 0),
(7345, 307, 0, 0),
(7346, 307, 1, 0),
(7347, 307, 2, 0),
(7348, 307, 3, 0),
(7349, 307, 4, 0),
(7350, 307, 5, 0),
(7351, 307, 6, 0),
(7352, 307, 7, 0),
(7353, 307, 8, 0),
(7354, 307, 9, 0),
(7355, 307, 10, 0),
(7356, 307, 11, 0),
(7357, 307, 12, 0),
(7358, 307, 13, 0),
(7359, 307, 14, 0),
(7360, 307, 15, 0),
(7361, 307, 16, 0),
(7362, 307, 17, 0),
(7363, 307, 18, 0),
(7364, 307, 19, 0),
(7365, 307, 20, 0),
(7366, 307, 21, 0),
(7367, 307, 22, 0),
(7368, 307, 23, 0),
(7369, 308, 0, 0),
(7370, 308, 1, 0),
(7371, 308, 2, 0),
(7372, 308, 3, 0),
(7373, 308, 4, 0),
(7374, 308, 5, 0),
(7375, 308, 6, 0),
(7376, 308, 7, 0),
(7377, 308, 8, 0),
(7378, 308, 9, 0),
(7379, 308, 10, 0),
(7380, 308, 11, 0),
(7381, 308, 12, 0),
(7382, 308, 13, 0),
(7383, 308, 14, 0),
(7384, 308, 15, 0),
(7385, 308, 16, 0),
(7386, 308, 17, 0),
(7387, 308, 18, 0),
(7388, 308, 19, 0),
(7389, 308, 20, 0),
(7390, 308, 21, 0),
(7391, 308, 22, 0),
(7392, 308, 23, 0),
(7393, 309, 0, 0),
(7394, 309, 1, 0),
(7395, 309, 2, 0),
(7396, 309, 3, 0),
(7397, 309, 4, 0),
(7398, 309, 5, 0),
(7399, 309, 6, 0),
(7400, 309, 7, 0),
(7401, 309, 8, 0),
(7402, 309, 9, 0),
(7403, 309, 10, 0),
(7404, 309, 11, 0),
(7405, 309, 12, 0),
(7406, 309, 13, 0),
(7407, 309, 14, 0),
(7408, 309, 15, 0),
(7409, 309, 16, 0),
(7410, 309, 17, 0),
(7411, 309, 18, 0),
(7412, 309, 19, 0),
(7413, 309, 20, 0),
(7414, 309, 21, 0),
(7415, 309, 22, 0),
(7416, 309, 23, 0),
(7417, 310, 0, 0),
(7418, 310, 1, 0),
(7419, 310, 2, 0),
(7420, 310, 3, 0),
(7421, 310, 4, 0),
(7422, 310, 5, 0),
(7423, 310, 6, 0),
(7424, 310, 7, 0),
(7425, 310, 8, 0),
(7426, 310, 9, 0),
(7427, 310, 10, 0),
(7428, 310, 11, 0),
(7429, 310, 12, 0),
(7430, 310, 13, 0),
(7431, 310, 14, 0),
(7432, 310, 15, 0),
(7433, 310, 16, 0),
(7434, 310, 17, 0),
(7435, 310, 18, 0),
(7436, 310, 19, 0),
(7437, 310, 20, 0),
(7438, 310, 21, 0),
(7439, 310, 22, 0),
(7440, 310, 23, 0),
(7441, 311, 0, 0),
(7442, 311, 1, 0),
(7443, 311, 2, 0),
(7444, 311, 3, 0),
(7445, 311, 4, 0),
(7446, 311, 5, 0),
(7447, 311, 6, 0),
(7448, 311, 7, 0),
(7449, 311, 8, 0),
(7450, 311, 9, 0),
(7451, 311, 10, 0),
(7452, 311, 11, 0),
(7453, 311, 12, 0),
(7454, 311, 13, 0),
(7455, 311, 14, 0),
(7456, 311, 15, 0),
(7457, 311, 16, 0),
(7458, 311, 17, 0),
(7459, 311, 18, 0),
(7460, 311, 19, 0),
(7461, 311, 20, 0),
(7462, 311, 21, 0),
(7463, 311, 22, 0),
(7464, 311, 23, 0),
(7465, 312, 0, 0),
(7466, 312, 1, 0),
(7467, 312, 2, 0),
(7468, 312, 3, 0),
(7469, 312, 4, 0),
(7470, 312, 5, 0),
(7471, 312, 6, 0),
(7472, 312, 7, 0),
(7473, 312, 8, 0),
(7474, 312, 9, 0),
(7475, 312, 10, 0),
(7476, 312, 11, 0),
(7477, 312, 12, 0),
(7478, 312, 13, 0),
(7479, 312, 14, 0),
(7480, 312, 15, 0),
(7481, 312, 16, 0),
(7482, 312, 17, 0),
(7483, 312, 18, 0),
(7484, 312, 19, 0),
(7485, 312, 20, 0),
(7486, 312, 21, 0),
(7487, 312, 22, 0),
(7488, 312, 23, 0),
(7489, 313, 0, 0),
(7490, 313, 1, 0),
(7491, 313, 2, 0),
(7492, 313, 3, 0),
(7493, 313, 4, 0),
(7494, 313, 5, 0),
(7495, 313, 6, 0),
(7496, 313, 7, 0),
(7497, 313, 8, 0),
(7498, 313, 9, 0),
(7499, 313, 10, 0),
(7500, 313, 11, 0),
(7501, 313, 12, 0),
(7502, 313, 13, 0),
(7503, 313, 14, 0),
(7504, 313, 15, 0),
(7505, 313, 16, 0),
(7506, 313, 17, 0),
(7507, 313, 18, 0),
(7508, 313, 19, 0),
(7509, 313, 20, 0),
(7510, 313, 21, 0),
(7511, 313, 22, 0),
(7512, 313, 23, 0),
(7513, 314, 0, 0),
(7514, 314, 1, 0),
(7515, 314, 2, 0),
(7516, 314, 3, 0),
(7517, 314, 4, 0),
(7518, 314, 5, 0),
(7519, 314, 6, 0),
(7520, 314, 7, 0),
(7521, 314, 8, 0),
(7522, 314, 9, 0),
(7523, 314, 10, 0),
(7524, 314, 11, 0),
(7525, 314, 12, 0),
(7526, 314, 13, 0),
(7527, 314, 14, 0),
(7528, 314, 15, 0),
(7529, 314, 16, 0),
(7530, 314, 17, 0),
(7531, 314, 18, 0),
(7532, 314, 19, 0),
(7533, 314, 20, 0),
(7534, 314, 21, 0),
(7535, 314, 22, 0),
(7536, 314, 23, 0),
(7537, 315, 0, 0),
(7538, 315, 1, 0),
(7539, 315, 2, 0),
(7540, 315, 3, 0),
(7541, 315, 4, 0),
(7542, 315, 5, 0),
(7543, 315, 6, 0),
(7544, 315, 7, 0),
(7545, 315, 8, 0),
(7546, 315, 9, 0),
(7547, 315, 10, 0),
(7548, 315, 11, 0),
(7549, 315, 12, 0),
(7550, 315, 13, 0),
(7551, 315, 14, 0),
(7552, 315, 15, 0),
(7553, 315, 16, 0),
(7554, 315, 17, 0),
(7555, 315, 18, 0),
(7556, 315, 19, 0),
(7557, 315, 20, 0),
(7558, 315, 21, 0),
(7559, 315, 22, 0),
(7560, 315, 23, 0),
(7561, 316, 0, 0),
(7562, 316, 1, 0),
(7563, 316, 2, 0),
(7564, 316, 3, 0),
(7565, 316, 4, 0),
(7566, 316, 5, 0),
(7567, 316, 6, 0),
(7568, 316, 7, 0),
(7569, 316, 8, 0),
(7570, 316, 9, 0),
(7571, 316, 10, 0),
(7572, 316, 11, 0),
(7573, 316, 12, 0),
(7574, 316, 13, 0),
(7575, 316, 14, 0),
(7576, 316, 15, 0),
(7577, 316, 16, 0),
(7578, 316, 17, 0),
(7579, 316, 18, 0),
(7580, 316, 19, 0),
(7581, 316, 20, 0),
(7582, 316, 21, 0),
(7583, 316, 22, 0),
(7584, 316, 23, 0),
(7585, 317, 0, 0),
(7586, 317, 1, 0),
(7587, 317, 2, 0),
(7588, 317, 3, 0),
(7589, 317, 4, 0),
(7590, 317, 5, 0),
(7591, 317, 6, 0),
(7592, 317, 7, 0),
(7593, 317, 8, 0),
(7594, 317, 9, 0),
(7595, 317, 10, 0),
(7596, 317, 11, 0),
(7597, 317, 12, 0),
(7598, 317, 13, 0),
(7599, 317, 14, 0),
(7600, 317, 15, 0),
(7601, 317, 16, 0),
(7602, 317, 17, 0),
(7603, 317, 18, 0),
(7604, 317, 19, 0),
(7605, 317, 20, 0),
(7606, 317, 21, 0),
(7607, 317, 22, 0),
(7608, 317, 23, 0),
(7609, 318, 0, 0),
(7610, 318, 1, 0),
(7611, 318, 2, 0),
(7612, 318, 3, 0),
(7613, 318, 4, 0),
(7614, 318, 5, 0),
(7615, 318, 6, 0),
(7616, 318, 7, 0),
(7617, 318, 8, 0),
(7618, 318, 9, 0),
(7619, 318, 10, 0),
(7620, 318, 11, 0),
(7621, 318, 12, 0),
(7622, 318, 13, 0),
(7623, 318, 14, 0),
(7624, 318, 15, 0),
(7625, 318, 16, 0),
(7626, 318, 17, 0),
(7627, 318, 18, 0),
(7628, 318, 19, 0),
(7629, 318, 20, 0),
(7630, 318, 21, 0),
(7631, 318, 22, 0),
(7632, 318, 23, 0),
(7633, 319, 0, 0),
(7634, 319, 1, 0),
(7635, 319, 2, 0),
(7636, 319, 3, 0),
(7637, 319, 4, 0),
(7638, 319, 5, 0),
(7639, 319, 6, 0),
(7640, 319, 7, 0),
(7641, 319, 8, 0),
(7642, 319, 9, 0),
(7643, 319, 10, 0),
(7644, 319, 11, 0),
(7645, 319, 12, 0),
(7646, 319, 13, 0),
(7647, 319, 14, 0),
(7648, 319, 15, 0),
(7649, 319, 16, 0),
(7650, 319, 17, 0),
(7651, 319, 18, 0),
(7652, 319, 19, 0),
(7653, 319, 20, 0),
(7654, 319, 21, 0),
(7655, 319, 22, 0),
(7656, 319, 23, 0),
(7657, 320, 0, 0),
(7658, 320, 1, 0),
(7659, 320, 2, 0),
(7660, 320, 3, 0),
(7661, 320, 4, 0),
(7662, 320, 5, 0),
(7663, 320, 6, 0),
(7664, 320, 7, 0),
(7665, 320, 8, 0),
(7666, 320, 9, 0),
(7667, 320, 10, 0),
(7668, 320, 11, 0),
(7669, 320, 12, 0),
(7670, 320, 13, 0),
(7671, 320, 14, 0),
(7672, 320, 15, 0),
(7673, 320, 16, 0),
(7674, 320, 17, 0),
(7675, 320, 18, 0),
(7676, 320, 19, 0),
(7677, 320, 20, 0),
(7678, 320, 21, 0),
(7679, 320, 22, 0),
(7680, 320, 23, 0),
(7681, 321, 0, 0),
(7682, 321, 1, 0),
(7683, 321, 2, 0),
(7684, 321, 3, 0),
(7685, 321, 4, 0),
(7686, 321, 5, 0),
(7687, 321, 6, 0),
(7688, 321, 7, 0),
(7689, 321, 8, 0),
(7690, 321, 9, 0),
(7691, 321, 10, 0),
(7692, 321, 11, 0),
(7693, 321, 12, 0),
(7694, 321, 13, 0),
(7695, 321, 14, 0),
(7696, 321, 15, 0),
(7697, 321, 16, 0),
(7698, 321, 17, 0),
(7699, 321, 18, 0),
(7700, 321, 19, 0),
(7701, 321, 20, 0),
(7702, 321, 21, 0),
(7703, 321, 22, 0),
(7704, 321, 23, 0),
(7705, 322, 0, 0),
(7706, 322, 1, 0),
(7707, 322, 2, 0),
(7708, 322, 3, 0),
(7709, 322, 4, 0),
(7710, 322, 5, 0),
(7711, 322, 6, 0),
(7712, 322, 7, 0),
(7713, 322, 8, 0),
(7714, 322, 9, 0),
(7715, 322, 10, 0),
(7716, 322, 11, 0),
(7717, 322, 12, 0),
(7718, 322, 13, 0),
(7719, 322, 14, 0),
(7720, 322, 15, 0),
(7721, 322, 16, 0),
(7722, 322, 17, 0),
(7723, 322, 18, 0),
(7724, 322, 19, 0),
(7725, 322, 20, 0),
(7726, 322, 21, 0),
(7727, 322, 22, 0),
(7728, 322, 23, 0),
(7729, 323, 0, 0),
(7730, 323, 1, 0),
(7731, 323, 2, 0),
(7732, 323, 3, 0),
(7733, 323, 4, 0),
(7734, 323, 5, 0),
(7735, 323, 6, 0),
(7736, 323, 7, 0),
(7737, 323, 8, 0),
(7738, 323, 9, 0),
(7739, 323, 10, 0),
(7740, 323, 11, 0),
(7741, 323, 12, 0),
(7742, 323, 13, 0),
(7743, 323, 14, 0),
(7744, 323, 15, 0),
(7745, 323, 16, 0),
(7746, 323, 17, 0),
(7747, 323, 18, 0),
(7748, 323, 19, 0),
(7749, 323, 20, 0),
(7750, 323, 21, 0),
(7751, 323, 22, 0),
(7752, 323, 23, 0),
(7753, 324, 0, 0),
(7754, 324, 1, 0),
(7755, 324, 2, 0),
(7756, 324, 3, 0),
(7757, 324, 4, 0),
(7758, 324, 5, 0),
(7759, 324, 6, 0),
(7760, 324, 7, 0),
(7761, 324, 8, 0),
(7762, 324, 9, 0),
(7763, 324, 10, 0),
(7764, 324, 11, 0),
(7765, 324, 12, 0),
(7766, 324, 13, 0),
(7767, 324, 14, 0),
(7768, 324, 15, 0),
(7769, 324, 16, 0),
(7770, 324, 17, 0),
(7771, 324, 18, 0),
(7772, 324, 19, 0),
(7773, 324, 20, 0),
(7774, 324, 21, 0),
(7775, 324, 22, 0),
(7776, 324, 23, 0),
(7777, 325, 0, 0),
(7778, 325, 1, 0),
(7779, 325, 2, 0),
(7780, 325, 3, 0),
(7781, 325, 4, 0),
(7782, 325, 5, 0),
(7783, 325, 6, 0),
(7784, 325, 7, 0),
(7785, 325, 8, 0),
(7786, 325, 9, 0),
(7787, 325, 10, 0),
(7788, 325, 11, 0),
(7789, 325, 12, 0),
(7790, 325, 13, 0),
(7791, 325, 14, 0),
(7792, 325, 15, 0),
(7793, 325, 16, 0),
(7794, 325, 17, 0),
(7795, 325, 18, 0),
(7796, 325, 19, 0),
(7797, 325, 20, 0),
(7798, 325, 21, 0),
(7799, 325, 22, 0),
(7800, 325, 23, 0),
(7801, 326, 0, 0),
(7802, 326, 1, 0),
(7803, 326, 2, 0),
(7804, 326, 3, 0),
(7805, 326, 4, 0),
(7806, 326, 5, 0),
(7807, 326, 6, 0),
(7808, 326, 7, 0),
(7809, 326, 8, 0),
(7810, 326, 9, 0),
(7811, 326, 10, 0),
(7812, 326, 11, 0),
(7813, 326, 12, 0),
(7814, 326, 13, 0),
(7815, 326, 14, 0),
(7816, 326, 15, 0),
(7817, 326, 16, 0),
(7818, 326, 17, 0),
(7819, 326, 18, 0),
(7820, 326, 19, 0),
(7821, 326, 20, 0),
(7822, 326, 21, 0),
(7823, 326, 22, 0),
(7824, 326, 23, 0),
(7825, 327, 0, 0),
(7826, 327, 1, 0),
(7827, 327, 2, 0),
(7828, 327, 3, 0),
(7829, 327, 4, 0),
(7830, 327, 5, 0),
(7831, 327, 6, 0),
(7832, 327, 7, 0),
(7833, 327, 8, 0),
(7834, 327, 9, 0),
(7835, 327, 10, 0),
(7836, 327, 11, 0),
(7837, 327, 12, 0),
(7838, 327, 13, 0),
(7839, 327, 14, 0),
(7840, 327, 15, 0),
(7841, 327, 16, 0),
(7842, 327, 17, 0),
(7843, 327, 18, 0),
(7844, 327, 19, 0),
(7845, 327, 20, 0),
(7846, 327, 21, 0),
(7847, 327, 22, 0),
(7848, 327, 23, 0),
(7849, 328, 0, 0),
(7850, 328, 1, 0),
(7851, 328, 2, 0),
(7852, 328, 3, 0),
(7853, 328, 4, 0),
(7854, 328, 5, 0),
(7855, 328, 6, 0),
(7856, 328, 7, 0),
(7857, 328, 8, 0),
(7858, 328, 9, 0),
(7859, 328, 10, 0),
(7860, 328, 11, 0),
(7861, 328, 12, 0),
(7862, 328, 13, 0),
(7863, 328, 14, 0),
(7864, 328, 15, 0),
(7865, 328, 16, 0),
(7866, 328, 17, 0),
(7867, 328, 18, 0),
(7868, 328, 19, 0),
(7869, 328, 20, 0),
(7870, 328, 21, 0),
(7871, 328, 22, 0),
(7872, 328, 23, 0),
(7873, 329, 0, 0),
(7874, 329, 1, 0),
(7875, 329, 2, 0),
(7876, 329, 3, 0),
(7877, 329, 4, 0),
(7878, 329, 5, 0),
(7879, 329, 6, 0),
(7880, 329, 7, 0),
(7881, 329, 8, 0),
(7882, 329, 9, 0),
(7883, 329, 10, 0),
(7884, 329, 11, 0),
(7885, 329, 12, 0),
(7886, 329, 13, 0),
(7887, 329, 14, 0),
(7888, 329, 15, 0),
(7889, 329, 16, 0),
(7890, 329, 17, 0),
(7891, 329, 18, 0),
(7892, 329, 19, 0),
(7893, 329, 20, 0),
(7894, 329, 21, 0),
(7895, 329, 22, 0),
(7896, 329, 23, 0),
(7897, 330, 0, 0),
(7898, 330, 1, 0),
(7899, 330, 2, 0),
(7900, 330, 3, 0),
(7901, 330, 4, 0),
(7902, 330, 5, 0),
(7903, 330, 6, 0),
(7904, 330, 7, 0),
(7905, 330, 8, 0),
(7906, 330, 9, 0),
(7907, 330, 10, 0),
(7908, 330, 11, 0),
(7909, 330, 12, 0),
(7910, 330, 13, 0),
(7911, 330, 14, 0),
(7912, 330, 15, 0),
(7913, 330, 16, 0),
(7914, 330, 17, 0),
(7915, 330, 18, 0),
(7916, 330, 19, 0),
(7917, 330, 20, 0),
(7918, 330, 21, 0),
(7919, 330, 22, 0),
(7920, 330, 23, 0),
(7921, 331, 0, 0),
(7922, 331, 1, 0),
(7923, 331, 2, 0),
(7924, 331, 3, 0),
(7925, 331, 4, 0),
(7926, 331, 5, 0),
(7927, 331, 6, 0),
(7928, 331, 7, 0),
(7929, 331, 8, 0),
(7930, 331, 9, 0),
(7931, 331, 10, 0),
(7932, 331, 11, 0),
(7933, 331, 12, 0),
(7934, 331, 13, 0),
(7935, 331, 14, 0),
(7936, 331, 15, 0),
(7937, 331, 16, 0),
(7938, 331, 17, 0),
(7939, 331, 18, 0),
(7940, 331, 19, 0),
(7941, 331, 20, 0),
(7942, 331, 21, 0),
(7943, 331, 22, 0),
(7944, 331, 23, 0),
(7945, 332, 0, 0),
(7946, 332, 1, 0),
(7947, 332, 2, 0),
(7948, 332, 3, 0),
(7949, 332, 4, 0),
(7950, 332, 5, 0),
(7951, 332, 6, 0),
(7952, 332, 7, 0),
(7953, 332, 8, 0),
(7954, 332, 9, 0),
(7955, 332, 10, 0),
(7956, 332, 11, 0),
(7957, 332, 12, 0),
(7958, 332, 13, 0),
(7959, 332, 14, 0),
(7960, 332, 15, 0),
(7961, 332, 16, 0),
(7962, 332, 17, 0),
(7963, 332, 18, 0),
(7964, 332, 19, 0),
(7965, 332, 20, 0),
(7966, 332, 21, 0),
(7967, 332, 22, 0),
(7968, 332, 23, 0),
(7969, 333, 0, 0),
(7970, 333, 1, 0),
(7971, 333, 2, 0),
(7972, 333, 3, 0),
(7973, 333, 4, 0),
(7974, 333, 5, 0),
(7975, 333, 6, 0),
(7976, 333, 7, 0),
(7977, 333, 8, 0),
(7978, 333, 9, 0),
(7979, 333, 10, 0),
(7980, 333, 11, 0),
(7981, 333, 12, 0),
(7982, 333, 13, 0),
(7983, 333, 14, 0),
(7984, 333, 15, 0),
(7985, 333, 16, 0),
(7986, 333, 17, 0),
(7987, 333, 18, 0),
(7988, 333, 19, 0),
(7989, 333, 20, 0),
(7990, 333, 21, 0),
(7991, 333, 22, 0),
(7992, 333, 23, 0),
(7993, 334, 0, 0),
(7994, 334, 1, 0),
(7995, 334, 2, 0),
(7996, 334, 3, 0),
(7997, 334, 4, 0),
(7998, 334, 5, 0),
(7999, 334, 6, 0),
(8000, 334, 7, 0),
(8001, 334, 8, 0),
(8002, 334, 9, 0),
(8003, 334, 10, 0),
(8004, 334, 11, 0),
(8005, 334, 12, 0),
(8006, 334, 13, 0),
(8007, 334, 14, 0),
(8008, 334, 15, 0),
(8009, 334, 16, 0),
(8010, 334, 17, 0),
(8011, 334, 18, 0),
(8012, 334, 19, 0),
(8013, 334, 20, 0),
(8014, 334, 21, 0),
(8015, 334, 22, 0),
(8016, 334, 23, 0),
(8017, 335, 0, 0),
(8018, 335, 1, 0),
(8019, 335, 2, 0),
(8020, 335, 3, 0),
(8021, 335, 4, 0),
(8022, 335, 5, 0),
(8023, 335, 6, 0),
(8024, 335, 7, 0),
(8025, 335, 8, 0),
(8026, 335, 9, 0),
(8027, 335, 10, 0),
(8028, 335, 11, 0),
(8029, 335, 12, 0),
(8030, 335, 13, 0),
(8031, 335, 14, 0),
(8032, 335, 15, 0),
(8033, 335, 16, 0),
(8034, 335, 17, 0),
(8035, 335, 18, 0),
(8036, 335, 19, 0),
(8037, 335, 20, 0),
(8038, 335, 21, 0),
(8039, 335, 22, 0),
(8040, 335, 23, 0),
(8041, 336, 0, 0),
(8042, 336, 1, 0),
(8043, 336, 2, 0),
(8044, 336, 3, 0),
(8045, 336, 4, 0),
(8046, 336, 5, 0),
(8047, 336, 6, 0),
(8048, 336, 7, 0),
(8049, 336, 8, 0),
(8050, 336, 9, 0),
(8051, 336, 10, 0),
(8052, 336, 11, 0),
(8053, 336, 12, 0),
(8054, 336, 13, 0),
(8055, 336, 14, 0),
(8056, 336, 15, 0),
(8057, 336, 16, 0),
(8058, 336, 17, 0),
(8059, 336, 18, 0),
(8060, 336, 19, 0),
(8061, 336, 20, 0),
(8062, 336, 21, 0),
(8063, 336, 22, 0),
(8064, 336, 23, 0),
(8065, 337, 0, 0),
(8066, 337, 1, 0),
(8067, 337, 2, 0),
(8068, 337, 3, 0),
(8069, 337, 4, 0),
(8070, 337, 5, 0),
(8071, 337, 6, 0),
(8072, 337, 7, 0),
(8073, 337, 8, 0),
(8074, 337, 9, 0),
(8075, 337, 10, 0),
(8076, 337, 11, 0),
(8077, 337, 12, 0),
(8078, 337, 13, 0),
(8079, 337, 14, 0),
(8080, 337, 15, 0),
(8081, 337, 16, 0),
(8082, 337, 17, 0),
(8083, 337, 18, 0),
(8084, 337, 19, 0),
(8085, 337, 20, 0),
(8086, 337, 21, 0),
(8087, 337, 22, 0),
(8088, 337, 23, 0),
(8089, 338, 0, 0),
(8090, 338, 1, 0),
(8091, 338, 2, 0),
(8092, 338, 3, 0),
(8093, 338, 4, 0),
(8094, 338, 5, 0),
(8095, 338, 6, 0),
(8096, 338, 7, 0),
(8097, 338, 8, 0),
(8098, 338, 9, 0),
(8099, 338, 10, 0),
(8100, 338, 11, 0),
(8101, 338, 12, 0),
(8102, 338, 13, 0),
(8103, 338, 14, 0),
(8104, 338, 15, 0),
(8105, 338, 16, 0),
(8106, 338, 17, 0),
(8107, 338, 18, 0),
(8108, 338, 19, 0),
(8109, 338, 20, 0),
(8110, 338, 21, 0),
(8111, 338, 22, 0),
(8112, 338, 23, 0),
(8113, 339, 0, 0),
(8114, 339, 1, 0),
(8115, 339, 2, 0),
(8116, 339, 3, 0),
(8117, 339, 4, 0),
(8118, 339, 5, 0),
(8119, 339, 6, 0),
(8120, 339, 7, 0),
(8121, 339, 8, 0),
(8122, 339, 9, 0),
(8123, 339, 10, 0),
(8124, 339, 11, 0),
(8125, 339, 12, 0),
(8126, 339, 13, 0),
(8127, 339, 14, 0),
(8128, 339, 15, 0),
(8129, 339, 16, 0),
(8130, 339, 17, 0),
(8131, 339, 18, 0),
(8132, 339, 19, 0),
(8133, 339, 20, 0),
(8134, 339, 21, 0),
(8135, 339, 22, 0),
(8136, 339, 23, 0),
(8137, 340, 0, 0),
(8138, 340, 1, 0),
(8139, 340, 2, 0),
(8140, 340, 3, 0),
(8141, 340, 4, 0),
(8142, 340, 5, 0),
(8143, 340, 6, 0),
(8144, 340, 7, 0),
(8145, 340, 8, 0),
(8146, 340, 9, 0),
(8147, 340, 10, 0),
(8148, 340, 11, 0),
(8149, 340, 12, 0),
(8150, 340, 13, 0),
(8151, 340, 14, 0),
(8152, 340, 15, 0),
(8153, 340, 16, 0),
(8154, 340, 17, 0),
(8155, 340, 18, 0),
(8156, 340, 19, 0),
(8157, 340, 20, 0),
(8158, 340, 21, 0),
(8159, 340, 22, 0),
(8160, 340, 23, 0),
(8161, 341, 0, 0),
(8162, 341, 1, 0),
(8163, 341, 2, 0),
(8164, 341, 3, 0),
(8165, 341, 4, 0),
(8166, 341, 5, 0),
(8167, 341, 6, 0),
(8168, 341, 7, 0),
(8169, 341, 8, 0),
(8170, 341, 9, 0),
(8171, 341, 10, 0),
(8172, 341, 11, 0),
(8173, 341, 12, 0),
(8174, 341, 13, 0),
(8175, 341, 14, 0),
(8176, 341, 15, 0),
(8177, 341, 16, 0),
(8178, 341, 17, 0),
(8179, 341, 18, 0),
(8180, 341, 19, 0),
(8181, 341, 20, 0),
(8182, 341, 21, 0),
(8183, 341, 22, 0),
(8184, 341, 23, 0),
(8185, 342, 0, 0),
(8186, 342, 1, 0),
(8187, 342, 2, 0),
(8188, 342, 3, 0),
(8189, 342, 4, 0),
(8190, 342, 5, 0),
(8191, 342, 6, 0),
(8192, 342, 7, 0),
(8193, 342, 8, 0),
(8194, 342, 9, 0),
(8195, 342, 10, 0),
(8196, 342, 11, 0),
(8197, 342, 12, 0),
(8198, 342, 13, 0),
(8199, 342, 14, 0),
(8200, 342, 15, 0),
(8201, 342, 16, 0),
(8202, 342, 17, 0),
(8203, 342, 18, 0),
(8204, 342, 19, 0),
(8205, 342, 20, 0),
(8206, 342, 21, 0),
(8207, 342, 22, 0),
(8208, 342, 23, 0),
(8209, 343, 0, 0),
(8210, 343, 1, 0),
(8211, 343, 2, 0),
(8212, 343, 3, 0),
(8213, 343, 4, 0),
(8214, 343, 5, 0),
(8215, 343, 6, 0),
(8216, 343, 7, 0),
(8217, 343, 8, 0),
(8218, 343, 9, 0),
(8219, 343, 10, 0),
(8220, 343, 11, 0),
(8221, 343, 12, 0),
(8222, 343, 13, 0),
(8223, 343, 14, 0),
(8224, 343, 15, 0),
(8225, 343, 16, 0),
(8226, 343, 17, 0),
(8227, 343, 18, 0),
(8228, 343, 19, 0),
(8229, 343, 20, 0),
(8230, 343, 21, 0),
(8231, 343, 22, 0),
(8232, 343, 23, 0),
(8233, 344, 0, 0),
(8234, 344, 1, 0),
(8235, 344, 2, 0),
(8236, 344, 3, 0),
(8237, 344, 4, 0),
(8238, 344, 5, 0),
(8239, 344, 6, 0),
(8240, 344, 7, 0),
(8241, 344, 8, 0),
(8242, 344, 9, 0),
(8243, 344, 10, 0),
(8244, 344, 11, 0),
(8245, 344, 12, 0),
(8246, 344, 13, 0),
(8247, 344, 14, 0),
(8248, 344, 15, 0),
(8249, 344, 16, 0),
(8250, 344, 17, 0),
(8251, 344, 18, 0),
(8252, 344, 19, 0),
(8253, 344, 20, 0),
(8254, 344, 21, 0),
(8255, 344, 22, 0),
(8256, 344, 23, 0),
(8257, 345, 0, 0),
(8258, 345, 1, 0),
(8259, 345, 2, 0),
(8260, 345, 3, 0),
(8261, 345, 4, 0),
(8262, 345, 5, 0),
(8263, 345, 6, 0),
(8264, 345, 7, 0),
(8265, 345, 8, 0),
(8266, 345, 9, 0),
(8267, 345, 10, 0),
(8268, 345, 11, 0),
(8269, 345, 12, 0),
(8270, 345, 13, 0),
(8271, 345, 14, 0),
(8272, 345, 15, 0),
(8273, 345, 16, 0),
(8274, 345, 17, 0),
(8275, 345, 18, 0),
(8276, 345, 19, 0),
(8277, 345, 20, 0),
(8278, 345, 21, 0),
(8279, 345, 22, 0),
(8280, 345, 23, 0),
(8281, 346, 0, 0),
(8282, 346, 1, 0),
(8283, 346, 2, 0),
(8284, 346, 3, 0),
(8285, 346, 4, 0),
(8286, 346, 5, 0),
(8287, 346, 6, 0),
(8288, 346, 7, 0),
(8289, 346, 8, 0),
(8290, 346, 9, 0),
(8291, 346, 10, 0),
(8292, 346, 11, 0),
(8293, 346, 12, 0),
(8294, 346, 13, 0),
(8295, 346, 14, 0),
(8296, 346, 15, 0),
(8297, 346, 16, 0),
(8298, 346, 17, 0),
(8299, 346, 18, 0),
(8300, 346, 19, 0),
(8301, 346, 20, 0),
(8302, 346, 21, 0),
(8303, 346, 22, 0),
(8304, 346, 23, 0),
(8305, 347, 0, 0),
(8306, 347, 1, 0),
(8307, 347, 2, 0),
(8308, 347, 3, 0),
(8309, 347, 4, 0),
(8310, 347, 5, 0),
(8311, 347, 6, 0),
(8312, 347, 7, 0),
(8313, 347, 8, 0),
(8314, 347, 9, 0),
(8315, 347, 10, 0),
(8316, 347, 11, 0),
(8317, 347, 12, 0),
(8318, 347, 13, 0),
(8319, 347, 14, 0),
(8320, 347, 15, 0),
(8321, 347, 16, 0),
(8322, 347, 17, 0),
(8323, 347, 18, 0),
(8324, 347, 19, 0),
(8325, 347, 20, 0),
(8326, 347, 21, 0),
(8327, 347, 22, 0),
(8328, 347, 23, 0),
(8329, 348, 0, 0),
(8330, 348, 1, 0),
(8331, 348, 2, 0),
(8332, 348, 3, 0),
(8333, 348, 4, 0),
(8334, 348, 5, 0),
(8335, 348, 6, 0),
(8336, 348, 7, 0),
(8337, 348, 8, 0),
(8338, 348, 9, 0),
(8339, 348, 10, 0),
(8340, 348, 11, 0),
(8341, 348, 12, 0),
(8342, 348, 13, 0),
(8343, 348, 14, 0),
(8344, 348, 15, 0),
(8345, 348, 16, 0),
(8346, 348, 17, 0),
(8347, 348, 18, 0),
(8348, 348, 19, 0),
(8349, 348, 20, 0),
(8350, 348, 21, 0),
(8351, 348, 22, 0),
(8352, 348, 23, 0),
(8353, 349, 0, 0),
(8354, 349, 1, 0),
(8355, 349, 2, 0),
(8356, 349, 3, 0),
(8357, 349, 4, 0),
(8358, 349, 5, 0),
(8359, 349, 6, 0),
(8360, 349, 7, 0),
(8361, 349, 8, 0),
(8362, 349, 9, 0),
(8363, 349, 10, 0),
(8364, 349, 11, 0),
(8365, 349, 12, 0),
(8366, 349, 13, 0),
(8367, 349, 14, 0),
(8368, 349, 15, 0),
(8369, 349, 16, 0),
(8370, 349, 17, 0),
(8371, 349, 18, 0),
(8372, 349, 19, 0),
(8373, 349, 20, 0),
(8374, 349, 21, 0),
(8375, 349, 22, 0),
(8376, 349, 23, 0),
(8377, 350, 0, 0),
(8378, 350, 1, 0),
(8379, 350, 2, 0),
(8380, 350, 3, 0),
(8381, 350, 4, 0),
(8382, 350, 5, 0),
(8383, 350, 6, 0),
(8384, 350, 7, 0),
(8385, 350, 8, 0),
(8386, 350, 9, 0),
(8387, 350, 10, 0),
(8388, 350, 11, 0),
(8389, 350, 12, 0),
(8390, 350, 13, 0),
(8391, 350, 14, 0),
(8392, 350, 15, 0),
(8393, 350, 16, 0),
(8394, 350, 17, 0),
(8395, 350, 18, 0),
(8396, 350, 19, 0),
(8397, 350, 20, 0),
(8398, 350, 21, 0),
(8399, 350, 22, 0),
(8400, 350, 23, 0),
(8401, 351, 0, 0),
(8402, 351, 1, 0),
(8403, 351, 2, 0),
(8404, 351, 3, 0),
(8405, 351, 4, 0),
(8406, 351, 5, 0),
(8407, 351, 6, 0),
(8408, 351, 7, 0),
(8409, 351, 8, 0),
(8410, 351, 9, 0),
(8411, 351, 10, 0),
(8412, 351, 11, 0),
(8413, 351, 12, 0),
(8414, 351, 13, 0),
(8415, 351, 14, 0),
(8416, 351, 15, 0),
(8417, 351, 16, 0),
(8418, 351, 17, 0),
(8419, 351, 18, 0),
(8420, 351, 19, 0),
(8421, 351, 20, 0),
(8422, 351, 21, 0),
(8423, 351, 22, 0),
(8424, 351, 23, 0),
(8425, 352, 0, 0),
(8426, 352, 1, 0),
(8427, 352, 2, 0),
(8428, 352, 3, 0),
(8429, 352, 4, 0),
(8430, 352, 5, 0),
(8431, 352, 6, 0),
(8432, 352, 7, 0),
(8433, 352, 8, 0),
(8434, 352, 9, 0),
(8435, 352, 10, 0),
(8436, 352, 11, 0),
(8437, 352, 12, 0),
(8438, 352, 13, 0),
(8439, 352, 14, 0),
(8440, 352, 15, 0),
(8441, 352, 16, 0),
(8442, 352, 17, 0),
(8443, 352, 18, 0),
(8444, 352, 19, 0),
(8445, 352, 20, 0),
(8446, 352, 21, 0),
(8447, 352, 22, 0),
(8448, 352, 23, 0),
(8449, 353, 0, 0),
(8450, 353, 1, 0),
(8451, 353, 2, 0),
(8452, 353, 3, 0),
(8453, 353, 4, 0),
(8454, 353, 5, 0),
(8455, 353, 6, 0),
(8456, 353, 7, 0),
(8457, 353, 8, 0),
(8458, 353, 9, 0),
(8459, 353, 10, 0),
(8460, 353, 11, 0),
(8461, 353, 12, 0),
(8462, 353, 13, 0),
(8463, 353, 14, 0),
(8464, 353, 15, 0),
(8465, 353, 16, 0),
(8466, 353, 17, 0),
(8467, 353, 18, 0),
(8468, 353, 19, 0),
(8469, 353, 20, 0),
(8470, 353, 21, 0),
(8471, 353, 22, 0),
(8472, 353, 23, 0),
(8473, 354, 0, 0),
(8474, 354, 1, 0),
(8475, 354, 2, 0),
(8476, 354, 3, 0),
(8477, 354, 4, 0),
(8478, 354, 5, 0),
(8479, 354, 6, 0),
(8480, 354, 7, 0),
(8481, 354, 8, 0),
(8482, 354, 9, 0),
(8483, 354, 10, 0),
(8484, 354, 11, 0),
(8485, 354, 12, 0),
(8486, 354, 13, 0),
(8487, 354, 14, 0),
(8488, 354, 15, 0),
(8489, 354, 16, 0),
(8490, 354, 17, 0),
(8491, 354, 18, 0),
(8492, 354, 19, 0),
(8493, 354, 20, 0),
(8494, 354, 21, 0),
(8495, 354, 22, 0),
(8496, 354, 23, 0),
(8497, 355, 0, 0),
(8498, 355, 1, 0),
(8499, 355, 2, 0),
(8500, 355, 3, 0),
(8501, 355, 4, 0),
(8502, 355, 5, 0),
(8503, 355, 6, 0),
(8504, 355, 7, 0),
(8505, 355, 8, 0),
(8506, 355, 9, 0),
(8507, 355, 10, 0),
(8508, 355, 11, 0),
(8509, 355, 12, 0),
(8510, 355, 13, 0),
(8511, 355, 14, 0),
(8512, 355, 15, 0),
(8513, 355, 16, 0),
(8514, 355, 17, 0),
(8515, 355, 18, 0),
(8516, 355, 19, 0),
(8517, 355, 20, 0),
(8518, 355, 21, 0),
(8519, 355, 22, 0),
(8520, 355, 23, 0),
(8521, 356, 0, 0),
(8522, 356, 1, 0),
(8523, 356, 2, 0),
(8524, 356, 3, 0),
(8525, 356, 4, 0),
(8526, 356, 5, 0),
(8527, 356, 6, 0),
(8528, 356, 7, 0),
(8529, 356, 8, 0),
(8530, 356, 9, 0),
(8531, 356, 10, 0),
(8532, 356, 11, 0),
(8533, 356, 12, 0),
(8534, 356, 13, 0),
(8535, 356, 14, 0),
(8536, 356, 15, 0),
(8537, 356, 16, 0),
(8538, 356, 17, 0),
(8539, 356, 18, 0),
(8540, 356, 19, 0),
(8541, 356, 20, 0),
(8542, 356, 21, 0),
(8543, 356, 22, 0),
(8544, 356, 23, 0),
(8545, 357, 0, 0),
(8546, 357, 1, 0),
(8547, 357, 2, 0),
(8548, 357, 3, 0),
(8549, 357, 4, 0),
(8550, 357, 5, 0),
(8551, 357, 6, 0),
(8552, 357, 7, 0),
(8553, 357, 8, 0),
(8554, 357, 9, 0),
(8555, 357, 10, 0),
(8556, 357, 11, 0),
(8557, 357, 12, 0),
(8558, 357, 13, 0),
(8559, 357, 14, 0),
(8560, 357, 15, 0),
(8561, 357, 16, 0),
(8562, 357, 17, 0),
(8563, 357, 18, 0),
(8564, 357, 19, 0),
(8565, 357, 20, 0),
(8566, 357, 21, 0),
(8567, 357, 22, 0),
(8568, 357, 23, 0),
(8569, 358, 0, 0),
(8570, 358, 1, 0),
(8571, 358, 2, 0),
(8572, 358, 3, 0),
(8573, 358, 4, 0),
(8574, 358, 5, 0),
(8575, 358, 6, 0),
(8576, 358, 7, 0),
(8577, 358, 8, 0),
(8578, 358, 9, 0),
(8579, 358, 10, 0),
(8580, 358, 11, 0),
(8581, 358, 12, 0),
(8582, 358, 13, 0),
(8583, 358, 14, 0),
(8584, 358, 15, 0),
(8585, 358, 16, 0),
(8586, 358, 17, 0),
(8587, 358, 18, 0),
(8588, 358, 19, 0),
(8589, 358, 20, 0),
(8590, 358, 21, 0),
(8591, 358, 22, 0),
(8592, 358, 23, 0),
(8593, 359, 0, 0),
(8594, 359, 1, 0),
(8595, 359, 2, 0),
(8596, 359, 3, 0),
(8597, 359, 4, 0),
(8598, 359, 5, 0),
(8599, 359, 6, 0),
(8600, 359, 7, 0),
(8601, 359, 8, 0),
(8602, 359, 9, 0),
(8603, 359, 10, 0),
(8604, 359, 11, 0),
(8605, 359, 12, 0),
(8606, 359, 13, 0),
(8607, 359, 14, 0),
(8608, 359, 15, 0),
(8609, 359, 16, 0),
(8610, 359, 17, 0),
(8611, 359, 18, 0),
(8612, 359, 19, 0),
(8613, 359, 20, 0),
(8614, 359, 21, 0),
(8615, 359, 22, 0),
(8616, 359, 23, 0),
(8617, 360, 0, 0),
(8618, 360, 1, 0),
(8619, 360, 2, 0),
(8620, 360, 3, 0),
(8621, 360, 4, 0),
(8622, 360, 5, 0),
(8623, 360, 6, 0),
(8624, 360, 7, 0),
(8625, 360, 8, 0),
(8626, 360, 9, 0),
(8627, 360, 10, 0),
(8628, 360, 11, 0),
(8629, 360, 12, 0),
(8630, 360, 13, 0),
(8631, 360, 14, 0),
(8632, 360, 15, 0),
(8633, 360, 16, 0),
(8634, 360, 17, 0),
(8635, 360, 18, 0),
(8636, 360, 19, 0),
(8637, 360, 20, 0),
(8638, 360, 21, 0),
(8639, 360, 22, 0),
(8640, 360, 23, 0),
(8641, 361, 0, 0),
(8642, 361, 1, 0),
(8643, 361, 2, 0),
(8644, 361, 3, 0),
(8645, 361, 4, 0),
(8646, 361, 5, 0),
(8647, 361, 6, 0),
(8648, 361, 7, 0),
(8649, 361, 8, 0),
(8650, 361, 9, 0),
(8651, 361, 10, 0),
(8652, 361, 11, 0),
(8653, 361, 12, 0),
(8654, 361, 13, 0),
(8655, 361, 14, 0),
(8656, 361, 15, 0),
(8657, 361, 16, 0),
(8658, 361, 17, 0),
(8659, 361, 18, 0),
(8660, 361, 19, 0),
(8661, 361, 20, 0),
(8662, 361, 21, 0),
(8663, 361, 22, 0),
(8664, 361, 23, 0),
(8665, 362, 0, 0),
(8666, 362, 1, 0),
(8667, 362, 2, 0),
(8668, 362, 3, 0),
(8669, 362, 4, 0),
(8670, 362, 5, 0),
(8671, 362, 6, 0),
(8672, 362, 7, 0),
(8673, 362, 8, 0),
(8674, 362, 9, 0),
(8675, 362, 10, 0),
(8676, 362, 11, 0),
(8677, 362, 12, 0),
(8678, 362, 13, 0),
(8679, 362, 14, 0),
(8680, 362, 15, 0),
(8681, 362, 16, 0),
(8682, 362, 17, 0),
(8683, 362, 18, 0),
(8684, 362, 19, 0),
(8685, 362, 20, 0),
(8686, 362, 21, 0),
(8687, 362, 22, 0),
(8688, 362, 23, 0),
(8689, 363, 0, 0),
(8690, 363, 1, 0),
(8691, 363, 2, 0),
(8692, 363, 3, 0),
(8693, 363, 4, 0),
(8694, 363, 5, 0),
(8695, 363, 6, 0),
(8696, 363, 7, 0),
(8697, 363, 8, 0),
(8698, 363, 9, 0),
(8699, 363, 10, 0),
(8700, 363, 11, 0),
(8701, 363, 12, 0),
(8702, 363, 13, 0),
(8703, 363, 14, 0),
(8704, 363, 15, 0),
(8705, 363, 16, 0),
(8706, 363, 17, 0),
(8707, 363, 18, 0),
(8708, 363, 19, 0),
(8709, 363, 20, 0),
(8710, 363, 21, 0),
(8711, 363, 22, 0),
(8712, 363, 23, 0),
(8713, 364, 0, 0),
(8714, 364, 1, 0),
(8715, 364, 2, 0),
(8716, 364, 3, 0),
(8717, 364, 4, 0),
(8718, 364, 5, 0),
(8719, 364, 6, 0),
(8720, 364, 7, 0),
(8721, 364, 8, 0),
(8722, 364, 9, 0);
INSERT INTO `glpi_plugin_glpiinventory_inventorycomputerstats` (`id`, `day`, `hour`, `counter`) VALUES
(8723, 364, 10, 0),
(8724, 364, 11, 0),
(8725, 364, 12, 0),
(8726, 364, 13, 0),
(8727, 364, 14, 0),
(8728, 364, 15, 0),
(8729, 364, 16, 0),
(8730, 364, 17, 0),
(8731, 364, 18, 0),
(8732, 364, 19, 0),
(8733, 364, 20, 0),
(8734, 364, 21, 0),
(8735, 364, 22, 0),
(8736, 364, 23, 0),
(8737, 365, 0, 0),
(8738, 365, 1, 0),
(8739, 365, 2, 0),
(8740, 365, 3, 0),
(8741, 365, 4, 0),
(8742, 365, 5, 0),
(8743, 365, 6, 0),
(8744, 365, 7, 0),
(8745, 365, 8, 0),
(8746, 365, 9, 0),
(8747, 365, 10, 0),
(8748, 365, 11, 0),
(8749, 365, 12, 0),
(8750, 365, 13, 0),
(8751, 365, 14, 0),
(8752, 365, 15, 0),
(8753, 365, 16, 0),
(8754, 365, 17, 0),
(8755, 365, 18, 0),
(8756, 365, 19, 0),
(8757, 365, 20, 0),
(8758, 365, 21, 0),
(8759, 365, 22, 0),
(8760, 365, 23, 0);

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_ipranges`;
CREATE TABLE `glpi_plugin_glpiinventory_ipranges` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ip_start` varchar(255) DEFAULT NULL,
  `ip_end` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_ipranges_snmpcredentials`;
CREATE TABLE `glpi_plugin_glpiinventory_ipranges_snmpcredentials` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_ipranges_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `snmpcredentials_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `rank` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_statediscoveries`;
CREATE TABLE `glpi_plugin_glpiinventory_statediscoveries` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_taskjob_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `agents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `threads` int(11) NOT NULL DEFAULT 0,
  `nb_ip` int(11) NOT NULL DEFAULT 0,
  `nb_found` int(11) NOT NULL DEFAULT 0,
  `nb_error` int(11) NOT NULL DEFAULT 0,
  `nb_exists` int(11) NOT NULL DEFAULT 0,
  `nb_import` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_taskjoblogs`;
CREATE TABLE `glpi_plugin_glpiinventory_taskjoblogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plugin_glpiinventory_taskjobstates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_taskjobs`;
CREATE TABLE `glpi_plugin_glpiinventory_taskjobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_tasks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `targets` text DEFAULT NULL,
  `actors` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `rescheduled_taskjob_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `statuscomments` text DEFAULT NULL,
  `enduser` text DEFAULT NULL,
  `restrict_to_task_entity` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_taskjobstates`;
CREATE TABLE `glpi_plugin_glpiinventory_taskjobstates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plugin_glpiinventory_taskjobs_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `agents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `specificity` text DEFAULT NULL,
  `uniqid` varchar(255) DEFAULT NULL,
  `date_start` timestamp NULL DEFAULT NULL,
  `nb_retry` int(11) NOT NULL DEFAULT 0,
  `max_retry` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_tasks`;
CREATE TABLE `glpi_plugin_glpiinventory_tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `datetime_start` timestamp NULL DEFAULT NULL,
  `datetime_end` timestamp NULL DEFAULT NULL,
  `plugin_glpiinventory_timeslots_prep_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plugin_glpiinventory_timeslots_exec_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `last_agent_wakeup` timestamp NULL DEFAULT NULL,
  `wakeup_agent_counter` int(11) NOT NULL DEFAULT 0,
  `wakeup_agent_time` int(11) NOT NULL DEFAULT 0,
  `reprepare_if_successful` tinyint(4) NOT NULL DEFAULT 1,
  `is_deploy_on_demand` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_timeslotentries`;
CREATE TABLE `glpi_plugin_glpiinventory_timeslotentries` (
  `id` int(10) UNSIGNED NOT NULL,
  `plugin_glpiinventory_timeslots_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `day` tinyint(4) NOT NULL DEFAULT 1,
  `begin` int(11) DEFAULT NULL,
  `end` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugin_glpiinventory_timeslots`;
CREATE TABLE `glpi_plugin_glpiinventory_timeslots` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_plugs`;
CREATE TABLE `glpi_plugs` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_printerlogs`;
CREATE TABLE `glpi_printerlogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `printers_id` int(10) UNSIGNED NOT NULL,
  `total_pages` int(11) NOT NULL DEFAULT 0,
  `bw_pages` int(11) NOT NULL DEFAULT 0,
  `color_pages` int(11) NOT NULL DEFAULT 0,
  `rv_pages` int(11) NOT NULL DEFAULT 0,
  `prints` int(11) NOT NULL DEFAULT 0,
  `bw_prints` int(11) NOT NULL DEFAULT 0,
  `color_prints` int(11) NOT NULL DEFAULT 0,
  `copies` int(11) NOT NULL DEFAULT 0,
  `bw_copies` int(11) NOT NULL DEFAULT 0,
  `color_copies` int(11) NOT NULL DEFAULT 0,
  `scanned` int(11) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `faxed` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_printermodels`;
CREATE TABLE `glpi_printermodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `picture_front` text DEFAULT NULL,
  `picture_rear` text DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_printers`;
CREATE TABLE `glpi_printers` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `have_serial` tinyint(4) NOT NULL DEFAULT 0,
  `have_parallel` tinyint(4) NOT NULL DEFAULT 0,
  `have_usb` tinyint(4) NOT NULL DEFAULT 0,
  `have_wifi` tinyint(4) NOT NULL DEFAULT 0,
  `have_ethernet` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `memory_size` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `printertypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `printermodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_global` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `init_pages_counter` int(11) NOT NULL DEFAULT 0,
  `last_pages_counter` int(11) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `sysdescr` text DEFAULT NULL,
  `last_inventory_update` timestamp NULL DEFAULT NULL,
  `snmpcredentials_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_printers_cartridgeinfos`;
CREATE TABLE `glpi_printers_cartridgeinfos` (
  `id` int(10) UNSIGNED NOT NULL,
  `printers_id` int(10) UNSIGNED NOT NULL,
  `property` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_printertypes`;
CREATE TABLE `glpi_printertypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problemcosts`;
CREATE TABLE `glpi_problemcosts` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `cost_time` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_material` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problems`;
CREATE TABLE `glpi_problems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1,
  `content` longtext DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `solvedate` timestamp NULL DEFAULT NULL,
  `closedate` timestamp NULL DEFAULT NULL,
  `time_to_resolve` timestamp NULL DEFAULT NULL,
  `users_id_recipient` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_lastupdater` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `urgency` int(11) NOT NULL DEFAULT 1,
  `impact` int(11) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 1,
  `itilcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `impactcontent` longtext DEFAULT NULL,
  `causecontent` longtext DEFAULT NULL,
  `symptomcontent` longtext DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `begin_waiting_date` timestamp NULL DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT 0,
  `close_delay_stat` int(11) NOT NULL DEFAULT 0,
  `solve_delay_stat` int(11) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problems_suppliers`;
CREATE TABLE `glpi_problems_suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 0,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problems_tickets`;
CREATE TABLE `glpi_problems_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problems_users`;
CREATE TABLE `glpi_problems_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 0,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problemtasks`;
CREATE TABLE `glpi_problemtasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `problems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `taskcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_editor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `state` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `tasktemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0,
  `is_private` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problemtemplatehiddenfields`;
CREATE TABLE `glpi_problemtemplatehiddenfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problemtemplatemandatoryfields`;
CREATE TABLE `glpi_problemtemplatemandatoryfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_problemtemplatemandatoryfields` (`id`, `problemtemplates_id`, `num`) VALUES
(1, 1, 21);

DROP TABLE IF EXISTS `glpi_problemtemplatepredefinedfields`;
CREATE TABLE `glpi_problemtemplatepredefinedfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_problemtemplates`;
CREATE TABLE `glpi_problemtemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_problemtemplates` (`id`, `name`, `entities_id`, `is_recursive`, `comment`) VALUES
(1, 'Default', 0, 1, NULL);

DROP TABLE IF EXISTS `glpi_profilerights`;
CREATE TABLE `glpi_profilerights` (
  `id` int(10) UNSIGNED NOT NULL,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `rights` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_profilerights` (`id`, `profiles_id`, `name`, `rights`) VALUES
(1, 1, 'computer', 0),
(2, 1, 'monitor', 0),
(3, 1, 'software', 0),
(4, 1, 'networking', 0),
(5, 1, 'internet', 0),
(6, 1, 'printer', 0),
(7, 1, 'peripheral', 0),
(8, 1, 'cartridge', 0),
(9, 1, 'consumable', 0),
(10, 1, 'phone', 0),
(11, 6, 'queuednotification', 0),
(12, 1, 'contact_enterprise', 0),
(13, 1, 'document', 0),
(14, 1, 'contract', 0),
(15, 1, 'infocom', 0),
(16, 1, 'knowbase', 2048),
(17, 1, 'reservation', 1024),
(18, 1, 'reports', 0),
(19, 1, 'dropdown', 0),
(20, 1, 'device', 0),
(21, 1, 'typedoc', 0),
(22, 1, 'link', 0),
(23, 1, 'config', 0),
(24, 1, 'rule_ticket', 0),
(25, 1, 'rule_import', 0),
(26, 1, 'rule_location', 0),
(27, 1, 'rule_ldap', 0),
(28, 1, 'rule_softwarecategories', 0),
(29, 1, 'search_config', 0),
(30, 5, 'location', 0),
(31, 7, 'domain', 23),
(32, 1, 'profile', 0),
(33, 1, 'user', 0),
(34, 1, 'group', 0),
(35, 1, 'entity', 0),
(36, 1, 'transfer', 0),
(37, 1, 'logs', 0),
(38, 1, 'reminder_public', 1),
(39, 1, 'rssfeed_public', 1),
(40, 1, 'bookmark_public', 0),
(41, 1, 'backup', 0),
(42, 1, 'ticket', 5),
(43, 1, 'followup', 5),
(44, 1, 'task', 1),
(45, 1, 'planning', 0),
(46, 2, 'state', 0),
(47, 2, 'taskcategory', 0),
(48, 1, 'statistic', 0),
(49, 1, 'password_update', 1),
(50, 1, 'show_group_hardware', 0),
(51, 1, 'rule_dictionnary_software', 0),
(52, 1, 'rule_dictionnary_dropdown', 0),
(53, 1, 'budget', 0),
(54, 1, 'notification', 0),
(55, 1, 'rule_mailcollector', 0),
(56, 7, 'solutiontemplate', 23),
(57, 7, 'itilfollowuptemplate', 23),
(58, 1, 'calendar', 0),
(59, 1, 'slm', 0),
(60, 1, 'rule_dictionnary_printer', 0),
(61, 1, 'problem', 0),
(62, 2, 'cable_management', 0),
(63, 4, 'knowbasecategory', 23),
(64, 5, 'itilcategory', 0),
(65, 1, 'itiltemplate', 0),
(66, 1, 'ticketrecurrent', 0),
(67, 1, 'ticketcost', 0),
(68, 6, 'changevalidation', 20),
(69, 1, 'ticketvalidation', 0),
(70, 2, 'computer', 33),
(71, 2, 'monitor', 33),
(72, 2, 'software', 33),
(73, 2, 'networking', 33),
(74, 2, 'internet', 1),
(75, 2, 'printer', 33),
(76, 2, 'peripheral', 33),
(77, 2, 'cartridge', 33),
(78, 2, 'consumable', 33),
(79, 2, 'phone', 33),
(80, 5, 'queuednotification', 0),
(81, 2, 'contact_enterprise', 33),
(82, 2, 'document', 33),
(83, 2, 'contract', 33),
(84, 2, 'infocom', 1),
(85, 2, 'knowbase', 10241),
(86, 2, 'reservation', 1025),
(87, 2, 'reports', 1),
(88, 2, 'dropdown', 0),
(89, 2, 'device', 0),
(90, 2, 'typedoc', 1),
(91, 2, 'link', 1),
(92, 2, 'config', 0),
(93, 2, 'rule_ticket', 0),
(94, 2, 'rule_import', 0),
(95, 2, 'rule_location', 0),
(96, 2, 'rule_ldap', 0),
(97, 2, 'rule_softwarecategories', 0),
(98, 2, 'search_config', 1024),
(99, 4, 'location', 23),
(100, 6, 'domain', 0),
(101, 2, 'profile', 0),
(102, 2, 'user', 2049),
(103, 2, 'group', 33),
(104, 2, 'entity', 0),
(105, 2, 'transfer', 0),
(106, 2, 'logs', 0),
(107, 2, 'reminder_public', 129),
(108, 2, 'rssfeed_public', 129),
(109, 2, 'bookmark_public', 0),
(110, 2, 'backup', 0),
(111, 2, 'ticket', 168989),
(112, 2, 'followup', 5),
(113, 2, 'task', 1),
(114, 6, 'projecttask', 1025),
(115, 7, 'projecttask', 1025),
(116, 2, 'planning', 1),
(117, 1, 'state', 0),
(118, 1, 'taskcategory', 0),
(119, 2, 'statistic', 1),
(120, 2, 'password_update', 1),
(121, 2, 'show_group_hardware', 0),
(122, 2, 'rule_dictionnary_software', 0),
(123, 2, 'rule_dictionnary_dropdown', 0),
(124, 2, 'budget', 33),
(125, 2, 'notification', 0),
(126, 2, 'rule_mailcollector', 0),
(127, 5, 'solutiontemplate', 0),
(128, 5, 'itilfollowuptemplate', 0),
(129, 6, 'solutiontemplate', 0),
(130, 6, 'itilfollowuptemplate', 0),
(131, 2, 'calendar', 0),
(132, 2, 'slm', 0),
(133, 2, 'rule_dictionnary_printer', 0),
(134, 2, 'problem', 1057),
(135, 1, 'cable_management', 0),
(136, 3, 'knowbasecategory', 23),
(137, 4, 'itilcategory', 23),
(138, 2, 'itiltemplate', 0),
(139, 2, 'ticketrecurrent', 0),
(140, 2, 'ticketcost', 1),
(141, 4, 'changevalidation', 1044),
(142, 5, 'changevalidation', 20),
(143, 2, 'ticketvalidation', 15376),
(144, 3, 'computer', 127),
(145, 3, 'monitor', 127),
(146, 3, 'software', 127),
(147, 3, 'networking', 127),
(148, 3, 'internet', 31),
(149, 3, 'printer', 127),
(150, 3, 'peripheral', 127),
(151, 3, 'cartridge', 127),
(152, 3, 'consumable', 127),
(153, 3, 'phone', 127),
(154, 4, 'queuednotification', 31),
(155, 3, 'contact_enterprise', 127),
(156, 3, 'document', 127),
(157, 3, 'contract', 127),
(158, 3, 'infocom', 23),
(159, 3, 'knowbase', 14359),
(160, 3, 'reservation', 1055),
(161, 3, 'reports', 1),
(162, 3, 'dropdown', 23),
(163, 3, 'device', 23),
(164, 3, 'typedoc', 23),
(165, 3, 'link', 23),
(166, 3, 'config', 0),
(167, 3, 'rule_ticket', 1047),
(168, 3, 'rule_import', 0),
(169, 3, 'rule_location', 0),
(170, 3, 'rule_ldap', 0),
(171, 3, 'rule_softwarecategories', 0),
(172, 3, 'search_config', 3072),
(173, 3, 'location', 23),
(174, 5, 'domain', 0),
(175, 3, 'profile', 1),
(176, 3, 'user', 7199),
(177, 3, 'group', 119),
(178, 3, 'entity', 33),
(179, 3, 'transfer', 1),
(180, 3, 'logs', 1),
(181, 3, 'reminder_public', 151),
(182, 3, 'rssfeed_public', 151),
(183, 3, 'bookmark_public', 23),
(184, 3, 'backup', 1024),
(185, 3, 'ticket', 261151),
(186, 3, 'followup', 31767),
(187, 3, 'task', 13329),
(188, 3, 'projecttask', 1121),
(189, 4, 'projecttask', 1121),
(190, 5, 'projecttask', 0),
(191, 3, 'planning', 3073),
(192, 7, 'taskcategory', 23),
(193, 7, 'cable_management', 31),
(194, 3, 'statistic', 1),
(195, 3, 'password_update', 1),
(196, 3, 'show_group_hardware', 0),
(197, 3, 'rule_dictionnary_software', 0),
(198, 3, 'rule_dictionnary_dropdown', 0),
(199, 3, 'budget', 127),
(200, 3, 'notification', 0),
(201, 3, 'rule_mailcollector', 23),
(202, 3, 'solutiontemplate', 23),
(203, 3, 'itilfollowuptemplate', 23),
(204, 4, 'solutiontemplate', 23),
(205, 4, 'itilfollowuptemplate', 23),
(206, 3, 'calendar', 23),
(207, 3, 'slm', 23),
(208, 3, 'rule_dictionnary_printer', 0),
(209, 3, 'problem', 1151),
(210, 2, 'knowbasecategory', 0),
(211, 3, 'itilcategory', 23),
(212, 3, 'itiltemplate', 23),
(213, 3, 'ticketrecurrent', 1),
(214, 3, 'ticketcost', 23),
(215, 2, 'changevalidation', 1044),
(216, 3, 'changevalidation', 1044),
(217, 3, 'ticketvalidation', 15376),
(218, 4, 'computer', 255),
(219, 4, 'monitor', 255),
(220, 4, 'software', 255),
(221, 4, 'networking', 255),
(222, 4, 'internet', 159),
(223, 4, 'printer', 255),
(224, 4, 'peripheral', 255),
(225, 4, 'cartridge', 255),
(226, 4, 'consumable', 255),
(227, 4, 'phone', 255),
(228, 4, 'contact_enterprise', 255),
(229, 4, 'document', 255),
(230, 4, 'contract', 255),
(231, 4, 'infocom', 23),
(232, 4, 'knowbase', 15383),
(233, 4, 'reservation', 1055),
(234, 4, 'reports', 1),
(235, 4, 'dropdown', 23),
(236, 4, 'device', 23),
(237, 4, 'typedoc', 23),
(238, 4, 'link', 159),
(239, 4, 'config', 3),
(240, 4, 'rule_ticket', 1047),
(241, 4, 'rule_import', 23),
(242, 4, 'rule_location', 23),
(243, 4, 'rule_ldap', 23),
(244, 4, 'rule_softwarecategories', 23),
(245, 4, 'search_config', 3072),
(246, 2, 'location', 0),
(247, 4, 'domain', 23),
(248, 4, 'profile', 23),
(249, 4, 'user', 7327),
(250, 4, 'group', 119),
(251, 4, 'entity', 3327),
(252, 4, 'transfer', 23),
(253, 4, 'logs', 1),
(254, 4, 'reminder_public', 159),
(255, 4, 'rssfeed_public', 159),
(256, 4, 'bookmark_public', 23),
(257, 4, 'backup', 1045),
(258, 4, 'ticket', 261151),
(259, 4, 'followup', 31767),
(260, 4, 'task', 13329),
(261, 7, 'project', 1151),
(262, 1, 'projecttask', 0),
(263, 2, 'projecttask', 1025),
(264, 4, 'planning', 3073),
(265, 6, 'taskcategory', 0),
(266, 6, 'cable_management', 0),
(267, 4, 'statistic', 1),
(268, 4, 'password_update', 1),
(269, 4, 'show_group_hardware', 1),
(270, 4, 'rule_dictionnary_software', 23),
(271, 4, 'rule_dictionnary_dropdown', 23),
(272, 4, 'budget', 127),
(273, 4, 'notification', 23),
(274, 4, 'rule_mailcollector', 23),
(275, 1, 'solutiontemplate', 0),
(276, 1, 'itilfollowuptemplate', 0),
(277, 2, 'solutiontemplate', 0),
(278, 2, 'itilfollowuptemplate', 0),
(279, 4, 'calendar', 23),
(280, 4, 'slm', 23),
(281, 4, 'rule_dictionnary_printer', 23),
(282, 4, 'problem', 1151),
(283, 1, 'knowbasecategory', 0),
(284, 2, 'itilcategory', 0),
(285, 4, 'itiltemplate', 23),
(286, 4, 'ticketrecurrent', 23),
(287, 4, 'ticketcost', 23),
(288, 7, 'change', 1151),
(289, 1, 'changevalidation', 0),
(290, 4, 'ticketvalidation', 15376),
(291, 5, 'computer', 0),
(292, 5, 'monitor', 0),
(293, 5, 'software', 0),
(294, 5, 'networking', 0),
(295, 5, 'internet', 0),
(296, 5, 'printer', 0),
(297, 5, 'peripheral', 0),
(298, 5, 'cartridge', 0),
(299, 5, 'consumable', 0),
(300, 5, 'phone', 0),
(301, 3, 'queuednotification', 0),
(302, 5, 'contact_enterprise', 0),
(303, 5, 'document', 0),
(304, 5, 'contract', 0),
(305, 5, 'infocom', 0),
(306, 5, 'knowbase', 10240),
(307, 5, 'reservation', 0),
(308, 5, 'reports', 0),
(309, 5, 'dropdown', 0),
(310, 5, 'device', 0),
(311, 5, 'typedoc', 0),
(312, 5, 'link', 0),
(313, 5, 'config', 0),
(314, 5, 'rule_ticket', 0),
(315, 5, 'rule_import', 0),
(316, 5, 'rule_location', 0),
(317, 5, 'rule_ldap', 0),
(318, 5, 'rule_softwarecategories', 0),
(319, 5, 'search_config', 0),
(320, 1, 'location', 0),
(321, 3, 'domain', 23),
(322, 5, 'profile', 0),
(323, 5, 'user', 1025),
(324, 5, 'group', 0),
(325, 5, 'entity', 0),
(326, 5, 'transfer', 0),
(327, 5, 'logs', 0),
(328, 5, 'reminder_public', 128),
(329, 5, 'rssfeed_public', 128),
(330, 5, 'bookmark_public', 0),
(331, 5, 'backup', 0),
(332, 5, 'ticket', 140295),
(333, 5, 'followup', 12295),
(334, 5, 'task', 8193),
(335, 4, 'project', 1151),
(336, 5, 'project', 1151),
(337, 6, 'project', 1151),
(338, 5, 'planning', 1),
(339, 5, 'taskcategory', 0),
(340, 5, 'cable_management', 0),
(341, 5, 'statistic', 1),
(342, 5, 'password_update', 1),
(343, 5, 'show_group_hardware', 0),
(344, 5, 'rule_dictionnary_software', 0),
(345, 5, 'rule_dictionnary_dropdown', 0),
(346, 5, 'budget', 0),
(347, 5, 'notification', 0),
(348, 5, 'rule_mailcollector', 0),
(349, 6, 'state', 0),
(350, 7, 'state', 23),
(351, 5, 'calendar', 0),
(352, 5, 'slm', 0),
(353, 5, 'rule_dictionnary_printer', 0),
(354, 5, 'problem', 1024),
(355, 7, 'knowbasecategory', 23),
(356, 1, 'itilcategory', 0),
(357, 5, 'itiltemplate', 0),
(358, 5, 'ticketrecurrent', 0),
(359, 5, 'ticketcost', 23),
(360, 5, 'change', 1054),
(361, 6, 'change', 1151),
(362, 5, 'ticketvalidation', 3088),
(363, 6, 'computer', 127),
(364, 6, 'monitor', 127),
(365, 6, 'software', 127),
(366, 6, 'networking', 127),
(367, 6, 'internet', 31),
(368, 6, 'printer', 127),
(369, 6, 'peripheral', 127),
(370, 6, 'cartridge', 127),
(371, 6, 'consumable', 127),
(372, 6, 'phone', 127),
(373, 2, 'queuednotification', 0),
(374, 6, 'contact_enterprise', 96),
(375, 6, 'document', 127),
(376, 6, 'contract', 96),
(377, 6, 'infocom', 0),
(378, 6, 'knowbase', 14359),
(379, 6, 'reservation', 1055),
(380, 6, 'reports', 1),
(381, 6, 'dropdown', 0),
(382, 6, 'device', 0),
(383, 6, 'typedoc', 0),
(384, 6, 'link', 0),
(385, 6, 'config', 0),
(386, 6, 'rule_ticket', 0),
(387, 6, 'rule_import', 0),
(388, 6, 'rule_location', 0),
(389, 6, 'rule_ldap', 0),
(390, 6, 'rule_softwarecategories', 0),
(391, 6, 'search_config', 0),
(392, 2, 'domain', 0),
(393, 6, 'profile', 0),
(394, 6, 'user', 1055),
(395, 6, 'group', 1),
(396, 6, 'entity', 33),
(397, 6, 'transfer', 1),
(398, 6, 'logs', 0),
(399, 6, 'reminder_public', 151),
(400, 6, 'rssfeed_public', 151),
(401, 6, 'bookmark_public', 0),
(402, 6, 'backup', 0),
(403, 6, 'ticket', 166919),
(404, 6, 'followup', 13319),
(405, 6, 'task', 13329),
(406, 1, 'project', 0),
(407, 2, 'project', 1025),
(408, 3, 'project', 1151),
(409, 6, 'planning', 1),
(410, 4, 'taskcategory', 23),
(411, 4, 'cable_management', 31),
(412, 6, 'statistic', 1),
(413, 6, 'password_update', 1),
(414, 6, 'show_group_hardware', 0),
(415, 6, 'rule_dictionnary_software', 0),
(416, 6, 'rule_dictionnary_dropdown', 0),
(417, 6, 'budget', 96),
(418, 6, 'notification', 0),
(419, 6, 'rule_mailcollector', 0),
(420, 4, 'state', 23),
(421, 5, 'state', 0),
(422, 6, 'calendar', 0),
(423, 6, 'slm', 1),
(424, 6, 'rule_dictionnary_printer', 0),
(425, 6, 'problem', 1121),
(426, 6, 'knowbasecategory', 0),
(427, 7, 'itilcategory', 23),
(428, 7, 'location', 23),
(429, 6, 'itiltemplate', 1),
(430, 6, 'ticketrecurrent', 1),
(431, 6, 'ticketcost', 23),
(432, 3, 'change', 1151),
(433, 4, 'change', 1151),
(434, 6, 'ticketvalidation', 3088),
(435, 7, 'computer', 127),
(436, 7, 'monitor', 127),
(437, 7, 'software', 127),
(438, 7, 'networking', 127),
(439, 7, 'internet', 31),
(440, 7, 'printer', 127),
(441, 7, 'peripheral', 127),
(442, 7, 'cartridge', 127),
(443, 7, 'consumable', 127),
(444, 7, 'phone', 127),
(445, 1, 'queuednotification', 0),
(446, 7, 'contact_enterprise', 96),
(447, 7, 'document', 127),
(448, 7, 'contract', 96),
(449, 7, 'infocom', 0),
(450, 7, 'knowbase', 14359),
(451, 7, 'reservation', 1055),
(452, 7, 'reports', 1),
(453, 7, 'dropdown', 0),
(454, 7, 'device', 0),
(455, 7, 'typedoc', 0),
(456, 7, 'link', 0),
(457, 7, 'config', 0),
(458, 7, 'rule_ticket', 1047),
(459, 7, 'rule_import', 0),
(460, 7, 'rule_location', 0),
(461, 7, 'rule_ldap', 0),
(462, 7, 'rule_softwarecategories', 0),
(463, 7, 'search_config', 0),
(464, 1, 'domain', 0),
(465, 7, 'profile', 0),
(466, 7, 'user', 1055),
(467, 7, 'group', 1),
(468, 7, 'entity', 33),
(469, 7, 'transfer', 1),
(470, 7, 'logs', 1),
(471, 7, 'reminder_public', 151),
(472, 7, 'rssfeed_public', 151),
(473, 7, 'bookmark_public', 0),
(474, 7, 'backup', 0),
(475, 7, 'ticket', 261151),
(476, 7, 'followup', 31767),
(477, 7, 'task', 13329),
(478, 7, 'queuednotification', 0),
(479, 7, 'planning', 3073),
(480, 3, 'taskcategory', 23),
(481, 3, 'cable_management', 31),
(482, 7, 'statistic', 1),
(483, 7, 'password_update', 1),
(484, 7, 'show_group_hardware', 0),
(485, 7, 'rule_dictionnary_software', 0),
(486, 7, 'rule_dictionnary_dropdown', 0),
(487, 7, 'budget', 96),
(488, 7, 'notification', 0),
(489, 7, 'rule_mailcollector', 23),
(490, 7, 'changevalidation', 1044),
(491, 3, 'state', 23),
(492, 7, 'calendar', 23),
(493, 7, 'slm', 23),
(494, 7, 'rule_dictionnary_printer', 0),
(495, 7, 'problem', 1151),
(496, 5, 'knowbasecategory', 0),
(497, 6, 'itilcategory', 0),
(498, 6, 'location', 0),
(499, 7, 'itiltemplate', 23),
(500, 7, 'ticketrecurrent', 1),
(501, 7, 'ticketcost', 23),
(502, 1, 'change', 0),
(503, 2, 'change', 1057),
(504, 7, 'ticketvalidation', 15376),
(505, 8, 'backup', 1),
(506, 8, 'bookmark_public', 1),
(507, 8, 'budget', 33),
(508, 8, 'calendar', 1),
(509, 8, 'cartridge', 33),
(510, 8, 'change', 1057),
(511, 8, 'changevalidation', 0),
(512, 8, 'computer', 33),
(513, 8, 'config', 1),
(514, 8, 'consumable', 33),
(515, 8, 'contact_enterprise', 33),
(516, 8, 'contract', 33),
(517, 8, 'device', 1),
(518, 8, 'document', 33),
(519, 8, 'domain', 1),
(520, 8, 'dropdown', 1),
(521, 8, 'entity', 33),
(522, 8, 'followup', 8193),
(523, 8, 'global_validation', 0),
(524, 8, 'group', 33),
(525, 8, 'infocom', 1),
(526, 8, 'internet', 1),
(527, 8, 'itilcategory', 1),
(528, 8, 'knowbase', 10241),
(529, 8, 'knowbasecategory', 1),
(530, 8, 'link', 1),
(531, 8, 'location', 1),
(532, 8, 'logs', 1),
(533, 8, 'monitor', 33),
(534, 8, 'cable_management', 1),
(535, 8, 'networking', 33),
(536, 8, 'notification', 1),
(537, 8, 'password_update', 0),
(538, 8, 'peripheral', 33),
(539, 8, 'phone', 33),
(540, 8, 'planning', 3073),
(541, 8, 'printer', 33),
(542, 8, 'problem', 1057),
(543, 8, 'profile', 1),
(544, 8, 'project', 1057),
(545, 8, 'projecttask', 33),
(546, 8, 'queuednotification', 1),
(547, 8, 'reminder_public', 1),
(548, 8, 'reports', 1),
(549, 8, 'reservation', 129),
(550, 8, 'rssfeed_public', 129),
(551, 8, 'rule_dictionnary_dropdown', 1),
(552, 8, 'rule_dictionnary_printer', 1),
(553, 8, 'rule_dictionnary_software', 1),
(554, 8, 'rule_import', 1),
(555, 8, 'rule_location', 1),
(556, 8, 'rule_ldap', 1),
(557, 8, 'rule_mailcollector', 1),
(558, 8, 'rule_softwarecategories', 1),
(559, 8, 'rule_ticket', 1),
(560, 8, 'search_config', 0),
(561, 8, 'show_group_hardware', 1),
(562, 8, 'slm', 1),
(563, 8, 'software', 33),
(564, 8, 'solutiontemplate', 1),
(565, 8, 'itilfollowuptemplate', 1),
(566, 8, 'state', 1),
(567, 8, 'statistic', 1),
(568, 8, 'task', 8193),
(569, 8, 'taskcategory', 1),
(570, 8, 'ticket', 138241),
(571, 8, 'ticketcost', 1),
(572, 8, 'ticketrecurrent', 1),
(573, 8, 'itiltemplate', 1),
(574, 8, 'ticketvalidation', 0),
(575, 8, 'transfer', 1),
(576, 8, 'typedoc', 1),
(577, 8, 'user', 1),
(578, 1, 'license', 0),
(579, 2, 'license', 33),
(580, 3, 'license', 127),
(581, 4, 'license', 255),
(582, 5, 'license', 0),
(583, 6, 'license', 127),
(584, 7, 'license', 127),
(585, 8, 'license', 33),
(586, 1, 'line', 0),
(587, 2, 'line', 33),
(588, 3, 'line', 127),
(589, 4, 'line', 255),
(590, 5, 'line', 0),
(591, 6, 'line', 127),
(592, 7, 'line', 127),
(593, 8, 'line', 33),
(594, 1, 'lineoperator', 0),
(595, 2, 'lineoperator', 33),
(596, 3, 'lineoperator', 23),
(597, 4, 'lineoperator', 23),
(598, 5, 'lineoperator', 0),
(599, 6, 'lineoperator', 0),
(600, 7, 'lineoperator', 23),
(601, 8, 'lineoperator', 1),
(602, 1, 'devicesimcard_pinpuk', 0),
(603, 2, 'devicesimcard_pinpuk', 1),
(604, 3, 'devicesimcard_pinpuk', 3),
(605, 4, 'devicesimcard_pinpuk', 3),
(606, 5, 'devicesimcard_pinpuk', 0),
(607, 6, 'devicesimcard_pinpuk', 3),
(608, 7, 'devicesimcard_pinpuk', 3),
(609, 8, 'devicesimcard_pinpuk', 1),
(610, 1, 'certificate', 0),
(611, 2, 'certificate', 33),
(612, 3, 'certificate', 127),
(613, 4, 'certificate', 255),
(614, 5, 'certificate', 0),
(615, 6, 'certificate', 127),
(616, 7, 'certificate', 127),
(617, 8, 'certificate', 33),
(618, 1, 'datacenter', 0),
(619, 2, 'datacenter', 1),
(620, 3, 'datacenter', 31),
(621, 4, 'datacenter', 31),
(622, 5, 'datacenter', 0),
(623, 6, 'datacenter', 31),
(624, 7, 'datacenter', 31),
(625, 8, 'datacenter', 1),
(626, 4, 'rule_asset', 1047),
(627, 1, 'personalization', 3),
(628, 2, 'personalization', 3),
(629, 3, 'personalization', 3),
(630, 4, 'personalization', 3),
(631, 5, 'personalization', 3),
(632, 6, 'personalization', 3),
(633, 7, 'personalization', 3),
(634, 8, 'personalization', 3),
(635, 1, 'rule_asset', 0),
(636, 2, 'rule_asset', 0),
(637, 3, 'rule_asset', 0),
(638, 5, 'rule_asset', 0),
(639, 6, 'rule_asset', 0),
(640, 7, 'rule_asset', 0),
(641, 8, 'rule_asset', 0),
(642, 1, 'global_validation', 0),
(643, 2, 'global_validation', 0),
(644, 3, 'global_validation', 0),
(645, 4, 'global_validation', 0),
(646, 5, 'global_validation', 0),
(647, 6, 'global_validation', 0),
(648, 7, 'global_validation', 0),
(649, 1, 'cluster', 0),
(650, 2, 'cluster', 1),
(651, 3, 'cluster', 31),
(652, 4, 'cluster', 31),
(653, 5, 'cluster', 0),
(654, 6, 'cluster', 31),
(655, 7, 'cluster', 31),
(656, 8, 'cluster', 1),
(657, 1, 'externalevent', 0),
(658, 2, 'externalevent', 1),
(659, 3, 'externalevent', 1055),
(660, 4, 'externalevent', 1055),
(661, 5, 'externalevent', 0),
(662, 6, 'externalevent', 1),
(663, 7, 'externalevent', 31),
(664, 8, 'externalevent', 1),
(665, 1, 'dashboard', 0),
(666, 2, 'dashboard', 0),
(667, 3, 'dashboard', 0),
(668, 4, 'dashboard', 23),
(669, 5, 'dashboard', 0),
(670, 6, 'dashboard', 0),
(671, 7, 'dashboard', 0),
(672, 8, 'dashboard', 0),
(673, 1, 'appliance', 0),
(674, 2, 'appliance', 1),
(675, 3, 'appliance', 31),
(676, 4, 'appliance', 31),
(677, 5, 'appliance', 0),
(678, 6, 'appliance', 31),
(679, 7, 'appliance', 31),
(680, 8, 'appliance', 1),
(681, 1, 'inventory', 0),
(682, 2, 'inventory', 0),
(683, 3, 'inventory', 3073),
(684, 4, 'inventory', 3073),
(685, 5, 'inventory', 0),
(686, 6, 'inventory', 0),
(687, 7, 'inventory', 0),
(688, 8, 'inventory', 0),
(689, 1, 'pendingreason', 0),
(690, 2, 'pendingreason', 0),
(691, 3, 'pendingreason', 31),
(692, 4, 'pendingreason', 31),
(693, 5, 'pendingreason', 1),
(694, 6, 'pendingreason', 1),
(695, 7, 'pendingreason', 1),
(696, 8, 'pendingreason', 1),
(697, 1, 'database', 0),
(698, 2, 'database', 1),
(699, 3, 'database', 31),
(700, 4, 'database', 31),
(701, 5, 'database', 0),
(702, 6, 'database', 31),
(703, 7, 'database', 31),
(704, 8, 'database', 1),
(705, 1, 'recurrentchange', 0),
(706, 2, 'recurrentchange', 0),
(707, 3, 'recurrentchange', 1),
(708, 4, 'recurrentchange', 31),
(709, 5, 'recurrentchange', 0),
(710, 6, 'recurrentchange', 1),
(711, 7, 'recurrentchange', 1),
(712, 8, 'recurrentchange', 1),
(713, 1, 'locked_field', 0),
(714, 2, 'locked_field', 0),
(715, 3, 'locked_field', 0),
(716, 4, 'locked_field', 6),
(717, 5, 'locked_field', 0),
(718, 6, 'locked_field', 0),
(719, 7, 'locked_field', 0),
(720, 8, 'locked_field', 0),
(721, 1, 'snmpcredential', 0),
(722, 2, 'snmpcredential', 0),
(723, 3, 'snmpcredential', 0),
(724, 4, 'snmpcredential', 31),
(725, 5, 'snmpcredential', 0),
(726, 6, 'snmpcredential', 0),
(727, 7, 'snmpcredential', 0),
(728, 8, 'snmpcredential', 0),
(729, 1, 'refusedequipment', 0),
(730, 2, 'refusedequipment', 0),
(731, 3, 'refusedequipment', 0),
(732, 4, 'refusedequipment', 19),
(733, 5, 'refusedequipment', 0),
(734, 6, 'refusedequipment', 0),
(735, 7, 'refusedequipment', 0),
(736, 8, 'refusedequipment', 0),
(737, 1, 'agent', 0),
(738, 2, 'agent', 0),
(739, 3, 'agent', 0),
(740, 4, 'agent', 19),
(741, 5, 'agent', 0),
(742, 6, 'agent', 0),
(743, 7, 'agent', 0),
(744, 8, 'agent', 0),
(745, 1, 'unmanaged', 0),
(746, 2, 'unmanaged', 0),
(747, 3, 'unmanaged', 0),
(748, 4, 'unmanaged', 27),
(749, 5, 'unmanaged', 0),
(750, 6, 'unmanaged', 0),
(751, 7, 'unmanaged', 0),
(752, 8, 'unmanaged', 0),
(753, 2, 'plugin_glpiinventory_menu', 0),
(754, 3, 'plugin_glpiinventory_menu', 0),
(755, 4, 'plugin_glpiinventory_menu', 1),
(756, 5, 'plugin_glpiinventory_menu', 0),
(757, 6, 'plugin_glpiinventory_menu', 0),
(758, 7, 'plugin_glpiinventory_menu', 0),
(759, 8, 'plugin_glpiinventory_menu', 0),
(760, 1, 'plugin_glpiinventory_menu', 0),
(761, 2, 'plugin_glpiinventory_configuration', 0),
(762, 3, 'plugin_glpiinventory_configuration', 0),
(763, 4, 'plugin_glpiinventory_configuration', 3),
(764, 5, 'plugin_glpiinventory_configuration', 0),
(765, 6, 'plugin_glpiinventory_configuration', 0),
(766, 7, 'plugin_glpiinventory_configuration', 0),
(767, 8, 'plugin_glpiinventory_configuration', 0),
(768, 1, 'plugin_glpiinventory_configuration', 0),
(769, 2, 'plugin_glpiinventory_task', 0),
(770, 3, 'plugin_glpiinventory_task', 0),
(771, 4, 'plugin_glpiinventory_task', 23),
(772, 5, 'plugin_glpiinventory_task', 0),
(773, 6, 'plugin_glpiinventory_task', 0),
(774, 7, 'plugin_glpiinventory_task', 0),
(775, 8, 'plugin_glpiinventory_task', 0),
(776, 1, 'plugin_glpiinventory_task', 0),
(777, 2, 'plugin_glpiinventory_wol', 0),
(778, 3, 'plugin_glpiinventory_wol', 0),
(779, 4, 'plugin_glpiinventory_wol', 1),
(780, 5, 'plugin_glpiinventory_wol', 0),
(781, 6, 'plugin_glpiinventory_wol', 0),
(782, 7, 'plugin_glpiinventory_wol', 0),
(783, 8, 'plugin_glpiinventory_wol', 0),
(784, 1, 'plugin_glpiinventory_wol', 0),
(785, 2, 'plugin_glpiinventory_group', 0),
(786, 3, 'plugin_glpiinventory_group', 0),
(787, 4, 'plugin_glpiinventory_group', 23),
(788, 5, 'plugin_glpiinventory_group', 0),
(789, 6, 'plugin_glpiinventory_group', 0),
(790, 7, 'plugin_glpiinventory_group', 0),
(791, 8, 'plugin_glpiinventory_group', 0),
(792, 1, 'plugin_glpiinventory_group', 0),
(793, 2, 'plugin_glpiinventory_collect', 0),
(794, 3, 'plugin_glpiinventory_collect', 0),
(795, 4, 'plugin_glpiinventory_collect', 23),
(796, 5, 'plugin_glpiinventory_collect', 0),
(797, 6, 'plugin_glpiinventory_collect', 0),
(798, 7, 'plugin_glpiinventory_collect', 0),
(799, 8, 'plugin_glpiinventory_collect', 0),
(800, 1, 'plugin_glpiinventory_collect', 0),
(801, 2, 'plugin_glpiinventory_iprange', 0),
(802, 3, 'plugin_glpiinventory_iprange', 0),
(803, 4, 'plugin_glpiinventory_iprange', 23),
(804, 5, 'plugin_glpiinventory_iprange', 0),
(805, 6, 'plugin_glpiinventory_iprange', 0),
(806, 7, 'plugin_glpiinventory_iprange', 0),
(807, 8, 'plugin_glpiinventory_iprange', 0),
(808, 1, 'plugin_glpiinventory_iprange', 0),
(809, 2, 'plugin_glpiinventory_credential', 0),
(810, 3, 'plugin_glpiinventory_credential', 0),
(811, 4, 'plugin_glpiinventory_credential', 23),
(812, 5, 'plugin_glpiinventory_credential', 0),
(813, 6, 'plugin_glpiinventory_credential', 0),
(814, 7, 'plugin_glpiinventory_credential', 0),
(815, 8, 'plugin_glpiinventory_credential', 0),
(816, 1, 'plugin_glpiinventory_credential', 0),
(817, 2, 'plugin_glpiinventory_credentialip', 0),
(818, 3, 'plugin_glpiinventory_credentialip', 0),
(819, 4, 'plugin_glpiinventory_credentialip', 23),
(820, 5, 'plugin_glpiinventory_credentialip', 0),
(821, 6, 'plugin_glpiinventory_credentialip', 0),
(822, 7, 'plugin_glpiinventory_credentialip', 0),
(823, 8, 'plugin_glpiinventory_credentialip', 0),
(824, 1, 'plugin_glpiinventory_credentialip', 0),
(825, 2, 'plugin_glpiinventory_esx', 0),
(826, 3, 'plugin_glpiinventory_esx', 0),
(827, 4, 'plugin_glpiinventory_esx', 23),
(828, 5, 'plugin_glpiinventory_esx', 0),
(829, 6, 'plugin_glpiinventory_esx', 0),
(830, 7, 'plugin_glpiinventory_esx', 0),
(831, 8, 'plugin_glpiinventory_esx', 0),
(832, 1, 'plugin_glpiinventory_esx', 0),
(833, 2, 'plugin_glpiinventory_networkequipment', 0),
(834, 3, 'plugin_glpiinventory_networkequipment', 0),
(835, 4, 'plugin_glpiinventory_networkequipment', 4),
(836, 5, 'plugin_glpiinventory_networkequipment', 0),
(837, 6, 'plugin_glpiinventory_networkequipment', 0),
(838, 7, 'plugin_glpiinventory_networkequipment', 0),
(839, 8, 'plugin_glpiinventory_networkequipment', 0),
(840, 1, 'plugin_glpiinventory_networkequipment', 0),
(841, 2, 'plugin_glpiinventory_printer', 0),
(842, 3, 'plugin_glpiinventory_printer', 0),
(843, 4, 'plugin_glpiinventory_printer', 4),
(844, 5, 'plugin_glpiinventory_printer', 0),
(845, 6, 'plugin_glpiinventory_printer', 0),
(846, 7, 'plugin_glpiinventory_printer', 0),
(847, 8, 'plugin_glpiinventory_printer', 0),
(848, 1, 'plugin_glpiinventory_printer', 0),
(849, 2, 'plugin_glpiinventory_rulecollect', 0),
(850, 3, 'plugin_glpiinventory_rulecollect', 0),
(851, 4, 'plugin_glpiinventory_rulecollect', 23),
(852, 5, 'plugin_glpiinventory_rulecollect', 0),
(853, 6, 'plugin_glpiinventory_rulecollect', 0),
(854, 7, 'plugin_glpiinventory_rulecollect', 0),
(855, 8, 'plugin_glpiinventory_rulecollect', 0),
(856, 1, 'plugin_glpiinventory_rulecollect', 0),
(857, 2, 'plugin_glpiinventory_package', 0),
(858, 3, 'plugin_glpiinventory_package', 0),
(859, 4, 'plugin_glpiinventory_package', 23),
(860, 5, 'plugin_glpiinventory_package', 0),
(861, 6, 'plugin_glpiinventory_package', 0),
(862, 7, 'plugin_glpiinventory_package', 0),
(863, 8, 'plugin_glpiinventory_package', 0),
(864, 1, 'plugin_glpiinventory_package', 0),
(865, 2, 'plugin_glpiinventory_userinteractiontemplate', 0),
(866, 3, 'plugin_glpiinventory_userinteractiontemplate', 0),
(867, 4, 'plugin_glpiinventory_userinteractiontemplate', 23),
(868, 5, 'plugin_glpiinventory_userinteractiontemplate', 0),
(869, 6, 'plugin_glpiinventory_userinteractiontemplate', 0),
(870, 7, 'plugin_glpiinventory_userinteractiontemplate', 0),
(871, 8, 'plugin_glpiinventory_userinteractiontemplate', 0),
(872, 1, 'plugin_glpiinventory_userinteractiontemplate', 0),
(873, 2, 'plugin_glpiinventory_deploymirror', 0),
(874, 3, 'plugin_glpiinventory_deploymirror', 0),
(875, 4, 'plugin_glpiinventory_deploymirror', 23),
(876, 5, 'plugin_glpiinventory_deploymirror', 0),
(877, 6, 'plugin_glpiinventory_deploymirror', 0),
(878, 7, 'plugin_glpiinventory_deploymirror', 0),
(879, 8, 'plugin_glpiinventory_deploymirror', 0),
(880, 1, 'plugin_glpiinventory_deploymirror', 0),
(881, 2, 'plugin_glpiinventory_selfpackage', 0),
(882, 3, 'plugin_glpiinventory_selfpackage', 0),
(883, 4, 'plugin_glpiinventory_selfpackage', 1),
(884, 5, 'plugin_glpiinventory_selfpackage', 0),
(885, 6, 'plugin_glpiinventory_selfpackage', 0),
(886, 7, 'plugin_glpiinventory_selfpackage', 0),
(887, 8, 'plugin_glpiinventory_selfpackage', 0),
(888, 1, 'plugin_glpiinventory_selfpackage', 0);

DROP TABLE IF EXISTS `glpi_profiles`;
CREATE TABLE `glpi_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `interface` varchar(255) DEFAULT 'helpdesk',
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `helpdesk_hardware` int(11) NOT NULL DEFAULT 0,
  `helpdesk_item_type` text DEFAULT NULL,
  `ticket_status` text DEFAULT NULL COMMENT 'json encoded array of from/dest allowed status change',
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `problem_status` text DEFAULT NULL COMMENT 'json encoded array of from/dest allowed status change',
  `create_ticket_on_login` tinyint(4) NOT NULL DEFAULT 0,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `problemtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `change_status` text DEFAULT NULL COMMENT 'json encoded array of from/dest allowed status change',
  `managed_domainrecordtypes` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_profiles` (`id`, `name`, `interface`, `is_default`, `helpdesk_hardware`, `helpdesk_item_type`, `ticket_status`, `date_mod`, `comment`, `problem_status`, `create_ticket_on_login`, `tickettemplates_id`, `changetemplates_id`, `problemtemplates_id`, `change_status`, `managed_domainrecordtypes`, `date_creation`) VALUES
(1, 'Self-Service', 'helpdesk', 1, 1, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}', NULL, '', '[]', 0, 0, 0, 0, NULL, '[]', NULL),
(2, 'Observer', 'central', 0, 1, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 0, 0, 0, 0, NULL, '[]', NULL),
(3, 'Admin', 'central', 0, 3, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 0, 0, 0, 0, NULL, '[-1]', NULL),
(4, 'Super-Admin', 'central', 0, 3, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 0, 0, 0, 0, NULL, '[-1]', NULL),
(5, 'Hotliner', 'central', 0, 3, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 1, 0, 0, 0, NULL, '[]', NULL),
(6, 'Technician', 'central', 0, 3, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 0, 0, 0, 0, NULL, '[]', NULL),
(7, 'Supervisor', 'central', 0, 3, '[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\", \"DCRoom\", \"Rack\", \"Enclosure\", \"Database\"]', '[]', NULL, '', '[]', 0, 0, 0, 0, NULL, '[]', NULL),
(8, 'Read-Only', 'central', 0, 0, '[]', '{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}', NULL, 'This profile defines read-only access. It is used when objects are locked. It can also be used to give to users rights to unlock objects.', '{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}', 0, 0, 0, 0, '{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}', '[]', NULL);

DROP TABLE IF EXISTS `glpi_profiles_reminders`;
CREATE TABLE `glpi_profiles_reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `reminders_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_profiles_rssfeeds`;
CREATE TABLE `glpi_profiles_rssfeeds` (
  `id` int(10) UNSIGNED NOT NULL,
  `rssfeeds_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `no_entity_restriction` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_profiles_users`;
CREATE TABLE `glpi_profiles_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 1,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `is_default_profile` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_profiles_users` (`id`, `users_id`, `profiles_id`, `entities_id`, `is_recursive`, `is_dynamic`, `is_default_profile`) VALUES
(2, 2, 4, 0, 1, 0, 0),
(3, 3, 1, 0, 1, 0, 0),
(4, 4, 6, 0, 1, 0, 0),
(5, 5, 2, 0, 1, 0, 0),
(6, 7, 1, 0, 0, 1, 1);

DROP TABLE IF EXISTS `glpi_projectcosts`;
CREATE TABLE `glpi_projectcosts` (
  `id` int(10) UNSIGNED NOT NULL,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projects`;
CREATE TABLE `glpi_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 1,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projectstates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plan_start_date` timestamp NULL DEFAULT NULL,
  `plan_end_date` timestamp NULL DEFAULT NULL,
  `real_start_date` timestamp NULL DEFAULT NULL,
  `real_end_date` timestamp NULL DEFAULT NULL,
  `percent_done` int(11) NOT NULL DEFAULT 0,
  `auto_percent_done` tinyint(4) NOT NULL DEFAULT 0,
  `show_on_global_gantt` tinyint(4) NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `comment` longtext DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `projecttemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projectstates`;
CREATE TABLE `glpi_projectstates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `is_finished` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_projectstates` (`id`, `name`, `comment`, `color`, `is_finished`, `date_mod`, `date_creation`) VALUES
(1, 'New', NULL, '#06ff00', 0, NULL, NULL),
(2, 'Processing', NULL, '#ffb800', 0, NULL, NULL),
(3, 'Closed', NULL, '#ff0000', 1, NULL, NULL);

DROP TABLE IF EXISTS `glpi_projecttasklinks`;
CREATE TABLE `glpi_projecttasklinks` (
  `id` int(10) UNSIGNED NOT NULL,
  `projecttasks_id_source` int(10) UNSIGNED NOT NULL,
  `source_uuid` varchar(255) NOT NULL,
  `projecttasks_id_target` int(10) UNSIGNED NOT NULL,
  `target_uuid` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0,
  `lag` smallint(6) DEFAULT 0,
  `lead` smallint(6) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttasks`;
CREATE TABLE `glpi_projecttasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `comment` longtext DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttasks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `plan_start_date` timestamp NULL DEFAULT NULL,
  `plan_end_date` timestamp NULL DEFAULT NULL,
  `real_start_date` timestamp NULL DEFAULT NULL,
  `real_end_date` timestamp NULL DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT 0,
  `effective_duration` int(11) NOT NULL DEFAULT 0,
  `projectstates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttasktypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `percent_done` int(11) NOT NULL DEFAULT 0,
  `auto_percent_done` tinyint(4) NOT NULL DEFAULT 0,
  `is_milestone` tinyint(4) NOT NULL DEFAULT 0,
  `projecttasktemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttasks_tickets`;
CREATE TABLE `glpi_projecttasks_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttasks_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttaskteams`;
CREATE TABLE `glpi_projecttaskteams` (
  `id` int(10) UNSIGNED NOT NULL,
  `projecttasks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttasktemplates`;
CREATE TABLE `glpi_projecttasktemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `comment` longtext DEFAULT NULL,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttasks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `plan_start_date` timestamp NULL DEFAULT NULL,
  `plan_end_date` timestamp NULL DEFAULT NULL,
  `real_start_date` timestamp NULL DEFAULT NULL,
  `real_end_date` timestamp NULL DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT 0,
  `effective_duration` int(11) NOT NULL DEFAULT 0,
  `projectstates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `projecttasktypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `percent_done` int(11) NOT NULL DEFAULT 0,
  `is_milestone` tinyint(4) NOT NULL DEFAULT 0,
  `comments` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttasktypes`;
CREATE TABLE `glpi_projecttasktypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projectteams`;
CREATE TABLE `glpi_projectteams` (
  `id` int(10) UNSIGNED NOT NULL,
  `projects_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_projecttypes`;
CREATE TABLE `glpi_projecttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_queuednotifications`;
CREATE TABLE `glpi_queuednotifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `notificationtemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `sent_try` int(11) NOT NULL DEFAULT 0,
  `create_time` timestamp NULL DEFAULT NULL,
  `send_time` timestamp NULL DEFAULT NULL,
  `sent_time` timestamp NULL DEFAULT NULL,
  `name` text DEFAULT NULL,
  `sender` text DEFAULT NULL,
  `sendername` text DEFAULT NULL,
  `recipient` text DEFAULT NULL,
  `recipientname` text DEFAULT NULL,
  `replyto` text DEFAULT NULL,
  `replytoname` text DEFAULT NULL,
  `headers` text DEFAULT NULL,
  `body_html` longtext DEFAULT NULL,
  `body_text` longtext DEFAULT NULL,
  `messageid` text DEFAULT NULL,
  `documents` text DEFAULT NULL,
  `mode` varchar(20) NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_rackmodels`;
CREATE TABLE `glpi_rackmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `product_number` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_racks`;
CREATE TABLE `glpi_racks` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `rackmodels_id` int(10) UNSIGNED DEFAULT NULL,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `racktypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `number_units` int(11) DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `dcrooms_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `room_orientation` int(11) NOT NULL DEFAULT 0,
  `position` varchar(50) DEFAULT NULL,
  `bgcolor` varchar(7) DEFAULT NULL,
  `max_power` int(11) NOT NULL DEFAULT 0,
  `mesured_power` int(11) NOT NULL DEFAULT 0,
  `max_weight` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_racktypes`;
CREATE TABLE `glpi_racktypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_recurrentchanges`;
CREATE TABLE `glpi_recurrentchanges` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `changetemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `begin_date` timestamp NULL DEFAULT NULL,
  `periodicity` varchar(255) DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT 0,
  `next_creation_date` timestamp NULL DEFAULT NULL,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `end_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_refusedequipments`;
CREATE TABLE `glpi_refusedequipments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ip` varchar(255) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `rules_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `method` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `agents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_registeredids`;
CREATE TABLE `glpi_registeredids` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `device_type` varchar(100) NOT NULL COMMENT 'USB, PCI ...'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_reminders`;
CREATE TABLE `glpi_reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `is_planned` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `begin_view_date` timestamp NULL DEFAULT NULL,
  `end_view_date` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_reminders_users`;
CREATE TABLE `glpi_reminders_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `reminders_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_remindertranslations`;
CREATE TABLE `glpi_remindertranslations` (
  `id` int(10) UNSIGNED NOT NULL,
  `reminders_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `language` varchar(5) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `text` longtext DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_requesttypes`;
CREATE TABLE `glpi_requesttypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_helpdesk_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_followup_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_mail_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_mailfollowup_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_ticketheader` tinyint(4) NOT NULL DEFAULT 1,
  `is_itilfollowup` tinyint(4) NOT NULL DEFAULT 1,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_requesttypes` (`id`, `name`, `is_helpdesk_default`, `is_followup_default`, `is_mail_default`, `is_mailfollowup_default`, `is_active`, `is_ticketheader`, `is_itilfollowup`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'Helpdesk', 1, 1, 0, 0, 1, 1, 1, NULL, NULL, NULL),
(2, 'E-Mail', 0, 0, 1, 1, 1, 1, 1, NULL, NULL, NULL),
(3, 'Phone', 0, 0, 0, 0, 1, 1, 1, NULL, NULL, NULL),
(4, 'Direct', 0, 0, 0, 0, 1, 1, 1, NULL, NULL, NULL),
(5, 'Written', 0, 0, 0, 0, 1, 1, 1, NULL, NULL, NULL),
(6, 'Other', 0, 0, 0, 0, 1, 1, 1, NULL, NULL, NULL),
(7, 'Formcreator', 0, 0, 0, 0, 1, 1, 1, NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_reservationitems`;
CREATE TABLE `glpi_reservationitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_reservations`;
CREATE TABLE `glpi_reservations` (
  `id` int(10) UNSIGNED NOT NULL,
  `reservationitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `group` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_rssfeeds`;
CREATE TABLE `glpi_rssfeeds` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `refresh_rate` int(11) NOT NULL DEFAULT 86400,
  `max_items` int(11) NOT NULL DEFAULT 20,
  `have_error` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_rssfeeds_users`;
CREATE TABLE `glpi_rssfeeds_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `rssfeeds_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ruleactions`;
CREATE TABLE `glpi_ruleactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `rules_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `action_type` varchar(255) DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_ruleactions` (`id`, `rules_id`, `action_type`, `field`, `value`) VALUES
(1, 1, 'assign', '_inventory', '2'),
(2, 2, 'assign', '_inventory', '0'),
(3, 3, 'assign', '_inventory', '0'),
(4, 4, 'assign', '_inventory', '0'),
(5, 5, 'assign', '_inventory', '0'),
(6, 6, 'assign', '_inventory', '0'),
(7, 7, 'assign', '_inventory', '0'),
(8, 8, 'assign', '_inventory', '0'),
(9, 9, 'assign', '_inventory', '0'),
(10, 10, 'assign', '_inventory', '2'),
(11, 11, 'assign', '_inventory', '0'),
(12, 12, 'assign', '_inventory', '0'),
(13, 13, 'assign', '_inventory', '0'),
(14, 14, 'assign', '_inventory', '0'),
(15, 15, 'assign', '_inventory', '0'),
(16, 16, 'assign', '_inventory', '0'),
(17, 17, 'assign', '_inventory', '0'),
(18, 18, 'assign', '_inventory', '0'),
(19, 19, 'assign', '_inventory', '0'),
(20, 20, 'assign', '_inventory', '0'),
(21, 21, 'assign', '_inventory', '0'),
(22, 22, 'assign', '_inventory', '2'),
(23, 23, 'assign', '_inventory', '2'),
(24, 24, 'assign', '_inventory', '0'),
(25, 25, 'assign', '_inventory', '0'),
(26, 26, 'assign', '_inventory', '0'),
(27, 27, 'assign', '_inventory', '0'),
(28, 28, 'assign', '_inventory', '2'),
(29, 29, 'assign', '_inventory', '2'),
(30, 30, 'assign', '_inventory', '0'),
(31, 31, 'assign', '_inventory', '0'),
(32, 32, 'assign', '_inventory', '0'),
(33, 33, 'assign', '_inventory', '0'),
(34, 34, 'assign', '_inventory', '2'),
(35, 35, 'assign', '_inventory', '0'),
(36, 36, 'assign', '_inventory', '0'),
(37, 37, 'assign', '_inventory', '2'),
(38, 38, 'assign', '_inventory', '0'),
(39, 39, 'assign', '_inventory', '0'),
(40, 40, 'assign', '_inventory', '2'),
(41, 41, 'assign', '_inventory', '2'),
(42, 42, 'assign', '_inventory', '0'),
(43, 43, 'assign', '_inventory', '0'),
(44, 44, 'assign', '_inventory', '2'),
(45, 45, 'assign', '_inventory', '0'),
(46, 46, 'assign', '_inventory', '0'),
(47, 47, 'assign', '_inventory', '2'),
(48, 48, 'assign', '_inventory', '0'),
(49, 49, 'assign', '_inventory', '0'),
(50, 50, 'assign', '_inventory', '2'),
(51, 51, 'assign', '_inventory', '2'),
(52, 52, 'assign', '_inventory', '0'),
(53, 53, 'assign', '_inventory', '0'),
(54, 54, 'assign', '_inventory', '0'),
(55, 55, 'assign', '_inventory', '0'),
(56, 56, 'assign', '_inventory', '2'),
(57, 57, 'assign', '_inventory', '0'),
(58, 58, 'assign', '_inventory', '0'),
(59, 59, 'assign', '_inventory', '2'),
(60, 60, 'assign', '_inventory', '0'),
(61, 61, 'assign', '_inventory', '0'),
(62, 62, 'assign', '_inventory', '2'),
(63, 63, 'assign', 'entities_id', '0'),
(64, 64, 'assign', '_refuse_email_no_response', '1'),
(65, 65, 'assign', '_refuse_email_no_response', '1'),
(66, 66, 'assign', 'entities_id', '0'),
(67, 67, 'assign', '_import_category', '1'),
(68, 68, 'fromitem', 'locations_id', '1'),
(69, 69, 'fromuser', 'locations_id', '1'),
(70, 70, 'regex_result', '_affect_user_by_regex', '#0'),
(71, 71, 'regex_result', '_affect_user_by_regex', '#0'),
(72, 72, 'regex_result', '_affect_user_by_regex', '#0'),
(73, 73, 'append_regex_result', 'name', '#0'),
(74, 74, 'append_regex_result', 'name', '#1'),
(75, 75, 'append_regex_result', 'name', '#1 #2'),
(76, 76, 'append_regex_result', 'name', '#1'),
(77, 77, 'append_regex_result', 'name', '#2'),
(78, 78, 'append_regex_result', 'name', '#3'),
(79, 79, 'append_regex_result', 'name', '#2'),
(80, 80, 'append_regex_result', 'name', '#4'),
(81, 81, 'append_regex_result', 'name', '#4');

DROP TABLE IF EXISTS `glpi_rulecriterias`;
CREATE TABLE `glpi_rulecriterias` (
  `id` int(10) UNSIGNED NOT NULL,
  `rules_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `criteria` varchar(255) DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_rulecriterias` (`id`, `rules_id`, `criteria`, `condition`, `pattern`) VALUES
(1, 1, 'partial', 0, '1'),
(2, 1, 'itemtype', 9, '1'),
(3, 2, 'itemtype', 9, '1'),
(4, 2, 'mac', 10, '1'),
(5, 2, 'mac', 8, '1'),
(6, 2, 'ifnumber', 10, '1'),
(7, 2, 'ifnumber', 8, '1'),
(8, 2, 'link_criteria_port', 203, '1'),
(9, 3, 'itemtype', 9, '1'),
(10, 3, 'mac', 10, '1'),
(11, 3, 'mac', 8, '1'),
(12, 3, 'ifnumber', 10, '1'),
(13, 3, 'ifnumber', 8, '1'),
(14, 4, 'itemtype', 9, '1'),
(15, 4, 'mac', 8, '1'),
(16, 4, 'ifnumber', 8, '1'),
(17, 5, 'itemtype', 9, '1'),
(18, 5, 'ip', 10, '1'),
(19, 5, 'ip', 8, '1'),
(20, 5, 'ifdescr', 10, '1'),
(21, 5, 'ifdescr', 8, '1'),
(22, 5, 'link_criteria_port', 203, '1'),
(23, 6, 'itemtype', 9, '1'),
(24, 6, 'ip', 10, '1'),
(25, 6, 'ip', 8, '1'),
(26, 6, 'ifdescr', 10, '1'),
(27, 6, 'ifdescr', 8, '1'),
(28, 7, 'itemtype', 9, '1'),
(29, 7, 'ip', 8, '1'),
(30, 7, 'ifdescr', 8, '1'),
(31, 8, 'itemtype', 9, '1'),
(32, 8, 'mac', 10, '1'),
(33, 8, 'mac', 8, '1'),
(34, 8, 'only_these_criteria', 204, '1'),
(35, 9, 'itemtype', 9, '1'),
(36, 9, 'mac', 8, '1'),
(37, 9, 'only_these_criteria', 204, '1'),
(38, 10, 'itemtype', 0, 'Computer'),
(39, 10, 'name', 9, '1'),
(40, 11, 'itemtype', 0, 'Computer'),
(41, 11, 'serial', 10, '1'),
(42, 11, 'serial', 8, '1'),
(43, 11, 'uuid', 10, '1'),
(44, 11, 'uuid', 8, '1'),
(45, 12, 'itemtype', 0, 'Computer'),
(46, 12, 'serial', 10, '1'),
(47, 12, 'serial', 8, '1'),
(48, 12, 'uuid', 30, '1'),
(49, 13, 'itemtype', 0, 'Computer'),
(50, 13, 'uuid', 8, '1'),
(51, 13, 'serial', 8, '1'),
(52, 14, 'itemtype', 0, 'Computer'),
(53, 14, 'serial', 10, '1'),
(54, 14, 'serial', 8, '1'),
(55, 15, 'itemtype', 0, 'Computer'),
(56, 15, 'uuid', 10, '1'),
(57, 15, 'uuid', 8, '1'),
(58, 16, 'itemtype', 0, 'Computer'),
(59, 16, 'mac', 10, '1'),
(60, 16, 'mac', 8, '1'),
(61, 17, 'itemtype', 0, 'Computer'),
(62, 17, 'name', 10, '1'),
(63, 17, 'name', 8, '1'),
(64, 18, 'itemtype', 0, 'Computer'),
(65, 18, 'serial', 8, '1'),
(66, 19, 'itemtype', 0, 'Computer'),
(67, 19, 'uuid', 8, '1'),
(68, 20, 'itemtype', 0, 'Computer'),
(69, 20, 'mac', 8, '1'),
(70, 21, 'itemtype', 0, 'Computer'),
(71, 21, 'name', 8, '1'),
(72, 22, 'itemtype', 0, 'Computer'),
(73, 23, 'itemtype', 0, 'Printer'),
(74, 23, 'name', 9, '1'),
(75, 24, 'itemtype', 0, 'Printer'),
(76, 24, 'serial', 8, '1'),
(77, 24, 'serial', 10, '1'),
(78, 25, 'itemtype', 0, 'Printer'),
(79, 25, 'mac', 8, '1'),
(80, 25, 'mac', 10, '1'),
(81, 26, 'itemtype', 0, 'Printer'),
(82, 26, 'serial', 8, '1'),
(83, 27, 'itemtype', 0, 'Printer'),
(84, 27, 'mac', 8, '1'),
(85, 28, 'itemtype', 0, 'Printer'),
(86, 29, 'itemtype', 0, 'NetworkEquipment'),
(87, 29, 'name', 9, '1'),
(88, 30, 'itemtype', 0, 'NetworkEquipment'),
(89, 30, 'serial', 8, '1'),
(90, 30, 'serial', 10, '1'),
(91, 31, 'itemtype', 0, 'NetworkEquipment'),
(92, 31, 'mac', 8, '1'),
(93, 31, 'mac', 10, '1'),
(94, 32, 'itemtype', 0, 'NetworkEquipment'),
(95, 32, 'serial', 8, '1'),
(96, 33, 'itemtype', 0, 'NetworkEquipment'),
(97, 33, 'mac', 8, '1'),
(98, 34, 'itemtype', 0, 'NetworkEquipment'),
(99, 35, 'itemtype', 0, 'Peripheral'),
(100, 35, 'serial', 8, '1'),
(101, 35, 'serial', 10, '1'),
(102, 36, 'itemtype', 0, 'Peripheral'),
(103, 36, 'serial', 8, '1'),
(104, 37, 'itemtype', 0, 'Peripheral'),
(105, 38, 'itemtype', 0, 'Monitor'),
(106, 38, 'serial', 8, '1'),
(107, 38, 'serial', 10, '1'),
(108, 39, 'itemtype', 0, 'Monitor'),
(109, 39, 'serial', 8, '1'),
(110, 40, 'itemtype', 0, 'Monitor'),
(111, 41, 'itemtype', 0, 'Phone'),
(112, 41, 'name', 9, '1'),
(113, 42, 'itemtype', 0, 'Phone'),
(114, 42, 'mac', 10, '1'),
(115, 42, 'mac', 8, '1'),
(116, 43, 'itemtype', 0, 'Phone'),
(117, 43, 'mac', 8, '1'),
(118, 44, 'itemtype', 0, 'Phone'),
(119, 45, 'itemtype', 0, 'Cluster'),
(120, 45, 'uuid', 8, '1'),
(121, 45, 'uuid', 10, '1'),
(122, 46, 'itemtype', 0, 'Cluster'),
(123, 46, 'uuid', 8, '1'),
(124, 47, 'itemtype', 0, 'Cluster'),
(125, 48, 'itemtype', 0, 'Enclosure'),
(126, 48, 'serial', 8, '1'),
(127, 48, 'serial', 10, '1'),
(128, 49, 'itemtype', 0, 'Enclosure'),
(129, 49, 'serial', 8, '1'),
(130, 50, 'itemtype', 0, 'Enclosure'),
(131, 51, 'name', 9, '1'),
(132, 52, 'serial', 8, '1'),
(133, 52, 'serial', 10, '1'),
(134, 53, 'mac', 8, '1'),
(135, 53, 'mac', 10, '1'),
(136, 54, 'serial', 8, '1'),
(137, 55, 'mac', 8, '1'),
(138, 56, 'itemtype', 0, ''),
(139, 57, 'itemtype', 0, 'DatabaseInstance'),
(140, 57, 'name', 8, '1'),
(141, 57, 'name', 10, '1'),
(142, 57, 'linked_item', 10, '1'),
(143, 58, 'itemtype', 0, 'DatabaseInstance'),
(144, 58, 'name', 8, '1'),
(145, 59, 'itemtype', 0, 'DatabaseInstance'),
(146, 60, 'itemtype', 0, 'Unmanaged'),
(147, 60, 'name', 8, '1'),
(148, 60, 'name', 10, '1'),
(149, 61, 'itemtype', 0, 'Unmanaged'),
(150, 61, 'name', 8, '1'),
(151, 62, 'itemtype', 0, 'Unmanaged'),
(152, 63, 'subject', 6, '/.*/'),
(153, 64, 'x-auto-response-suppress', 6, '/\\S+/'),
(154, 65, 'auto-submitted', 6, '/^(?!.*no).+$/i'),
(155, 66, 'TYPE', 0, '3'),
(156, 66, 'TYPE', 0, '2'),
(157, 67, 'name', 0, '*'),
(158, 68, 'locations_id', 9, '1'),
(159, 68, 'items_locations', 8, '1'),
(160, 69, 'locations_id', 9, '1'),
(161, 69, '_locations_id_of_requester', 8, '1'),
(162, 70, '_itemtype', 0, 'Computer'),
(163, 70, '_auto', 0, '1'),
(164, 70, 'contact', 6, '/(.*)@/'),
(165, 71, '_itemtype', 0, 'Computer'),
(166, 71, '_auto', 0, '1'),
(167, 71, 'contact', 6, '/(.*)[,|\\/]/'),
(168, 72, '_itemtype', 0, 'Computer'),
(169, 72, '_auto', 0, '1'),
(170, 72, 'contact', 6, '/(.*)/'),
(171, 73, 'os_name', 6, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]*) ?(?:\\(?([\\w ]+)\\)?)?/'),
(172, 74, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/'),
(173, 75, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/'),
(174, 76, 'os_name', 6, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]+) ?(?:\\(?([\\w ]+)\\)?)?/'),
(175, 77, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/'),
(176, 78, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/'),
(177, 79, 'os_name', 6, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]+) ?(?:\\(?([\\w ]+)\\)?)?/'),
(178, 80, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/'),
(179, 81, 'os_name', 6, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/');

DROP TABLE IF EXISTS `glpi_rulematchedlogs`;
CREATE TABLE `glpi_rulematchedlogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `rules_id` int(10) UNSIGNED DEFAULT NULL,
  `agents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `method` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_rulerightparameters`;
CREATE TABLE `glpi_rulerightparameters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_rulerightparameters` (`id`, `name`, `value`, `comment`, `date_mod`, `date_creation`) VALUES
(1, '(LDAP)Organization', 'o', NULL, NULL, NULL),
(2, '(LDAP)Common Name', 'cn', NULL, NULL, NULL),
(3, '(LDAP)Department Number', 'departmentnumber', NULL, NULL, NULL),
(4, '(LDAP)Email', 'mail', NULL, NULL, NULL),
(5, 'Object Class', 'objectclass', NULL, NULL, NULL),
(6, '(LDAP)User ID', 'uid', NULL, NULL, NULL),
(7, '(LDAP)Telephone Number', 'phone', NULL, NULL, NULL),
(8, '(LDAP)Employee Number', 'employeenumber', NULL, NULL, NULL),
(9, '(LDAP)Manager', 'manager', NULL, NULL, NULL),
(10, '(LDAP)DistinguishedName', 'dn', NULL, NULL, NULL),
(12, '(AD)User ID', 'samaccountname', NULL, NULL, NULL),
(13, '(LDAP) Title', 'title', NULL, NULL, NULL),
(14, '(LDAP) MemberOf', 'memberof', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_rules`;
CREATE TABLE `glpi_rules` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sub_type` varchar(255) NOT NULL DEFAULT '',
  `ranking` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `match` char(10) DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `uuid` varchar(255) DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_rules` (`id`, `entities_id`, `sub_type`, `ranking`, `name`, `description`, `match`, `is_active`, `comment`, `date_mod`, `is_recursive`, `uuid`, `condition`, `date_creation`) VALUES
(1, 0, 'RuleImportAsset', 1, 'No creation on partial import', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_no_creation_on_partial_import', 0, '2023-06-07 20:36:23'),
(2, 0, 'RuleImportAsset', 2, 'Global update (by mac+ifnumber restricted port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_mac_ifnumber_restricted_port', 0, '2023-06-07 20:36:23'),
(3, 0, 'RuleImportAsset', 3, 'Global update (by mac+ifnumber not restricted port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_mac_ifnumber_no_restricted_port', 0, '2023-06-07 20:36:23'),
(4, 0, 'RuleImportAsset', 4, 'Global import (by mac+ifnumber)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_import_mac_ifnumber', 0, '2023-06-07 20:36:23'),
(5, 0, 'RuleImportAsset', 5, 'Global update (by ip+ifdescr restricted port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_mac_ifdescr_restricted_port', 0, '2023-06-07 20:36:23'),
(6, 0, 'RuleImportAsset', 6, 'Global update (by ip+ifdescr not restricted port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_ip_ifdescr_no_restricted_port', 0, '2023-06-07 20:36:23'),
(7, 0, 'RuleImportAsset', 7, 'Global import (by ip+ifdescr)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_import_ip_ifdescr', 0, '2023-06-07 20:36:23'),
(8, 0, 'RuleImportAsset', 8, 'Update only mac address (mac on switch port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_update_only_mac_adress', 0, '2023-06-07 20:36:23'),
(9, 0, 'RuleImportAsset', 9, 'Import only mac address (mac on switch port)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_import_only_mac_adress', 0, '2023-06-07 20:36:23'),
(10, 0, 'RuleImportAsset', 10, 'Computer constraint (name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_constraint_name', 0, '2023-06-07 20:36:23'),
(11, 0, 'RuleImportAsset', 11, 'Computer update (by serial + uuid)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_serial_uuid', 0, '2023-06-07 20:36:23'),
(12, 0, 'RuleImportAsset', 12, 'Computer update (by serial + uuid is empty in GLPI)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_serial_uuid_empty', 0, '2023-06-07 20:36:23'),
(13, 0, 'RuleImportAsset', 13, 'Computer import (by serial + uuid)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_serial_uuid', 0, '2023-06-07 20:36:23'),
(14, 0, 'RuleImportAsset', 14, 'Computer update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_serial', 0, '2023-06-07 20:36:23'),
(15, 0, 'RuleImportAsset', 15, 'Computer update (by uuid)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_uuid', 0, '2023-06-07 20:36:23'),
(16, 0, 'RuleImportAsset', 16, 'Computer update (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_mac', 0, '2023-06-07 20:36:23'),
(17, 0, 'RuleImportAsset', 17, 'Computer update (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_update_name', 0, '2023-06-07 20:36:23'),
(18, 0, 'RuleImportAsset', 18, 'Computer import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_serial', 0, '2023-06-07 20:36:23'),
(19, 0, 'RuleImportAsset', 19, 'Computer import (by uuid)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_uuid', 0, '2023-06-07 20:36:23'),
(20, 0, 'RuleImportAsset', 20, 'Computer import (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_mac', 0, '2023-06-07 20:36:23'),
(21, 0, 'RuleImportAsset', 21, 'Computer import (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_name', 0, '2023-06-07 20:36:23'),
(22, 0, 'RuleImportAsset', 22, 'Computer import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_computer_import_denied', 0, '2023-06-07 20:36:23'),
(23, 0, 'RuleImportAsset', 23, 'Printer constraint (name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_constraint_name', 0, '2023-06-07 20:36:23'),
(24, 0, 'RuleImportAsset', 24, 'Printer update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_update_serial', 0, '2023-06-07 20:36:23'),
(25, 0, 'RuleImportAsset', 25, 'Printer update (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_update_mac', 0, '2023-06-07 20:36:23'),
(26, 0, 'RuleImportAsset', 26, 'Printer import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_import_serial', 0, '2023-06-07 20:36:23'),
(27, 0, 'RuleImportAsset', 27, 'Printer import (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_import_mac', 0, '2023-06-07 20:36:23'),
(28, 0, 'RuleImportAsset', 28, 'Printer import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_printer_import_denied', 0, '2023-06-07 20:36:23'),
(29, 0, 'RuleImportAsset', 29, 'NetworkEquipment constraint (name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_constraint_name', 0, '2023-06-07 20:36:23'),
(30, 0, 'RuleImportAsset', 30, 'NetworkEquipment update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_update_serial', 0, '2023-06-07 20:36:23'),
(31, 0, 'RuleImportAsset', 31, 'NetworkEquipment update (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_update_mac', 0, '2023-06-07 20:36:23'),
(32, 0, 'RuleImportAsset', 32, 'NetworkEquipment import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_import_serial', 0, '2023-06-07 20:36:23'),
(33, 0, 'RuleImportAsset', 33, 'NetworkEquipment import (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_import_mac', 0, '2023-06-07 20:36:23'),
(34, 0, 'RuleImportAsset', 34, 'NetworkEquipment import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_networkequipment_import_denied', 0, '2023-06-07 20:36:23'),
(35, 0, 'RuleImportAsset', 35, 'Device update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_device_update_serial', 0, '2023-06-07 20:36:23'),
(36, 0, 'RuleImportAsset', 36, 'Device import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_device_importe_serial', 0, '2023-06-07 20:36:23'),
(37, 0, 'RuleImportAsset', 37, 'Device import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_device_import_denied', 0, '2023-06-07 20:36:23'),
(38, 0, 'RuleImportAsset', 38, 'Monitor update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_monitor_update_serial', 0, '2023-06-07 20:36:23'),
(39, 0, 'RuleImportAsset', 39, 'Monitor import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_monitor_import_serial', 0, '2023-06-07 20:36:23'),
(40, 0, 'RuleImportAsset', 40, 'Monitor import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_monitor_import_denied', 0, '2023-06-07 20:36:23'),
(41, 0, 'RuleImportAsset', 41, 'Phone constraint (name)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_phone_constraint_name', 0, '2023-06-07 20:36:23'),
(42, 0, 'RuleImportAsset', 42, 'Phone update (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_phone_update_mac', 0, '2023-06-07 20:36:23'),
(43, 0, 'RuleImportAsset', 43, 'Phone import (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_phone_import_mac', 0, '2023-06-07 20:36:23'),
(44, 0, 'RuleImportAsset', 44, 'Phone import denied', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_phone_import_denied', 0, '2023-06-07 20:36:23'),
(45, 0, 'RuleImportAsset', 45, 'Cluster update (by uuid)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_cluster_update_uuid', 0, '2023-06-07 20:36:23'),
(46, 0, 'RuleImportAsset', 46, 'Cluster import (by uuid)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_cluster_import_uuid', 0, '2023-06-07 20:36:23'),
(47, 0, 'RuleImportAsset', 47, 'Cluster import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_cluster_import_denied', 0, '2023-06-07 20:36:23'),
(48, 0, 'RuleImportAsset', 48, 'Enclosure update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_enclosure_update_serial', 0, '2023-06-07 20:36:23'),
(49, 0, 'RuleImportAsset', 49, 'Enclosure import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_enclosure_import_serial', 0, '2023-06-07 20:36:23'),
(50, 0, 'RuleImportAsset', 50, 'Enclosure import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_enclosure_import_denied', 0, '2023-06-07 20:36:23'),
(51, 0, 'RuleImportAsset', 51, 'Global constraint (name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_constraint_name', 0, '2023-06-07 20:36:23'),
(52, 0, 'RuleImportAsset', 52, 'Global update (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_serial', 0, '2023-06-07 20:36:23'),
(53, 0, 'RuleImportAsset', 53, 'Global update (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_update_mac', 0, '2023-06-07 20:36:23'),
(54, 0, 'RuleImportAsset', 54, 'Global import (by serial)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_import_serial', 0, '2023-06-07 20:36:23'),
(55, 0, 'RuleImportAsset', 55, 'Global import (by mac)', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_import_mac', 0, '2023-06-07 20:36:23'),
(56, 0, 'RuleImportAsset', 56, 'Global import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_global_import_denied', 0, '2023-06-07 20:36:23'),
(57, 0, 'RuleImportAsset', 57, 'Database update (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_database_update_name', 0, '2023-06-07 20:36:23'),
(58, 0, 'RuleImportAsset', 58, 'Database import (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_database_import_name', 0, '2023-06-07 20:36:23'),
(59, 0, 'RuleImportAsset', 59, 'Database import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_database_import_denied', 0, '2023-06-07 20:36:23'),
(60, 0, 'RuleImportAsset', 60, 'Unmanaged update (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_unmanaged_update_name', 0, '2023-06-07 20:36:23'),
(61, 0, 'RuleImportAsset', 61, 'Unmanaged import (by name)', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_unmanaged_import_name', 0, '2023-06-07 20:36:23'),
(62, 0, 'RuleImportAsset', 62, 'Unmanaged import denied', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_import_asset_unmanaged_import_denied', 0, '2023-06-07 20:36:23'),
(63, 0, 'RuleMailCollector', 3, 'Root', '', 'OR', 1, '', '2023-06-07 20:36:23', 0, 'glpi_rule_mail_collector_root', 0, '2023-06-07 20:36:23'),
(64, 0, 'RuleMailCollector', 1, 'X-Auto-Response-Suppress', 'Exclude Auto-Reply emails using X-Auto-Response-Suppress header', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_mail_collector_x_auto_response_suppress', 0, '2023-06-07 20:36:23'),
(65, 0, 'RuleMailCollector', 2, 'Auto-Reply Auto-Submitted', 'Exclude Auto-Reply emails using Auto-Submitted header', 'OR', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_mail_collector_auto_reply_auto_submitted', 0, '2023-06-07 20:36:23'),
(66, 0, 'RuleRight', 1, 'Root', '', 'OR', 1, '', '2023-06-07 20:36:23', 0, 'glpi_rule_right_root', 0, '2023-06-07 20:36:23'),
(67, 0, 'RuleSoftwareCategory', 1, 'Import category from inventory tool', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_software_category_import_category_from_inventory_tool', 1, '2023-06-07 20:36:23'),
(68, 0, 'RuleTicket', 1, 'Ticket location from item', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_ticket_location_from_item', 1, '2023-06-07 20:36:23'),
(69, 0, 'RuleTicket', 2, 'Ticket location from user', '', 'AND', 0, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_ticket_location_from_user', 1, '2023-06-07 20:36:23'),
(70, 0, 'RuleAsset', 1, 'Domain user assignation', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_asset_domain_user_assignation', 3, '2023-06-07 20:36:23'),
(71, 0, 'RuleAsset', 2, 'Multiple users: assign to the first', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_asset_multiple_user_assign_to_first', 3, '2023-06-07 20:36:23'),
(72, 0, 'RuleAsset', 3, 'One user assignation', '', 'AND', 1, '', '2023-06-07 20:36:23', 1, 'glpi_rule_rule_asset_one_user_assignation', 3, '2023-06-07 20:36:23'),
(73, 0, 'RuleDictionnaryOperatingSystem', 1, 'Clean Linux OS Name', '', 'AND', 0, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]*) ?(?:\\(?([\\w ]+)\\)?)?/\n\n            Example :\n            Ubuntu 22.04.1 LTS -&#62; #0 = Ubuntu\n            SUSE Linux Enterprise Server 11 (x86_64)  -&#62;#0 = SUSE\n            SunOS -&#62; #0 = SunOS\n            Red Hat Enterprise Linux Server release 7.9 (Maipo) -&#62; #0 = Red Hat\n            Oracle Linux Server release 7.3 -&#62; #0 = Oracle\n            Fedora release 36 (Thirty Six) -&#62; #0 = Fedora\n            Debian GNU/Linux 9.5 (stretch) -&#62; #0 = Debian\n            CentOS Stream release 8 -&#62; #0 = CentOS\n            AlmaLinux 9.0 (Emerald Puma) -&#62; #0 = AlmaLinux', '2023-06-07 20:36:23', 1, 'clean_linux_os_name', 0, '2023-06-07 20:36:23'),
(74, 0, 'RuleDictionnaryOperatingSystem', 2, 'Clean Windows OS Name', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/\n\n            Example :\n            Microsoft Windows XP Professionnel -&#62; #1 : Windows\n            Microsoft Windows 7 Enterprise  -&#62; #1 : Windows\n            Microsoft® Windows Vista Professionnel  -&#62; #1 : Windows\n            Microsoft Windows XP Édition familiale  -&#62; #1 : Windows\n            Microsoft Windows 10 Entreprise  -&#62; #1 : Windows\n            Microsoft Windows 10 Professionnel  -&#62; #1 : Windows\n            Microsoft Windows 11 Professionnel  -&#62; #1 : Windows', '2023-06-07 20:36:23', 1, 'clean_windows_os_name', 0, '2023-06-07 20:36:23'),
(75, 0, 'RuleDictionnaryOperatingSystem', 3, 'Clean Windows Server OS Name', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/\n\n            Example :\n            Microsoft Windows Server 2012 R2 Datacenter -&#62; #1 #2 : Windows Server\n            Microsoft(R) Windows(R) Server 2003, Standard Edition x64 -&#62; #1 #2 : Windows Server\n            Microsoft Hyper-V Server 2012 R2 -&#62; #1 #2 : Hyper-V Server\n            Microsoft® Windows Server® 2008 Standard -&#62; #1 #2 : Windows Server', '2023-06-07 20:36:23', 1, 'clean_windows_server_os_name', 0, '2023-06-07 20:36:23'),
(76, 0, 'RuleDictionnaryOperatingSystemVersion', 1, 'Clean Linux OS Version', '', 'AND', 0, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]+) ?(?:\\(?([\\w ]+)\\)?)?/\n\n            Example :\n            Ubuntu 22.04.1 LTS -&#62; #1 = 22.04.1\n            SUSE Linux Enterprise Server 11 (x86_64) -&#62; #1 =  11\n            SunOS 5.10 -&#62; #1 = 5.10\n            Red Hat Enterprise Linux Server release 7.9 (Maipo) -&#62; #1 = 7.9\n            Oracle Linux Server release 7.3 -&#62; #1 = 7.3\n            Fedora release 36 (Thirty Six) -&#62; #1 =  36\n            Debian GNU/Linux 9.5 (stretch) -&#62; #1 = 9.5\n            CentOS release 6.9 (Final) -&#62; #1 = 6.9\n            AlmaLinux 9.0 (Emerald Puma) -&#62; #1 = 9.0', '2023-06-07 20:36:23', 1, 'clean_linux_os_version', 0, '2023-06-07 20:36:23'),
(77, 0, 'RuleDictionnaryOperatingSystemVersion', 2, 'Clean Windows OS Version', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/\n\n            Example :\n            Microsoft Windows XP Professionnel -&#62; #2 : XP\n            Microsoft Windows 7 Enterprise  -&#62; #2 : 7\n            Microsoft® Windows Vista Professionnel  -&#62; #2 : Vista\n            Microsoft Windows XP Édition familiale  -&#62; #2 : XP\n            Microsoft Windows 10 Entreprise  -&#62; #2 : 10\n            Microsoft Windows 10 Professionnel  -&#62; #2 : 10\n            Microsoft Windows 11 Professionnel  -&#62; #2 : 11', '2023-06-07 20:36:23', 1, 'clean_windows_os_version', 0, '2023-06-07 20:36:23'),
(78, 0, 'RuleDictionnaryOperatingSystemVersion', 3, 'Clean Windows Server OS Version', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/\n\n            Example :\n            Microsoft Windows Server 2012 R2 Datacenter -&#62; #3 : 2012 R2\n            Microsoft(R) Windows(R) Server 2003, Standard Edition x64 -&#62; #3 : 2003\n            Microsoft Hyper-V Server 2012 R2 -&#62; #3 : 2012 R2\n            Microsoft® Windows Server® 2008 Standard -&#62; #3 : 2008', '2023-06-07 20:36:23', 1, 'clean_windows_server_os_version', 0, '2023-06-07 20:36:23'),
(79, 0, 'RuleDictionnaryOperatingSystemEdition', 1, 'Clean Linux OS Edition', '', 'AND', 0, '/(SUSE|SunOS|Red Hat|CentOS|Ubuntu|Debian|Fedora|AlmaLinux|Oracle)(?:\\D+|)([\\d.]+) ?(?:\\(?([\\w ]+)\\)?)?/\n\n        Example :\n        Ubuntu 22.04.1 LTS -&#62; #2 = LTS\n        SUSE Linux Enterprise Server 11 (x86_64) -&#62; #2 = x86_64\n        Red Hat Enterprise Linux Server release 7.9 (Maipo) -&#62; #2 = Maipo\n        Red Hat Enterprise Linux Server release 6.10 (Santiago) -&#62; #2 = Santiago\n        Fedora release 36 (Thirty Six) -&#62; #2 = Thirty Six\n        Debian GNU/Linux 9.5 (stretch) -&#62; #2 = stretch\n        Debian GNU/Linux 8.9 (jessie) -&#62; #2 = jessie\n        CentOS Linux release 7.2.1511 (Core) -&#62; #2 = Core\n        AlmaLinux 9.0 (Emerald Puma) -&#62; #2 = Emerald Puma\n        AlmaLinux 8.6 (Sky Tiger) -&#62; #2 = Sky Tiger', '2023-06-07 20:36:23', 1, 'clean_linux_os_edition', 0, '2023-06-07 20:36:23'),
(80, 0, 'RuleDictionnaryOperatingSystemEdition', 2, 'Clean Windows OS Edition', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (Windows) (XP|\\d\\.\\d|\\d{1,4}|Vista)(™)? ?(.*)/\n\n        Example :\n        Microsoft Windows XP Professionnel -&#62; #4 : Professionnel\n        Microsoft Windows 7 Enterprise  -&#62; #4 : Enterprise\n        Microsoft® Windows Vista Professionnel  -&#62; #4 : Professionnel\n        Microsoft Windows XP Édition familiale  -&#62; #4 : Édition familiale\n        Microsoft Windows 10 Entreprise  -&#62; #4 : Entreprise\n        Microsoft Windows 10 Professionnel  -&#62; #4 : Professionnel\n        Microsoft Windows 11 Professionnel  -&#62; #4 : Professionnel', '2023-06-07 20:36:23', 1, 'clean_windows_os_edition', 0, '2023-06-07 20:36:23'),
(81, 0, 'RuleDictionnaryOperatingSystemEdition', 3, 'Clean Windows Server OS Edition', '', 'AND', 0, '/(Microsoft)(?&#62;\\(R\\)|®)? (?:(Hyper-V|Windows)(?:\\(R\\))?) ((?:Server|))(?:\\(R\\)|®)? (\\d{4}(?: R2)?)(?:[,\\s]++)?([^\\s]*)(?: Edition(?: x64)?)?$/\n\n        Example :\n        Microsoft Windows Server 2012 R2 Datacenter -&#62; #4 : Datacenter\n        Microsoft(R) Windows(R) Server 2003, Standard Edition x64 -&#62; #4 : Standard\n        Microsoft Hyper-V Server 2012 R2 -&#62; #4 :\n        Microsoft® Windows Server® 2008 Standard -&#62; #4: Standard', '2023-06-07 20:36:23', 1, 'clean_windows_server_os_edition', 0, '2023-06-07 20:36:23');

DROP TABLE IF EXISTS `glpi_savedsearches`;
CREATE TABLE `glpi_savedsearches` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 0 COMMENT 'see SavedSearch:: constants',
  `itemtype` varchar(100) NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_private` tinyint(4) NOT NULL DEFAULT 1,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `query` text DEFAULT NULL,
  `last_execution_time` int(11) DEFAULT NULL,
  `do_count` tinyint(4) NOT NULL DEFAULT 2 COMMENT 'Do or do not count results on list display see SavedSearch::COUNT_* constants',
  `last_execution_date` timestamp NULL DEFAULT NULL,
  `counter` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_savedsearches_alerts`;
CREATE TABLE `glpi_savedsearches_alerts` (
  `id` int(10) UNSIGNED NOT NULL,
  `savedsearches_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `operator` tinyint(4) NOT NULL,
  `value` int(11) NOT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `frequency` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_savedsearches_users`;
CREATE TABLE `glpi_savedsearches_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) NOT NULL,
  `savedsearches_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slalevelactions`;
CREATE TABLE `glpi_slalevelactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `slalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `action_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slalevelcriterias`;
CREATE TABLE `glpi_slalevelcriterias` (
  `id` int(10) UNSIGNED NOT NULL,
  `slalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `criteria` varchar(255) DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT 0 COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slalevels`;
CREATE TABLE `glpi_slalevels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slas_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `match` char(10) DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slalevels_tickets`;
CREATE TABLE `glpi_slalevels_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `slalevels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slas`;
CREATE TABLE `glpi_slas` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `number_time` int(11) NOT NULL,
  `use_ticket_calendar` tinyint(4) NOT NULL DEFAULT 0,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `definition_time` varchar(255) DEFAULT NULL,
  `end_of_working_day` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `slms_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_slms`;
CREATE TABLE `glpi_slms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `use_ticket_calendar` tinyint(4) NOT NULL DEFAULT 0,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_snmpcredentials`;
CREATE TABLE `glpi_snmpcredentials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `snmpversion` varchar(8) NOT NULL DEFAULT '1',
  `community` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `authentication` varchar(255) DEFAULT NULL,
  `auth_passphrase` varchar(255) DEFAULT NULL,
  `encryption` varchar(255) DEFAULT NULL,
  `priv_passphrase` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_snmpcredentials` (`id`, `name`, `snmpversion`, `community`, `username`, `authentication`, `auth_passphrase`, `encryption`, `priv_passphrase`, `is_deleted`) VALUES
(1, 'Public community v1', '1', 'public', NULL, NULL, NULL, NULL, NULL, 0),
(2, 'Public community v2c', '2', 'public', NULL, NULL, NULL, NULL, NULL, 0);

DROP TABLE IF EXISTS `glpi_socketmodels`;
CREATE TABLE `glpi_socketmodels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_sockets`;
CREATE TABLE `glpi_sockets` (
  `id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `socketmodels_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `wiring_side` tinyint(4) DEFAULT 1,
  `itemtype` varchar(255) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networkports_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_softwarecategories`;
CREATE TABLE `glpi_softwarecategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `softwarecategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_softwarecategories` (`id`, `name`, `comment`, `softwarecategories_id`, `completename`, `level`, `ancestors_cache`, `sons_cache`) VALUES
(1, 'Inventoried', NULL, 0, 'Software from inventories', 1, NULL, NULL);

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
CREATE TABLE `glpi_softwarelicenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `softwares_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `softwarelicenses_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL DEFAULT 0,
  `softwarelicensetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `softwareversions_id_buy` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `softwareversions_id_use` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `expire` date DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `is_valid` tinyint(4) NOT NULL DEFAULT 1,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_helpdesk_visible` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `allow_overquota` tinyint(4) NOT NULL DEFAULT 0,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_softwarelicensetypes`;
CREATE TABLE `glpi_softwarelicensetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `softwarelicensetypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_softwarelicensetypes` (`id`, `name`, `comment`, `date_mod`, `date_creation`, `softwarelicensetypes_id`, `level`, `ancestors_cache`, `sons_cache`, `entities_id`, `is_recursive`, `completename`) VALUES
(1, 'OEM', NULL, NULL, NULL, 0, 0, NULL, NULL, 0, 1, 'OEM');

DROP TABLE IF EXISTS `glpi_softwares`;
CREATE TABLE `glpi_softwares` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_update` tinyint(4) NOT NULL DEFAULT 0,
  `softwares_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `is_template` tinyint(4) NOT NULL DEFAULT 0,
  `template_name` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ticket_tco` decimal(20,4) DEFAULT 0.0000,
  `is_helpdesk_visible` tinyint(4) NOT NULL DEFAULT 1,
  `softwarecategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_valid` tinyint(4) NOT NULL DEFAULT 1,
  `date_creation` timestamp NULL DEFAULT NULL,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_softwareversions`;
CREATE TABLE `glpi_softwareversions` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `softwares_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `arch` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `operatingsystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_solutiontemplates`;
CREATE TABLE `glpi_solutiontemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `solutiontypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_solutiontypes`;
CREATE TABLE `glpi_solutiontypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ssovariables`;
CREATE TABLE `glpi_ssovariables` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_ssovariables` (`id`, `name`, `comment`, `date_mod`, `date_creation`) VALUES
(1, 'HTTP_AUTH_USER', NULL, NULL, NULL),
(2, 'REMOTE_USER', NULL, NULL, NULL),
(3, 'PHP_AUTH_USER', NULL, NULL, NULL),
(4, 'USERNAME', NULL, NULL, NULL),
(5, 'REDIRECT_REMOTE_USER', NULL, NULL, NULL),
(6, 'HTTP_REMOTE_USER', NULL, NULL, NULL);

DROP TABLE IF EXISTS `glpi_states`;
CREATE TABLE `glpi_states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `completename` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `is_visible_computer` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_monitor` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_networkequipment` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_peripheral` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_phone` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_printer` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_softwareversion` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_softwarelicense` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_line` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_certificate` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_rack` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_passivedcequipment` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_enclosure` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_pdu` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_cluster` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_contract` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_appliance` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_databaseinstance` tinyint(4) NOT NULL DEFAULT 1,
  `is_visible_cable` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_suppliers`;
CREATE TABLE `glpi_suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `suppliertypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `registration_number` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `pictures` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_suppliers_tickets`;
CREATE TABLE `glpi_suppliers_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `suppliers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 1,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_suppliertypes`;
CREATE TABLE `glpi_suppliertypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_taskcategories`;
CREATE TABLE `glpi_taskcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `taskcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `completename` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `ancestors_cache` longtext DEFAULT NULL,
  `sons_cache` longtext DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_helpdeskvisible` tinyint(4) NOT NULL DEFAULT 1,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `knowbaseitemcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tasktemplates`;
CREATE TABLE `glpi_tasktemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `taskcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `is_private` tinyint(4) NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ticketcosts`;
CREATE TABLE `glpi_ticketcosts` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `cost_time` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `cost_material` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `budgets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ticketrecurrents`;
CREATE TABLE `glpi_ticketrecurrents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `begin_date` timestamp NULL DEFAULT NULL,
  `periodicity` varchar(255) DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT 0,
  `next_creation_date` timestamp NULL DEFAULT NULL,
  `calendars_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `end_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickets`;
CREATE TABLE `glpi_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `closedate` timestamp NULL DEFAULT NULL,
  `solvedate` timestamp NULL DEFAULT NULL,
  `takeintoaccountdate` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `users_id_lastupdater` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1,
  `users_id_recipient` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `requesttypes_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `urgency` int(11) NOT NULL DEFAULT 1,
  `impact` int(11) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 1,
  `itilcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `global_validation` int(11) NOT NULL DEFAULT 1,
  `slas_id_ttr` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `slas_id_tto` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `slalevels_id_ttr` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `time_to_resolve` timestamp NULL DEFAULT NULL,
  `time_to_own` timestamp NULL DEFAULT NULL,
  `begin_waiting_date` timestamp NULL DEFAULT NULL,
  `sla_waiting_duration` int(11) NOT NULL DEFAULT 0,
  `ola_waiting_duration` int(11) NOT NULL DEFAULT 0,
  `olas_id_tto` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `olas_id_ttr` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `olalevels_id_ttr` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ola_tto_begin_date` timestamp NULL DEFAULT NULL,
  `ola_ttr_begin_date` timestamp NULL DEFAULT NULL,
  `internal_time_to_resolve` timestamp NULL DEFAULT NULL,
  `internal_time_to_own` timestamp NULL DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT 0,
  `close_delay_stat` int(11) NOT NULL DEFAULT 0,
  `solve_delay_stat` int(11) NOT NULL DEFAULT 0,
  `takeintoaccount_delay_stat` int(11) NOT NULL DEFAULT 0,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `validation_percent` int(11) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_ticketsatisfactions`;
CREATE TABLE `glpi_ticketsatisfactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `date_begin` timestamp NULL DEFAULT NULL,
  `date_answered` timestamp NULL DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickets_contracts`;
CREATE TABLE `glpi_tickets_contracts` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `contracts_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickets_tickets`;
CREATE TABLE `glpi_tickets_tickets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id_1` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id_2` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `link` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickets_users`;
CREATE TABLE `glpi_tickets_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1,
  `use_notification` tinyint(4) NOT NULL DEFAULT 1,
  `alternative_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickettasks`;
CREATE TABLE `glpi_tickettasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `taskcategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date` timestamp NULL DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_editor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` longtext DEFAULT NULL,
  `is_private` tinyint(4) NOT NULL DEFAULT 0,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `begin` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 1,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `tasktemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0,
  `sourceitems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sourceof_items_id` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickettemplatehiddenfields`;
CREATE TABLE `glpi_tickettemplatehiddenfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickettemplatemandatoryfields`;
CREATE TABLE `glpi_tickettemplatemandatoryfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_tickettemplatemandatoryfields` (`id`, `tickettemplates_id`, `num`) VALUES
(1, 1, 21);

DROP TABLE IF EXISTS `glpi_tickettemplatepredefinedfields`;
CREATE TABLE `glpi_tickettemplatepredefinedfields` (
  `id` int(10) UNSIGNED NOT NULL,
  `tickettemplates_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `num` int(11) NOT NULL DEFAULT 0,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_tickettemplates`;
CREATE TABLE `glpi_tickettemplates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_tickettemplates` (`id`, `name`, `entities_id`, `is_recursive`, `comment`) VALUES
(1, 'Default', 0, 1, NULL);

DROP TABLE IF EXISTS `glpi_ticketvalidations`;
CREATE TABLE `glpi_ticketvalidations` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `tickets_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_validate` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `comment_submission` text DEFAULT NULL,
  `comment_validation` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 2,
  `submission_date` timestamp NULL DEFAULT NULL,
  `validation_date` timestamp NULL DEFAULT NULL,
  `timeline_position` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_transfers`;
CREATE TABLE `glpi_transfers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `keep_ticket` int(11) NOT NULL DEFAULT 0,
  `keep_networklink` int(11) NOT NULL DEFAULT 0,
  `keep_reservation` int(11) NOT NULL DEFAULT 0,
  `keep_history` int(11) NOT NULL DEFAULT 0,
  `keep_device` int(11) NOT NULL DEFAULT 0,
  `keep_infocom` int(11) NOT NULL DEFAULT 0,
  `keep_dc_monitor` int(11) NOT NULL DEFAULT 0,
  `clean_dc_monitor` int(11) NOT NULL DEFAULT 0,
  `keep_dc_phone` int(11) NOT NULL DEFAULT 0,
  `clean_dc_phone` int(11) NOT NULL DEFAULT 0,
  `keep_dc_peripheral` int(11) NOT NULL DEFAULT 0,
  `clean_dc_peripheral` int(11) NOT NULL DEFAULT 0,
  `keep_dc_printer` int(11) NOT NULL DEFAULT 0,
  `clean_dc_printer` int(11) NOT NULL DEFAULT 0,
  `keep_supplier` int(11) NOT NULL DEFAULT 0,
  `clean_supplier` int(11) NOT NULL DEFAULT 0,
  `keep_contact` int(11) NOT NULL DEFAULT 0,
  `clean_contact` int(11) NOT NULL DEFAULT 0,
  `keep_contract` int(11) NOT NULL DEFAULT 0,
  `clean_contract` int(11) NOT NULL DEFAULT 0,
  `keep_software` int(11) NOT NULL DEFAULT 0,
  `clean_software` int(11) NOT NULL DEFAULT 0,
  `keep_document` int(11) NOT NULL DEFAULT 0,
  `clean_document` int(11) NOT NULL DEFAULT 0,
  `keep_cartridgeitem` int(11) NOT NULL DEFAULT 0,
  `clean_cartridgeitem` int(11) NOT NULL DEFAULT 0,
  `keep_cartridge` int(11) NOT NULL DEFAULT 0,
  `keep_consumable` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `keep_disk` int(11) NOT NULL DEFAULT 0,
  `keep_certificate` int(11) NOT NULL DEFAULT 0,
  `clean_certificate` int(11) NOT NULL DEFAULT 0,
  `lock_updated_fields` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_transfers` (`id`, `name`, `keep_ticket`, `keep_networklink`, `keep_reservation`, `keep_history`, `keep_device`, `keep_infocom`, `keep_dc_monitor`, `clean_dc_monitor`, `keep_dc_phone`, `clean_dc_phone`, `keep_dc_peripheral`, `clean_dc_peripheral`, `keep_dc_printer`, `clean_dc_printer`, `keep_supplier`, `clean_supplier`, `keep_contact`, `clean_contact`, `keep_contract`, `clean_contract`, `keep_software`, `clean_software`, `keep_document`, `clean_document`, `keep_cartridgeitem`, `clean_cartridgeitem`, `keep_cartridge`, `keep_consumable`, `date_mod`, `date_creation`, `comment`, `keep_disk`, `keep_certificate`, `clean_certificate`, `lock_updated_fields`) VALUES
(1, 'complete', 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, NULL, 1, 1, 1, 0);

DROP TABLE IF EXISTS `glpi_unmanageds`;
CREATE TABLE `glpi_unmanageds` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `otherserial` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `networks_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `manufacturers_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `states_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `groups_id_tech` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `date_creation` timestamp NULL DEFAULT NULL,
  `autoupdatesystems_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sysdescr` text DEFAULT NULL,
  `agents_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `itemtype` varchar(100) DEFAULT NULL,
  `accepted` tinyint(4) NOT NULL DEFAULT 0,
  `hub` tinyint(4) NOT NULL DEFAULT 0,
  `ip` varchar(255) DEFAULT NULL,
  `snmpcredentials_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `last_inventory_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_usbvendors`;
CREATE TABLE `glpi_usbvendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `vendorid` varchar(4) NOT NULL,
  `deviceid` varchar(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_usercategories`;
CREATE TABLE `glpi_usercategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_useremails`;
CREATE TABLE `glpi_useremails` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_dynamic` tinyint(4) NOT NULL DEFAULT 0,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_users`;
CREATE TABLE `glpi_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `password_last_update` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `phone2` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `locations_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `language` char(10) DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` int(11) NOT NULL DEFAULT 0,
  `list_limit` int(11) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `comment` text DEFAULT NULL,
  `auths_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `authtype` int(11) NOT NULL DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_sync` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `profiles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `usertitles_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `usercategories_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_format` int(11) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `names_format` int(11) DEFAULT NULL,
  `csv_delimiter` char(1) DEFAULT NULL,
  `is_ids_visible` tinyint(4) DEFAULT NULL,
  `use_flat_dropdowntree` tinyint(4) DEFAULT NULL,
  `show_jobs_at_login` tinyint(4) DEFAULT NULL,
  `priority_1` char(20) DEFAULT NULL,
  `priority_2` char(20) DEFAULT NULL,
  `priority_3` char(20) DEFAULT NULL,
  `priority_4` char(20) DEFAULT NULL,
  `priority_5` char(20) DEFAULT NULL,
  `priority_6` char(20) DEFAULT NULL,
  `followup_private` tinyint(4) DEFAULT NULL,
  `task_private` tinyint(4) DEFAULT NULL,
  `default_requesttypes_id` int(10) UNSIGNED DEFAULT NULL,
  `password_forget_token` char(40) DEFAULT NULL,
  `password_forget_token_date` timestamp NULL DEFAULT NULL,
  `user_dn` text DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `show_count_on_tabs` tinyint(4) DEFAULT NULL,
  `refresh_views` int(11) DEFAULT NULL,
  `set_default_tech` tinyint(4) DEFAULT NULL,
  `personal_token` varchar(255) DEFAULT NULL,
  `personal_token_date` timestamp NULL DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `api_token_date` timestamp NULL DEFAULT NULL,
  `cookie_token` varchar(255) DEFAULT NULL,
  `cookie_token_date` timestamp NULL DEFAULT NULL,
  `display_count_on_home` int(11) DEFAULT NULL,
  `notification_to_myself` tinyint(4) DEFAULT NULL,
  `duedateok_color` varchar(255) DEFAULT NULL,
  `duedatewarning_color` varchar(255) DEFAULT NULL,
  `duedatecritical_color` varchar(255) DEFAULT NULL,
  `duedatewarning_less` int(11) DEFAULT NULL,
  `duedatecritical_less` int(11) DEFAULT NULL,
  `duedatewarning_unit` varchar(255) DEFAULT NULL,
  `duedatecritical_unit` varchar(255) DEFAULT NULL,
  `display_options` text DEFAULT NULL,
  `is_deleted_ldap` tinyint(4) NOT NULL DEFAULT 0,
  `pdffont` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `begin_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `keep_devices_when_purging_item` tinyint(4) DEFAULT NULL,
  `privatebookmarkorder` longtext DEFAULT NULL,
  `backcreated` tinyint(4) DEFAULT NULL,
  `task_state` int(11) DEFAULT NULL,
  `palette` char(20) DEFAULT NULL,
  `page_layout` char(20) DEFAULT NULL,
  `fold_menu` tinyint(4) DEFAULT NULL,
  `fold_search` tinyint(4) DEFAULT NULL,
  `savedsearches_pinned` text DEFAULT NULL,
  `timeline_order` char(20) DEFAULT NULL,
  `itil_layout` text DEFAULT NULL,
  `richtext_layout` char(20) DEFAULT NULL,
  `set_default_requester` tinyint(4) DEFAULT NULL,
  `lock_autolock_mode` tinyint(4) DEFAULT NULL,
  `lock_directunlock_notification` tinyint(4) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL,
  `highcontrast_css` tinyint(4) DEFAULT 0,
  `plannings` text DEFAULT NULL,
  `sync_field` varchar(255) DEFAULT NULL,
  `groups_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `users_id_supervisor` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `timezone` varchar(50) DEFAULT NULL,
  `default_dashboard_central` varchar(100) DEFAULT NULL,
  `default_dashboard_assets` varchar(100) DEFAULT NULL,
  `default_dashboard_helpdesk` varchar(100) DEFAULT NULL,
  `default_dashboard_mini_ticket` varchar(100) DEFAULT NULL,
  `default_central_tab` tinyint(4) DEFAULT 0,
  `nickname` varchar(255) DEFAULT NULL,
  `timeline_action_btn_layout` tinyint(4) DEFAULT 0,
  `timeline_date_format` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `glpi_users` (`id`, `name`, `password`, `password_last_update`, `phone`, `phone2`, `mobile`, `realname`, `firstname`, `locations_id`, `language`, `use_mode`, `list_limit`, `is_active`, `comment`, `auths_id`, `authtype`, `last_login`, `date_mod`, `date_sync`, `is_deleted`, `profiles_id`, `entities_id`, `usertitles_id`, `usercategories_id`, `date_format`, `number_format`, `names_format`, `csv_delimiter`, `is_ids_visible`, `use_flat_dropdowntree`, `show_jobs_at_login`, `priority_1`, `priority_2`, `priority_3`, `priority_4`, `priority_5`, `priority_6`, `followup_private`, `task_private`, `default_requesttypes_id`, `password_forget_token`, `password_forget_token_date`, `user_dn`, `registration_number`, `show_count_on_tabs`, `refresh_views`, `set_default_tech`, `personal_token`, `personal_token_date`, `api_token`, `api_token_date`, `cookie_token`, `cookie_token_date`, `display_count_on_home`, `notification_to_myself`, `duedateok_color`, `duedatewarning_color`, `duedatecritical_color`, `duedatewarning_less`, `duedatecritical_less`, `duedatewarning_unit`, `duedatecritical_unit`, `display_options`, `is_deleted_ldap`, `pdffont`, `picture`, `begin_date`, `end_date`, `keep_devices_when_purging_item`, `privatebookmarkorder`, `backcreated`, `task_state`, `palette`, `page_layout`, `fold_menu`, `fold_search`, `savedsearches_pinned`, `timeline_order`, `itil_layout`, `richtext_layout`, `set_default_requester`, `lock_autolock_mode`, `lock_directunlock_notification`, `date_creation`, `highcontrast_css`, `plannings`, `sync_field`, `groups_id`, `users_id_supervisor`, `timezone`, `default_dashboard_central`, `default_dashboard_assets`, `default_dashboard_helpdesk`, `default_dashboard_mini_ticket`, `default_central_tab`, `nickname`, `timeline_action_btn_layout`, `timeline_date_format`) VALUES
(2, 'glpi', '$2y$10$EVr/44FFpQ4kHTN2YW9FvuwDbl0X4vjrID.xRTryuX9g0F8DjbVFO', '2023-06-07 20:50:14', NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 10, 1, NULL, 0, 1, '2023-06-07 23:47:06', '2023-06-07 23:47:06', NULL, 0, 0, 0, 0, 0, 1, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$10$Lv8xUOjBVeYqcD21tpKlTO8BWsJ9wCCv8mlX8SBLtVVVVazl1ANNa', '2023-06-07 23:47:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, 0),
(3, 'post-only', '$2y$10$Tm2F9SgOcRWOLWUMzOsiRuVrFw8IRBpLMTWbRutwEdnO/VflzZqZi', '2023-06-07 20:50:02', NULL, NULL, NULL, NULL, NULL, 0, 'en_GB', 0, 20, 1, NULL, 0, 1, NULL, '2023-06-07 20:50:02', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0),
(4, 'tech', '$2y$10$Ka7hTVBAOrfNR4LMVfAWrOyyMb2cM08XGJNXoxI/MdUauAEHD5Uli', '2023-06-07 20:50:23', NULL, NULL, NULL, NULL, NULL, 0, 'en_GB', 0, 20, 1, NULL, 0, 1, NULL, '2023-06-07 20:50:23', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0),
(5, 'normal', '$2y$10$tc9PRsvMswPjUIGlJIS9vuozP93yfoqHtMOjDQVmrs.M7bAtiHiLm', '2023-06-07 20:50:27', NULL, NULL, NULL, NULL, NULL, 0, 'en_GB', 0, 20, 1, NULL, 0, 1, NULL, '2023-06-07 20:50:27', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0),
(6, 'glpi-system', '', NULL, NULL, NULL, NULL, 'Support', NULL, 0, NULL, 0, NULL, 1, NULL, 0, 1, NULL, NULL, NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0),
(7, 'Plugin_GLPI_Inventory', '31', NULL, NULL, NULL, NULL, NULL, 'Plugin GLPI Inventory', 0, NULL, 0, NULL, 1, NULL, 0, 1, NULL, '2023-06-07 21:08:19', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-06-07 21:08:19', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0);

DROP TABLE IF EXISTS `glpi_usertitles`;
CREATE TABLE `glpi_usertitles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_virtualmachinestates`;
CREATE TABLE `glpi_virtualmachinestates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_virtualmachinesystems`;
CREATE TABLE `glpi_virtualmachinesystems` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_virtualmachinetypes`;
CREATE TABLE `glpi_virtualmachinetypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_vlans`;
CREATE TABLE `glpi_vlans` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `tag` int(11) NOT NULL DEFAULT 0,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_vobjects`;
CREATE TABLE `glpi_vobjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `itemtype` varchar(100) DEFAULT NULL,
  `items_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `glpi_wifinetworks`;
CREATE TABLE `glpi_wifinetworks` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_recursive` tinyint(4) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `essid` varchar(255) DEFAULT NULL,
  `mode` varchar(255) DEFAULT NULL COMMENT 'ad-hoc, access_point',
  `comment` text DEFAULT NULL,
  `date_mod` timestamp NULL DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


ALTER TABLE `glpi_agents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `deviceid` (`deviceid`),
  ADD KEY `name` (`name`),
  ADD KEY `agenttypes_id` (`agenttypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_agenttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_alerts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  ADD KEY `type` (`type`),
  ADD KEY `date` (`date`);

ALTER TABLE `glpi_apiclients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_applianceenvironments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_appliances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`externalidentifier`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `appliancetypes_id` (`appliancetypes_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `applianceenvironments_id` (`applianceenvironments_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_appliances_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`appliances_id`,`items_id`,`itemtype`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_appliances_items_relations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appliances_items_id` (`appliances_items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_appliancetypes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `externalidentifier` (`externalidentifier`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_authldapreplicates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `authldaps_id` (`authldaps_id`);

ALTER TABLE `glpi_authldaps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_default` (`is_default`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `sync_field` (`sync_field`);

ALTER TABLE `glpi_authmails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_active` (`is_active`);

ALTER TABLE `glpi_autoupdatesystems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_blacklistedmailcontents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_blacklists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_budgets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `budgettypes_id` (`budgettypes_id`);

ALTER TABLE `glpi_budgettypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_businesscriticities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`businesscriticities_id`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_cables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `item_endpoint_a` (`itemtype_endpoint_a`,`items_id_endpoint_a`),
  ADD KEY `item_endpoint_b` (`itemtype_endpoint_b`,`items_id_endpoint_b`),
  ADD KEY `items_id_endpoint_b` (`items_id_endpoint_b`),
  ADD KEY `items_id_endpoint_a` (`items_id_endpoint_a`),
  ADD KEY `socketmodels_id_endpoint_a` (`socketmodels_id_endpoint_a`),
  ADD KEY `socketmodels_id_endpoint_b` (`socketmodels_id_endpoint_b`),
  ADD KEY `sockets_id_endpoint_a` (`sockets_id_endpoint_a`),
  ADD KEY `sockets_id_endpoint_b` (`sockets_id_endpoint_b`),
  ADD KEY `cablestrands_id` (`cablestrands_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `complete` (`entities_id`,`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `cabletypes_id` (`cabletypes_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_deleted` (`is_deleted`);

ALTER TABLE `glpi_cablestrands`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_cabletypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_calendars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_calendarsegments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `calendars_id` (`calendars_id`),
  ADD KEY `day` (`day`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_calendars_holidays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  ADD KEY `holidays_id` (`holidays_id`);

ALTER TABLE `glpi_cartridgeitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `alarm_threshold` (`alarm_threshold`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_cartridgeitems_printermodels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  ADD KEY `cartridgeitems_id` (`cartridgeitems_id`);

ALTER TABLE `glpi_cartridgeitemtypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_cartridges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cartridgeitems_id` (`cartridgeitems_id`),
  ADD KEY `printers_id` (`printers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_certificates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `certificatetypes_id` (`certificatetypes_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_certificates_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`certificates_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_certificatetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_changecosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `changes_id` (`changes_id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `budgets_id` (`budgets_id`);

ALTER TABLE `glpi_changes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date` (`date`),
  ADD KEY `closedate` (`closedate`),
  ADD KEY `status` (`status`),
  ADD KEY `priority` (`priority`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `itilcategories_id` (`itilcategories_id`),
  ADD KEY `users_id_recipient` (`users_id_recipient`),
  ADD KEY `solvedate` (`solvedate`),
  ADD KEY `urgency` (`urgency`),
  ADD KEY `impact` (`impact`),
  ADD KEY `time_to_resolve` (`time_to_resolve`),
  ADD KEY `global_validation` (`global_validation`),
  ADD KEY `users_id_lastupdater` (`users_id_lastupdater`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_changes_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  ADD KEY `group` (`groups_id`,`type`);

ALTER TABLE `glpi_changes_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_changes_problems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  ADD KEY `problems_id` (`problems_id`);

ALTER TABLE `glpi_changes_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  ADD KEY `group` (`suppliers_id`,`type`);

ALTER TABLE `glpi_changes_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  ADD KEY `tickets_id` (`tickets_id`);

ALTER TABLE `glpi_changes_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  ADD KEY `user` (`users_id`,`type`);

ALTER TABLE `glpi_changetasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `changes_id` (`changes_id`),
  ADD KEY `state` (`state`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_editor` (`users_id_editor`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `taskcategories_id` (`taskcategories_id`),
  ADD KEY `tasktemplates_id` (`tasktemplates_id`),
  ADD KEY `is_private` (`is_private`);

ALTER TABLE `glpi_changetemplatehiddenfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changetemplates_id`,`num`);

ALTER TABLE `glpi_changetemplatemandatoryfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`changetemplates_id`,`num`);

ALTER TABLE `glpi_changetemplatepredefinedfields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `changetemplates_id` (`changetemplates_id`);

ALTER TABLE `glpi_changetemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_changevalidations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_validate` (`users_id_validate`),
  ADD KEY `changes_id` (`changes_id`),
  ADD KEY `submission_date` (`submission_date`),
  ADD KEY `validation_date` (`validation_date`),
  ADD KEY `status` (`status`);

ALTER TABLE `glpi_clusters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `group_id_tech` (`groups_id_tech`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `clustertypes_id` (`clustertypes_id`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_clustertypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_computerantiviruses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `antivirus_version` (`antivirus_version`),
  ADD KEY `signature_version` (`signature_version`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_uptodate` (`is_uptodate`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `computers_id` (`computers_id`),
  ADD KEY `date_expiration` (`date_expiration`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`);

ALTER TABLE `glpi_computermodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_computers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `computermodels_id` (`computermodels_id`),
  ADD KEY `networks_id` (`networks_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `computertypes_id` (`computertypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_computers_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `computers_id` (`computers_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`);

ALTER TABLE `glpi_computertypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_computervirtualmachines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `computers_id` (`computers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `name` (`name`),
  ADD KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  ADD KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  ADD KEY `vcpu` (`vcpu`),
  ADD KEY `ram` (`ram`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `virtualmachinetypes_id` (`virtualmachinetypes_id`);

ALTER TABLE `glpi_configs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`context`,`name`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_consumableitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `alarm_threshold` (`alarm_threshold`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `otherserial` (`otherserial`);

ALTER TABLE `glpi_consumableitemtypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_consumables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_in` (`date_in`),
  ADD KEY `date_out` (`date_out`),
  ADD KEY `consumableitems_id` (`consumableitems_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `contacttypes_id` (`contacttypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `usertitles_id` (`usertitles_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_contacts_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  ADD KEY `contacts_id` (`contacts_id`);

ALTER TABLE `glpi_contacttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_contractcosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `contracts_id` (`contracts_id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `budgets_id` (`budgets_id`);

ALTER TABLE `glpi_contracts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `name` (`name`),
  ADD KEY `contracttypes_id` (`contracttypes_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `use_sunday` (`use_sunday`),
  ADD KEY `use_saturday` (`use_saturday`),
  ADD KEY `alert` (`alert`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_contracts_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_contracts_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  ADD KEY `contracts_id` (`contracts_id`);

ALTER TABLE `glpi_contracttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_crontasklogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `crontasks_id` (`crontasks_id`),
  ADD KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`);

ALTER TABLE `glpi_crontasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `mode` (`mode`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_dashboards_dashboards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `name` (`name`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_dashboards_filters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboards_dashboards_id` (`dashboards_dashboards_id`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_dashboards_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboards_dashboards_id` (`dashboards_dashboards_id`);

ALTER TABLE `glpi_dashboards_rights`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`dashboards_dashboards_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_databaseinstancecategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_databaseinstances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `databaseinstancetypes_id` (`databaseinstancetypes_id`),
  ADD KEY `databaseinstancecategories_id` (`databaseinstancecategories_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`);

ALTER TABLE `glpi_databaseinstancetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_databases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `databaseinstances_id` (`databaseinstances_id`);

ALTER TABLE `glpi_datacenters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_dcrooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `datacenters_id` (`datacenters_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicebatteries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicebatterymodels_id` (`devicebatterymodels_id`),
  ADD KEY `devicebatterytypes_id` (`devicebatterytypes_id`);

ALTER TABLE `glpi_devicebatterymodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicebatterytypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicecameramodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicecameras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicecameramodels_id` (`devicecameramodels_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicecasemodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicecases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicecasetypes_id` (`devicecasetypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicecasemodels_id` (`devicecasemodels_id`);

ALTER TABLE `glpi_devicecasetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicecontrolmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicecontrols`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `interfacetypes_id` (`interfacetypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicecontrolmodels_id` (`devicecontrolmodels_id`);

ALTER TABLE `glpi_devicedrivemodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicedrives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `interfacetypes_id` (`interfacetypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicedrivemodels_id` (`devicedrivemodels_id`);

ALTER TABLE `glpi_devicefirmwaremodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicefirmwares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicefirmwaremodels_id` (`devicefirmwaremodels_id`),
  ADD KEY `devicefirmwaretypes_id` (`devicefirmwaretypes_id`);

ALTER TABLE `glpi_devicefirmwaretypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicegenericmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicegenerics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicegenerictypes_id` (`devicegenerictypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicegenericmodels_id` (`devicegenericmodels_id`);

ALTER TABLE `glpi_devicegenerictypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_devicegraphiccardmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicegraphiccards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `interfacetypes_id` (`interfacetypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `chipset` (`chipset`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicegraphiccardmodels_id` (`devicegraphiccardmodels_id`);

ALTER TABLE `glpi_deviceharddrivemodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_deviceharddrives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `interfacetypes_id` (`interfacetypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `deviceharddrivemodels_id` (`deviceharddrivemodels_id`);

ALTER TABLE `glpi_devicememories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicememorytypes_id` (`devicememorytypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicememorymodels_id` (`devicememorymodels_id`);

ALTER TABLE `glpi_devicememorymodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicememorytypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicemotherboardmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicemotherboards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicemotherboardmodels_id` (`devicemotherboardmodels_id`);

ALTER TABLE `glpi_devicenetworkcardmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicenetworkcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicenetworkcardmodels_id` (`devicenetworkcardmodels_id`);

ALTER TABLE `glpi_devicepcimodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicepcis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicenetworkcardmodels_id` (`devicenetworkcardmodels_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicepcimodels_id` (`devicepcimodels_id`);

ALTER TABLE `glpi_devicepowersupplies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicepowersupplymodels_id` (`devicepowersupplymodels_id`);

ALTER TABLE `glpi_devicepowersupplymodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_deviceprocessormodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_deviceprocessors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `deviceprocessormodels_id` (`deviceprocessormodels_id`);

ALTER TABLE `glpi_devicesensormodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicesensors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `devicesensortypes_id` (`devicesensortypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicesensormodels_id` (`devicesensormodels_id`);

ALTER TABLE `glpi_devicesensortypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_devicesimcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `devicesimcardtypes_id` (`devicesimcardtypes_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`);

ALTER TABLE `glpi_devicesimcardtypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_devicesoundcardmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_devicesoundcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designation` (`designation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `devicesoundcardmodels_id` (`devicesoundcardmodels_id`);

ALTER TABLE `glpi_displaypreferences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  ADD KEY `rank` (`rank`),
  ADD KEY `num` (`num`),
  ADD KEY `itemtype` (`itemtype`);

ALTER TABLE `glpi_documentcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`documentcategories_id`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `tickets_id` (`tickets_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `documentcategories_id` (`documentcategories_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `sha1sum` (`sha1sum`),
  ADD KEY `tag` (`tag`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_documents_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`,`timeline_position`),
  ADD KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date` (`date`);

ALTER TABLE `glpi_documenttypes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`ext`),
  ADD KEY `name` (`name`),
  ADD KEY `is_uploadable` (`is_uploadable`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_domainrecords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `domains_id` (`domains_id`),
  ADD KEY `domainrecordtypes_id` (`domainrecordtypes_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_domainrecordtypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_domainrelations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_domains`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `domaintypes_id` (`domaintypes_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_expiration` (`date_expiration`),
  ADD KEY `date_domaincreation` (`date_domaincreation`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_domains_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`domains_id`,`itemtype`,`items_id`),
  ADD KEY `domainrelations_id` (`domainrelations_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted` (`is_deleted`);

ALTER TABLE `glpi_domaintypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_dropdowntranslations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  ADD KEY `language` (`language`),
  ADD KEY `field` (`field`);

ALTER TABLE `glpi_enclosuremodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_enclosures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `enclosuremodels_id` (`enclosuremodels_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `group_id_tech` (`groups_id_tech`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_entities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`entities_id`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `tickettemplates_id` (`tickettemplates_id`),
  ADD KEY `changetemplates_id` (`changetemplates_id`),
  ADD KEY `problemtemplates_id` (`problemtemplates_id`),
  ADD KEY `transfers_id` (`transfers_id`),
  ADD KEY `authldaps_id` (`authldaps_id`),
  ADD KEY `calendars_id` (`calendars_id`),
  ADD KEY `entities_id_software` (`entities_id_software`),
  ADD KEY `contracts_id_default` (`contracts_id_default`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_entities_knowbaseitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_entities_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reminders_id` (`reminders_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_entities_rssfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rssfeeds_id` (`rssfeeds_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `level` (`level`),
  ADD KEY `item` (`type`,`items_id`);

ALTER TABLE `glpi_fieldblacklists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_fieldunicities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_filesystems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_fqdns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `name` (`name`),
  ADD KEY `fqdn` (`fqdn`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `ldap_field` (`ldap_field`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `ldap_value` (`ldap_value`(200)),
  ADD KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `is_requester` (`is_requester`),
  ADD KEY `is_watcher` (`is_watcher`),
  ADD KEY `is_assign` (`is_assign`),
  ADD KEY `is_notify` (`is_notify`),
  ADD KEY `is_itemgroup` (`is_itemgroup`),
  ADD KEY `is_usergroup` (`is_usergroup`),
  ADD KEY `is_manager` (`is_manager`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_groups_knowbaseitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_groups_problems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  ADD KEY `group` (`groups_id`,`type`);

ALTER TABLE `glpi_groups_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reminders_id` (`reminders_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_groups_rssfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rssfeeds_id` (`rssfeeds_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_groups_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  ADD KEY `group` (`groups_id`,`type`);

ALTER TABLE `glpi_groups_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_manager` (`is_manager`),
  ADD KEY `is_userdelegate` (`is_userdelegate`);

ALTER TABLE `glpi_holidays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `is_perpetual` (`is_perpetual`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_imageformats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_imageresolutions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_video` (`is_video`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_impactcompounds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_impactcontexts`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_impactitems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  ADD KEY `source` (`itemtype`,`items_id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `impactcontexts_id` (`impactcontexts_id`);

ALTER TABLE `glpi_impactrelations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype_source`,`items_id_source`,`itemtype_impacted`,`items_id_impacted`),
  ADD KEY `impacted_asset` (`itemtype_impacted`,`items_id_impacted`);

ALTER TABLE `glpi_infocoms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  ADD KEY `buy_date` (`buy_date`),
  ADD KEY `alert` (`alert`),
  ADD KEY `budgets_id` (`budgets_id`),
  ADD KEY `suppliers_id` (`suppliers_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `businesscriticities_id` (`businesscriticities_id`);

ALTER TABLE `glpi_interfacetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_ipaddresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  ADD KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`);

ALTER TABLE `glpi_ipaddresses_ipnetworks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  ADD KEY `ipnetworks_id` (`ipnetworks_id`);

ALTER TABLE `glpi_ipnetworks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `network_definition` (`entities_id`,`address`,`netmask`),
  ADD KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  ADD KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  ADD KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `ipnetworks_id` (`ipnetworks_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_ipnetworks_vlans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`),
  ADD KEY `vlans_id` (`vlans_id`);

ALTER TABLE `glpi_items_clusters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`clusters_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_items_devicebatteries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicebatteries_id` (`devicebatteries_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicecameras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_id` (`items_id`),
  ADD KEY `devicecameras_id` (`devicecameras_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_items_devicecameras_imageformats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_devicecameras_id` (`items_devicecameras_id`),
  ADD KEY `imageformats_id` (`imageformats_id`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted` (`is_deleted`);

ALTER TABLE `glpi_items_devicecameras_imageresolutions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_devicecameras_id` (`items_devicecameras_id`),
  ADD KEY `imageresolutions_id` (`imageresolutions_id`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted` (`is_deleted`);

ALTER TABLE `glpi_items_devicecases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicecases_id` (`devicecases_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicecontrols`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicecontrols_id` (`devicecontrols_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicedrives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicedrives_id` (`devicedrives_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicefirmwares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicefirmwares_id` (`devicefirmwares_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicegenerics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicegenerics_id` (`devicegenerics_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicegraphiccards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  ADD KEY `specificity` (`memory`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_deviceharddrives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deviceharddrives_id` (`deviceharddrives_id`),
  ADD KEY `specificity` (`capacity`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicememories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicememories_id` (`devicememories_id`),
  ADD KEY `specificity` (`size`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicemotherboards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicemotherboards_id` (`devicemotherboards_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicenetworkcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  ADD KEY `specificity` (`mac`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicepcis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicepcis_id` (`devicepcis_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicepowersupplies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_deviceprocessors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deviceprocessors_id` (`deviceprocessors_id`),
  ADD KEY `specificity` (`frequency`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `nbcores` (`nbcores`),
  ADD KEY `nbthreads` (`nbthreads`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicesensors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicesensors_id` (`devicesensors_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_devicesimcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `devicesimcards_id` (`devicesimcards_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `lines_id` (`lines_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `groups_id` (`groups_id`);

ALTER TABLE `glpi_items_devicesoundcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `devicesoundcards_id` (`devicesoundcards_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `serial` (`serial`),
  ADD KEY `busID` (`busID`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`);

ALTER TABLE `glpi_items_disks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `device` (`device`),
  ADD KEY `mountpoint` (`mountpoint`),
  ADD KEY `totalsize` (`totalsize`),
  ADD KEY `freesize` (`freesize`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `filesystems_id` (`filesystems_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_items_enclosures`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item` (`itemtype`,`items_id`),
  ADD KEY `relation` (`enclosures_id`,`itemtype`,`items_id`);

ALTER TABLE `glpi_items_kanbans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_items_operatingsystems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`items_id`,`itemtype`,`operatingsystems_id`,`operatingsystemarchitectures_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `operatingsystems_id` (`operatingsystems_id`),
  ADD KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  ADD KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  ADD KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  ADD KEY `operatingsystemkernelversions_id` (`operatingsystemkernelversions_id`),
  ADD KEY `operatingsystemeditions_id` (`operatingsystemeditions_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_items_problems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_items_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_items_racks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item` (`itemtype`,`items_id`,`is_reserved`),
  ADD KEY `relation` (`racks_id`,`itemtype`,`items_id`);

ALTER TABLE `glpi_items_remotemanagements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_items_softwarelicenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `softwarelicenses_id` (`softwarelicenses_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`);

ALTER TABLE `glpi_items_softwareversions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`softwareversions_id`),
  ADD KEY `softwareversions_id` (`softwareversions_id`),
  ADD KEY `computers_info` (`entities_id`,`is_template_item`,`is_deleted_item`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `is_deleted_item` (`is_deleted_item`),
  ADD KEY `is_template_item` (`is_template_item`),
  ADD KEY `date_install` (`date_install`);

ALTER TABLE `glpi_items_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  ADD KEY `tickets_id` (`tickets_id`);

ALTER TABLE `glpi_itilcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  ADD KEY `itilcategories_id` (`itilcategories_id`),
  ADD KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  ADD KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  ADD KEY `changetemplates_id` (`changetemplates_id`),
  ADD KEY `problemtemplates_id` (`problemtemplates_id`),
  ADD KEY `is_incident` (`is_incident`),
  ADD KEY `is_request` (`is_request`),
  ADD KEY `is_problem` (`is_problem`),
  ADD KEY `is_change` (`is_change`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_itilfollowups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_editor` (`users_id_editor`),
  ADD KEY `is_private` (`is_private`),
  ADD KEY `requesttypes_id` (`requesttypes_id`),
  ADD KEY `sourceitems_id` (`sourceitems_id`),
  ADD KEY `sourceof_items_id` (`sourceof_items_id`);

ALTER TABLE `glpi_itilfollowuptemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `requesttypes_id` (`requesttypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_private` (`is_private`);

ALTER TABLE `glpi_itilsolutions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `solutiontypes_id` (`solutiontypes_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_editor` (`users_id_editor`),
  ADD KEY `users_id_approval` (`users_id_approval`),
  ADD KEY `status` (`status`),
  ADD KEY `itilfollowups_id` (`itilfollowups_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_itils_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`projects_id`),
  ADD KEY `projects_id` (`projects_id`);

ALTER TABLE `glpi_knowbaseitemcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_knowbaseitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `is_faq` (`is_faq`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`);
ALTER TABLE `glpi_knowbaseitems` ADD FULLTEXT KEY `fulltext` (`name`,`answer`);
ALTER TABLE `glpi_knowbaseitems` ADD FULLTEXT KEY `name` (`name`);
ALTER TABLE `glpi_knowbaseitems` ADD FULLTEXT KEY `answer` (`answer`);

ALTER TABLE `glpi_knowbaseitems_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `parent_comment_id` (`parent_comment_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_knowbaseitems_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`knowbaseitems_id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_knowbaseitems_knowbaseitemcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`);

ALTER TABLE `glpi_knowbaseitems_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_knowbaseitems_revisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`knowbaseitems_id`,`revision`,`language`),
  ADD KEY `revision` (`revision`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date` (`date`);

ALTER TABLE `glpi_knowbaseitems_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `knowbaseitems_id` (`knowbaseitems_id`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_knowbaseitemtranslations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`knowbaseitems_id`,`language`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);
ALTER TABLE `glpi_knowbaseitemtranslations` ADD FULLTEXT KEY `fulltext` (`name`,`answer`);
ALTER TABLE `glpi_knowbaseitemtranslations` ADD FULLTEXT KEY `name` (`name`);
ALTER TABLE `glpi_knowbaseitemtranslations` ADD FULLTEXT KEY `answer` (`answer`);

ALTER TABLE `glpi_lineoperators`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`mcc`,`mnc`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `lineoperators_id` (`lineoperators_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `linetypes_id` (`linetypes_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_linetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_links_itemtypes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  ADD KEY `links_id` (`links_id`);

ALTER TABLE `glpi_locations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_lockedfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`field`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_global` (`is_global`);

ALTER TABLE `glpi_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `itemtype_link` (`itemtype_link`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `id_search_option` (`id_search_option`);

ALTER TABLE `glpi_mailcollectors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_manuallinks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `items_id` (`items_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_manufacturers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_monitormodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_monitors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_global` (`is_global`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `monitormodels_id` (`monitormodels_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `monitortypes_id` (`monitortypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_monitortypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkaliases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `name` (`name`),
  ADD KEY `networknames_id` (`networknames_id`),
  ADD KEY `fqdns_id` (`fqdns_id`);

ALTER TABLE `glpi_networkequipmentmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_networkequipments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  ADD KEY `networks_id` (`networks_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `snmpcredentials_id` (`snmpcredentials_id`);

ALTER TABLE `glpi_networkequipmenttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkinterfaces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_networknames`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `FQDN` (`name`,`fqdns_id`),
  ADD KEY `fqdns_id` (`fqdns_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `ipnetworks_id` (`ipnetworks_id`);

ALTER TABLE `glpi_networkportaggregates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportaliases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `networkports_id_alias` (`networkports_id_alias`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportconnectionlogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `networkports_id_source` (`networkports_id_source`),
  ADD KEY `networkports_id_destination` (`networkports_id_destination`);

ALTER TABLE `glpi_networkportdialups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportethernets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `card` (`items_devicenetworkcards_id`),
  ADD KEY `type` (`type`),
  ADD KEY `speed` (`speed`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportfiberchannels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `card` (`items_devicenetworkcards_id`),
  ADD KEY `type` (`networkportfiberchanneltypes_id`),
  ADD KEY `wwn` (`wwn`),
  ADD KEY `speed` (`speed`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportfiberchanneltypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportlocals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportmetrics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`networkports_id`,`date`),
  ADD KEY `date` (`date`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_networkports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `mac` (`mac`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkports_networkports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  ADD KEY `networkports_id_2` (`networkports_id_2`);

ALTER TABLE `glpi_networkports_vlans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  ADD KEY `vlans_id` (`vlans_id`);

ALTER TABLE `glpi_networkporttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `value_decimal` (`value_decimal`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_importable` (`is_importable`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_networkportwifis`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `networkports_id` (`networkports_id`),
  ADD KEY `card` (`items_devicenetworkcards_id`),
  ADD KEY `essid` (`wifinetworks_id`),
  ADD KEY `version` (`version`),
  ADD KEY `mode` (`mode`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `networkportwifis_id` (`networkportwifis_id`);

ALTER TABLE `glpi_networks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_notepads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `users_id_lastupdater` (`users_id_lastupdater`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `itemtype` (`itemtype`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_notifications_notificationtemplates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`notifications_id`,`mode`,`notificationtemplates_id`),
  ADD KEY `notificationtemplates_id` (`notificationtemplates_id`),
  ADD KEY `mode` (`mode`);

ALTER TABLE `glpi_notificationtargets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items` (`type`,`items_id`),
  ADD KEY `notifications_id` (`notifications_id`);

ALTER TABLE `glpi_notificationtemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `itemtype` (`itemtype`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_notificationtemplatetranslations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notificationtemplates_id` (`notificationtemplates_id`);

ALTER TABLE `glpi_notimportedemails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `mailcollectors_id` (`mailcollectors_id`);

ALTER TABLE `glpi_objectlocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item` (`itemtype`,`items_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date` (`date`);

ALTER TABLE `glpi_olalevelactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `olalevels_id` (`olalevels_id`);

ALTER TABLE `glpi_olalevelcriterias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `olalevels_id` (`olalevels_id`),
  ADD KEY `condition` (`condition`);

ALTER TABLE `glpi_olalevels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `olas_id` (`olas_id`);

ALTER TABLE `glpi_olalevels_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`olalevels_id`),
  ADD KEY `olalevels_id` (`olalevels_id`);

ALTER TABLE `glpi_olas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `calendars_id` (`calendars_id`),
  ADD KEY `slms_id` (`slms_id`);

ALTER TABLE `glpi_operatingsystemarchitectures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_operatingsystemeditions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_operatingsystemkernels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_operatingsystemkernelversions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `operatingsystemkernels_id` (`operatingsystemkernels_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_operatingsystems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_operatingsystemservicepacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_operatingsystemversions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_passivedcequipmentmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_passivedcequipments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `passivedcequipmentmodels_id` (`passivedcequipmentmodels_id`),
  ADD KEY `passivedcequipmenttypes_id` (`passivedcequipmenttypes_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `group_id_tech` (`groups_id_tech`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_passivedcequipmenttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_pcivendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`vendorid`,`deviceid`),
  ADD KEY `deviceid` (`deviceid`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_pdumodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_rackable` (`is_rackable`),
  ADD KEY `product_number` (`product_number`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_pdus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `pdumodels_id` (`pdumodels_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `group_id_tech` (`groups_id_tech`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `pdutypes_id` (`pdutypes_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_pdus_plugs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugs_id` (`plugs_id`),
  ADD KEY `pdus_id` (`pdus_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_pdus_racks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `racks_id` (`racks_id`),
  ADD KEY `pdus_id` (`pdus_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_pdutypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_pendingreasons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `itilfollowuptemplates_id` (`itilfollowuptemplates_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `solutiontemplates_id` (`solutiontemplates_id`);

ALTER TABLE `glpi_pendingreasons_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`items_id`,`itemtype`),
  ADD KEY `pendingreasons_id` (`pendingreasons_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_peripheralmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_peripherals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_global` (`is_global`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `peripheralmodels_id` (`peripheralmodels_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `peripheraltypes_id` (`peripheraltypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_peripheraltypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_phonemodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_phonepowersupplies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_phones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_global` (`is_global`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `phonemodels_id` (`phonemodels_id`),
  ADD KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `phonetypes_id` (`phonetypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_phonetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_planningeventcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_planningexternalevents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `name` (`name`),
  ADD KEY `planningexternaleventtemplates_id` (`planningexternaleventtemplates_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date` (`date`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `state` (`state`),
  ADD KEY `planningeventcategories_id` (`planningeventcategories_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_planningexternaleventtemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `state` (`state`),
  ADD KEY `planningeventcategories_id` (`planningeventcategories_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_planningrecalls`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `before_time` (`before_time`),
  ADD KEY `when` (`when`);

ALTER TABLE `glpi_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`directory`),
  ADD KEY `name` (`name`),
  ADD KEY `state` (`state`);

ALTER TABLE `glpi_plugin_glpiinventory_agentmodules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `modulename` (`modulename`),
  ADD KEY `is_active` (`is_active`);

ALTER TABLE `glpi_plugin_glpiinventory_collects`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_files`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_files_contents`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_registries`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_registries_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `computers_id` (`computers_id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_wmis`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_collects_wmis_contents`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_configs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`type`);

ALTER TABLE `glpi_plugin_glpiinventory_credentialips`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_credentials`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_deployfiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shortsha512` (`shortsha512`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups_dynamicdatas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploygroups_id` (`plugin_glpiinventory_deploygroups_id`),
  ADD KEY `can_update_group` (`can_update_group`);

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups_staticdatas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploygroups_id` (`plugin_glpiinventory_deploygroups_id`),
  ADD KEY `items_id` (`items_id`);

ALTER TABLE `glpi_plugin_glpiinventory_deploymirrors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_entities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploypackages_id` (`plugin_glpiinventory_deploypackages_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploypackages_id` (`plugin_glpiinventory_deploypackages_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploypackages_id` (`plugin_glpiinventory_deploypackages_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_deploypackages_id` (`plugin_glpiinventory_deploypackages_id`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_plugin_glpiinventory_deployuserinteractiontemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_plugin_glpiinventory_inventorycomputerstats`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_ipranges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`);

ALTER TABLE `glpi_plugin_glpiinventory_ipranges_snmpcredentials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `unicity` (`plugin_glpiinventory_ipranges_id`,`snmpcredentials_id`);

ALTER TABLE `glpi_plugin_glpiinventory_statediscoveries`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugin_glpiinventory_taskjoblogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_taskjobstates_id` (`plugin_glpiinventory_taskjobstates_id`,`state`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_plugin_glpiinventory_taskjobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_tasks_id` (`plugin_glpiinventory_tasks_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `method` (`method`);

ALTER TABLE `glpi_plugin_glpiinventory_taskjobstates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_taskjobs_id` (`plugin_glpiinventory_taskjobs_id`),
  ADD KEY `agents_id` (`agents_id`),
  ADD KEY `uniqid` (`uniqid`,`state`);

ALTER TABLE `glpi_plugin_glpiinventory_tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `plugin_glpiinventory_timeslots_prep_id` (`plugin_glpiinventory_timeslots_prep_id`),
  ADD KEY `plugin_glpiinventory_timeslots_exec_id` (`plugin_glpiinventory_timeslots_exec_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `reprepare_if_successful` (`reprepare_if_successful`),
  ADD KEY `is_deploy_on_demand` (`is_deploy_on_demand`),
  ADD KEY `wakeup_agent_counter` (`wakeup_agent_counter`);

ALTER TABLE `glpi_plugin_glpiinventory_timeslotentries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plugin_glpiinventory_calendars_id` (`plugin_glpiinventory_timeslots_id`),
  ADD KEY `day` (`day`);

ALTER TABLE `glpi_plugin_glpiinventory_timeslots`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `glpi_plugs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_printerlogs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`printers_id`,`date`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_printermodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `product_number` (`product_number`);

ALTER TABLE `glpi_printers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_global` (`is_global`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `printermodels_id` (`printermodels_id`),
  ADD KEY `networks_id` (`networks_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `printertypes_id` (`printertypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `last_pages_counter` (`last_pages_counter`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `uuid` (`uuid`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `snmpcredentials_id` (`snmpcredentials_id`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`);

ALTER TABLE `glpi_printers_cartridgeinfos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `printers_id` (`printers_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_printertypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_problemcosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `problems_id` (`problems_id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `budgets_id` (`budgets_id`);

ALTER TABLE `glpi_problems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date` (`date`),
  ADD KEY `closedate` (`closedate`),
  ADD KEY `status` (`status`),
  ADD KEY `priority` (`priority`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `itilcategories_id` (`itilcategories_id`),
  ADD KEY `users_id_recipient` (`users_id_recipient`),
  ADD KEY `solvedate` (`solvedate`),
  ADD KEY `urgency` (`urgency`),
  ADD KEY `impact` (`impact`),
  ADD KEY `time_to_resolve` (`time_to_resolve`),
  ADD KEY `users_id_lastupdater` (`users_id_lastupdater`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_problems_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problems_id`,`type`,`suppliers_id`),
  ADD KEY `group` (`suppliers_id`,`type`);

ALTER TABLE `glpi_problems_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problems_id`,`tickets_id`),
  ADD KEY `tickets_id` (`tickets_id`);

ALTER TABLE `glpi_problems_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problems_id`,`type`,`users_id`,`alternative_email`),
  ADD KEY `user` (`users_id`,`type`);

ALTER TABLE `glpi_problemtasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `problems_id` (`problems_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_editor` (`users_id_editor`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `state` (`state`),
  ADD KEY `taskcategories_id` (`taskcategories_id`),
  ADD KEY `tasktemplates_id` (`tasktemplates_id`),
  ADD KEY `is_private` (`is_private`);

ALTER TABLE `glpi_problemtemplatehiddenfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problemtemplates_id`,`num`);

ALTER TABLE `glpi_problemtemplatemandatoryfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`problemtemplates_id`,`num`);

ALTER TABLE `glpi_problemtemplatepredefinedfields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `problemtemplates_id` (`problemtemplates_id`);

ALTER TABLE `glpi_problemtemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_profilerights`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`profiles_id`,`name`),
  ADD KEY `name` (`name`);

ALTER TABLE `glpi_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `interface` (`interface`),
  ADD KEY `is_default` (`is_default`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `tickettemplates_id` (`tickettemplates_id`),
  ADD KEY `changetemplates_id` (`changetemplates_id`),
  ADD KEY `problemtemplates_id` (`problemtemplates_id`);

ALTER TABLE `glpi_profiles_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reminders_id` (`reminders_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_profiles_rssfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rssfeeds_id` (`rssfeeds_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_profiles_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_dynamic` (`is_dynamic`);

ALTER TABLE `glpi_projectcosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `projects_id` (`projects_id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `budgets_id` (`budgets_id`);

ALTER TABLE `glpi_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `code` (`code`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `projects_id` (`projects_id`),
  ADD KEY `projectstates_id` (`projectstates_id`),
  ADD KEY `projecttypes_id` (`projecttypes_id`),
  ADD KEY `priority` (`priority`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `plan_start_date` (`plan_start_date`),
  ADD KEY `plan_end_date` (`plan_end_date`),
  ADD KEY `real_start_date` (`real_start_date`),
  ADD KEY `real_end_date` (`real_end_date`),
  ADD KEY `percent_done` (`percent_done`),
  ADD KEY `show_on_global_gantt` (`show_on_global_gantt`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `projecttemplates_id` (`projecttemplates_id`),
  ADD KEY `is_template` (`is_template`);

ALTER TABLE `glpi_projectstates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_finished` (`is_finished`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_projecttasklinks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `projecttasks_id_source` (`projecttasks_id_source`),
  ADD KEY `projecttasks_id_target` (`projecttasks_id_target`);

ALTER TABLE `glpi_projecttasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `projects_id` (`projects_id`),
  ADD KEY `projecttasks_id` (`projecttasks_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `plan_start_date` (`plan_start_date`),
  ADD KEY `plan_end_date` (`plan_end_date`),
  ADD KEY `real_start_date` (`real_start_date`),
  ADD KEY `real_end_date` (`real_end_date`),
  ADD KEY `percent_done` (`percent_done`),
  ADD KEY `projectstates_id` (`projectstates_id`),
  ADD KEY `projecttasktypes_id` (`projecttasktypes_id`),
  ADD KEY `projecttasktemplates_id` (`projecttasktemplates_id`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_milestone` (`is_milestone`);

ALTER TABLE `glpi_projecttasks_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`projecttasks_id`),
  ADD KEY `projects_id` (`projecttasks_id`);

ALTER TABLE `glpi_projecttaskteams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`projecttasks_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_projecttasktemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `projects_id` (`projects_id`),
  ADD KEY `projecttasks_id` (`projecttasks_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `plan_start_date` (`plan_start_date`),
  ADD KEY `plan_end_date` (`plan_end_date`),
  ADD KEY `real_start_date` (`real_start_date`),
  ADD KEY `real_end_date` (`real_end_date`),
  ADD KEY `percent_done` (`percent_done`),
  ADD KEY `projectstates_id` (`projectstates_id`),
  ADD KEY `projecttasktypes_id` (`projecttasktypes_id`),
  ADD KEY `is_milestone` (`is_milestone`);

ALTER TABLE `glpi_projecttasktypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_projectteams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`);

ALTER TABLE `glpi_projecttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_queuednotifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`itemtype`,`items_id`,`notificationtemplates_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `sent_try` (`sent_try`),
  ADD KEY `create_time` (`create_time`),
  ADD KEY `send_time` (`send_time`),
  ADD KEY `sent_time` (`sent_time`),
  ADD KEY `mode` (`mode`),
  ADD KEY `notificationtemplates_id` (`notificationtemplates_id`);

ALTER TABLE `glpi_rackmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `product_number` (`product_number`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_racks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `rackmodels_id` (`rackmodels_id`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `racktypes_id` (`racktypes_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `group_id_tech` (`groups_id_tech`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `dcrooms_id` (`dcrooms_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_racktypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `name` (`name`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_recurrentchanges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `changetemplates_id` (`changetemplates_id`),
  ADD KEY `next_creation_date` (`next_creation_date`),
  ADD KEY `calendars_id` (`calendars_id`);

ALTER TABLE `glpi_refusedequipments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `agents_id` (`agents_id`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `rules_id` (`rules_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_registeredids`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `device_type` (`device_type`);

ALTER TABLE `glpi_reminders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `name` (`name`),
  ADD KEY `date` (`date`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `is_planned` (`is_planned`),
  ADD KEY `state` (`state`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_reminders_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reminders_id` (`reminders_id`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_remindertranslations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`reminders_id`,`language`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `date_mod` (`date_mod`);

ALTER TABLE `glpi_requesttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_helpdesk_default` (`is_helpdesk_default`),
  ADD KEY `is_followup_default` (`is_followup_default`),
  ADD KEY `is_mail_default` (`is_mail_default`),
  ADD KEY `is_mailfollowup_default` (`is_mailfollowup_default`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_ticketheader` (`is_ticketheader`),
  ADD KEY `is_itilfollowup` (`is_itilfollowup`);

ALTER TABLE `glpi_reservationitems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `resagroup` (`reservationitems_id`,`group`);

ALTER TABLE `glpi_rssfeeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `have_error` (`have_error`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_rssfeeds_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rssfeeds_id` (`rssfeeds_id`),
  ADD KEY `users_id` (`users_id`);

ALTER TABLE `glpi_ruleactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rules_id` (`rules_id`),
  ADD KEY `field_value` (`field`(50),`value`(50));

ALTER TABLE `glpi_rulecriterias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rules_id` (`rules_id`),
  ADD KEY `condition` (`condition`);

ALTER TABLE `glpi_rulematchedlogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agents_id` (`agents_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `rules_id` (`rules_id`);

ALTER TABLE `glpi_rulerightparameters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `sub_type` (`sub_type`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `condition` (`condition`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `type` (`type`),
  ADD KEY `itemtype` (`itemtype`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `is_private` (`is_private`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `last_execution_time` (`last_execution_time`),
  ADD KEY `last_execution_date` (`last_execution_date`),
  ADD KEY `do_count` (`do_count`);

ALTER TABLE `glpi_savedsearches_alerts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`savedsearches_id`,`operator`,`value`),
  ADD KEY `name` (`name`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_savedsearches_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  ADD KEY `savedsearches_id` (`savedsearches_id`);

ALTER TABLE `glpi_slalevelactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slalevels_id` (`slalevels_id`);

ALTER TABLE `glpi_slalevelcriterias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slalevels_id` (`slalevels_id`),
  ADD KEY `condition` (`condition`);

ALTER TABLE `glpi_slalevels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `slas_id` (`slas_id`);

ALTER TABLE `glpi_slalevels_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`slalevels_id`),
  ADD KEY `slalevels_id` (`slalevels_id`);

ALTER TABLE `glpi_slas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `calendars_id` (`calendars_id`),
  ADD KEY `slms_id` (`slms_id`);

ALTER TABLE `glpi_slms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `calendars_id` (`calendars_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_snmpcredentials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `snmpversion` (`snmpversion`),
  ADD KEY `is_deleted` (`is_deleted`);

ALTER TABLE `glpi_socketmodels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_sockets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `socketmodels_id` (`socketmodels_id`),
  ADD KEY `location_name` (`locations_id`,`name`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `networkports_id` (`networkports_id`),
  ADD KEY `wiring_side` (`wiring_side`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_softwarecategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `softwarecategories_id` (`softwarecategories_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_softwarelicenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `expire` (`expire`),
  ADD KEY `softwareversions_id_buy` (`softwareversions_id_buy`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  ADD KEY `softwareversions_id_use` (`softwareversions_id_use`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `softwares_id_expire_number` (`softwares_id`,`expire`,`number`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `allow_overquota` (`allow_overquota`),
  ADD KEY `softwarelicenses_id` (`softwarelicenses_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_softwarelicensetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_softwares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `name` (`name`),
  ADD KEY `is_template` (`is_template`),
  ADD KEY `is_update` (`is_update`),
  ADD KEY `softwarecategories_id` (`softwarecategories_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `softwares_id` (`softwares_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_softwareversions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `arch` (`arch`),
  ADD KEY `softwares_id` (`softwares_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `operatingsystems_id` (`operatingsystems_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_solutiontemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `solutiontypes_id` (`solutiontypes_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_solutiontypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_ssovariables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_states`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`states_id`,`name`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_visible_computer` (`is_visible_computer`),
  ADD KEY `is_visible_monitor` (`is_visible_monitor`),
  ADD KEY `is_visible_networkequipment` (`is_visible_networkequipment`),
  ADD KEY `is_visible_peripheral` (`is_visible_peripheral`),
  ADD KEY `is_visible_phone` (`is_visible_phone`),
  ADD KEY `is_visible_printer` (`is_visible_printer`),
  ADD KEY `is_visible_softwareversion` (`is_visible_softwareversion`),
  ADD KEY `is_visible_softwarelicense` (`is_visible_softwarelicense`),
  ADD KEY `is_visible_line` (`is_visible_line`),
  ADD KEY `is_visible_certificate` (`is_visible_certificate`),
  ADD KEY `is_visible_rack` (`is_visible_rack`),
  ADD KEY `is_visible_passivedcequipment` (`is_visible_passivedcequipment`),
  ADD KEY `is_visible_enclosure` (`is_visible_enclosure`),
  ADD KEY `is_visible_pdu` (`is_visible_pdu`),
  ADD KEY `is_visible_cluster` (`is_visible_cluster`),
  ADD KEY `is_visible_contract` (`is_visible_contract`),
  ADD KEY `is_visible_appliance` (`is_visible_appliance`),
  ADD KEY `is_visible_databaseinstance` (`is_visible_databaseinstance`),
  ADD KEY `is_visible_cable` (`is_visible_cable`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `suppliertypes_id` (`suppliertypes_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_active` (`is_active`);

ALTER TABLE `glpi_suppliers_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`type`,`suppliers_id`),
  ADD KEY `group` (`suppliers_id`,`type`);

ALTER TABLE `glpi_suppliertypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_taskcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `taskcategories_id` (`taskcategories_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  ADD KEY `level` (`level`);

ALTER TABLE `glpi_tasktemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `taskcategories_id` (`taskcategories_id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `is_private` (`is_private`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`);

ALTER TABLE `glpi_ticketcosts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `tickets_id` (`tickets_id`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `budgets_id` (`budgets_id`);

ALTER TABLE `glpi_ticketrecurrents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `tickettemplates_id` (`tickettemplates_id`),
  ADD KEY `next_creation_date` (`next_creation_date`),
  ADD KEY `calendars_id` (`calendars_id`);

ALTER TABLE `glpi_tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date` (`date`),
  ADD KEY `closedate` (`closedate`),
  ADD KEY `status` (`status`),
  ADD KEY `priority` (`priority`),
  ADD KEY `request_type` (`requesttypes_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `users_id_recipient` (`users_id_recipient`),
  ADD KEY `solvedate` (`solvedate`),
  ADD KEY `takeintoaccountdate` (`takeintoaccountdate`),
  ADD KEY `urgency` (`urgency`),
  ADD KEY `impact` (`impact`),
  ADD KEY `global_validation` (`global_validation`),
  ADD KEY `slas_id_tto` (`slas_id_tto`),
  ADD KEY `slas_id_ttr` (`slas_id_ttr`),
  ADD KEY `time_to_resolve` (`time_to_resolve`),
  ADD KEY `time_to_own` (`time_to_own`),
  ADD KEY `olas_id_tto` (`olas_id_tto`),
  ADD KEY `olas_id_ttr` (`olas_id_ttr`),
  ADD KEY `slalevels_id_ttr` (`slalevels_id_ttr`),
  ADD KEY `internal_time_to_resolve` (`internal_time_to_resolve`),
  ADD KEY `internal_time_to_own` (`internal_time_to_own`),
  ADD KEY `users_id_lastupdater` (`users_id_lastupdater`),
  ADD KEY `type` (`type`),
  ADD KEY `itilcategories_id` (`itilcategories_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `name` (`name`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `ola_waiting_duration` (`ola_waiting_duration`),
  ADD KEY `olalevels_id_ttr` (`olalevels_id_ttr`);

ALTER TABLE `glpi_ticketsatisfactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tickets_id` (`tickets_id`);

ALTER TABLE `glpi_tickets_contracts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`contracts_id`),
  ADD KEY `contracts_id` (`contracts_id`);

ALTER TABLE `glpi_tickets_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id_1`,`tickets_id_2`),
  ADD KEY `tickets_id_2` (`tickets_id_2`);

ALTER TABLE `glpi_tickets_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickets_id`,`type`,`users_id`,`alternative_email`),
  ADD KEY `user` (`users_id`,`type`);

ALTER TABLE `glpi_tickettasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `date` (`date`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_editor` (`users_id_editor`),
  ADD KEY `tickets_id` (`tickets_id`),
  ADD KEY `is_private` (`is_private`),
  ADD KEY `taskcategories_id` (`taskcategories_id`),
  ADD KEY `state` (`state`),
  ADD KEY `users_id_tech` (`users_id_tech`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `begin` (`begin`),
  ADD KEY `end` (`end`),
  ADD KEY `tasktemplates_id` (`tasktemplates_id`),
  ADD KEY `sourceitems_id` (`sourceitems_id`),
  ADD KEY `sourceof_items_id` (`sourceof_items_id`);

ALTER TABLE `glpi_tickettemplatehiddenfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickettemplates_id`,`num`);

ALTER TABLE `glpi_tickettemplatemandatoryfields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`tickettemplates_id`,`num`);

ALTER TABLE `glpi_tickettemplatepredefinedfields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tickettemplates_id` (`tickettemplates_id`);

ALTER TABLE `glpi_tickettemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`);

ALTER TABLE `glpi_ticketvalidations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `users_id_validate` (`users_id_validate`),
  ADD KEY `tickets_id` (`tickets_id`),
  ADD KEY `submission_date` (`submission_date`),
  ADD KEY `validation_date` (`validation_date`),
  ADD KEY `status` (`status`);

ALTER TABLE `glpi_transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_unmanageds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `manufacturers_id` (`manufacturers_id`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `networks_id` (`networks_id`),
  ADD KEY `states_id` (`states_id`),
  ADD KEY `groups_id_tech` (`groups_id_tech`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `is_dynamic` (`is_dynamic`),
  ADD KEY `serial` (`serial`),
  ADD KEY `otherserial` (`otherserial`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  ADD KEY `agents_id` (`agents_id`),
  ADD KEY `snmpcredentials_id` (`snmpcredentials_id`),
  ADD KEY `users_id_tech` (`users_id_tech`);

ALTER TABLE `glpi_usbvendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`vendorid`,`deviceid`),
  ADD KEY `deviceid` (`deviceid`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_usercategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_useremails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`users_id`,`email`),
  ADD KEY `email` (`email`),
  ADD KEY `is_default` (`is_default`),
  ADD KEY `is_dynamic` (`is_dynamic`);

ALTER TABLE `glpi_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicityloginauth` (`name`,`authtype`,`auths_id`),
  ADD KEY `firstname` (`firstname`),
  ADD KEY `realname` (`realname`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `profiles_id` (`profiles_id`),
  ADD KEY `locations_id` (`locations_id`),
  ADD KEY `usertitles_id` (`usertitles_id`),
  ADD KEY `usercategories_id` (`usercategories_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `is_active` (`is_active`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `authitem` (`authtype`,`auths_id`),
  ADD KEY `is_deleted_ldap` (`is_deleted_ldap`),
  ADD KEY `date_creation` (`date_creation`),
  ADD KEY `begin_date` (`begin_date`),
  ADD KEY `end_date` (`end_date`),
  ADD KEY `sync_field` (`sync_field`),
  ADD KEY `groups_id` (`groups_id`),
  ADD KEY `users_id_supervisor` (`users_id_supervisor`),
  ADD KEY `auths_id` (`auths_id`),
  ADD KEY `default_requesttypes_id` (`default_requesttypes_id`);

ALTER TABLE `glpi_usertitles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_virtualmachinestates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_virtualmachinesystems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_virtualmachinetypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_vlans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `tag` (`tag`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_vobjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  ADD KEY `item` (`itemtype`,`items_id`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);

ALTER TABLE `glpi_wifinetworks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entities_id` (`entities_id`),
  ADD KEY `is_recursive` (`is_recursive`),
  ADD KEY `essid` (`essid`),
  ADD KEY `name` (`name`),
  ADD KEY `date_mod` (`date_mod`),
  ADD KEY `date_creation` (`date_creation`);


ALTER TABLE `glpi_agents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_agenttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_alerts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_apiclients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `glpi_applianceenvironments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_appliances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_appliances_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_appliances_items_relations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_appliancetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_authldapreplicates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_authldaps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_authmails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_autoupdatesystems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_blacklistedmailcontents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_blacklists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

ALTER TABLE `glpi_budgets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_budgettypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_businesscriticities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cablestrands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cabletypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_calendars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_calendarsegments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `glpi_calendars_holidays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cartridgeitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cartridgeitems_printermodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cartridgeitemtypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_cartridges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_certificates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_certificates_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_certificatetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changecosts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_problems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changes_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changetasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changetemplatehiddenfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changetemplatemandatoryfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_changetemplatepredefinedfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_changetemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_changevalidations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_clusters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_clustertypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computerantiviruses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computermodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computers_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computertypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_computervirtualmachines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_configs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;

ALTER TABLE `glpi_consumableitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_consumableitemtypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_consumables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contacts_suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contacttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contractcosts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contracts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contracts_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contracts_suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_contracttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_crontasklogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

ALTER TABLE `glpi_crontasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

ALTER TABLE `glpi_dashboards_dashboards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `glpi_dashboards_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_dashboards_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=547;

ALTER TABLE `glpi_dashboards_rights`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_databaseinstancecategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_databaseinstances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_databaseinstancetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_databases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_datacenters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `glpi_dcrooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicebatteries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicebatterymodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicebatterytypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecameramodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecameras`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecasemodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecasetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecontrolmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicecontrols`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicedrivemodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicedrives`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicefirmwaremodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicefirmwares`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicefirmwaretypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `glpi_devicegenericmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicegenerics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicegenerictypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicegraphiccardmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicegraphiccards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_deviceharddrivemodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_deviceharddrives`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicememories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicememorymodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicememorytypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `glpi_devicemotherboardmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicemotherboards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicenetworkcardmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicenetworkcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicepcimodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicepcis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicepowersupplies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicepowersupplymodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_deviceprocessormodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_deviceprocessors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesensormodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesensors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesensortypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesimcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesimcardtypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `glpi_devicesoundcardmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_devicesoundcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_displaypreferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=359;

ALTER TABLE `glpi_documentcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_documents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_documents_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_documenttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

ALTER TABLE `glpi_domainrecords`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_domainrecordtypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

ALTER TABLE `glpi_domainrelations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `glpi_domains`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_domains_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_domaintypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_dropdowntranslations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_enclosuremodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_enclosures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_entities_knowbaseitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_entities_reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_entities_rssfeeds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_events`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

ALTER TABLE `glpi_fieldblacklists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_fieldunicities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_filesystems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

ALTER TABLE `glpi_fqdns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_knowbaseitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_problems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_rssfeeds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_groups_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_holidays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_imageformats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_imageresolutions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_impactcompounds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_impactcontexts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_impactitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_impactrelations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_infocoms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_interfacetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `glpi_ipaddresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ipaddresses_ipnetworks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ipnetworks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ipnetworks_vlans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_clusters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicebatteries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicecameras`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicecameras_imageformats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicecameras_imageresolutions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicecases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicecontrols`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicedrives`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicefirmwares`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicegenerics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicegraphiccards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_deviceharddrives`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicememories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicemotherboards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicenetworkcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicepcis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicepowersupplies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_deviceprocessors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicesensors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicesimcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_devicesoundcards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_disks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_enclosures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_kanbans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_operatingsystems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_problems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_racks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_remotemanagements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_softwarelicenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_softwareversions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_items_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_itilcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `glpi_itilfollowups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_itilfollowuptemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_itilsolutions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_itils_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitemcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_knowbaseitemcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitems_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_knowbaseitemtranslations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_lineoperators`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_lines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_linetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_links`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_links_itemtypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_locations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `glpi_lockedfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=708;

ALTER TABLE `glpi_mailcollectors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_manuallinks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_manufacturers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_monitormodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_monitors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_monitortypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkaliases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkequipmentmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkequipments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkequipmenttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkinterfaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networknames`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportaggregates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportaliases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportconnectionlogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportdialups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportethernets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportfiberchannels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportfiberchanneltypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportlocals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkportmetrics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkports_networkports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkports_vlans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networkporttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=305;

ALTER TABLE `glpi_networkportwifis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_networks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_notepads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

ALTER TABLE `glpi_notifications_notificationtemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

ALTER TABLE `glpi_notificationtargets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

ALTER TABLE `glpi_notificationtemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

ALTER TABLE `glpi_notificationtemplatetranslations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

ALTER TABLE `glpi_notimportedemails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_objectlocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_olalevelactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_olalevelcriterias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_olalevels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_olalevels_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_olas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemarchitectures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemeditions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemkernels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemkernelversions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemservicepacks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_operatingsystemversions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_passivedcequipmentmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_passivedcequipments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_passivedcequipmenttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pcivendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pdumodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pdus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pdus_plugs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pdus_racks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pdutypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pendingreasons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_pendingreasons_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_peripheralmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_peripherals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_peripheraltypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_phonemodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_phonepowersupplies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_phones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_phonetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_planningeventcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_planningexternalevents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_planningexternaleventtemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_planningrecalls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `glpi_plugin_glpiinventory_agentmodules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `glpi_plugin_glpiinventory_collects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_files_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_registries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_registries_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_wmis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_collects_wmis_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_configs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

ALTER TABLE `glpi_plugin_glpiinventory_credentialips`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_credentials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deployfiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups_dynamicdatas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploygroups_staticdatas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploymirrors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_entities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deploypackages_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_deployuserinteractiontemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_inventorycomputerstats`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8761;

ALTER TABLE `glpi_plugin_glpiinventory_ipranges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_ipranges_snmpcredentials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_statediscoveries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_taskjoblogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_taskjobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_taskjobstates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_timeslotentries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugin_glpiinventory_timeslots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_plugs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_printerlogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_printermodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_printers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_printers_cartridgeinfos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_printertypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problemcosts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problems_suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problems_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problems_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problemtasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problemtemplatehiddenfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problemtemplatemandatoryfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_problemtemplatepredefinedfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_problemtemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_profilerights`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=889;

ALTER TABLE `glpi_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `glpi_profiles_reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_profiles_rssfeeds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_profiles_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `glpi_projectcosts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projectstates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `glpi_projecttasklinks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttasks_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttaskteams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttasktemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttasktypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projectteams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_projecttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_queuednotifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_rackmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_racks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_racktypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_recurrentchanges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_refusedequipments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_registeredids`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_reminders_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_remindertranslations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_requesttypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `glpi_reservationitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_reservations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_rssfeeds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_rssfeeds_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ruleactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

ALTER TABLE `glpi_rulecriterias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

ALTER TABLE `glpi_rulematchedlogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_rulerightparameters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `glpi_rules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

ALTER TABLE `glpi_savedsearches`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_savedsearches_alerts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_savedsearches_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slalevelactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slalevelcriterias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slalevels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slalevels_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_slms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_snmpcredentials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `glpi_socketmodels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_sockets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_softwarecategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_softwarelicenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_softwarelicensetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_softwares`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_softwareversions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_solutiontemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_solutiontypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ssovariables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `glpi_states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_suppliers_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_suppliertypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_taskcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tasktemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ticketcosts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ticketrecurrents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_ticketsatisfactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickets_contracts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickets_tickets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickets_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickettasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickettemplatehiddenfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickettemplatemandatoryfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_tickettemplatepredefinedfields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_tickettemplates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_ticketvalidations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_transfers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `glpi_unmanageds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_usbvendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_usercategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_useremails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `glpi_usertitles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_virtualmachinestates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_virtualmachinesystems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_virtualmachinetypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_vlans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_vobjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `glpi_wifinetworks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
